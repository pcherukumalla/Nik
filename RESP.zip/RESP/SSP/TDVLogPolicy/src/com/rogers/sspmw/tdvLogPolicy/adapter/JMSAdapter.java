package com.rogers.sspmw.tdvLogPolicy.adapter;

import java.util.Properties;

import javax.jms.JMSException;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import weblogic.logging.NonCatalogLogger;

import com.rogers.sspmw.tdvLogPolicy.MessageBean;
import com.rogers.sspmw.tdvLogPolicy.exception.TDVException;

public class JMSAdapter implements ILogAdapter {
	private static NonCatalogLogger log = new NonCatalogLogger("TDVLog");
	
	private String DEFAULT_JMS_FACTORY = "common.tdv.cf";
	private String DEFAULT_JMS_QUEUE = "common.tdv.request.internal.q";
	
	private Properties properties;
	private String jmsFactory;
	private String jmsQueue;
	private boolean isInitialized;

	private Context ctx;
	private QueueConnection qcon;
	private Queue queue;

	
	public String getJmsFactory() {
		return jmsFactory;
	}

	public void setJmsFactory(String jmsFactory) {
		this.jmsFactory = jmsFactory;
	}

	public String getJmsQueue() {
		return jmsQueue;
	}

	public void setJmsQueue(String jmsQueue) {
		this.jmsQueue = jmsQueue;
	}

	@Override
	public void log(MessageBean message) throws TDVException {
		QueueSession qsession = null;
		QueueSender qsender = null;
		try {
			if(!isInitialized) {
				init();
			}
			qsession = qcon.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);
			qsender = qsession.createSender(queue);

			TextMessage msg = qsession.createTextMessage();
			msg.setText(message.getTDVMessage());

			qsender.send(msg);

		} catch (JMSException e) {
			clear();
			throw new TDVException(e);
		} finally {
			if (qsender != null) {
				try {
					qsender.close();
				} catch (JMSException e) {
					log.debug("close qsender error.");
				}
			}

			if (qsession != null) {
				try {
					qsession.close();
				} catch (JMSException e) {
					log.debug("close qsession error.");
				}
			}
		}
	}

	private void clear() {
		try {
			qcon.close();
		} catch (JMSException e) {
			log.debug("close connection error.");
		}
		try {
			ctx.close();
		} catch (NamingException e) {
			log.debug("close context error.");
		}
		isInitialized = false;
	}

	@Override
	public void initAdapter(Properties properties) throws TDVException {
		this.properties = properties;
		init();
	}

	private void init() throws TDVException {
		this.jmsFactory = this.properties.getProperty("jms.jndi.connectionFactory", this.DEFAULT_JMS_FACTORY);
		this.jmsQueue = this.properties.getProperty("jms.jndi.queue", this.DEFAULT_JMS_QUEUE);
		
		try {
			ctx = new InitialContext();

			// createQueueConnection
			QueueConnectionFactory qconFactory = (QueueConnectionFactory) ctx.lookup(this.jmsFactory);
			qcon = qconFactory.createQueueConnection();

			// look up queue
			queue = (Queue) ctx.lookup(this.jmsQueue);
		} catch (NamingException e) {
			throw new TDVException("InitialContext Error.", e);
		} catch (JMSException e) {
			throw new TDVException("Init JMS Adapter Error.", e);
		}
		
		isInitialized = true;
	}
	
	
}
