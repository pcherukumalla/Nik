package com.rogers.msit.ngws.common.dao;

import java.io.*;
import java.util.*;
import java.sql.*;
import java.util.logging.*;

import com.rogers.msit.ngws.common.utils.*;
import com.rogers.msit.ngws.common.dao.base.*;



public class CommonDAOComponent extends DAOComponent {
	public List getErrorMessages() throws CommonDAOException {
		List ret = null;
		
		// params...

		// get data...
		Connection conn = null;
		try {
			conn = getConnection();
			ret = getDAOObjectList(conn, Constants.GET_ERROR_MESSAGES_SQL, null);
		} catch(Exception e) {
			Constants.LOGGER.log(Level.SEVERE,  this.getClass().getName() + ".getErrorMessages error: " + e.toString());
			throw new CommonDAOException(e);
		} finally {
			closeConnection(conn);
		}
		
		return ret;
	}
	
	
	
	public int insertMessage(int msgTypeId, String szKey, String message, int setId, String statsDate) throws CommonDAOException {
		int nRet = -1;
		
		// params...

		// get data...
		Connection conn = null;
		PreparedStatement st = null;
		PreparedStatement st1 = null;
		PreparedStatement st2 = null;
		try {
			conn = getConnection();
			conn.setAutoCommit(false);
			
			st = conn.prepareStatement(Constants.INSERT_MESSAGE_SQL);
			st.setInt(1, msgTypeId);
			st.setString(2, szKey);
			st.setBinaryStream(3, new ByteArrayInputStream(message.getBytes()), message.length());
			st.setInt(4, setId);
			
			nRet = st.executeUpdate();
			
			// *****************************************************************************************************************
			// update stats...
			st1 = conn.prepareStatement(Constants.UPDATE_NR_OF_MSG_STATS_SQL);
			st1.setString(1, statsDate);
			int nUpdateStatsRet = st1.executeUpdate();
			
			// if no row exists for this day of year then insert one and then update again...
			if(nUpdateStatsRet == 0) {
				st2 = conn.prepareStatement(Constants.INSERT_STATS_SQL);
				st2.setString(1, statsDate);
				st2.executeUpdate();
				
				st1.executeUpdate();
			}
			// *****************************************************************************************************************
			
			conn.commit();
			conn.setAutoCommit(true);
		} catch(Exception e) {
			Constants.LOGGER.log(Level.SEVERE,  this.getClass().getName() + ".insertMessage error: " + e.toString());
			throw new CommonDAOException(e);
		} finally {
			closeStatement(st);
			closeStatement(st1);
			closeStatement(st2);
			closeConnection(conn);
		}
		
		return nRet;
	}
	
	
	
	public int updateMessageAfterProcessing(long msgId, int statusIn, String errorCd, String errorDesc, int nMoveToHist, String statsDate) throws CommonDAOException {
		int nRet = -1;
		
		// params...

		// get data...
		Connection conn = null;
		PreparedStatement st = null;
		PreparedStatement st1 = null;
		PreparedStatement st2 = null;
		PreparedStatement st3 = null;
		PreparedStatement st4 = null;
		PreparedStatement st5 = null;
		ResultSet res = null;
		try {
			conn = getConnection();
			conn.setAutoCommit(false);
			
			// update message...
			st = conn.prepareStatement(Constants.UPDATE_MESSAGE_AFTER_PROCESSING_SQL);
			st.setInt(1, statusIn);
			st.setString(2, errorCd);
			st.setString(3, errorDesc);
			st.setLong(4, msgId);
			nRet = st.executeUpdate();
			
			if(nMoveToHist == 0) {
				// insert into history table...
				st2 = conn.prepareStatement(Constants.INSERT_MESSAGE_TO_HISTORY_SQL);
				st2.setLong(1, msgId);
				nRet = st2.executeUpdate();
				
				// delete message...
				st3 = conn.prepareStatement(Constants.DELETE_MESSAGE_SQL);
				st3.setLong(1, msgId);
				nRet = st3.executeUpdate();
			} else if(nMoveToHist > 0) {
				// get number of retries...
				st1 = conn.prepareStatement(Constants.GET_MESSAGE_NR_OF_RETRIES_SQL);
				st1.setLong(1, msgId);
				res = st1.executeQuery();
				
				int nNrOfRetries = -1;
				if(res.next()) {
					nNrOfRetries = res.getInt("NR_OF_RETRIES");
				}
				
				if(nNrOfRetries >= nMoveToHist) {
					// insert into history table...
					st2 = conn.prepareStatement(Constants.INSERT_MESSAGE_TO_HISTORY_SQL);
					st2.setLong(1, msgId);
					nRet = st2.executeUpdate();
					
					// delete message...
					st3 = conn.prepareStatement(Constants.DELETE_MESSAGE_SQL);
					st3.setLong(1, msgId);
					nRet = st3.executeUpdate();
				}
			}
			
			// *****************************************************************************************************************
			// store stats about this event...
			String strStatsSQL = Constants.UPDATE_NR_OF_MSG_OTHER_ERRORS_STATS_SQL;
			if(Constants.OK.equals(errorCd)) {
				strStatsSQL = Constants.UPDATE_NR_OF_MSG_OK_STATS_SQL;
			} else if(Constants.TIMEOUT_ERROR.equals(errorCd)) {
				strStatsSQL = Constants.UPDATE_NR_OF_MSG_ELMS_TIMEOUT_STATS_SQL;
			} else if(Constants.ELMS_DOWN_ERROR.equals(errorCd)) {
				strStatsSQL = Constants.UPDATE_NR_OF_MSG_ELMS_DOWN_STATS_SQL;
			}
			
			// update stats...
			st4 = conn.prepareStatement(strStatsSQL);
			st4.setString(1, statsDate);
			int nUpdateStatsRet = st4.executeUpdate();
			
			// if no row exists for this day of year then insert one and then update again...
			if(nUpdateStatsRet == 0) {
				st5 = conn.prepareStatement(Constants.INSERT_STATS_SQL);
				st5.setString(1, statsDate);
				st5.executeUpdate();
				
				st4.executeUpdate();
			}
			// *****************************************************************************************************************
			
			conn.commit();
			conn.setAutoCommit(true);
		} catch(Exception e) {
			try {
				conn.rollback();
			} catch(SQLException sqle) {
				Constants.LOGGER.log(Level.SEVERE,  this.getClass().getName() + ".updateMessageAfterProcessing rollback error: " + sqle.toString());
			}
			Constants.LOGGER.log(Level.SEVERE,  this.getClass().getName() + ".updateMessageAfterProcessing error: " + e.toString());
			throw new CommonDAOException(e);
		} finally {
			closeResultSet(res);
			closeStatement(st);
			closeStatement(st1);
			closeStatement(st2);
			closeStatement(st3);
			closeStatement(st4);
			closeStatement(st5);
			closeConnection(conn);
		}
		
		return nRet;
	}
}
