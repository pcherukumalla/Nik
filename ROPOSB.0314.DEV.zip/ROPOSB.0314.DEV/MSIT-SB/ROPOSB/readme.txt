1. Copy all the R713 FLDS files to the startup folder of each managed server in the ROP-OSB domain.


2. Create new WTC gateway for each managed server as below::
	- for each WTCServerX:
		- create Local Access Point:
			RDOMIMEIx
			RDOMIMEIx
			//ROP_OSB_MSx_IP:ROP_OSB_MSx_Port
		- create Remote Access Point:
			LDOMIMEI
			LDOMIMEI
			RDOMIMEIx
			//Tuxedo_IP:Tuxedo_Port

Where x can be 1 or 2 as we need this setting for each managed server.
You have to sync this with the settings done on the Tuxedo side as these should be in sync on both sides.
You have to provide them the IP and Pors used on your side (ROP_OSB_MSx_IP, ROP_OSB_MSx_Port) and they have to provide you the same thing from their side (Tuxedo_IP, Tuxedo_Port).

