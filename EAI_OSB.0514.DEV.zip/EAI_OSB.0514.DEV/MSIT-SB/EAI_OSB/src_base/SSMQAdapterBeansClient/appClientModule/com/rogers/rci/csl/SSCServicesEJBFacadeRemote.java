package com.rogers.rci.csl;

import java.rmi.RemoteException;
import javax.ejb.EJBObject;

public abstract interface SSCServicesEJBFacadeRemote extends EJBObject
{
  public abstract void sendSSCRequestForDocsis(String mscOutMsgBody, String mqconfiguration, boolean resetMqConn, boolean resetMqDetail, String correlationId, String mscMsgReceived, String returnCode, String applicationName, String appStructID, String company, String action)
    throws RemoteException, Exception;
  
  public abstract void resetSSCMQConnectionForDocsis() 
  	throws RemoteException,Exception;
}