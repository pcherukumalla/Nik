package com.rogers.msit.ngws.common.services;

import java.util.*;
import java.util.logging.*;

import javax.naming.*;
import javax.sql.*;

import com.rogers.msit.ngws.common.utils.*;
import com.rogers.msit.ngws.common.dao.*;
import com.rogers.msit.ngws.common.dao.base.*;



public class AsyncAdaptorService {
	private static long lastErrorMessagesRefreshTime = 0;
	private static String lastErrorMessagesRefreshTimeAsString = "";
	private static HashMap errorMessages = new HashMap();
	private static Object refreshErrorMessagesSyncObject = new Object();
	
	protected static CommonDAOComponent commonDAOComponent = null;
	
	static {
		try {
			// try first to get data source name from JVM system property (-Dngws.config.datasource=mydatasource)...
			String strDataSourceName = System.getProperty(Constants.DATA_SOURCE_CONFIG_NAME);
			// if no one found then use the default one...
			if(strDataSourceName == null) {
				Constants.LOGGER.log(Level.WARNING, "Unable to retrive the data source name from JVM startup config, will use the default one: " + Constants.DEFAULT_DATA_SOURCE_JNDI_NAME);
				strDataSourceName = Constants.DEFAULT_DATA_SOURCE_JNDI_NAME;
			}
			
			// obtain initial context...
			InitialContext ctx = new InitialContext();
			// get data source...
			DataSource dataSource = (DataSource)ctx.lookup(strDataSourceName);
			if(dataSource == null) {
				throw new AsyncAdaptorServiceException("No data source found with this name: " + strDataSourceName);
			}
			
			// create the DAO component and set the datasource...
			commonDAOComponent = new CommonDAOComponent();
			commonDAOComponent.setDataSource(dataSource);
		} catch(Exception e) {
			Constants.LOGGER.log(Level.SEVERE, "com.rogers.msit.ngws.common.services.AsyncAdaptorService - Unable to create data source: " + e.toString());
		}
	}
	
	
	
	public static void push(int msgTypeId, String szKey, String message, int setId) throws Exception {
		// refresh data from the database if expired...
		refreshErrorMessages();
		
		commonDAOComponent.insertMessage(msgTypeId, szKey, message, setId, lastErrorMessagesRefreshTimeAsString);
	}
	
	
		
	public static void push(int msgTypeId, String szKey, String message) throws Exception {
		push(msgTypeId, szKey, message, 0);
	}
		
	
	
	public static void acknowledge(long msgId, String errorCd, String errorDesc) throws Exception {
		// refresh data from the database if expired...
		refreshErrorMessages();
		
		// get the details for this error and use the default error if the sent one not found in the current configuration...
		DAOObject err = (DAOObject)errorMessages.get(errorCd);
		if(err == null) {
			err = (DAOObject)errorMessages.get(Constants.ERROR);
		}
		
		// update/move message...
		commonDAOComponent.updateMessageAfterProcessing(msgId, err.getInt("STATUS_IN"), errorCd, errorDesc, err.getInt("MOVE_TO_HIST_IN"), lastErrorMessagesRefreshTimeAsString);
	}
	
	
	
	public static void acknowledge(long msgId) throws Exception {
		acknowledge(msgId, Constants.OK, "");
	}
	
	
	
	private static void refreshErrorMessages() throws Exception {
		long currentTime = System.currentTimeMillis();
		
		// if more then Constants.ERROR_MESSAGES_REFRESH_PERIOD minutes have passed then refresh...
		if(currentTime - lastErrorMessagesRefreshTime > Constants.ERROR_MESSAGES_REFRESH_PERIOD) {
			synchronized(refreshErrorMessagesSyncObject) {
				// get message types from the database...
				List entries = commonDAOComponent.getErrorMessages();
				
				// cache data...
				errorMessages.clear();
				
				DAOObject o = null;
				for(int i = 0; i < entries.size(); i++) {
					o = (DAOObject)entries.get(i);
					
					errorMessages.put(o.getString("ERR_CD"), o);
				}				
		
				// store the current time...
				lastErrorMessagesRefreshTime = currentTime;
				lastErrorMessagesRefreshTimeAsString = Constants.STATS_DATE_FORMAT.format(new Date(lastErrorMessagesRefreshTime));
			}
		}
	}
}


