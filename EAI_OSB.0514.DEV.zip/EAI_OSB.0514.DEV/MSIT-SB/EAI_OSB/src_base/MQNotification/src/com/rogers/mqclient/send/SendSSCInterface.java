package com.rogers.mqclient.send;

public interface SendSSCInterface extends SendInterface
{
	public void setAdditionalHeaderDetails( String applicationName, String appStructID, String company, String action);
}
