/*
****************************************************************************************************
ezWebToolkit Library, http://www.ezwebtoolkit.com
****************************************************************************************************
Copyright [2006-2008] [Pro Net Systems Inc., http://www.pronetsystems.com]

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
***************************************************************************************************
*/
// http://adamv.com/dev/javascript/qslicense.txt



js.util.Querystring = function(qs) { // optionally pass a querystring to parse...
	this.params = {};
	
	if (qs == null) qs = document.location.search.substring(1, location.search.length);
	if (qs.length == 0) return;

    // Turn <plus> back to <space>...
    // See: http://www.w3.org/TR/REC-html40/interact/forms.html#h-17.13.4.1
	qs = qs.replace(/\+/g, ' ');
	var args = qs.split('&'); // parse out name/value pairs separated via &
	
    // split out each name=value pair...
	for (var i = 0; i < args.length; i++) {
		var pair = args[i].split('=');
		var name = decodeURIComponent(pair[0]);
		
		var value = (pair.length==2)
			? decodeURIComponent(pair[1])
			: name;
		
		this.params[name] = value;
    }

    this.objectType = "js.util.Querystring";
}

js.util.Querystring.prototype.get = function(key, default_) {
	var value = this.params[key];
	return (value != null) ? value : default_;
}

js.util.Querystring.prototype.contains = function(key) {
	var value = this.params[key];
	return (value != null);
}



// get a "singleton"...
js.util.Querystring = new js.util.Querystring();
