/*
------------------------------------------------------------------------------------------
Button
------------------------------------------------------------------------------------------
*/
com.rogers.rci.ngws.Button = function(n) {
	js.wtc.Button.call(this, n);
}
com.rogers.rci.ngws.Button.prototype = new js.wtc.Button();
com.rogers.rci.ngws.Button.prototype.constructor = com.rogers.rci.ngws.Button;



com.rogers.rci.ngws.Button.prototype.init = function() {
	js.wtc.Button.prototype.init.call(this);

	// set attributes...
	this.set("height", "22px");
	this.set("borderWidth", "1px");
	this.set("backgroundColor", "rgb(120,172,255)");
	this.set("color", "rgb(255, 255, 255)");
}
