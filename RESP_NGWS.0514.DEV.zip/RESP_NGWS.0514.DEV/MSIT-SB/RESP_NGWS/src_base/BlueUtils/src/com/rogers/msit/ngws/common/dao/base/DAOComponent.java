package com.rogers.msit.ngws.common.dao.base;

import java.util.*;
import java.sql.*;
import java.util.logging.*;

import javax.sql.*;

import com.rogers.msit.ngws.common.utils.*;



public class DAOComponent {
	private DataSource dataSource = null;
	private Properties queries = null;
	
	
	
	public DataSource getDataSource() {
		return dataSource;
	}



	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}



	public Properties getQueries() {
		return queries;
	}



	public void setQueries(Properties queries) {
		this.queries = queries;
	}



	protected String getQuery(String strName) {
		return this.queries.getProperty(strName);
	}
	

	
	protected Connection getConnection() throws SQLException {
		return this.dataSource.getConnection();
	}
	
	
	
	protected void closeResultSet(ResultSet result) {
	    try {
	      if (result != null) {
	        result.close();
	      }
	    } catch(Exception e) {
	    	Constants.LOGGER.log(Level.WARNING, this.getClass().getName() + ".closeResultSet error: " + e.toString());
	    }
	}



	protected void closeStatement(Statement stmt) {
	    try {
	      if (stmt != null) {
	        stmt.close();
	      }
	    } catch(Exception e) {
	    	Constants.LOGGER.log(Level.WARNING, this.getClass().getName() + ".closeStatement error: " + e.toString());
	    }
	}
	
	
	
	protected void closeConnection(Connection c) {
	    try {
	      if ((c != null) && !c.isClosed()) {
	        c.close();
	      }
	    } catch(Exception e) {
	    	Constants.LOGGER.log(Level.WARNING, this.getClass().getName() + ".closeConnection error: " + e.toString());
	    }
	}
	
	
	
	protected int getSQLType(Object obj) {
	    int nRet = -1;
	
	    if(obj instanceof java.lang.String) {
	    	nRet = Types.VARCHAR;
	    } else if(obj instanceof java.lang.Integer) {
	    	nRet = Types.INTEGER;
	    } else if(obj instanceof java.lang.Short) {
	    	nRet = Types.INTEGER;
	    } else if(obj instanceof java.lang.Long) {
	    	nRet = Types.BIGINT;
	    } else if(obj instanceof java.lang.Double) {
	    	nRet = Types.DOUBLE;
	    } else if(obj instanceof java.sql.Date) {
	    	nRet = Types.DATE;
	    } else if(obj instanceof java.sql.Time) {
	    	nRet = Types.TIME;
	    } else if(obj instanceof java.sql.Timestamp) {
	    	nRet = Types.TIMESTAMP;
	    }
	
	    return nRet;
	}
	
	
	
	protected PreparedStatement getPreparedStatement(Connection conn, String strSQL, Object[] params) throws SQLException {
		//System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>start sql\n" + strSQL);
		PreparedStatement stsql = conn.prepareStatement(strSQL);
		//System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>end sql");
		
	    if(params != null) {
	      for(int i = 0; i < params.length; i++) {
	    	//System.out.println("**************************");
	    	//System.out.println(i + "  -  " + params[i] + "  -  " + getSQLType(params[i]));
	    	//System.out.println("**************************");
	        stsql.setObject(i+1, params[i], getSQLType(params[i]));
	      }
	    }
	    
	    return stsql;
	}
	
	
	
	public int executeUpdate(Connection conn, String strSQL, Object[] params) throws DAOException {
	    int nRet = -1;

	    PreparedStatement stsql = null;
	    try {
	    	stsql = getPreparedStatement(conn, strSQL, params);
	
		    nRet = stsql.executeUpdate();
	    } catch(Exception e) {
	    	Constants.LOGGER.log(Level.SEVERE, this.getClass().getName() + ".executeUpdate error: " + e.toString());
	    	throw new DAOException(e);
	    }  finally {
	    	closeStatement(stsql);
	    }

	    return nRet;
	}
	
	
	
	protected DAOObject getDAOObject(ResultSet ress, ResultSetMetaData rsmd) throws DAOException {
	    DAOObject ret = null;
	    
	    try {
		    ret = new DAOObject();
	
		    String strAttrName = "";
		    for(int i = 1; i <= rsmd.getColumnCount(); i++) {
		    	strAttrName = rsmd.getColumnName(i).toUpperCase();
		    	
		    	ret.set(strAttrName, ress.getObject(strAttrName));
		    }
	    } catch(Exception e) {
	    	Constants.LOGGER.log(Level.SEVERE, this.getClass().getName() + ".getObjectDAO error: " + e.toString());
	    	throw new DAOException(e);
	    }

	    return ret;
	}
	
	
	
	public DAOObject getDAOObject(Connection conn, String strSQL, Object[] params) throws DAOException {
	    DAOObject ret = null;

	    ResultSet ress = null;
	    PreparedStatement stsql = null;
	    try {
	    	stsql = getPreparedStatement(conn, strSQL, params);
	    	ress = stsql.executeQuery();
	    	ResultSetMetaData rsmd = ress.getMetaData();

	    	if(ress.next()) {
	    		ret = getDAOObject(ress, rsmd);
	    	}
	    } catch(Exception e) {
	    	Constants.LOGGER.log(Level.SEVERE, this.getClass().getName() + ".getObjectDAO (#2) error: " + e.toString());
	    	throw new DAOException(e);
	    } finally {
	      closeResultSet(ress);
	      closeStatement(stsql);
	    }

	    return ret;
	}
	
	
	
	public List getDAOObjectList(Connection conn, String strSQL, Object[] params, int nMaxRows) throws DAOException {
	    ArrayList ret = new ArrayList();
	    int nCount = 0;

	    ResultSet ress = null;
	    PreparedStatement stsql = null;
	    try {
	    	stsql = getPreparedStatement(conn, strSQL, params);
	    	ress = stsql.executeQuery();
	    	ResultSetMetaData rsmd = ress.getMetaData();
	    	
	    	while(ress.next()) {
	    		ret.add(getDAOObject(ress, rsmd));
	        
	    		if(nMaxRows > 0) {
	    			nCount++;
	    			if(nCount == nMaxRows) {
	    				break;
	    			}
	    		}
	    	}
	    } catch(SQLException e) {
	    	Constants.LOGGER.log(Level.SEVERE, this.getClass().getName() + ".getObjectDAOList error: " + e.toString());
	    	throw new DAOException(e);
	    } finally {
	      closeResultSet(ress);
	      closeStatement(stsql);
	    }

	    return ret;
	}
	
	
	
	public List getDAOObjectList(Connection conn, String strSQL, Object[] params) throws DAOException {
		return getDAOObjectList(conn, strSQL, params, 0);
	}
}
