package com.rogers.mqclient.msc;

public class MscSessionFactory 
{
	   // singleton instance
    private static MscSessionFactory instance = null;
    private static int sessionCount;
    private static int lastSession;
    private static String sessionToken;


    private MscSessionFactory()  {}

    /**
     * Gets the singleton instance of the class
     */
    public static synchronized MscSessionFactory getInstance()
    {
        if(instance==null) {
            instance = new MscSessionFactory();
        }
        return instance;
    }

    public static synchronized void clear() {
        sessionToken=null;
        lastSession=-1;
    }

    /**
     * synchronizing this is likely redundant, but hey what's the harm, it's only called occationally
     */
    public synchronized void setTokenData(String token,int count)
    {
        sessionCount=count;
        sessionToken=token;
        lastSession=0;
    }

    public String getSessionToken() {
        return(sessionToken);
    }

    public String getTokenFromSession(String session) {
        return(session.substring(0,8));
    }

    /**
     * grabs the first free session from the list, and updates that session to reserved
     * if the instance has not been initialized by calling setTokenData, then it returns null.
     */
    public synchronized String reserveSession()
    		throws Exception
    {
        String session = null;
        if( sessionToken!=null ) 
        {
            if( lastSession!=(-1) ) 
            {
                if( lastSession == sessionCount - 1 )
                    lastSession = 1;
                else
                    lastSession++;
                
                session = createSession(sessionToken,lastSession);
            }
        }
        return(session);
    }

    /**
     * creates a session token(8)+sessionName(10)+sessionNumber(6)
     * sessionName = blanks
     * sessionNumber - padded to left with zeros
    */
    private String createSession(String token,int i) {
        String session = token;
        //session+="          ";
        session+=String.valueOf( MscMessageUtils.numToSsStr( i, 6 ));
        return(session);
    }

    private boolean LOGNStatus = false;
    public boolean getLOGNStatus()
    {
    	return LOGNStatus;
    }
    
    public synchronized void setLOGNStatus(boolean status)
    {
    	LOGNStatus = status;
    }
}
