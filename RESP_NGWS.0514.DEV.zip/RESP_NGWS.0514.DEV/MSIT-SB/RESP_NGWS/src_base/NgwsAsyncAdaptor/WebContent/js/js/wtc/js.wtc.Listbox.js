/*
****************************************************************************************************
 ezWebToolkit Library, http://ezwt.blogspot.com
****************************************************************************************************
Copyright [2006-2008] [Pro Net Systems Inc., http://www.pronetsystems.com]

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

	http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
***************************************************************************************************
*/



/*
------------------------------------------------------------------------------------------
Listbox
------------------------------------------------------------------------------------------
*/
document.write("<style type=\"text/css\">");
document.write(".ezListboxSelectedClass {");
document.write("	background-color: navy;");
document.write("	color: white;");
document.write("}");
document.write("</style>");



js.wtc.Listbox = function() {
	js.wtc.ContentPanel.call(this);

	this.options = new Array();
	this.theOPTION = -1;
	this.multipleIn = false;
	this.dropdownIn = false;
	this.closeOnMouseOut = false;

	// dropdown...
	this.textboxDD = null;
	this.imageDD = null;
	this.buttonDD = null;
	this.layoutDD = null;

	// options...
	this.optContainer = null;
	this.layout = null;
	
	this.listboxOptionSelectedClass = "ezListboxSelectedClass";
	this.listboxOptionUnselectedClass = "";
	
	this.objectType = "js.wtc.Listbox";
}
js.wtc.Listbox.prototype = new js.wtc.ContentPanel();
js.wtc.Listbox.prototype.constructor = js.wtc.Listbox;



js.wtc.Listbox.prototype.init = function() {
    js.wtc.ContentPanel.prototype.init.call(this);

    // pointer to the object itself...
    var SELF = this;

    // if dropdown then create the dropdown...
    if (this.dropdownIn) {
        this.textboxDD = new js.wtc.Textbox();
        this.textboxDD.init();
        this.textboxDD.set("position", "");
        this.textboxDD.addEventListener("onclick", function() { SELF.optContainer.hide() });
        var tbvp = this.textboxDD.viewport();
        this.textboxDD.addEventListener("onfocus", function() { tbvp.blur() });

        this.imageDD = new js.wtc.Image("images/ldn.gif");
        this.imageDD.init();
        this.imageDD.set("position", "");

        this.buttonDD = new js.wtc.Button();
        this.buttonDD.init();
        this.buttonDD.set("width", "20px");
        this.buttonDD.set("height", "23px");
        this.buttonDD.set("position", "");
        if(this.closeOnMouseOut) {
        	this.buttonDD.addEventListener("onclick", function() { SELF.optContainer.show() });
        } else {
        	this.buttonDD.addEventListener("onclick", function() { SELF.optContainer.show(); js.wtc.Manager.openedListbox = SELF; });
        }
        this.buttonDD.append(this.imageDD);

        this.layoutDD = new js.wtc.Table();
        this.layoutDD.init();
        this.layoutDD.set("cellPadding", "0");
        this.layoutDD.set("cellSpacing", "0");

        var tbody = this.layoutDD.appendTBody();
        var row = tbody.insertRow(-1);

        var cell = row.insertCell(-1);
        this.layoutDD.append(this.textboxDD, cell);
        cell = row.insertCell(-1);
        this.layoutDD.append(this.buttonDD, cell);

        // append it to the content panel...
        this.append(this.layoutDD);
    }

    // set the options container content panel attributes...
    this.optContainer = new js.wtc.ContentPanel();
    this.optContainer.init();
    this.optContainer.set("overflowX", "hidden");
    this.optContainer.set("overflowY", "auto");
    this.optContainer.set("backgroundColor", "#FFFFFF");
    this.optContainer.set("border", "1px solid #000000");
    this.optContainer.set("cursor", "arrow");
    if (this.dropdownIn) {
        this.optContainer.set("top", "23px");
        
        if(this.closeOnMouseOut) {
			//if(document.all) {
			if(com.ezwt.sys.Browser.isIE) {
				eval("doHideDropdownMenu" + this.index + " = function() {SELF.mouseLeave();}");
	        	eval("SELF.optContainer.viewport().attachEvent(\"onmouseout\", doHideDropdownMenu" + this.index + ")");
	        } else {
	        	this.optContainer.viewport().onmouseout = eval("function(e) {SELF.mouseLeave(e);}");
	        }
        }
    }

    // create the layout that will contain the options...
    this.layout = new js.wtc.Table();
    this.layout.init();
    this.layout.set("width", "100%");
    this.layout.set("cellPadding", "1");
    this.layout.set("cellSpacing", "1");
    this.layout.appendTBody();

    // append it to the options container content panel...
    this.optContainer.append(this.layout);

    // append it to the content panel...
    this.append(this.optContainer);
}



js.wtc.Listbox.prototype.mouseLeave = function(e) {
	var evt = null;
	if(document.all) {
		evt = window.event;
	} else {
		evt = e;
	}

	var pos = com.ezwt.utils.Position.get(this.optContainer.viewport());
	
	if(!js.wtc.Manager.isInRectangle(evt.clientX + js.wtc.Manager.scrollLeft(), evt.clientY + js.wtc.Manager.scrollTop(), pos.left, pos.top, pos.width, pos.height)) {
		this.optContainer.hide();
	}
}



js.wtc.Listbox.prototype.show = function() {
	js.wtc.ContentPanel.prototype.show.call(this);

	if(this.dropdownIn) {
		this.optContainer.hide();
	}
}



js.wtc.Listbox.prototype.addOption = function(text, value, o) {
	// create new row&cell...
	var row = this.layout.viewport().tBodies[0].insertRow(-1);
	var cell = row.insertCell(-1);

	// add the cell to the cells array...
	var idx = this.options.push(cell) - 1;

	// set cell attributes...
	cell.id = "div_ezListboxOption" + this.index + "_" + idx;
	//cell.style.cursor = "arrow";
	cell.setAttribute("value", value);
	cell.setAttribute("index", idx);
	cell.setAttribute("text", text);

	// set the content...
	if(o) {
		this.layout.append(o, cell);
	} else {
		cell.innerHTML = text.replace(/ /gi, "&nbsp;") + "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
	}
	
	// add event...
	var SELF = this;
	js.wtc.Manager.addEventListener(cell, "onclick", function(){SELF.selectOptionByIndex(idx)});
}



js.wtc.Listbox.prototype.removeOption = function(v) {
	var tbody = this.layout.viewport().tBodies[0];
	for(var i = 0; i < tbody.rows.length; i++) {
		if(tbody.rows.item(i).cells.item(0).getAttribute("value") == v) {
			if(!this.multipleIn && this.theOPTION == tbody.rows.item(i).cells.item(0).getAttribute("index")) {
				this.theOPTION = -1;

				if(this.dropdownIn) {
					this.textboxDD.set("value", "");
				}
			}
		
			this.options[tbody.rows.item(i).cells.item(0).getAttribute("index")] = null;
			tbody.deleteRow(tbody.rows.item(i).sectionRowIndex);
		}
	}
}



js.wtc.Listbox.prototype.selectOptionByIndex = function(idx) {
	var cell = null;
	if(this.multipleIn) {
		cell = document.getElementById("div_ezListboxOption" + this.index + "_" + idx);

		if(cell != null) {
			if(cell.className == this.listboxOptionUnselectedClass) {
				cell.className = this.listboxOptionSelectedClass;
			} else {
				cell.className = this.listboxOptionUnselectedClass;
			}
		}
	} else {
		cell = document.getElementById("div_ezListboxOption" + this.index + "_" + idx);
		if(cell != null) {
			cell.className = this.listboxOptionSelectedClass;
		}

		if((this.theOPTION != -1) && (this.theOPTION != idx)) {
			cell = document.getElementById("div_ezListboxOption" + this.index + "_" + this.theOPTION);
			cell.className = this.listboxOptionUnselectedClass;
		}
	
		this.theOPTION = idx;
	}

	if(this.dropdownIn) {
		this.optContainer.hide();

		if(this.options[idx] != null) {
			this.textboxDD.set("value", this.options[idx].getAttribute("text"));
		} else {
			this.textboxDD.set("value", "");
		}
	}
}



js.wtc.Listbox.prototype.selectOption = function(v) {
	var tbody = this.layout.viewport().tBodies[0];
	for(var i = 0; i < tbody.rows.length; i++) {
		if(tbody.rows.item(i).cells.item(0).getAttribute("value") == v) {
			this.selectOptionByIndex(tbody.rows.item(i).cells.item(0).getAttribute("index"));
		}
	}
}



js.wtc.Listbox.prototype.set = function(name, value) {
	if(name == "multiple") {
		this.multipleIn = value;
	} else if(name == "dropdown") {
		this.dropdownIn = value;

		// you can not have multiple selection and dropdown...
		if((value == true) && (this.multipleIn)) {
			this.multipleIn = false;
		}
	} else if(name == "left") {
		this.viewport().style.left = value;
	} else if(name == "top") {
		this.viewport().style.top = value;
	} else if(name == "selectedClassName") {
		this.listboxOptionSelectedClass = value;
		for(var i = 0; i < this.options.length; i++) {
			if((this.options[i] != null) && (this.options[i].className == this.listboxOptionSelectedClass)) {
				ret.push(this.options[i].className = this.listboxOptionSelectedClass);
			}
		}
	} else if(name == "unselectedClassName") {
		this.listboxOptionSelectedClass = value;
		for(var i = 0; i < this.options.length; i++) {
			if((this.options[i] != null) && (this.options[i].className == this.listboxOptionUnselectedClass)) {
				ret.push(this.options[i].className = this.listboxOptionUnselectedClass);
			}
		}
	} else if(name == "closeOnMouseOut") {
		this.closeOnMouseOut = value;
	} else {
		this.optContainer.set(name, value);

		if(this.dropdownIn && (name == "width")) {
			this.textboxDD.set("width", (parseInt(value) - 22) + "px");
		}
	}
}



js.wtc.Listbox.prototype.get = function(name) {
	if(name == "multiple") {
		return this.multipleIn;
	} else if(name == "dropdown") {
		return this.dropdownIn;
	} else if(name == "left") {
		return this.viewport().style.left;
	} else if(name == "top") {
		return this.viewport().style.top;
	} else if(name == "closeOnMouseOut") {
		return this.closeOnMouseOut;
	} else if(name == "value") {
		var ret = null;
		
		if(!this.multipleIn) {
			if(this.theOPTION != -1) {
				ret = this.options[this.theOPTION].getAttribute("value");
			}
		} else {
			ret = new Array();
			for(var i = 0; i < this.options.length; i++) {
				if((this.options[i] != null) && (this.options[i].className == this.listboxOptionSelectedClass)) {
					ret.push(this.options[i].getAttribute("value"));
				}
			}
		}
		
		return ret;
	} else {
		return this.optContainer.get(name);
	}
}
