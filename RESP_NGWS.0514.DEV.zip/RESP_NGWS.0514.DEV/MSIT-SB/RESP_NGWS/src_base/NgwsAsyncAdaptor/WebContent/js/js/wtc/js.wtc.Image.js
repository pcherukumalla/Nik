/*
****************************************************************************************************
 ezWebToolkit Library, http://ezwt.blogspot.com
****************************************************************************************************
Copyright [2006-2008] [Pro Net Systems Inc., http://www.pronetsystems.com]

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

	http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
***************************************************************************************************
*/



/*
------------------------------------------------------------------------------------------
Image
------------------------------------------------------------------------------------------
*/
js.wtc.Image = function(s) {
	js.wtc.ContentPanel.call(this);

	this.src = "";
	if(s) {
		this.src = s;
	}

	this.objectType = "js.wtc.Image";
}
js.wtc.Image.prototype = new js.wtc.ContentPanel();
js.wtc.Image.prototype.constructor = js.wtc.Image;



js.wtc.Image.prototype.init = function() {
	// create the main div...
	this.theViewport = document.createElement("IMG");
	this.theViewport.src = this.src;
	
	// instrument the new node...
	this.instrumentViewport();
}



js.wtc.Image.prototype.set = function(name, value) {
	if(name == "src") {
		this.src = value;
		this.viewport().src = this.src;
	} else {
		js.wtc.ContentPanel.prototype.set.call(this, name, value);
	}
}



js.wtc.Image.prototype.get = function(name) {
	if(name == "src") {
		return this.src;
	} else {
		return js.wtc.ContentPanel.prototype.get.call(this, name);
	}
}
