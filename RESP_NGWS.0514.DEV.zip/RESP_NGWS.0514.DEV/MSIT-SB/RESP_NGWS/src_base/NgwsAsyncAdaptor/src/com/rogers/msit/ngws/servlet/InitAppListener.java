package com.rogers.msit.ngws.servlet;

import java.io.*;
import java.util.*;
import java.util.logging.*;

import javax.servlet.*;

import com.rogers.msit.ngws.dao.base.*;
import com.rogers.msit.ngws.engine.*;
import com.rogers.msit.ngws.services.*;
import com.rogers.msit.ngws.utils.*;



public class InitAppListener implements ServletContextListener {
	public void	contextInitialized(ServletContextEvent ce) {
		try {
			// init the DAO utils...
			DAOUtils.initUtils(ce.getServletContext());
			Constants.LOGGER.info("AsyncAdaptor - DAOUtils initialized.");
			
			// init the service...
			AsyncAdaptorService.initService(ce.getServletContext());
			AsyncAdaptorService.getInstance().createAsyncAdaptorConfigDAO();
			AsyncAdaptorService.getInstance().createAsyncAdaptorDAO();
			Constants.LOGGER.info("AsyncAdaptor - System initialized.");
			
			// load NGWS related properties...
			String strFilename = ce.getServletContext().getRealPath("WEB-INF/" + Constants.PROP_FILENAME);
			if(strFilename == null) {
				strFilename = ce.getServletContext().getResource("/WEB-INF").getFile() + Constants.PROP_FILENAME;
			}
			Properties p = new Properties();
			p.load(new FileInputStream(strFilename));
			AsyncAdaptorService.getInstance().setProps(p);
			
			// start engine...
			AsyncAdaptorEngine.getInstance().start();
			Constants.LOGGER.info("AsyncAdaptor - Engine started.");
			
			// start control engine...
			AsyncAdaptorControlEngine.getInstance().start();
			Constants.LOGGER.info("AsyncAdaptor - Control Engine started.");
		} catch(Exception e) {
			e.printStackTrace();
			Constants.LOGGER.log(Level.SEVERE, this.getClass().getName() + "contextInitialized - error while initializing the app: " + e.toString());
		}
	}


	
	public void	contextDestroyed(ServletContextEvent ce) {
		// ...
	}
}
