package com.rogers.rci.wsl;

import java.rmi.RemoteException;
import javax.ejb.CreateException;
import javax.ejb.EJBHome;

public abstract interface GetSwitchForNewTNEJBFacadeRemoteHome extends EJBHome
{
  public abstract GetSwitchForNewTNEJBFacadeRemote create()
    throws CreateException, RemoteException, CreateException;
}