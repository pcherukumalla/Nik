/*
****************************************************************************************************
 ezWebToolkit Library, http://ezwt.blogspot.com
****************************************************************************************************
Copyright [2006-2008] [Pro Net Systems Inc., http://www.pronetsystems.com]

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

	http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
***************************************************************************************************
*/



/*
------------------------------------------------------------------------------------------
Window
------------------------------------------------------------------------------------------
*/
document.write("<style type=\"text/css\">");
document.write(".ezWindowControlFrameClass {");
document.write("	background-color: #FFFFFF;");
document.write("	border: 1px solid rgb(120,172,255);");
document.write("	padding: 1px;");
document.write("}");
document.write(".ezWindowControlShadowClass {");
document.write("	background-color: #CFCFCF;");
document.write("	width: 1px;");
document.write("	height: 1px;");
document.write("	overflow: hidden;");
document.write("}");
document.write(".ezWindowControlHeaderClass {");
document.write("	background-color: rgb(120,172,255);");
document.write("	height: 20px;");
document.write("	color: #FFFFFF;");
document.write("	font-family: Arial;");
document.write("	font-weight: bold;");
document.write("	font-size: 12px;");
document.write("}");
document.write("</style>");



js.wtc.Window = function() {
	js.wtc.ContentPanel.call(this);

	this.draggableIn = true;
	this.closeIn = true;
	this.resizeIn = true;
	this.minresIn = true;
	this.shadowIn = true;
	this.title = null;
	this.displayMode = "default";

	this.minWidth = "120px";
	this.minHeight = "33px";
	
	this.frameClass = "ezWindowControlFrameClass";
	this.headerClass = "ezWindowControlHeaderClass";
	this.shadowClass = "ezWindowControlShadowClass";

	this.closeImg = js.IMAGES_PATH + "delete.gif";
	this.minImg = js.IMAGES_PATH + "up.gif";
	this.resImg = js.IMAGES_PATH + "dn.gif";
	this.resizeImg = js.IMAGES_PATH + "resize.gif";

	this.header = null;
	this.headerTitleViewport = null;
	this.headerMinResImage = null;
	this.headerCloseImage = null;  
	this.content = null;
	this.resize = null;
	this.shadowBottom = null;
	this.shadowRight = null;
	this.contentOffsetY = "22px";
	this.restoreHeight = ""; // store the window's height when minimize...
	
	this.objectType = "js.wtc.Window";
}
js.wtc.Window.prototype = new js.wtc.ContentPanel();
js.wtc.Window.prototype.constructor = js.wtc.Window;



js.wtc.Window.prototype.init = function() {
	js.wtc.ContentPanel.prototype.init.call(this);

	// reference to itself...
	var SELF = this;

	// bring window in front on onmousedown event...
	this.addEventListener("onmousedown", function(){SELF.set("zIndex", "" + (js.wtc.Manager.getMaxZIndex() + 1))});

	// set frame class...
	this.viewport().className = this.frameClass;
	
	// set the header content panel attributes...
	this.header = new js.wtc.Table();
	this.header.init();
	this.header.set("cellPadding", "0");
	this.header.set("cellSpacing", "1");
	this.header.set("className", this.headerClass);
	this.header.set("position", "");
	this.header.set("width", "100%");
	this.header.generate(1, 2);

	var nColIndex = 0;

	// set up the title cell...
	this.header.cell(0, nColIndex).innerHTML = "&nbsp;";
	nColIndex++;
	this.headerTitleViewport = this.header.cell(0, nColIndex); // store a reference to this cell...
	this.headerTitleViewport.width = "100%";
	// make it draggable if neccessary...
	if(this.draggableIn) {
		this.headerTitleViewport.style.cursor = "move";
		this.headerTitleViewport.title = "move window";
		this.draggable(true, this.headerTitleViewport);
	}
	nColIndex++;

	// set up minmax cell...
	if(this.minresIn) {
		this.header.insertCol(-1);
		this.header.cell(0, nColIndex).style.cursor = "pointer";
		
		// create the min/res image...
		this.headerMinResImage = new js.wtc.Image(this.minImg);
		this.headerMinResImage.init();
		this.headerMinResImage.set("position", "");
		// append it to the current cell...
		this.header.append(this.headerMinResImage, this.header.cell(0, nColIndex));
		
		// add the event handler...
		js.wtc.Manager.addEventListener(this.header.cell(0, nColIndex), "onclick", function(){SELF.onMinRestore()});
		
		nColIndex++;
	}

	// set up close cell...
	if(this.closeIn) {
		this.header.insertCol(-1);
		this.header.cell(0, nColIndex).style.cursor = "pointer";
		
		// create the close image...
		this.headerCloseImage = new js.wtc.Image(this.closeImg);
		this.headerCloseImage.init();
		this.headerCloseImage.set("position", "");
		// append it to the current cell...
		this.header.append(this.headerCloseImage, this.header.cell(0, nColIndex));

		// add the event handler...		
		js.wtc.Manager.addEventListener(this.header.cell(0, nColIndex), "onclick", function(){SELF.onClose()});
		
		nColIndex++;
	}

	// add empty space in the end...
	this.header.insertCol(-1);
	this.header.cell(0, nColIndex).innerHTML = "&nbsp;";
	nColIndex++;
	
	// append to the main ContentPanel...
	this.append(this.header);


	// create the window content ContentPanel...
	this.content = new js.wtc.ContentPanel();
	this.content.init();
	this.content.set("left", "1px");
	this.content.set("top", this.contentOffsetY);

	// append to the main ContentPanel...
	this.append(this.content);
		
	// shadow...
	if(this.shadowIn) {
		// bottom shadow...
		this.shadowBottom = new js.wtc.ContentPanel();
		this.shadowBottom.init();
		this.shadowBottom.set("left", "1px");
		this.shadowBottom.viewport().className = this.shadowClass;
		
		// append to the main ContentPanel...
		this.append(this.shadowBottom);
		
		// right shadow...
		this.shadowRight = new js.wtc.ContentPanel();
		this.shadowRight.init();
		this.shadowRight.set("top", "1px");
		this.shadowRight.viewport().className = this.shadowClass;
		
		// append to the main ContentPanel...
		this.append(this.shadowRight);
	}

	// resize...
	if(this.resizeIn) {
		this.resize = new js.wtc.Image(this.resizeImg);
		this.resize.init();
		this.resize.set("cursor", "NW-resize");
		this.resize.set("title", "resize window");
		//this.resize.onDrag = this.whenResize;
		this.resize.onDrag = function(x, y) {
			if(parseInt(this.get("left")) < parseInt(this.parent.minWidth)) {
				this.set("left", parseInt(this.parent.minWidth) + "px");
			}
			if(parseInt(this.get("top")) < parseInt(this.parent.minHeight)) {
				this.set("top", parseInt(this.parent.minHeight) + "px");
			}
		
			this.parent.setWidth((parseInt(this.get("left")) + 10) + "px");
			this.parent.setHeight((parseInt(this.get("top")) + 10) + "px");
		};
		this.resize.draggable(true);

		// append to the main ContentPanel...
		this.append(this.resize);
	}
}



// this will be assigned to the "resize" icon (deprecated now)...
/*js.wtc.Window.prototype.whenResize = function() {
	// this is actually a pointer to the "resize" icon (the Image object)...
	var SELF = js.wtc.Manager.childByViewport(this);

	if(parseInt(Drag.obj.style.left) < parseInt(SELF.parent.minWidth)) {
		Drag.obj.style.left = parseInt(SELF.parent.minWidth) + "px";
	}
	if(parseInt(Drag.obj.style.top) < parseInt(SELF.parent.minHeight)) {
		Drag.obj.style.top = parseInt(SELF.parent.minHeight) + "px";
	}

	SELF.parent.setWidth((parseInt(Drag.obj.style.left) + 10) + "px");
	SELF.parent.setHeight((parseInt(Drag.obj.style.top) + 10) + "px");
}*/



js.wtc.Window.prototype.show = function() {
	js.wtc.ContentPanel.prototype.show.call(this);
	
	this.set("zIndex", "" + (parseInt(js.wtc.Manager.getMaxZIndex()) + 1));
}



js.wtc.Window.prototype.body = function() {
	return this.content;
}



js.wtc.Window.prototype.onClose = function() {
	js.wtc.ContentPanel.prototype.onClose.call(this);

	this.hide();
}



js.wtc.Window.prototype.onMinRestore = function() {
	if(this.displayMode == "default") {
		this.displayMode = "minimized";
		this.headerMinResImage.set("src", this.resImg);
		this.headerMinResImage.set("title", "restore window");

		this.content.hide();
		this.restoreHeight = this.get("height");

		if(document.all) {
			this.set("height", (parseInt(this.contentOffsetY) + 4) + "px");
		} else {
			this.set("height", (parseInt(this.contentOffsetY) - 1) + "px");
		}

		if(this.resizeIn) {
			this.resize.hide();
		}
	} else {
		this.displayMode = "default";
		this.headerMinResImage.set("src", this.minImg);
		this.headerMinResImage.set("title", "minimize window");

		this.set("height", this.restoreHeight);
		this.content.show();

		if(this.resizeIn) {
			this.resize.show();
		}
	}
}



js.wtc.Window.prototype.setHeaderTitle = function() {
	if(typeof this.title == "string") {
		this.headerTitleViewport.innerHTML = this.title;
	} else {
		this.header.append(this.title, this.headerTitleViewport);
	}
}



js.wtc.Window.prototype.setWidth = function(value) {
	js.wtc.ContentPanel.prototype.set.call(this, "width", value);
		
	this.content.set("width", this.get("width"));
	
	if(this.shadowIn) {
		this.shadowBottom.set("width", (parseInt(this.get("width")) + 3) + "px");
		this.shadowRight.set("left", (parseInt(this.get("width")) + 3) + "px");
	}
}



js.wtc.Window.prototype.setHeight = function(value) {
	js.wtc.ContentPanel.prototype.set.call(this, "height", value);

	this.content.set("height", (parseInt(this.get("height")) - parseInt(this.contentOffsetY) + 1) + "px");
	
	if(this.shadowIn) {
		this.shadowBottom.set("top", (parseInt(this.get("height")) + 3) + "px");
		this.shadowRight.set("height", (parseInt(this.get("height")) + 3) + "px");
	}
}



js.wtc.Window.prototype.set = function(name, value) {
	if(name == "width") {
		this.setWidth(value);

		if(this.resizeIn) {
			this.resize.set("left", (parseInt(this.get("width")) - 10) + "px");
		}
	} else if(name == "height") {
		this.setHeight(value);

		if(this.resizeIn) {
			this.resize.set("top", (parseInt(this.get("height")) - 10) + "px");
		}
	} else if(name == "frameClass") {
		js.wtc.ContentPanel.prototype.set.call(this, "className", value);
		this.frameClass = value;
	} else if(name == "shadowClass") {
		this.shadowBottom.set("className", value);
		this.shadowRight.set("className", value);
		this.shadowClass = value;
	} else if(name == "headerClass") {
		this.header.set("className", value);
		this.headerClass = value;
	} else if(name == "contentOffsetY") { // before init...
		this.contentOffsetY = value;
	} else if(name == "draggable") { // before init...
		this.draggableIn = value;
	} else if(name == "title") {
		this.title = value;
		this.setHeaderTitle();
	} else if(name == "close") { // before init...
		this.closeIn = value;
	} else if(name == "resize") { // before init...
		this.resizeIn = value;
	} else if(name == "shadow") { // before init...
		this.shadowIn = value;
	} else if(name == "minres") { // before init...
		this.minresIn = value;
	} else if(name == "closeIcon") { // before init...
		this.closeImg = value;
	} else if(name == "minIcon") { // before init...
		this.minImg = value;
	} else if(name == "resIcon") { // before init...
		this.resImg = value;
	} else if(name == "resizeIcon") { // before init...
		this.resizeImg = value;
	} else if(name == "minWidth") { // before init...
		this.minWidth = value;
		if(parseInt(this.minWidth) < 120) {
			this.minWidth = "120px";
		}
	} else if(name == "minHeight") { // before init...
		this.minHeight = value;
		if(parseInt(this.minHeight) < 33) {
			this.minHeight = "33px";
		}
	} else {
		js.wtc.ContentPanel.prototype.set.call(this, name, value);
	}
}



js.wtc.Window.prototype.get = function(name) {
	if(name == "contentOffsetY") {
		return this.contentOffsetY;
	} if(name == "draggable") {
		return this.draggableIn;
	} else if(name == "title") {
		return this.title;
	} else if(name == "close") {
		return this.closeIn;
	} else if(name == "resize") {
		return this.resizeIn;
	} else if(name == "shadow") {
		return this.shadowIn;
	} else if(name == "minres") {
		return this.minresIn;
	} else if(name == "closeIcon") {
		return this.closeImg;
	} else if(name == "minIcon") {
		return this.minImg;
	} else if(name == "resIcon") {
		return this.resImg;
	} else if(name == "resizeIcon") {
		return this.resizeImg;
	} else if(name == "minWidth") {
		return this.minWidth;
	} else if(name == "minHeight") {
		return this.minHeight;
	} else {
		return js.wtc.ContentPanel.prototype.get.call(this, name);
	}
}



js.wtc.Window.prototype.preLoad = function() {
	// show loading image...
	if(this.loadImage != null) {
		this.body().viewport().innerHTML = "<div align=\"center\"><img src=\"" + this.loadImage + "\" border=\"0\"></div>";
	}
}



js.wtc.Window.prototype.onLoad = function(txt, xml) {
	this.body().viewport().innerHTML = txt;
}
