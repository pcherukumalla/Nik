package com.rogers.msit.common.logging;

import java.util.*;
import java.text.*;
import java.util.logging.*;

import com.rogers.msit.common.dao.base.*;
import com.rogers.msit.common.utils.*;



public class Logger extends CommonBase {
	private static long refreshPeriod = Constants.LOGGER_REFRESH_PERIOD;
	private static long lastRefreshTime = 0;
	private static Properties props = new Properties();
	
	private static Object syncObject = new Object();
	
	
	
	private static void refreshData() throws Exception {
		long currentTime = Calendar.getInstance().getTimeInMillis();
		
		// if more then 10 minutes have passed then refresh...
		if(currentTime - lastRefreshTime > refreshPeriod) {
			synchronized(syncObject) {
				// get data from the database...
				List entries = commonDAOComponent.getLogConfigEntries();
				
				// cache data...
				props.clear();
				
				DAOObject o = null;
				for(int i = 0; i < entries.size(); i++) {
					o = (DAOObject)entries.get(i);
					
					props.setProperty(o.getString("PROCESS_TYPE"), o.getString("LOG_ENABLED"));
				}
		
				// store the current time...
				lastRefreshTime = currentTime;
			}
		}
	}
	
	
	
	// for internal use only...
	private static boolean isValid(String processType) {
		boolean bRet = false;
		
		if("Y".equals(props.getProperty("#DEFAULT")) && !"N".equals(props.getProperty(processType))) {
			bRet = true;
		} else if("N".equals(props.getProperty("#DEFAULT")) && "Y".equals(props.getProperty(processType))) {
			bRet = true;
		}
		
		return bRet;
	}
	
	
	
	// for public use - for example when using queues to store the initial log entry and needs decision if the log should be sent to the queue or not...
	public static boolean isLoggable(String processType) {
		boolean bRet = false;
		
		try {
			// refresh log config data from the database if expired...
			refreshData();
			
			bRet = isValid(processType);
		} catch(Exception e) {
			Constants.LOGGER.log(Level.SEVERE,  "com.rogers.msit.common.logging.Logger.log error: " + e.toString());
		}
		
		return bRet;
	}
	
	
	
	public static void log(String processInstance, String processType, String message) {
		try {
			// refresh log config data from the database if expired...
			refreshData();
			
			// if a valid log entry...
			if(isValid(processType)) {
				// insert the log entry...
				commonDAOComponent.insertLogEntry(Calendar.getInstance().getTimeInMillis(), processInstance, processType, message);
			}
		} catch(Exception e) {
			Constants.LOGGER.log(Level.SEVERE,  "com.rogers.msit.common.logging.Logger.log error: " + e.toString());
		}
	}
	
	
	
	public static void log(String processInstance, String processType, String message, long timeInMillis) {
		try {
			// refresh log config data from the database if expired...
			refreshData();
			
			// if a valid log entry...
			if(isValid(processType)) {
				// insert the log entry...
				commonDAOComponent.insertLogEntry(timeInMillis, processInstance, processType, message);
			}
		} catch(Exception e) {
			Constants.LOGGER.log(Level.SEVERE,  "com.rogers.msit.common.logging.Logger.log error: " + e.toString());
		}
	}
	
	
	
	public static void log(String processInstance, String processType, String message, String timeStamp, String pattern) {
		try {
			// refresh log config data from the database if expired...
			refreshData();
			
			// if a valid log entry...
			if(isValid(processType)) {
				SimpleDateFormat sdf = new SimpleDateFormat(pattern);
				Date dt = sdf.parse(timeStamp);
				
				// insert the log entry...
				commonDAOComponent.insertLogEntry(dt.getTime(), processInstance, processType, message);
			}
		} catch(Exception e) {
			Constants.LOGGER.log(Level.SEVERE,  "com.rogers.msit.common.logging.Logger.log error: " + e.toString());
		}
	}
}
