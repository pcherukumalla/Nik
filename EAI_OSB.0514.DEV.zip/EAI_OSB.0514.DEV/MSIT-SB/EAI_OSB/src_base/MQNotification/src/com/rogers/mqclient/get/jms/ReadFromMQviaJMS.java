package com.rogers.mqclient.get.jms;

import javax.jms.JMSException;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueReceiver;
import javax.jms.QueueSession;
import javax.jms.Session;

import com.ibm.mq.MQEnvironment;
import com.ibm.mq.jms.JMSC;
import com.ibm.mq.jms.MQQueueConnectionFactory;
import com.rogers.logger.utility.UtilityLogger;
import com.rogers.mqclient.env.MSCOutEnvDetail;

public class ReadFromMQviaJMS {
    public static void startReader( )
    {
      UtilityLogger.getLogger().info("Starting Remote Receiver...");

      QueueConnection connection =null;

      try
      {
        MQEnvironment.hostname =  MSCOutEnvDetail.HOST;
        MQEnvironment.channel = MSCOutEnvDetail.CHANNEL;
        MQEnvironment.port = new Integer(MSCOutEnvDetail.PORT).intValue();

        QueueConnectionFactory factory = new MQQueueConnectionFactory();
        ((MQQueueConnectionFactory)factory).setQueueManager( MSCOutEnvDetail.QMGR );

        ((MQQueueConnectionFactory)factory).setHostName( MSCOutEnvDetail.HOST );
        ((MQQueueConnectionFactory)factory).setPort( new Integer(MSCOutEnvDetail.PORT).intValue() );
        ((MQQueueConnectionFactory)factory).setChannel( MSCOutEnvDetail.CHANNEL );
        ((MQQueueConnectionFactory)factory).setTransportType( JMSC.MQJMS_TP_CLIENT_MQ_TCPIP );

        // display the settings:
        UtilityLogger.getLogger().info("---------- Factory Properties ---------------");
        UtilityLogger.getLogger().info("HOST_NAME = "+((MQQueueConnectionFactory)factory).getHostName());
        UtilityLogger.getLogger().info("PORT = "+((MQQueueConnectionFactory)factory).getPort());
        UtilityLogger.getLogger().info("CHANNEL = "+((MQQueueConnectionFactory)factory).getChannel());
        UtilityLogger.getLogger().info("QM = "+((MQQueueConnectionFactory)factory).getQueueManager());
        UtilityLogger.getLogger().info("Type= "+ ((MQQueueConnectionFactory)factory).getTransportType());
        UtilityLogger.getLogger().info("---------------------------------------------\n");

        connection = factory.createQueueConnection();

        QueueSession session = connection.createQueueSession( false, Session.AUTO_ACKNOWLEDGE );
        Queue queue = session.createQueue( MSCOutEnvDetail.QNAME );
        QueueReceiver receiver = session.createReceiver( queue );

        RemoteListener listener = new RemoteListener( connection, session );
        receiver.setMessageListener( listener );
        connection.start();

      }// end try
      catch( JMSException je )
      {
        UtilityLogger.getLogger().info("JMS Exception occurred in ReadFromMQRemote! The system will shut down!");
        je.printStackTrace();
        if( connection!=null )
        {
          try
          {
            connection.close();
          }
          catch( JMSException je2 )
          {}
        }
      }// end catch
    }
}