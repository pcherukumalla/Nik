package com.rogers.rci.wsl;

import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.logging.Logger;

public class WSLLogger
{
  private static WSLLogger logger = null;

  public static WSLLogger getLogger()
  {
    if (logger == null)
    {
      synchronized (WSLLogger.class)
      {
        if (logger == null) logger = new WSLLogger();
      }
    }
    return logger;
  }

  public void infoToLog(String message)
  {
    try {
    	weblogic.logging.LoggingHelper.getServerLogger().info(message);
    } catch (Exception ex) {
      System.out.println("L0:" + message);
    }
  }

  public void info(String message)
  {
    infoToLog(message);
  }

  public void logException(Throwable exc)
  {
    StringWriter buffer = new StringWriter();
    exc.printStackTrace(new PrintWriter(buffer));
    infoToLog(buffer.toString());
  }
}