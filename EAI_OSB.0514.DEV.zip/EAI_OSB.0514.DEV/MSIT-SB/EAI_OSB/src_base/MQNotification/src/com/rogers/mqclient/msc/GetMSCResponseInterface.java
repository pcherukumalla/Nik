package com.rogers.mqclient.msc;

import com.rogers.mqclient.send.SendInterface;

public interface GetMSCResponseInterface  extends SendInterface
{
    public String getMSCResponse (byte[] correlationId ) throws Exception;
}
