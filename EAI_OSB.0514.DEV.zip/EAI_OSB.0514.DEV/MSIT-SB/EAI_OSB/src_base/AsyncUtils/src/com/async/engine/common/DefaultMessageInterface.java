package com.async.engine.common;

import com.async.engine.common.dao.base.*;
import com.async.engine.common.services.*;

public class DefaultMessageInterface implements MessageInterface {
	public String getSzKey(String msg) throws Exception {
		return "";
	}



	public String getSzKey(Object obj) throws Exception {
		return null;
	}



	public String getOtherInfo(String msgType) throws Exception {
		DAOObject typ = (DAOObject)AsyncAdaptorService.getMessageType(msgType);

		if(typ != null) {
			return typ.getString("OTHER_INFO");
		} else {
			return "";
		}
	}
}