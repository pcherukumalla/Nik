package com.rogers.msit.common.dao;

import java.io.*;
import java.util.*;
import java.sql.*;
import java.util.logging.*;

import com.rogers.msit.common.utils.*;
import com.rogers.msit.common.dao.base.*;



public class CommonDAOComponent extends DAOComponent {
	public List getConfigEntries() throws CommonDAOException {
		List ret = null;
		
		// params...

		// get data...
		Connection conn = null;
		try {
			conn = getConnection();
			ret = getDAOObjectList(conn, Constants.GET_CONFIG_ENTRIES_SQL, null);
		} catch(Exception e) {
			Constants.LOGGER.log(Level.SEVERE,  this.getClass().getName() + ".getConfigEntries error: " + e.toString());
			throw new CommonDAOException(e);
		} finally {
			closeConnection(conn);
		}
		
		return ret;
	}
	
	
	
	public List getLogConfigEntries() throws CommonDAOException {
		List ret = null;
		
		// params...

		// get data...
		Connection conn = null;
		try {
			conn = getConnection();
			ret = getDAOObjectList(conn, Constants.GET_LOG_CONFIG_ENTRIES_SQL, null);
		} catch(Exception e) {
			Constants.LOGGER.log(Level.SEVERE,  this.getClass().getName() + ".getLogConfigEntries error: " + e.toString());
			throw new CommonDAOException(e);
		} finally {
			closeConnection(conn);
		}
		
		return ret;
	}
	
	
	
	public int insertLogEntry(long eventTime, String processInstance, String processType, String message) throws CommonDAOException {
		int nRet = -1;
		
		// params...

		// get data...
		Connection conn = null;
		PreparedStatement st = null;
		try {
			conn = getConnection();
			
			st = conn.prepareStatement(Constants.INSERT_LOG_ENTRY_SQL);
			st.setLong(1, eventTime);
			st.setString(2, processInstance);
			st.setString(3, processType);
			st.setBinaryStream(4, new ByteArrayInputStream(message.getBytes()), message.length());
			
			nRet = st.executeUpdate();
		} catch(Exception e) {
			Constants.LOGGER.log(Level.SEVERE,  this.getClass().getName() + ".insertLogEntry error: " + e.toString());
			throw new CommonDAOException(e);
		} finally {
			closeStatement(st);
			closeConnection(conn);
		}
		
		return nRet;
	}
}
