package com.rogers.msit.ngws.services;

import java.util.*;
import java.util.logging.*;

import javax.servlet.*;
import javax.jms.*;
import javax.naming.*;

import org.apache.commons.httpclient.*;
import org.apache.commons.httpclient.methods.*;
import org.apache.commons.lang.*;

import com.rogers.msit.ngws.dao.*;
import com.rogers.msit.ngws.dao.base.*;
import com.rogers.msit.ngws.utils.*;



public class AsyncAdaptorService {
	private static AsyncAdaptorService theInstance = null;
	private static Object refreshConfigValuesSyncObject = new Object();
	
	private static String NGWS_CONFIG_JNDI_NAME = "";
	private static String NGWS_JNDI_NAME = "";
	private static String THIS_SERVER_NAME = "";
	static {
		try {
			// get JNDI data source name...
			// -Dngws.config.datasource=java:comp/env/jdbc/NgwsConfigDataSource
			NGWS_CONFIG_JNDI_NAME = System.getProperty(Constants.NGWS_JNDI_NAME_CONFIG_PARAM);
			// -Dngws.db.datasource=java:comp/env/jdbc/NgwsDataSource
			NGWS_JNDI_NAME = System.getProperty(Constants.NGWS_DB_JNDI_NAME_CONFIG_PARAM);
			
			// get server name...
			// -DweblogicName=server_name_here
			THIS_SERVER_NAME = System.getProperty(Constants.THIS_SERVER_NAME_CONFIG_PARAM);
		} catch(Exception e) {
			Constants.LOGGER.log(Level.SEVERE, "Unable to get JNDI data source name or/and server name: " + e.toString());
		}
	}
	
	private ServletContext servletContext = null;
	private AsyncAdaptorConfigDAO asyncAdaptorConfigDAO = null;
	private AsyncAdaptorDAO asyncAdaptorDAO = null;
	private Properties props = new Properties();
	
	private long lastConfigValuesRefreshTime = 0;
	private String lastConfigValuesRefreshTimeAsString = ""; // used for  storing the stats in the stats table...
	private Properties configValues = new Properties();
	private HashMap errorMessages = new HashMap();
	
	private QueueConnectionFactory queueConnectionFactory = null;
	private javax.jms.Queue queue = null;
	

	
	private AsyncAdaptorService(ServletContext ctx) {
		try {
			this.servletContext = ctx;
		} catch(Exception e) {
			e.printStackTrace();
			Constants.LOGGER.log(Level.SEVERE, this.getClass().getName() + " ThunderRoadAdminService constructor - error while initializing the app: " + e.toString());
		}
	}
	
	
	
	public static void initService(ServletContext ctx) {
		if(theInstance == null) {
			theInstance = new AsyncAdaptorService(ctx);
		}
	}
	
	
	
	public static AsyncAdaptorService getInstance() {
		return theInstance;
	}
	
	
	
	public ServletContext getServletContext() {
		return servletContext;
	}



	public AsyncAdaptorDAO getAsyncAdaptorDAO() {
		return this.asyncAdaptorDAO;
	}



	public void createAsyncAdaptorDAO() {
		this.asyncAdaptorDAO = new AsyncAdaptorDAO();
		
		try {
			this.asyncAdaptorDAO.setDataSourceByJndiName(NGWS_JNDI_NAME);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}



	public AsyncAdaptorConfigDAO getAsyncAdaptorConfigDAO() {
		return asyncAdaptorConfigDAO;
	}



	public void createAsyncAdaptorConfigDAO() {
		this.asyncAdaptorConfigDAO = new AsyncAdaptorConfigDAO();
		
		try {
			this.asyncAdaptorConfigDAO.setDataSourceByJndiName(NGWS_CONFIG_JNDI_NAME);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}



	public Properties getProps() {
		return props;
	}



	public void setProps(Properties props) {
		this.props = props;
		this.props.setProperty("THIS_SERVER_NAME", THIS_SERVER_NAME);
	}
	
	
	
	public String getThisServerName() {
		return THIS_SERVER_NAME;
	}
	
	
	
	public long getLastConfigValuesRefreshTime() {
		return lastConfigValuesRefreshTime;
	}



	public String getLastConfigValuesRefreshTimeAsString() {
		return lastConfigValuesRefreshTimeAsString;
	}



	public void refreshConfigValues(boolean bForceIn) throws Exception {
		long currentTime = System.currentTimeMillis();
		if(bForceIn) {
			lastConfigValuesRefreshTime = currentTime - Constants.CONFIG_VALUES_REFRESH_PERIOD - 100;
		}
		
		// if more then Constants.CONFIG_VALUES_REFRESH_PERIOD minutes have passed then refresh...
		if(currentTime - this.lastConfigValuesRefreshTime > Constants.CONFIG_VALUES_REFRESH_PERIOD) {
			synchronized(refreshConfigValuesSyncObject) {
				// get config values from the database...
				List entries = this.asyncAdaptorConfigDAO.getConfigEntries();
				
				// cache data...
				this.configValues.clear();
				
				DAOObject o = null;
				for(int i = 0; i < entries.size(); i++) {
					o = (DAOObject)entries.get(i);
					
					if(o.get("CFG_VALUE") == null) {
						this.configValues.setProperty(o.getString("CFG_NAME"), "");
					} else {
						this.configValues.setProperty(o.getString("CFG_NAME"), o.getString("CFG_VALUE"));
					}
				}
				
				// get message types from the database...
				List errors = this.asyncAdaptorConfigDAO.getErrorMessages();
				
				// cache data...
				this.errorMessages.clear();
				
				for(int i = 0; i < errors.size(); i++) {
					o = (DAOObject)errors.get(i);
					
					this.errorMessages.put(o.getString("ERR_CD"), o);
				}
		
				// store the current time...
				this.lastConfigValuesRefreshTime = currentTime;
				this.lastConfigValuesRefreshTimeAsString = Constants.STATS_DATE_FORMAT.format(new Date(this.lastConfigValuesRefreshTime));
			}
		}
	}
	
	
	
	public String getValue(String configName) {
		String strRet = "";
		try {
			// refresh data from the database if expired...
			//this.refreshConfigValues();
		
			// return config value...
			strRet =  this.configValues.getProperty(configName);
			
			if(strRet == null) {
				strRet = "";
			}
		} catch(Exception e) {
			// ...
		}
		
		return strRet;
	}
	
	
	
	public String getValue(String configName, String strDefault) {
		String strRet = "";
		try {
			// refresh data from the database if expired...
			//this.refreshConfigValues();
		
			// return config value...
			strRet =  this.configValues.getProperty(configName);
			
			if(strRet == null) {
				strRet = strDefault;
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		return strRet;
	}
	
	
	
	public void acknowledge(long msgId, String errorCd, String errorDesc) {
		try {
			// refresh data from the database if expired...
			//this.refreshConfigValues();
			
			// get the details for this error and use the default error if the sent one not found in the current configuration...
			DAOObject err = (DAOObject)this.errorMessages.get(errorCd);
			if(err == null) {
				err = (DAOObject)this.errorMessages.get(Constants.ERROR);
			}
			
			// update/move message...
			this.asyncAdaptorDAO.updateMessageAfterProcessing(msgId, err.getInt("STATUS_IN"), errorCd, errorDesc, err.getInt("MOVE_TO_HIST_IN"), this.lastConfigValuesRefreshTimeAsString);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	
	
	private String enrichMessageWithIdAndType(long msgId, int msgTypeId, String msg) throws Exception {
		String strRet = "";
		String strNS = this.getValue("DISPATCH_TO_PROCESS_INPUT_MESSAGE_NS");
		
		if(msg.startsWith("<?xml version=\"1.0\" encoding=\"UTF-8\"?>")) {
			msg = msg.substring(38, msg.length());
		}
		
		int nIndex = msg.lastIndexOf("</" + strNS + ":ELMSRequest>");
		if(nIndex == -1) {
			throw new AsyncAdaptorServiceException(Constants.MESSAGE_FORMAT_ERROR);
		} else {
			strRet = msg.substring(0, nIndex) + 
						"<" + strNS + ":ELMSRetryMsgID>" + msgId + "</" + strNS + ":ELMSRetryMsgID>" +
						"<" + strNS + ":ELMSOpType>" + msgTypeId + "</" + strNS + ":ELMSOpType>" + 
						msg.substring(nIndex, msg.length());
		}
		
		return strRet;
	}
	
	
	
	public void pushMessageForProcessing(long msgId, int msgTypeId, String msg) throws Exception {
		String strRequest = this.getValue("DISPATCH_TO_PROCESS_INPUT_MESSAGE");
		
		// enrich the message with the message ID and type...
		String strMessage = this.enrichMessageWithIdAndType(msgId, msgTypeId, msg);
		
		// create web service request...
		strRequest = StringUtils.replace(strRequest, "[[ELMS_REQUEST]]", strMessage);
		
		// invoke web service...
				//long nStart = System.currentTimeMillis();
		String strResponse = this.invokeWebService(this.getValue("DISPATCH_TO_PROCESS_END_POINT"), strRequest);
				//System.out.println("invoke WS: " + (System.currentTimeMillis() - nStart));
		
		// throw exception if any error(s)...
		if(strResponse.indexOf("Status>1<") == -1) {
			throw new AsyncAdaptorServiceException("Error while invoking pushMessageForProcessing: " + strResponse);
		}
	}
	
	
	
	public String invokeWebService(String strEndPoint, String strRequest) throws Exception {
		String strRet = null;
		
		StringRequestEntity entity = new StringRequestEntity(strRequest, "text/xml", "UTF-8");
		
		// create the http client...
		HttpClient client = new HttpClient();
		
		// create the post method...
		PostMethod post = new PostMethod(strEndPoint);
		
		// configure the post method...
		post.addRequestHeader("Content-Length", "" + strRequest.length());
        post.setRequestEntity(entity);
        post.addRequestHeader("Content-type", "text/xml; charset=utf-8");
        post.addRequestHeader("User-Agent", "SQA_TestClient0");
		
        // execute method...
        			long nStart = System.currentTimeMillis();
		int nStatusCode = client.executeMethod(post);
					System.out.println("invoke WS: " + (System.currentTimeMillis() - nStart));
		// get response...
		strRet = post.getResponseBodyAsString();
		
		/*System.out.println("--------------------------------------------------------------------------");
		System.out.println("HttpStatus = " + nStatusCode);
		System.out.println(strRet);
		System.out.println("--------------------------------------------------------------------------");
		System.out.println();
		System.out.println();*/
		
		if(nStatusCode != HttpStatus.SC_OK) {
			throw new AsyncAdaptorServiceException("Error while invoking invokeWebService - " + nStatusCode +  ":\n\n" + strRet);
		}
		
		return strRet;
	}
	

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	private void initJMSConnection() throws Exception {
		this.refreshConfigValues(false);
					//System.out.println(">>>>>>> getting JMS connection... ");
		
		InitialContext ic = new InitialContext();
		
		this.queueConnectionFactory = (QueueConnectionFactory)ic.lookup(Constants.ELMS_TEMP_JMS_CONNECTION_FACTORY);
		this.queue = (javax.jms.Queue)ic.lookup(Constants.ELMS_TEMP_JMS_QUEUE);
	}
	
	
	
	public void sendMessage(DAOObject msg) {
		long nMessageId = msg.getLong("MSGID");
		
		try {
			if((this.queueConnectionFactory == null) || (this.queue == null)) {
				initJMSConnection();
			}
			
			QueueConnection connection = this.queueConnectionFactory.createQueueConnection();
	
			QueueSession session = null;
	        try {
	        	// enrich the message with the message ID and type...
	    		String strMessage = this.enrichMessageWithIdAndType(nMessageId, msg.getInt("MSGTYPE_ID"), msg.getString("MSG_DATA_STR"));
	        	
	            session = connection.createQueueSession(false, 0);
	            
	            BytesMessage message = session.createBytesMessage();
	            message.writeBytes(strMessage.getBytes());
	            
	            QueueSender sender = session.createSender(this.queue);
	            sender.send(message);
	            				//System.out.println("nMessageId: " + nMessageId);
	        } finally {
	        	if (session != null) {
	                session.close();
	        	}
	
	            if (connection != null) {
	            	connection.close();
	            }
	        }
		} catch(Exception e) {
			// update message with failure if necessary...
			try {
				if(Constants.MESSAGE_FORMAT_ERROR.equals(e.getMessage())) {
					this.acknowledge(nMessageId, Constants.MESSAGE_FORMAT_ERROR, e.toString());
				} else {
					this.acknowledge(nMessageId, Constants.PUSH_FOR_PROCESSING_ERROR, e.toString());
				}
			} catch(Exception e2) {
				// ...
			}
		}
	}
}
