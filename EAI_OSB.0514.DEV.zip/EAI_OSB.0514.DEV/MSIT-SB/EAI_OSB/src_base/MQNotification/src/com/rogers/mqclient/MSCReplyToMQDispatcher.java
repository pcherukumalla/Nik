package com.rogers.mqclient;

import com.rogers.logger.utility.UtilityLogger;
import com.rogers.mqclient.send.SendInterface;
import com.rogers.mqclient.send.SendNativeMSCReplyToMQ;
import com.rogers.mqclient.send.SendViaJMSMSCReplyToMQ;


public class MSCReplyToMQDispatcher implements SendInterface
{
    private static boolean jmsBased =  false; //use by default ibm/native solution
    private static SendInterface sendInterface = new SendNativeMSCReplyToMQ();

	/**
	 * By default solution is native; use this to route to either JMS or Native solution
	 * @param jmsBased
	 */
    public void setSolution( boolean jmsBased )
	{
		synchronized (this)
		{
			MSCReplyToMQDispatcher.jmsBased = jmsBased;
			if ( MSCReplyToMQDispatcher.jmsBased )
				sendInterface = new SendViaJMSMSCReplyToMQ();
			else
				sendInterface = new SendNativeMSCReplyToMQ();
		}
	}

    public static boolean getSolutionTypeIndicator()
    {
    	return MSCReplyToMQDispatcher.jmsBased;
    }

    /*
     * Usage sample: setPrerequisites( "<mq_details_string>", false, true
     * On flows that work with messages first boolean flag can be false.
     * On flows that work with messages second boolean flag can be false even on first call since code will determine that it is a first call
     */
    public void setPrerequisites(String mqconfiguration, boolean resetMqConn, boolean resetMqDetail, String correlationId, String mscMsgReceived, String returnCode)
    	throws Exception
    {
    	sendInterface.setPrerequisites( mqconfiguration, resetMqConn, resetMqDetail, correlationId, mscMsgReceived, returnCode);
    }

    /**
     * @param txtMessage (message including MSC header)
     * @throws Exception
     */
	public void putMessage( String txtMessage )
        throws Exception
	{
	  long startTime = System.currentTimeMillis();

	  sendInterface.putMessage( txtMessage );

	  UtilityLogger.getLogger().info("Duration (msec):" + (System.currentTimeMillis() - startTime));
    }

    public void resetConnection()
    {
    	sendInterface.resetConnection();
    }
}