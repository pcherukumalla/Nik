package com.rogers.msit.ngws.dao;



public class AsyncAdaptorDAOException extends Exception {
	final private static long serialVersionUID = -197010084L;
	
	
	
	public AsyncAdaptorDAOException() {
		super();
	}
	
	
	
	public AsyncAdaptorDAOException(String message) {
		super(message);
	}
	
	
	
	public AsyncAdaptorDAOException(String message, Throwable cause) {
		super(message, cause);
	}
	
	
	
	public AsyncAdaptorDAOException(Throwable cause) {
		super(cause);
	}
}