/*
------------------------------------------------------------------------------------------
DetailsWindow
------------------------------------------------------------------------------------------
*/
com.rogers.rci.ngws.DetailsWindow = function(p) {
	js.wtc.Window.call(this);
	
	this.app = p;
	this.data = null;
}
com.rogers.rci.ngws.DetailsWindow.prototype = new js.wtc.Window();
com.rogers.rci.ngws.DetailsWindow.prototype.constructor = com.rogers.rci.ngws.DetailsWindow;



com.rogers.rci.ngws.DetailsWindow.prototype.init = function() {
	this.set("minres", false);
	this.set("resize", false);
	js.wtc.Window.prototype.init.call(this);

	// set attributes...
	this.set("left", "240px");
	this.set("top", "140px");
	this.set("width", "550px");
	this.set("height", "374px");
	this.set("title", "Record Details");
	this.set("backgroundColor", "#EFEFEF");
	
	var SELF = this;
	
	// init the table layout...
	this.initLayoutTable();
	
	// init the close button...
	this.closeButton = new com.rogers.rci.ngws.Button("Close");
	this.closeButton.init();
	this.closeButton.set("left", "485px");
	this.closeButton.set("top", (parseInt(this.get("height")) - 48) + "px");
	this.closeButton.set("width", "60px");
	this.closeButton.viewport().onclick = function() {
		SELF.hide();
	}
	// append it...
	this.body().append(this.closeButton);
}



com.rogers.rci.ngws.DetailsWindow.prototype.initLayoutTable = function() {
	this.bdyContentPanel = new js.wtc.ContentPanel();
	this.bdyContentPanel.init();
	this.bdyContentPanel.set("left", "0px");
	this.bdyContentPanel.set("top", "0px");
	this.bdyContentPanel.set("width", (parseInt(this.get("width")) - 2) + "px");
	this.bdyContentPanel.set("height", (parseInt(this.get("height")) - 55) + "px");
	this.bdyContentPanel.set("overflow", "hidden");
	this.bdyContentPanel.set("border", "1px solid rgb(120,172,255)");
	this.bdyContentPanel.set("backgroundColor", "#FFFFFF");
	// append it...
	this.body().append(this.bdyContentPanel);
	
	
	// create...
	var nNrOfRows = 3;
	this.layoutTable = new js.wtc.Table();
	this.layoutTable.init();
	this.layoutTable.set("left", "0px");
	this.layoutTable.set("top", "0px");
	this.layoutTable.set("cellPadding", "1");
	this.layoutTable.set("cellSpacing", "1");
	this.layoutTable.generate(nNrOfRows, 3);
	// append it...
	this.bdyContentPanel.append(this.layoutTable);
	
	var cell = null;
	for(var i = 0; i < nNrOfRows; i++) {
		cell = this.layoutTable.cell(i, 0);

		cell.style.width = "80px";		
		cell.style.backgroundColor = "#EFEFEF";
	
		if(i == 0) {
			cell.innerHTML = "&nbsp;ERROR:";
		} else if(i == 1) {
			cell.innerHTML = "&nbsp;ERR_DESC:";
		} else if(i == 2) {
			cell.innerHTML = "&nbsp;MESSAGE:";
		} 
				
		cell = this.layoutTable.cell(i, 1);
		cell.style.backgroundColor = "#EFEFEF";
				
		if(i == 0) {
			this.errorTextbox = new com.rogers.rci.ngws.Textbox();
			this.errorTextbox.init();
			this.errorTextbox.set("value", "");
			this.errorTextbox.set("width", "466px");
			this.errorTextbox.set("position", "");
			this.errorTextbox.set("color", "#AFAFAF");
			
			this.layoutTable.append(this.errorTextbox, cell);
		} else if(i == 1) {
			this.errorDescTextbox = new com.rogers.rci.ngws.Textarea();
			this.errorDescTextbox.init();
			this.errorDescTextbox.set("value", "");
			this.errorDescTextbox.set("width", "462px");
			this.errorDescTextbox.set("height", "96px");
			this.errorDescTextbox.set("position", "");
			this.errorDescTextbox.set("color", "#AFAFAF");
			
			this.layoutTable.append(this.errorDescTextbox, cell);
		} else if(i == 2) {
			this.messageTextbox = new com.rogers.rci.ngws.Textarea();
			this.messageTextbox.init();
			this.messageTextbox.set("value", "");
			this.messageTextbox.set("width", "462px");
			this.messageTextbox.set("height", "180px");
			this.messageTextbox.set("position", "");
			this.messageTextbox.set("color", "#AFAFAF");
			
			this.layoutTable.append(this.messageTextbox, cell);
		}
	}
}



com.rogers.rci.ngws.DetailsWindow.prototype.loadData = function(d) {
		// reset scrolling...
		this.bdyContentPanel.viewport().scrollTop = 0;
	
		// update fields values...
		if(d.ERR_CD != null) {
			this.errorTextbox.set("value", d.ERR_CD + " - " + this.app.getError(d.ERR_CD).ERR_NAME);
			this.errorTextbox.set("color", "red");
		} else {
			this.errorTextbox.set("value", "");
			this.errorTextbox.set("color", "");
		}
		if(d.ERR_DESC != null) {
			this.errorDescTextbox.set("value", d.ERR_DESC);
			this.errorDescTextbox.set("color", "red");
		} else {
			this.errorDescTextbox.set("value", "");
			this.errorDescTextbox.set("color", "");
		}
		this.messageTextbox.set("value", d.MSG_DATA_STR);
		
		// update window title...
		this.set("title", "Record Details - ECID: " + d.MSGID + "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; MSGID: " + d.SZKEY);
}



com.rogers.rci.ngws.DetailsWindow.prototype.resetData = function() {
		// reset scrolling...
		this.bdyContentPanel.viewport().scrollTop = 0;
	
		// update fields values...
		this.errorTextbox.set("value", "");
		this.errorDescTextbox.set("value", "");
		this.messageTextbox.set("value", "");
		
		
		// update window title...
		this.set("title", "Record Details");
}



com.rogers.rci.ngws.DetailsWindow.prototype.getMessage = function(d) {
	// fix Firefox...
    if (js.util.Browser.isFirefox) {
        try {
            netscape.security.PrivilegeManager.enablePrivilege("UniversalBrowserRead");
        } catch (e) {
            //alert("Permission UniversalBrowserRead denied.");
        }
    }
    
    // TO DO...
    var xmlHttpRequest = new js.ajax.XMLHttpRequest();
    xmlHttpRequest.set("url", this.app.appServicesURL);
    xmlHttpRequest.setVar("cmd", "getMessage");
    xmlHttpRequest.setVar("id", d.MSGID);
    xmlHttpRequest.setVar("l", d.RECORD_LOCATION);
    xmlHttpRequest.object = this;
    xmlHttpRequest.open();

    xmlHttpRequest.onComplete = function() {
        //alert(this.response);
        
        // eval the JSON data...
        var data = null;
        eval("data = " + this.response);
        
        // ...
        this.object.loadData(data.item);
		this.object.show();
        
        this.object.app.loadingDataContentPanel.hide();
    }
    xmlHttpRequest.onError = function() {
    	this.object.app.loadingDataContentPanel.hide();
    	
        alert("ERROR while executing getMessage: " + this.response);
    }

	this.app.loadingDataContentPanel.show();
	try {
    	xmlHttpRequest.send();
	} catch(e) {
		alert("ERROR (getMessage):\n\n" + e);
	}
}

