package com.async.test;



public class Test2 {
	public static void main(String[] args) throws Exception {
		String strColumn = "NR_OF_MSG_OTHER_ERRORS";
		String str = "UPDATE NGWS_RETRY_MESSAGES_STATS SET col = col + 1 WHERE day_of_year = ?";

		System.out.println(str.replaceAll("col", strColumn));
	}
}
