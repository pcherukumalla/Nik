package com.rogers.rci.csl;

public class SSMQMscConstants 
{
	public static final String JMS_CONNECTION_FACTORY_JNDI = "SyncMsgsConnectionFactory";
	public static final String JMS_DESTINATION_QUEUE_JNDI = "SYNC_REQUESTS_QUEUE";
	public static final String JMS_ERROR_DESTINATION_QUEUE_JNDI = "SYNC_REQUESTS_ERROR_QUEUE";
}
