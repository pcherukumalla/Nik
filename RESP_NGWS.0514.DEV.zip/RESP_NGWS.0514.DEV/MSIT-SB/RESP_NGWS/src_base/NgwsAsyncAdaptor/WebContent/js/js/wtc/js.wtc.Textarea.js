/*
****************************************************************************************************
 ezWebToolkit Library, http://ezwt.blogspot.com
****************************************************************************************************
Copyright [2006-2008] [Pro Net Systems Inc., http://www.pronetsystems.com]

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

	http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
***************************************************************************************************
*/



/*
------------------------------------------------------------------------------------------
Textarea
------------------------------------------------------------------------------------------
*/
js.wtc.Textarea = function() {
	js.wtc.ContentPanel.call(this);
	
	this.passwordIn = false;

	this.objectType = "js.wtc.Textarea";
}
js.wtc.Textarea.prototype = new js.wtc.ContentPanel();
js.wtc.Textarea.prototype.constructor = js.wtc.Textarea;



js.wtc.Textarea.prototype.init = function() {
	// create the main div...
	this.theViewport = document.createElement("TEXTAREA");
	
	// instrument the new node...
	this.instrumentViewport();
}



js.wtc.Textarea.prototype.set = function(name, value) {

	if(name == "value") {
		this.viewport().value = value;
	} else if(name == "cols") {
		this.viewport().cols = value;
	} else if(name == "rows") {
		this.viewport().rows = value;
	} else if(name == "wrap") {
		this.viewport().wrap = value;
	} else {
		js.wtc.ContentPanel.prototype.set.call(this, name, value);
	}
}



js.wtc.Textarea.prototype.get = function(name) {
	if(name == "value") {
		return this.viewport().value;
	} else if(name == "cols") {
		return this.viewport().cols;
	} else if(name == "rows") {
		return this.viewport().rows;
	} else if(name == "wrap") {
		return this.viewport().wrap;
	} else {
		return js.wtc.ContentPanel.prototype.get.call(this, name);
	}
}
