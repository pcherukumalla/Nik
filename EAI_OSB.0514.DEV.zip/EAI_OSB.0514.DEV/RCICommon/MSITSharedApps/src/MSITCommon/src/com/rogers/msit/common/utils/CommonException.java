package com.rogers.msit.common.utils;



public class CommonException extends Exception {
final private static long serialVersionUID = 1L;
	
	
	
	public CommonException() {
		super();
	}
	
	
	
	public CommonException(String message) {
		super(message);
	}
	
	
	
	public CommonException(String message, Throwable cause) {
		super(message, cause);
	}
	
	
	
	public CommonException(Throwable cause) {
		super(cause);
	}
}
