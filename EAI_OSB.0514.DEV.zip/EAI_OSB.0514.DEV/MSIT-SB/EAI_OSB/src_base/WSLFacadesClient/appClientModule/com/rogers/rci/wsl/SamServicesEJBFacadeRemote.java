package com.rogers.rci.wsl;

import java.rmi.RemoteException;
import javax.ejb.EJBObject;
import org.apache.xmlbeans.XmlObject;

public abstract interface SamServicesEJBFacadeRemote extends EJBObject
{
  public abstract XmlObject getCustomerBalance(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject getCustomerProducts(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject getCustomerProfile(XmlObject paramXmlObject)
    throws RemoteException, Exception;
}