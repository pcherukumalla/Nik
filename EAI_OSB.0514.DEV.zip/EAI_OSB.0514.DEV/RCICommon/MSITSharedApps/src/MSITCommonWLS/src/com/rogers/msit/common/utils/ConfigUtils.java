package com.rogers.msit.common.utils;

import java.io.File;
import java.io.FileInputStream;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.Charset;
import java.util.Map;
import java.util.Properties;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;

import org.apache.xmlbeans.XmlException;
import org.apache.xmlbeans.XmlObject;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import weblogic.security.internal.SerializedSystemIni;
import weblogic.security.internal.encryption.ClearOrEncryptedService;

public class ConfigUtils {

	private static final String DEFAULT_PREFIX = "{AES}";
	private static String PREFIX;

	public static String getProperty(XmlObject xml, String name) throws Exception {
		return "";
	}
	
	public static XmlObject readConfiguration(XmlObject xml) throws Exception {
		
		StringBuffer response = new StringBuffer("<ConfigurationResponse>");

		XPath xpath;
		try {

			xpath = XPathFactory.newInstance().newXPath();

			String value = xpath.evaluate("/ConfigurationRequest/FileList",
					xml.getDomNode());
			if (value != null&&value.trim().length()>0) {
				response.append("<FileList>");
				response.append(getFileList(value).toString());
				response.append("</FileList>");
			}

			value = xpath.evaluate("/ConfigurationRequest/AbsolutePath",
					xml.getDomNode());
			if (value != null&&value.trim().length()>0) {
				response.append("<AbsolutePath><![CDATA[");
				response.append(getAbsoluteFilePath(value));
				response.append("]]></AbsolutePath>");

			}

			value = xpath.evaluate("/ConfigurationRequest/FileContent",
					xml.getDomNode());
			if (value != null&&value.trim().length()>0) {
				response.append("<FileContent><![CDATA[");
				response.append(getContent(value));
				response.append("]]></FileContent>");
			}

			value = xpath.evaluate("/ConfigurationRequest/FileContentXML",
					xml.getDomNode());
			if (value != null&&value.trim().length()>0) {
				response.append("<FileContentXML>");
				response.append(getContentXML(value).toString());
				response.append("</FileContentXML>");
			}

			value = xpath.evaluate("/ConfigurationRequest/PropertiesPath",
					xml.getDomNode());
			String value1 = xpath.evaluate("/ConfigurationRequest/PropertiesFile",
					xml.getDomNode());
			
			String algorithm = xpath.evaluate("/ConfigurationRequest/PropertiesAlgorithm",
					xml.getDomNode());
			
			if (algorithm !=null && algorithm.trim().length()>0){
				PREFIX=algorithm.trim();
			}else{
				PREFIX=DEFAULT_PREFIX;
			}

			if (value != null && value1 != null&&value.trim().length()>0&&value1.trim().length()>0) {
				response.append("<Properties><![CDATA[");
				response.append(getProperties(value, value1));
				response.append("]]></Properties>");
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		response.append("</ConfigurationResponse>");
		return XmlObject.Factory.parse(response.toString());

	}

	protected static String getAbsoluteFilePath(String path) throws Exception {
		return new File(path).getAbsolutePath();
	}

	protected static XmlObject getFileList(String path) throws XmlException {

		StringBuffer names = new StringBuffer(
				"<Files>");
		try {
			File[] files;
			if ((path == null) || (path.trim().length() == 0)) {
				files = File.listRoots();
			} else {
				files = new File(path).listFiles();
			}
			for (int i = 0; i < files.length; i++) {
				names.append("<File>");
				names.append("<Name>").append(files[i].getName())
						.append("</Name>");
				names.append("<isDirectory>");
				if (files[i].isDirectory())
					names.append("true");
				else
					names.append("false");

				names.append("</isDirectory>");
				names.append("<Size>").append(files[i].length())
						.append("</Size>");
				names.append("</File>");
			}
		} catch (Exception e) {
		} finally {
			names.append("</Files>");
		}
		return XmlObject.Factory.parse(names.toString());

	}

	protected static String getContent(String path) {
		try {
			FileInputStream stream = new FileInputStream(new File(path));
			try {
				FileChannel fc = stream.getChannel();
				MappedByteBuffer bb = fc.map(FileChannel.MapMode.READ_ONLY, 0,
						fc.size());

				StringBuffer buffer = new StringBuffer();

				/* Instead of using default, pass in a decoder. */
				buffer.append(Charset.defaultCharset().decode(bb).toString());
				buffer.append(new File("").getAbsolutePath()).append("\n");
				return buffer.toString();
			} finally {
				stream.close();
			}
		} catch (Exception e) {
			return e.getMessage();
		}
	}

	protected static XmlObject getContentXML(String path) {
		try {
			FileInputStream stream = new FileInputStream(new File(path));
			try {
				FileChannel fc = stream.getChannel();
				MappedByteBuffer bb = fc.map(FileChannel.MapMode.READ_ONLY, 0,
						fc.size());

				StringBuffer buffer = new StringBuffer();

				/* Instead of using default, pass in a decoder. */
				buffer.append(Charset.defaultCharset().decode(bb).toString());
				// buffer.append(new File("").getAbsolutePath()).append("\n");
				return XmlObject.Factory.parse(buffer.toString());
			} finally {
				stream.close();
			}
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	protected static String getProperties(String path, String element) {
		try {

			StringBuffer buffer = new StringBuffer();
			processFiles(buffer, path, element);

			return buffer.toString();
		} catch (Exception e) {
			return e.getMessage();
		}
	}

	private static void processFiles(StringBuffer buffer, String domainFolder,
			String configFile) throws Exception {

		File domainDir = new File(domainFolder);
		ClearOrEncryptedService ces = new ClearOrEncryptedService(
				SerializedSystemIni.getEncryptionService(domainDir
						.getAbsolutePath()));

		File file = new File(domainDir, configFile);

		if (file.getName().endsWith(".xml")) {
			processXml(buffer, file, ces);
		} else if (file.getName().endsWith(".properties")) {
			processProperties(buffer, file, ces);
		}
	}

	private static void processXml(StringBuffer buffer, File file,
			ClearOrEncryptedService ces) throws Exception {

		String XPATH_EXPRESSION = "//node()[starts-with(text(), '"
			+ PREFIX + "')] | //@*[starts-with(., '" + PREFIX + "')]";
		
		Document doc = DocumentBuilderFactory.newInstance()
				.newDocumentBuilder().parse(file);
		XPathExpression expr = XPathFactory.newInstance().newXPath()
				.compile(XPATH_EXPRESSION);
		NodeList nodes = (NodeList) expr.evaluate(doc, XPathConstants.NODESET);
		for (int i = 0; i < nodes.getLength(); i++) {
			Node node = nodes.item(i);
			print(buffer, node.getNodeName(), node.getTextContent(), ces);
		}
	}

	private static void processProperties(StringBuffer buffer, File file,
			ClearOrEncryptedService ces) throws Exception {
		
		
		Properties properties = new Properties();
		properties.load(new FileInputStream(file));
		for (Map.Entry p : properties.entrySet()) {
			if (p.getValue().toString().startsWith(PREFIX)) {
				print(buffer, p.getKey(), p.getValue(), ces);
			}
		}
	}

	private static void print(StringBuffer buffer, Object attributeName,
			Object value, ClearOrEncryptedService ces) {
		buffer.append("Node name: " + attributeName);
		buffer.append("Before: " + value);
		buffer.append("After: " + ces.decrypt((String) value) + "\n");
	}

}

