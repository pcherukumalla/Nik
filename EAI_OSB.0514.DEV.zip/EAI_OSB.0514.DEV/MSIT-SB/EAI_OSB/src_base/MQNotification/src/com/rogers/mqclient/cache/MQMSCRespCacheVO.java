package com.rogers.mqclient.cache;

public class MQMSCRespCacheVO extends MQCacheBase
{
	private static MQCacheBase mqCacheVO = null;
	
	public static MQCacheBase getInstance()
	{
		synchronized( MQMSCRespCacheVO.class )
		{
			if ( mqCacheVO == null ) mqCacheVO = new MQCacheBase();
		}
		return mqCacheVO;
	}
	
}
