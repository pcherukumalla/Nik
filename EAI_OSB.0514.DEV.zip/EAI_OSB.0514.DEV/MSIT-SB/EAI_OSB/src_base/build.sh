#!/bin/sh
${ANT_HOME}/bin/ant $*
