/*
------------------------------------------------------------------------------------------
LoadingContentPanel
------------------------------------------------------------------------------------------
*/
com.rogers.rci.ngws.LoadingContentPanel = function() {
	js.wtc.ContentPanel.call(this);
}
com.rogers.rci.ngws.LoadingContentPanel.prototype = new js.wtc.ContentPanel();
com.rogers.rci.ngws.LoadingContentPanel.prototype.constructor = com.rogers.rci.ngws.LoadingContentPanel;



com.rogers.rci.ngws.LoadingContentPanel.prototype.init = function() {
	js.wtc.ContentPanel.prototype.init.call(this);

	// set attributes...
	this.set("left", parseInt(screen.width/2 - 50) + "px");
	this.set("top", "150px");
	this.set("width", "100px");
	this.set("height", "50px");
	this.set("backgroundColor", "#FFFFFF");
	this.set("border", "1px solid #AFAFAF");
	this.set("zIndex", "1");
	this.set("showWhenParentDisplayed", false);
	
	this.set("innerHTML", "<div align=\"center\"><br><img src=\"images/loading.gif\"></div>");
}
