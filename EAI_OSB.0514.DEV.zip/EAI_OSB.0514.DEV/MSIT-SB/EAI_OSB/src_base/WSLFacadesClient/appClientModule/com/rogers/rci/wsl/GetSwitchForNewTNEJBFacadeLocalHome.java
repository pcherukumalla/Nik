package com.rogers.rci.wsl;

import javax.ejb.CreateException;
import javax.ejb.EJBLocalHome;

public abstract interface GetSwitchForNewTNEJBFacadeLocalHome extends EJBLocalHome
{
  public abstract GetSwitchForNewTNEJBFacadeLocal create()
    throws CreateException, CreateException;
}