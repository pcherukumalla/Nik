
Additional Instructions deployment for Defect CQUSR00538827 (major changes due to SGI issue)
---------------------------------------------------------------------------------
---------------------------------------------------------------------------------
Backup complete sbconfig.jar for all the projects on the domain.

Deploy the new package from SCM

Create a new OSB session.
Change accordingly end point for each specified resource:

OLBServices\services\business_services\olb\OLBSSWebService.biz
http://eaiqavip3.rogers.com:5419/SSAWeb/SSAWeb.jws

EAIServiceUtils\services\businessServices\rogers_com\RogersComOLBService.biz
http://vmelxap123.rogers.com:6219/AccountAssociation/AutoRegistrationServicesProxy


EAIServiceUtils\services\businessServices\eaic\EAICCustomerAccountMaintenance.biz
http://10.3.61.64:5410/CustomerAccountMaintenance/CustomerAccountMaintenance.jws

EAIServiceUtils\services\businessServices\rop\ROPAsyncService.biz
http://10.3.61.174:9410/AsyncMsgProcess/AsyncMessageProcessorWSFacade

EAIServiceUtils\services\businessServices\rws_olb\RWSAccountMaintenance.biz
http://10.3.61.79:6410/WSLServices/AccountMaintenance.jws

Save and activate all changes.


Create a OSB session.
Remove files that will create conflict at deployment or will remain orfan/unused:
a) Remove (under OLBServices project) all structure and files under "wsdls" and "schemas" child folder
b) Remove (under OLBServices project) from services/business_services/olb/ all the files EXCEPT the OLBSSWebService.biz (this one keep)
c) Remove (under OLBServices project) from services/proxy_services_olb/ 
the OLBAsyncUpdateConsolidatedService.proxy and the OLBServiceFacade.proxy files.
Save and activate changes.