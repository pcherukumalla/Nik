/*
****************************************************************************************************
ezWebToolkit Library, http://www.ezwebtoolkit.com
****************************************************************************************************
Copyright [2006-2009] [Pro Net Systems Inc., http://www.pronetsystems.com]

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
***************************************************************************************************
*/



/*
------------------------------------------------------------------------------------------
Color
this class holds the color information and provides some color related basic functions.
------------------------------------------------------------------------------------------
*/
js.canvas.draw2d.Color = function() {
    //Member variables
    var hex = "#000000";

    switch (arguments.length) {
        //Hexadecimal Color 
        case 1:
            setHex(arguments[0]);
            break;
        //RGB Color 
        case 3:
            var red = arguments[0];
            var green = arguments[1];
            var blue = arguments[2];
            hex = rgbToHex(red, green, blue);
            if (hex == false)
                hex = "#000000";
            break;
    }

    //Public Methods

    //Set color by specifying the hexa-decimal value. 
    this.setHex = setHex;
    function setHex(hexColor) {
        if (hexColor.charAt(0) == "#") {
            hex = hexColor;
        }
        else {
            if (isNaN(hexColor)) {
                setNamedColor(hexColor.toLowerCase());
            }
            else {
                hex = "#" + hexColor;
            }
        }

        var rgbArray = hexToRgb(hex);
        if (!rgbArray) {
            hex = "#000000"
        }
    }
    //Get the hexa-decimal value of the object
    this.getHex = getHex;
    function getHex() {
        return hex;
    }

    //Set color by specifying the RGB values.
    this.setRGB = setRGB;
    function setRGB(redValue, greenValue, blueValue) {
        hex = rgbToHex(redValue, greenValue, blueValue);
        if (hex == false)
            hex = "#000000";
    }

    //Get the RGB values of the object
    this.getRGB = getRGB;
    function getRGB() {
        return hexToRgb(hex);
    }

    //Returns new jsColor object with darker color shade 
    this.getDarkerShade = getDarkerShade;
    function getDarkerShade(value) {
        var redValue, greenValue, blueValue;
        var resArray = getRGB();

        if (!isNaN(value)) {
            redValue = parseInt(resArray[0] - value);
            greenValue = parseInt(resArray[1] - value);
            blueValue = parseInt(resArray[2] - value);
        }

        if (redValue < 0)
            redValue = 0;
        if (greenValue < 0)
            greenValue = 0;
        if (blueValue < 0)
            blueValue = 0;

        return new jsColor(redValue, greenValue, blueValue);
    }

    //Returns new jsColor object with lighter color shade 
    this.getLighterShade = getLighterShade;
    function getLighterShade(value) {
        var redValue, greenValue, blueValue;
        var resArray = getRGB();

        if (!isNaN(value)) {
            redValue = parseInt(resArray[0] + value);
            greenValue = parseInt(resArray[1] + value);
            blueValue = parseInt(resArray[2] + value);
        }

        if (redValue > 255)
            redValue = 255;
        if (greenValue > 255)
            greenValue = 255;
        if (blueValue > 255)
            blueValue = 255;

        return new jsColor(redValue, greenValue, blueValue);
    }

    //Static-Shared Utility Methods

    //Convert RGB color to Hex color
    this.rgbToHex = rgbToHex;
    function rgbToHex(redValue, greenValue, blueValue) {
        //Check argument values
        if (redValue < 0 || redValue > 255 || greenValue < 0 || greenValue > 255 || blueValue < 0 || blueValue > 255) {
            return false;
        }

        var colorDec = Math.round(blueValue) + 256 * Math.round(greenValue) + 65536 * Math.round(redValue);
        return "#" + zeroPad(colorDec.toString(16), 6);
    }

    //Convert Hex color to RGB color
    this.hexToRgb = hexToRgb;
    function hexToRgb(hexValue) {
        var redValue, greenValue, blueValue;
        if (hexValue.charAt(0) == "#") {
            hexValue = hexValue.substring(1, 7);
        }

        redValue = parseInt(hexValue.substring(0, 2), 16);
        greenValue = parseInt(hexValue.substring(2, 4), 16);
        blueValue = parseInt(hexValue.substring(4, 6), 16);

        //Check argument values
        if (redValue < 0 || redValue > 255 || greenValue < 0 || greenValue > 255 || blueValue < 0 || blueValue > 255) {
            return false;
        }

        return new Array(redValue, greenValue, blueValue);
    }

    //Private Methods
    //Set the color using specified name of the color out of 16 web colors.
    function setNamedColor(colorName) {
        switch (colorName) {
            case "aqua":
                hex = "#00FFFF";
                break;
            case "black":
                hex = "#000000";
                break;
            case "blue":
                hex = "#0000FF";
                break;
            case "fuchsia":
                hex = "#FF00FF";
                break;
            case "green":
                hex = "#008000";
                break;
            case "gray":
                hex = "#808080";
                break;
            case "lime":
                hex = "#00FF00";
                break;
            case "maroon":
                hex = "#800000";
                break;
            case "navy":
                hex = "#000080";
                break;
            case "olive":
                hex = "#808000";
                break;
            case "purple":
                hex = "#800080";
                break;
            case "red":
                hex = "#FF0000";
                break;
            case "silver":
                hex = "#C0C0C0";
                break;
            case "teal":
                hex = "#008080";
                break;
            case "white":
                hex = "#FFFFFF";
                break;
            case "yellow":
                hex = "#FFFF00";
                break;
        }
    }

    //Add zero padding to the left. Used for building hexa-decimal string.	
    function zeroPad(val, count) {
        var valZeropad = val + "";
        while (valZeropad.length < count) {
            valZeropad = "0" + valZeropad;
        }
        return valZeropad;
    }

}