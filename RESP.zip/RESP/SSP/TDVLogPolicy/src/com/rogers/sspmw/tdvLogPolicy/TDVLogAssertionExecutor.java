package com.rogers.sspmw.tdvLogPolicy;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.namespace.QName;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPHeaderElement;
import javax.xml.soap.SOAPMessage;

import oracle.wsm.common.sdk.IContext;
import oracle.wsm.common.sdk.IMessageContext.STAGE;
import oracle.wsm.common.sdk.IResult;
import oracle.wsm.common.sdk.Result;
import oracle.wsm.common.sdk.SOAPBindingMessageContext;
import oracle.wsm.common.sdk.WSMException;
import oracle.wsm.policy.model.IAssertion;
import oracle.wsm.policy.model.IProperty;
import oracle.wsm.policy.model.impl.SimpleAssertion;
import oracle.wsm.policyengine.IExecutionContext;
import oracle.wsm.policyengine.impl.AssertionExecutor;

import org.apache.xmlbeans.XmlException;
import org.apache.xmlbeans.XmlObject;
import org.w3c.dom.NodeList;

import weblogic.logging.NonCatalogLogger;

import com.rogers.sspmw.mask.MaskConfigParser;
import com.rogers.sspmw.mask.MaskRegEx;
import com.rogers.sspmw.tdvLogPolicy.adapter.FileAdapter;
import com.rogers.sspmw.tdvLogPolicy.adapter.ILogAdapter;
import com.rogers.sspmw.tdvLogPolicy.adapter.JMSAdapter;
import com.rogers.sspmw.tdvLogPolicy.exception.TDVException;

public class TDVLogAssertionExecutor extends AssertionExecutor {
	private static NonCatalogLogger log = new NonCatalogLogger("TDVLog");

	private Map<String, String> maskConfg;
	private ILogAdapter jmsAdapter;
	private ILogAdapter fileAdapter;

	public TDVLogAssertionExecutor() {
		super();
	}

	@Override
	public void init(IAssertion assertion, IExecutionContext econtext,
			IContext context) throws WSMException {
		log.info("--------------TDVLogPolicy.init---------------");
		this.assertion = assertion;
		this.econtext = econtext;

		boolean isSuccess = false;
		try {
			List<IProperty> properties = ((SimpleAssertion) this.assertion)
					.getBindings().getConfigs().get(0).getProperties();
			initMaskConfig(properties.get(0).getValue());
			initAdapters(properties);

			isSuccess = true;
		} catch (XmlException e) {
			log.error("Init mask config error!", e);
		} catch (TDVException e) {
			log.error("Init adapters error!", e);
		}

		if (isSuccess) {
			log.info("--------------TDVLogPolicy.init Success---------------");
		} else {
			log.error("--------------TDVLogPolicy.init Fail. Please fix issue in rogers/tdv_policy and try again.---------------");
		}
	}

	private void initAdapters(List<IProperty> properties) throws TDVException {
		Properties log4jProperties = filterProperties(properties, "log4j.");
		log.info("log4jProperties: " + log4jProperties.toString());
		this.fileAdapter = new FileAdapter();
		this.fileAdapter.initAdapter(log4jProperties);

		Properties jmsProperties = filterProperties(properties, "jms.");
		log.info("jmsProperties: " + jmsProperties.toString());
		this.jmsAdapter = new JMSAdapter();
		this.jmsAdapter.initAdapter(jmsProperties);

	}

	private Properties filterProperties(List<IProperty> policyProperties,
			String prefix) {
		Properties properties = new Properties();
		for (IProperty p : policyProperties) {
			if (p.getName().startsWith(prefix)) {
				properties.put(p.getName(), p.getValue());
			}
		}
		return properties;
	}

	private void initMaskConfig(String maskConfgStr) throws XmlException {
		log.info("maskConfg=" + maskConfgStr);
		maskConfg = MaskConfigParser.getConfig(XmlObject.Factory.parse(maskConfgStr));
	}

	@Override
	public void destroy() {
		log.info("--------------TDVLogPolicy.destroy---------------");
//		this.assertion = null;
//		this.econtext = null;
//		this.maskConfg = null;
	}

	@Override
	public IResult execute(IContext context) throws WSMException {
		long timeStart = System.currentTimeMillis();
		SOAPBindingMessageContext c = (SOAPBindingMessageContext) context;
		SOAPMessage request = c.getRequestMessage();
		SOAPMessage response = c.getResponseMessage();
		SOAPMessage fault = c.getFault();
		STAGE currentStage = c.getStage();
		
		OutputStream out = null;
		try {
			out = new ByteArrayOutputStream();
			String msgId = null;

			if(STAGE.request.equals(currentStage)) {
				dumpMessage(c, request, out);
			} else if(STAGE.response.equals(currentStage)) {
				dumpMessage(c, response, out);
			} else {
				dumpMessage(c, fault, out);
			}

			String message = out.toString();
			if (message != null && !"".equals(message.trim())) {
				String serivceURL = c.getServiceURL();

				if (STAGE.request.equals(currentStage)) {
					msgId = getMessageId(message);
					msgId = addMsgIdToHeader(request, msgId);
				} else if(STAGE.response.equals(currentStage)) {
					msgId = removeMsgIdFromHeader(response, message);
				} else {
					msgId = removeMsgIdFromHeader(fault, message);

				}

				if ((STAGE.request.equals(currentStage) || STAGE.response.equals(currentStage)) && needMask(serivceURL)) {
					message = MaskRegEx.mask(this.maskConfg, message);
				}

				MessageBean bean = new MessageBean(msgId, serivceURL, message);
				try {
					this.jmsAdapter.log(bean);
				} catch (TDVException e) {
					log.error(
							"Logging TDVRequest to JMS Queue fail! TDVRequest will be logged to file.",
							e);
					try {
						this.fileAdapter.log(bean);
					} catch (TDVException e1) {
						log.error("Logging TDVRequest to file fail!", e1);
					}
				}

			}
		} catch (SOAPException e) {
			log.error("TDV log error!", e);
		} catch (IOException e) {
			log.error("TDV log error!", e);
		} finally {
			if(out != null) {
				try {
					out.close();
				} catch (IOException e) {
					log.debug("Close out stream error.");
				}
			}
		}

		IResult result = new Result();
		result.setStatus(IResult.SUCCEEDED);

		long timeEnd = System.currentTimeMillis();
		log.debug("--------------TDVLog.execute---------------" + (timeEnd - timeStart));

		return result;
	}

	private void dumpMessage(SOAPBindingMessageContext c, SOAPMessage message,
			OutputStream out) throws SOAPException, IOException {
		if(message.getAttachments().hasNext()) {
			SOAPMessage temp = c.cloneSOAPMessage(message);
			temp.removeAllAttachments();
			temp.writeTo(out);
		} else {
			message.writeTo(out);
		}
	}

	private String addMsgIdToHeader(SOAPMessage message, String msgId) {
		String id = msgId;
		if (id == null) {
			id = UUID.randomUUID().toString();
		}

		try {
			SOAPHeader header = message.getSOAPHeader();
			if (header == null) {
				header = message.getSOAPPart().getEnvelope().addHeader();
			}
			QName qname = new QName("http://rci.rogers.com/msit", "tdvProcessID");
			SOAPHeaderElement e = header.addHeaderElement(qname);
			e.addTextNode(id);
		} catch (SOAPException e) {
			log.error("TDV log error!", e);
		}

		return id;
	}

	private String removeMsgIdFromHeader(SOAPMessage message, String xml) {
		String msgId = null;
		try {
			SOAPHeader header = message.getSOAPHeader();
			if(header == null) {
				msgId = getMessageId(xml);
				if (msgId == null) {
					msgId = UUID.randomUUID().toString();
				}
			} else {
				NodeList nodeList = header.getElementsByTagNameNS( "http://rci.rogers.com/msit", "tdvProcessID");
				if (nodeList != null && nodeList.getLength() > 0 && !message.getAttachments().hasNext()) {
					msgId = nodeList.item(0).getTextContent();
					int count = nodeList.getLength();
					for(int i= count-1; i>=0; i--) {
						header.removeChild(nodeList.item(i));
					}
				} else {
					msgId = getMessageId(xml);
					if (msgId == null) {
						msgId = UUID.randomUUID().toString();
					}
				}
			}
		} catch (SOAPException e) {
			log.error("TDV log error!", e);
		}

		return msgId;
	}

	private String getMessageId(String xml) {
		String pattern = "(?s)<(([A-Za-z0-9]*:)?(TransactionID|RequestID))\\b[^>]*>(.*?)</\\1>";

		String value = null;
		Pattern p = Pattern.compile(pattern);
		Matcher m = p.matcher(xml);
		if (m.find()) {
			value = m.group(4);
		}

		return value;
	}

	private boolean needMask(String serivceURL) {
		// determine need mask or not
		return true;
	}

}
