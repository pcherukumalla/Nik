/*
****************************************************************************************************
 ezWebToolkit Library, http://ezwt.blogspot.com
****************************************************************************************************
Copyright [2006-2008] [Pro Net Systems Inc., http://www.pronetsystems.com]

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

	http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
***************************************************************************************************
*/



/*
------------------------------------------------------------------------------------------
TabPanelHeaderOption
------------------------------------------------------------------------------------------
*/
js.wtc.TabPanelHeaderOption = function(n, bClose, imgClose, fClose) {
	js.wtc.Table.call(this);

	this.name = n;
	this.closeIn = bClose;
	this.imgClose = imgClose;
	this.functionClose = fClose;

	this.imageClose = null;
	
	this.objectType = "js.wtc.TabPanelHeaderOption";
}
js.wtc.TabPanelHeaderOption.prototype = new js.wtc.Table();
js.wtc.TabPanelHeaderOption.prototype.constructor = js.wtc.TabPanelHeaderOption;



js.wtc.TabPanelHeaderOption.prototype.init = function() {
	js.wtc.Table.prototype.init.call(this);

	this.set("position", "");
	this.set("cellPadding", "0");
	this.set("cellSpacing", "0");
	var tbody = this.appendTBody();

	// start creating cells...
	var row = tbody.insertRow(-1);

	// delimiter cell...
	var cell = row.insertCell(-1);
	cell.innerHTML = "&nbsp;";

	// title cell...
	cell = row.insertCell(-1);
	if(typeof(this.name) == "string") {
		cell.innerHTML = this.name.replace(/ /gi, "&nbsp;");
	} else {
		this.append(this.name, cell);
	}

	// close cell...
	if(this.closeIn) {
		// delimiter cell...
		cell = row.insertCell(-1);
		cell.innerHTML = "&nbsp;&nbsp;";

		cell = row.insertCell(-1);

		// add event action...
		this.imageClose = new js.wtc.Image(this.imgClose);
		this.imageClose.init();
		this.imageClose.set("position", "");
		this.imageClose.set("title", "close tab option");
		this.imageClose.addEventListener("onclick", this.functionClose);
		this.append(this.imageClose, cell);
	}

	// delimiter cell...
	cell = row.insertCell(-1);
	cell.innerHTML = "&nbsp;";
}
