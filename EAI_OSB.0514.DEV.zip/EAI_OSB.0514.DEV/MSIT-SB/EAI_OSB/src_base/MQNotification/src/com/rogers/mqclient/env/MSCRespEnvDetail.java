package com.rogers.mqclient.env;

public class MSCRespEnvDetail extends MQEnvDetailBase implements MQEnvDetailInterface 
 {
	 public MSCRespEnvDetail( String params )
	    throws Exception
	{        
	    try
	    {  
	    	setMQEnvDetail( params, this );
	    }
	    catch (Exception ex)
	    {
	    	ex.printStackTrace();
	    }        
	}   
	 
    public  static String HOST = "";
    public  static String PORT = "";
    public  static String CHANNEL = "";
    public  static String QNAME = "";
    public  static String QMGR = "";
    public  static int CCSID = 0;  
    
    public static String LAST_GOOD_MQ_DETAILS = "";                                   	
	
	public void setHOST(String host) {
		HOST = host;
	}

	public void setPORT(String port) {
		PORT = port;
	}

	public void setCHANNEL(String channel) {
		CHANNEL = channel;
	}

	public void setQNAME(String qname) {
		QNAME = qname;
	}

	public void setQMGR(String qmgr) {
		QMGR = qmgr;
	}

	public void setCCSID(int ccsid) {
		CCSID = ccsid;
	}

	public void setLAST_GOOD_MQ_DETAILS(String last_good_mq_details) {
		LAST_GOOD_MQ_DETAILS = last_good_mq_details;
	}
	
    public static String SYS_USER = null;
	public void setSYS_USER(String sysuser) {
		SYS_USER = sysuser;
	}
	
    public static void main(String[] args)
    throws Exception
	{
		new MSCRespEnvDetail("HOST=mvsd.rogers.com;PORT=1434;QMANAGER=MQDY;CHANNEL=MSC_ER_CLIENT_01;CCSID=819;QUEUE=SS_SERVICE_REPLY2;SYS_USER=Tst");
	    System.out.println(MSCRespEnvDetail.QMGR);
	    System.out.println(MSCRespEnvDetail.PORT);
	    System.out.println(MSCRespEnvDetail.CCSID);
	    System.out.println("SYS_USER:" + DocsisSSCOutEnvDetail.SYS_USER);
	}	
 }