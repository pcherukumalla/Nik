package com.rogers.msit.ngws.engine;

import java.util.*;
import java.util.logging.*;

import com.rogers.msit.ngws.dao.base.*;
import com.rogers.msit.ngws.services.*;
import com.rogers.msit.ngws.thread.*;
import com.rogers.msit.ngws.utils.*;



public class AsyncAdaptorEngine extends Thread {
	private static AsyncAdaptorEngine instance = null;
	
	private boolean resetInProgressOnStart = false;
	private boolean active = true;
	private boolean paused = false;
	private boolean processing = false;
	private long nrOfCycles = 0;
	private int currentMessageListSize = 0;
	private long getCurrentMessageListDuration = 0;
	private int getCurrentMessageListInProgress = 0;
	private long currentCycleNrOfMessages = 0;
	private String currentCycleError = "";
	private long currentCycleStartTime = 0;
	private long currentCycleFirstMessageId = 0;
	
	private int moveListSize = 0;
	private int maxNrOfRecsInProcessingTable = 0;
	
	private int runInterval = 0;
	private int nextMessageListSize = 0;
	private String nextMessageListSQL = "";
	private String sendDirectlyToJMS = "N";
	
	private ThreadPool threadPool = null;
	
	
	
	private AsyncAdaptorEngine() {
		// ...
	}
	
	
	
	public static AsyncAdaptorEngine getInstance() {
		if (instance == null) {
			instance = new AsyncAdaptorEngine();
		}
		
		return instance;
	}
	
	
	
	public static void cleanUp() {
		instance = null;
	}
	
	
	
	public void run() {
		this.setPriority(NORM_PRIORITY);
		
		while(this.active) {
			// no current cycle error
			this.currentCycleError = "";
			// get current cycle start time...
			this.currentCycleStartTime = System.currentTimeMillis();
			
			if(!this.paused) {
				// refresh & get new configuration values...
				boolean bRefreshConfigValuesOK = true;
				boolean bElmsServersOK = false;
				try {
					this.refreshConfigurationValues(false);
										
					// you can deactivate this engine by setting manually the "this.active" attribute
					// as also if the server name attribute in the configuration table is not equal  
					// with the current server/machine name this code is running...
					boolean bActiveServerName = AsyncAdaptorService.getInstance().getThisServerName().equals(AsyncAdaptorService.getInstance().getValue("ACTIVE_SERVER_NAME"));
					if(!bActiveServerName) {
						this.currentCycleError = "This server/machine name not equal with the one in the configuration table. The engine will be stopped.";
						
						this.active = false;
						break;
					} else {
						// reset all those messages that are stucked as "IN_PROGRESS" in the "temp/processing" table...
						if(!this.resetInProgressOnStart) {
							AsyncAdaptorService.getInstance().getAsyncAdaptorDAO().updateInProgressOnStart();
							
							this.resetInProgressOnStart = true;
						}
					
					}
					
					// get ELMS servers status...
					bElmsServersOK = "Y".equals(AsyncAdaptorService.getInstance().getValue("ELMS_SERVERS_OK"));
					if(!bElmsServersOK) {
						this.currentCycleError = "ELMS servers are down.";
					}
				} catch(Exception e) {
					Constants.LOGGER.log(Level.SEVERE, "Error while trying to refresh the config values from the configuration table: " + e.toString());
					this.currentCycleError = "Error while trying to refresh the config values from the configuration table: " + e.toString();
					bRefreshConfigValuesOK = false;
				}
				

				
				// start processing cycle...
				if(bRefreshConfigValuesOK && bElmsServersOK) {
					// set as running...
					this.processing = true;
					// reset number of messages pushed for processing successfully in this cycle...
					this.currentCycleNrOfMessages = 0;
					

					// move the new list of messages for processing from the buffer table to the processing one...
					this.moveMessageListForProcessing();
					
					
					// get the next message list to be processed...
					List messageList = this.getNextMessageList();
					
					
					
					if("".equals(this.currentCycleError)) {
						// go through the list...
						DAOObject msg = null;
													//long nStart = System.currentTimeMillis();
						for(int i = 0; i < messageList.size(); i++) {
							// if engine has been stopped or paused in the meantime then break the "for" loop...
							if(!this.active || this.paused) {
								break;
							}
							
							// get the next message...
							msg = (DAOObject)messageList.get(i);
							
							// store the first message ID... 
							if(i == 0) {
								this.currentCycleFirstMessageId = msg.getLong("MSGID"); 
							}
														
							// update/mark message for processing...
							String strCurrentMessageError = "";
							try {
								// **************************
								// **************************
								AsyncAdaptorService.getInstance().getAsyncAdaptorDAO().updateMessageForProcessing(msg.getLong("MSGID"));
								// **************************
								// **************************
							} catch(Exception e2) {
								// get/save error...
								strCurrentMessageError = this.getErrorMessage(e2, msg.getLong("MSGID"), Constants.UPDATE_FOR_PROCESSING);
								this.currentCycleError = "\n\n" + strCurrentMessageError;
							}
							
							// if no error so far for this message then push the message for processing...
							if("".equals(strCurrentMessageError)) {
								if("Y".equals(this.sendDirectlyToJMS)) {
									AsyncAdaptorService.getInstance().sendMessage(msg);
								} else {
									this.threadPool.execute(new AsyncAdaptorAuxThread(msg));
								}
							}
						}
													//System.out.println("markAndPushAll: " + (System.currentTimeMillis() - nStart));
												
						// set the new number of processing cycles...
						this.nrOfCycles++;
					}
									
					
					
					// set as not running...
					this.processing = false;
										
					// pause/idle engine...
					if(this.active) {
						try {
							if(this.paused) {
								Thread.sleep(Constants.ASYNC_ADAPTOR_ENGINE_IDLE_INTERVAL);
							} else {
								Thread.sleep(this.runInterval);
							}
						} catch(InterruptedException ie) {
							this.currentCycleError += "\n\n" + "Error while trying to pause or idle the engine: " + ie.toString();
						}
					}
				} else {
					// set as not running...
					this.processing = false;
					
					// pause engine...
					try	{
						Thread.sleep(Constants.ASYNC_ADAPTOR_ENGINE_IDLE_INTERVAL);
					} catch(InterruptedException ie) {
						if(this.currentCycleError.indexOf("ELMS servers are down") != -1) {
							this.currentCycleError += "\n\n" + "Error while trying to pause the engine because of 'refresh config values error': " + ie.toString();
						}
					}
				}
			} else {
				// set as not running...
				this.processing = false;
				
				// pause engine...
				try	{
					Thread.sleep(Constants.ASYNC_ADAPTOR_ENGINE_IDLE_INTERVAL);
				} catch(InterruptedException ie) {
					this.currentCycleError += "\n\n" + "Error while trying to pause the engine: " + ie.toString();
				}
			}
		}
	}
	
	
	
	private void moveMessageListForProcessing() {
		try {
					long nStart = System.currentTimeMillis();
			AsyncAdaptorService.getInstance().getAsyncAdaptorDAO().moveMessageListForProcessing(this.moveListSize, this.maxNrOfRecsInProcessingTable);
					System.out.println("moved for processing in: " + (System.currentTimeMillis() - nStart));
		} catch(Exception e) {
			Constants.LOGGER.log(Level.SEVERE, "Error while moving the message list to be processed: " + e.toString());
			this.currentCycleError = "\n\n" + "Error while moving the message list to be processed: " + e.toString();
		}
	}
	
	
	
	private List getNextMessageList() {
		List ret = null;
		
		try {
			//this.getCurrentMessageListDuration = 0;
			this.getCurrentMessageListInProgress = 1;
			long nStartRunSQL = System.currentTimeMillis();
			ret =  AsyncAdaptorService.getInstance().getAsyncAdaptorDAO().getNextMessageList(this.nextMessageListSize,	this.nextMessageListSQL);
			this.getCurrentMessageListDuration = System.currentTimeMillis() - nStartRunSQL;
			this.getCurrentMessageListInProgress = 0;
			
			// store the list size...
			this.currentMessageListSize = ret.size();
			
			if(this.currentMessageListSize == 0) {
				this.currentCycleError = "\n\n" + "No messages were found to be processed in this cycle.";
			}
		} catch(Exception e) {
			Constants.LOGGER.log(Level.SEVERE, "Error while getting the next message list to be processed: " + e.toString());
			this.currentCycleError = "\n\n" + "Error while getting the next message list to be processed: " + e.toString();
		}
		
		return ret;
	}
	
	
	
	/*public void markAndPushMessageForProcessing(DAOObject msg) {
		String strCurrentMessageError = "";
		long nMessageId = msg.getLong("MSGID");
		
		// update/mark message for processing...
		try {
			// **************************
			// **************************
			AsyncAdaptorService.getInstance().getAsyncAdaptorDAO().updateMessageForProcessing(nMessageId);
			// **************************
			// **************************
		} catch(Exception e2) {
			// get/save error...
			strCurrentMessageError = this.getErrorMessage(e2, nMessageId, Constants.UPDATE_FOR_PROCESSING);
			this.currentCycleError = "\n\n" + strCurrentMessageError;
		}
		
		// if no error so far for this message then push the message for processing...
		if("".equals(strCurrentMessageError)) {
			try {
				// **************************
				// **************************
				AsyncAdaptorService.getInstance().pushMessageForProcessing(nMessageId, msg.getInt("MSGTYPE_ID"), msg.getString("MSG_DATA_STR"));
				// **************************
				// **************************
				
				this.currentCycleNrOfMessages++;
			} catch(Exception e3) {
				// get/save error...
				this.currentCycleError = "\n\n" + this.getErrorMessage(e3, nMessageId, Constants.PUSH_FOR_PROCESSING);
				
				// update message with failure if necessary...
				try {
					if(Constants.MESSAGE_FORMAT_ERROR.equals(e3.getMessage())) {
						AsyncAdaptorService.getInstance().acknowledge(nMessageId, Constants.MESSAGE_FORMAT_ERROR, e3.toString());
					} else {
						AsyncAdaptorService.getInstance().acknowledge(nMessageId, Constants.PUSH_FOR_PROCESSING_ERROR, e3.toString());
					}
				} catch(Exception e4) {
					// get/save error...
					this.currentCycleError += "\n\n" + this.getErrorMessage(e4, nMessageId, Constants.AFTER_PUSH_FOR_PROCESSING);
				}
			}
		}
	}*/
	
	
	
	public void refreshConfigurationValues(boolean bForceIn) throws Exception {
		AsyncAdaptorService srv = AsyncAdaptorService.getInstance();
		srv.refreshConfigValues(bForceIn);
		
		// get the next message list size...
		this.nextMessageListSize = Integer.parseInt(srv.getValue("NEXT_MESSAGE_LIST_SIZE"));
		// get next message list SQL...
		this.nextMessageListSQL = srv.getValue("GET_NEXT_MESSAGE_LIST_SQL");
		// get the engine run interval...
		this.runInterval = Integer.parseInt(srv.getValue("ASYNC_ADAPTOR_ENGINE_RUN_INTERVAL"));
		// number of records to be moved from the buffer table to the processing one...
		this.moveListSize = Integer.parseInt(srv.getValue("MOVE_FOR_PROCESSING_LIST_SIZE"));
		// max number of records in the processing table...
		this.maxNrOfRecsInProcessingTable = Integer.parseInt(srv.getValue("MAX_NR_OF_RECORDS_FOR_PROCESSING"));
		// send directly to JMS or send by web service...
		this.sendDirectlyToJMS = srv.getValue("SEND_DIRECTLY_TO_JMS");
	}
	
	
	
	private Throwable getRootException(Exception e) {
		Throwable err = e;
		
		while (err.getCause() != null) {
			err = err.getCause();								
		}
		
		return err;
	}
	
	
	
	private String getErrorMessage(Exception e, long msgId, int actionType) {
		String strRet = "";
		Throwable err = null; 
		
		try {
			// get root exception...
			err = getRootException(e);
			
			if(actionType == Constants.UPDATE_FOR_PROCESSING) {
				strRet = "Error while marking message " + msgId + " for processing: " + err.toString();
			} else if(actionType == Constants.PUSH_FOR_PROCESSING) {
				strRet = "Error while pushing message " + msgId + " for processing: " + err.toString();
			} else if(actionType == Constants.AFTER_PUSH_FOR_PROCESSING) {
				strRet = "Error while updating message " + msgId + " after push for processing: " + err.toString();
			} else {
				strRet = "Error for message " + msgId + ": " + err.toString();
			}
		} catch(Exception e2) {
			if(actionType == Constants.UPDATE_FOR_PROCESSING) {
				strRet = "Error while marking message for processing: " + err.toString();
			} else if(actionType == Constants.PUSH_FOR_PROCESSING) {
				strRet = "Error while pushing message for processing: " + err.toString();
			} else if(actionType == Constants.AFTER_PUSH_FOR_PROCESSING) {
				strRet = "Error while updating message after push for processing: " + err.toString();
			} else {
				strRet = "Error: " + err.toString();
			}
		}
		
		return strRet;
	}

	
	
	public boolean isActive() {
		return active;
	}

	
	
	public synchronized void setActive(boolean active) {
		this.active = active;
	}

	
	
	public boolean isProcessing() {
		return processing;
	}

	
	
	public long getNrOfCycles() {
		return nrOfCycles;
	}

	
	
	public boolean isPaused() {
		return paused;
	}

	
	
	public synchronized void setPaused(boolean paused) {
		this.paused = paused;
	}



	public String getCurrentCycleError() {
		return currentCycleError;
	}



	public long getCurrentCycleNrOfMessages() {
		return currentCycleNrOfMessages;
	}



	public int getCurrentMessageListSize() {
		return currentMessageListSize;
	}



	public int getRunInterval() {
		return runInterval;
	}



	public int getNextMessageListSize() {
		return nextMessageListSize;
	}



	public String getNextMessageListSQL() {
		return nextMessageListSQL;
	}



	public long getCurrentCycleStartTime() {
		return currentCycleStartTime;
	}



	public long getGetCurrentMessageListDuration() {
		return getCurrentMessageListDuration;
	}



	public long getCurrentCycleFirstMessageId() {
		return currentCycleFirstMessageId;
	}
	
	
	
	public int getGetCurrentMessageListInProgress() {
		return getCurrentMessageListInProgress;
	}



	public int getMoveListSize() {
		return moveListSize;
	}



	public int getMaxNrOfRecsInProcessingTable() {
		return maxNrOfRecsInProcessingTable;
	}



	public String getSendDirectlyToJMS() {
		return sendDirectlyToJMS;
	}



	public ThreadPool getThreadPool() {
		return threadPool;
	}



	public void setThreadPool(ThreadPool threadPool) {
		this.threadPool = threadPool;
	}
}


