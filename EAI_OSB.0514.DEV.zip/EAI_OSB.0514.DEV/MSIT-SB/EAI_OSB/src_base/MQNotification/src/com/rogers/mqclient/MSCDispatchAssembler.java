package com.rogers.mqclient;

import com.rogers.logger.utility.UtilityLogger;
import com.rogers.mqclient.msc.MscResponseVO;
import com.rogers.mqclient.msc.MscSessionFactory;
import com.rogers.mqclient.msc.SessionData;
import com.rogers.mqclient.msc.SsUserLogon;
import com.rogers.mqclient.msc.TokenStore;

public class MSCDispatchAssembler 
{		
	public static String sendMSCRequestToMQ(String mscOutMsgBody, String mqconfigurationRequest, String resetMqConn, String resetMqDetail, String correlationId, String mscMsgReceived, String password, String mqconfigurationResponse, String initSessionDataForSSUser)
		throws Exception
	{
		//initSessionDataForSSUser sample:
		//sstart=xx;company=xy;passwd=yy;pstarttime=uu;pwd_updated=ii;days_valid=yythk;setScount=15;token=jhsd9k;
				
		setSessionData(initSessionDataForSSUser);
		String tokenOnFile = TokenStore.getInstance().getTokenFromFile( sessionData.getUserid() );
		overrideWithTokenFromFile(tokenOnFile);
		
		MSCRequestToMQDispatcher dispatcher =  new MSCRequestToMQDispatcher();
	
		dispatcher.setRequestPrerequisites(mqconfigurationRequest, Boolean.parseBoolean(resetMqConn), Boolean.parseBoolean(resetMqDetail), correlationId, mscMsgReceived, password);
		dispatcher.setResponsePrerequisites(mqconfigurationResponse, Boolean.parseBoolean(resetMqConn), Boolean.parseBoolean(resetMqDetail), correlationId, mscMsgReceived, password);
        MscSessionFactory sessionFactory = MscSessionFactory.getInstance();
        
		String mscResponseMessage = getMscResponseForRequest(dispatcher, sessionFactory, sessionData, mscMsgReceived);				
		return mscResponseMessage;
	}
	
	private static String getMscResponseForRequest( MSCRequestToMQDispatcher dispatcher, MscSessionFactory sessionFactory, SessionData sessionData, String mscMsgReceived )
		throws Exception
	{
		 MscResponseVO mscResponseVO = null;
		 if( sessionData == null )
	            throw new Exception("MSCAdapter.refreshSession: unable to retrieve data from DB for configured user ");
		
		String session = sessionFactory.reserveSession(); //note that return can be null
        
        //if no token exists in the in memory store 
        if ( session == null )
        {
        	//.. and no successful attempt to LOGN: can only happen if just coming up, we should try first the stored token before doing a login
        	if ( sessionData.getToken() != null && sessionData.getToken().trim().length() > 0 )
        	{
        		 mscResponseVO = handleFirstSyncMscCallWithStoredToken( dispatcher,  sessionFactory,  mscMsgReceived);
        	}
        	else
        	{
        		//no token and no session case
        		 mscResponseVO = handleFirstSyncMscCallWithoutToken( dispatcher,  sessionFactory,  mscMsgReceived);
        	}
        }
        else        
        	mscResponseVO = handleSyncMscCall( dispatcher, mscMsgReceived, session, "USUAL");
		
		return mscResponseVO.getMscResponse();
	}
	
	private static synchronized MscResponseVO handleFirstSyncMscCallWithStoredToken(MSCRequestToMQDispatcher dispatcher, MscSessionFactory sessionFactory, String mscMsgReceived)
		throws Exception
	{
    	UtilityLogger.getLogger().info("MSCAdapter.refreshSession: token=null && sessionData.token=" + getSessionData().getToken() );
        sessionFactory.setTokenData( getSessionData().getToken(), getSessionData().getScount() );
        
        MscResponseVO mscResponseVO = handleSyncMscCall(dispatcher, mscMsgReceived, sessionFactory.reserveSession(), "USUAL");
        
        String retcode = mscResponseVO.getRetCode();
        if( (retcode.equals(SsUserLogon.passwdExpiredStatus)) ||
            	(retcode.equals(SsUserLogon.invalidTokenStatus)) ||
            	(retcode.equals(SsUserLogon.notSignedInStatus))) 
        {
        	mscResponseVO = handleFirstSyncMscCallWithoutToken(dispatcher, sessionFactory, mscMsgReceived);
        }      
        return mscResponseVO;
	}
	
	private static synchronized MscResponseVO handleFirstSyncMscCallWithoutToken(MSCRequestToMQDispatcher dispatcher, MscSessionFactory sessionFactory, String mscMsgReceived)
		throws Exception
	{	
    	UtilityLogger.getLogger().info("MSCAdapter.refreshSession: stored token=null, in memory session=null: need to log in");
    	//perform the LOGN call:
    	MscResponseVO mscResponseVO = null;
    	//check if another thread did not perform LOGN successfully already
    	if (!sessionFactory.getLOGNStatus())
    	{
	    	mscResponseVO = handleSyncMscCall(dispatcher, mscMsgReceived, sessionFactory.reserveSession(), "LOGN");
	        if ( !mscResponseVO.getRetCode().equalsIgnoreCase( SsUserLogon.successStatus )) 
	        {
	        	UtilityLogger.getLogger().info("MscAdapter.ssLogin failed: responseMessage=" + mscResponseVO.getMscResponse());
	        	MscSessionFactory.clear();
	        	UtilityLogger.getLogger().info("MscAdapter.ssLogin failed: cleared the session factory");
	        	throw new Exception("MscAdapter.ssLogin failed: responseMessage=" + mscResponseVO.getMscResponse());
	        }
	        else
	        {
	        	//store data from successful login
	        	storeDataFromSuccessfulLogin(mscResponseVO, sessionFactory);
	        	
	        	//perform again the real call after successful login
	            mscResponseVO = handleSyncMscCall(dispatcher, mscMsgReceived, sessionFactory.reserveSession(), "USUAL");
	        }
    	}
    	else
    		mscResponseVO = handleSyncMscCall(dispatcher, mscMsgReceived, sessionFactory.reserveSession(), "USUAL");
    	
    	return 	mscResponseVO;
	}
	
	private static void storeDataFromSuccessfulLogin(MscResponseVO mscResponseVO, MscSessionFactory sessionFactory)
		throws Exception
	{
    	String loginRespNoHeader = getResponseMessage(mscResponseVO.getMscResponse(), false);
    	String token = SsUserLogon.parseSessionToken( loginRespNoHeader );
    	int scount = SsUserLogon.parseSessionEstablished( loginRespNoHeader );
    	
    	sessionData.setToken(token);
    	sessionData.setScount(scount);

    	MscSessionFactory.clear();
    	UtilityLogger.getLogger().info("MSCAdapter.refreshSession: token=null && sessionData.token=" + getSessionData().getToken() );
        sessionFactory.setTokenData( token, scount );   
        sessionFactory.setLOGNStatus(true);        
        
        TokenStore.getInstance().setTokenStore(getSessionData().getUserid(), token, scount);
	}
	
	private static MscResponseVO handleSyncMscCall(MSCRequestToMQDispatcher dispatcher, String mscMsgReceived, String session, String typeOfCall)
		throws Exception
	{
		byte[] msgid = dispatcher.putMSCMessage(mscMsgReceived, session, typeOfCall);
		UtilityLogger.getLogger().info("Successfuly placed MSC request to MQ queue.");
		String msgResponse = dispatcher.getMSCResponse(msgid);
		String retcode = getReturnCode(msgResponse);
		return new MscResponseVO(msgResponse,retcode);
	}

	private static String getResponseMessage( String response, boolean withHeader )
		throws Exception
	{
		String retcode = getReturnCode( response );
		if(! retcode.equals( SsUserLogon.successStatus ) )
		{
	        //special handling for SS error 3126 - the aditional information flags required:
	        if( "3126".equalsIgnoreCase( retcode ) )
	        {
	            retcode = get3126RetCode( response );
	        }
	
			// error code from SS
	        UtilityLogger.getLogger().info("MSCAdapter.getResponseMessage (about to throw): "+response);
	        String errorDescription = new StringBuffer("SS Error returnCode(").append( retcode).append(") msg(").append( response.substring(60)).append( ")").toString();
			throw new Exception( errorDescription );
		}
	    else {
	    	UtilityLogger.getLogger().info("MSCAdapter.getResponseMessage: "+response);
	    }
		return (withHeader ? response : response.substring( 60 ));
	}	
	
    private static String get3126RetCode( String response )
    	throws Exception
    {
	    // add to the error code additional info to be used: IN_TERRITORY, ON_PLANT, ALLOW_ADD_ADDRESS as last 3 digits
	    return getReturnCode(response) + response.substring( response.length()-3, response.length() );
    }
	
	private static String getReturnCode( String response )
		throws Exception
	{
		if ( response == null || response.length() < 60 )	{
			// unable to find the valid header
			throw new Exception( "Invalid SS response:" + response );
		}
	
		// store the status code and indicator
		String statusCode = response.substring( 35, 39 );
		char statusIndicator = response.charAt( 39 );
	
		// any warnings stored in status code
		//if ( statusIndicator == 'G' ) return successStatus;
		if ( statusIndicator != 'B' && statusIndicator != 'U' )
	        return SsUserLogon.successStatus;
	
		// return code other than success for bad status
		return statusCode.equals( SsUserLogon.successStatus )? "????" : statusCode;
	}

	private static SessionData sessionData = new SessionData();
	
	private static void setSessionData(String initSessionDataForSSUser)
		throws Exception
	{
		SessionData.parseSessionData(initSessionDataForSSUser,sessionData);
	}
	private static SessionData getSessionData()
	{
		return MSCDispatchAssembler.sessionData;
	}
	
	private static void overrideWithTokenFromFile(String tokenFromFile)
	{
		if ( tokenFromFile != null && !tokenFromFile.trim().equalsIgnoreCase("") )
		{
			sessionData.setToken(tokenFromFile);
		}
	}
	
    public static void resetMSCReqConnection()
    {
    	(new MSCRequestToMQDispatcher()).resetConnection();
    }
    public static void resetMSCRespConnection()
    {
    	(new MSCRequestToMQDispatcher()).resetConnection();
    } 	
}
