/*
------------------------------------------------------------------------------------------
LibraryLogoContentPanel
------------------------------------------------------------------------------------------
*/
com.rogers.rci.ngws.LibraryLogoContentPanel = function() {
	js.wtc.ContentPanel.call(this);
}
com.rogers.rci.ngws.LibraryLogoContentPanel.prototype = new js.wtc.ContentPanel();
com.rogers.rci.ngws.LibraryLogoContentPanel.prototype.constructor = com.rogers.rci.ngws.LibraryLogoContentPanel;



com.rogers.rci.ngws.LibraryLogoContentPanel.prototype.init = function() {
	js.wtc.ContentPanel.prototype.init.call(this);
	
	// set attributes...
	this.set("left", "1000px");
	this.set("top", "550px");
	this.set("width", "33px");
	this.set("overflow", "hidden");
	this.set("height", "12px");
	this.set("cursor", "pointer");
	this.set("title", "go to ezWebToolkit website");
	this.addEventListener("onclick", function() { window.open("http://www.ezwebtoolkit.com", "", "") });
}
