package com.rogers.mqclient.msc;

import java.util.HashMap;

import com.rogers.logger.utility.UtilityLogger;

public class SessionData implements java.io.Serializable, SessionDataInterface
{
	private static final long serialVersionUID = 1L;
	
	private String sstart = null;
	private String passwd = null;
	private String pstarttime = null;
	private String pwd_updated = null;
	private String days_valid= null;
	private String userid = null;
	private int scount = 0;
	private String company = null;	
	private String token = null;
	
	public synchronized void setToken(String token) {
		this.token = token;
	}

	public void setSstart(String sstart) {
		this.sstart = sstart;
	}

	public synchronized void setScount(int scount) {
		this.scount = scount;
	}

	public void setCompany(String company) {
		this.company = company;
	}
	
	public void setPasswd(String passwd) {
		this.passwd = passwd;
	}
	public void setPstarttime(String pstarttime) {
		this.pstarttime = pstarttime;
	}

	public void setPwd_updated(String pwd_updated) {
		this.pwd_updated = pwd_updated;
	}

	public void setDays_valid(String days_valid) {
		this.days_valid = days_valid;
	}

	public void  setUserid(String userid) {
		this.userid = userid;
	}
	
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getToken() {
		return token;
	}

	public String getSstart() {
		return sstart;
	}

	public int getScount() {
		return scount;
	}

	public String getCompany() {
		return company;
	}

	public String getPasswd() {
		return passwd;
	}

	public String getPstarttime() {
		return pstarttime;
	}

	public String getPwd_updated() {
		return pwd_updated;
	}

	public String getDays_valid() {
		return days_valid;
	}

	public String getUserid() {
		return userid;
	}
	
	public static synchronized void parseSessionData(String sessionData, SessionDataInterface obj)
		throws Exception
	{
		//KEEP IN MIND to set it the data just once .. than will remain in memory
		//sessionData sample:
		//sstart=xx;company=xy;passwd=yy;pstarttime=uu;pwd_updated=ii;days_valid=yythk;setScount=15;token=jhsd9k;
		
		obj.setSessionDataDetail(sessionData, obj);
		//returns the populated obj
	}
	
	public void setSessionDataDetail(String params, SessionDataInterface obj)
		throws Exception
	{
		UtilityLogger.getLogger().info("Received for SessionData: " + params);
	
		HashMap<String, String> mp = new HashMap<String, String>();
		int poz = -1;
	
		String sessionDataForUser = params;
		if (sessionDataForUser == null || "".equalsIgnoreCase( sessionDataForUser.trim() ))
		{
			throw new Exception("Error: initSessionDataForSSUser not defined!");
		}
	
		String[] pairs = sessionDataForUser.toLowerCase().split( ";" );
		for ( int count = 0; count < pairs.length; count ++ )
		{
		  poz = pairs[ count ].indexOf("=");
		  mp.put( pairs[ count ].substring(0,poz).trim(), pairs[ count ].substring(poz+1).trim() );
		}
		
		if (obj.getSstart() == null)
			obj.setSstart( getConfField( mp, "sstart" ) );
		//Allow override of 'company'
		obj.setCompany( getConfField( mp, "company" ));
		
		if (obj.getCompany() == null)
			obj.setPasswd( getConfField( mp, "passwd" ));
		if (obj.getPstarttime() == null)
			obj.setPstarttime( getConfField( mp, "pstarttime" ));
		if (obj.getPwd_updated() == null)
			obj.setPwd_updated( getConfField( mp, "pwd_updated" ) );
		if (obj.getDays_valid() == null)
			obj.setDays_valid( getConfField( mp, "days_valid" ) );				
		
		obj.setScount( Integer.parseInt( getConfField( mp, "scount" ) ));
		
		if (obj.getToken() == null)
			obj.setToken ( getConfField( mp, "token" ).toUpperCase() );	
		if (obj.getUserid() == null )
			obj.setUserid ( getConfField( mp, "userid" ).toUpperCase() );
		//System.out.println("userid:" + getConfField( mp, "userid" ));		
	}
	
	private String getConfField( HashMap<String, String> mp, String name )
	{
	      if (!mp.containsKey( name ) ) return null;
		    return (String)mp.get( name );
	}	
	
	public static void main(String[] notused)
		throws Exception
	{
		String input = "sstart=1;company=230;passwd=er1029;pstarttime= ;pwdupdated=11-APR-06;days valid=27;scount=15;token=48744810DEVERT5    ;userid=DEVERT5";
		//String userid="DEVERT5";
		SessionData obj = new SessionData();
		obj.setSessionDataDetail(input, obj);
		System.out.println("Done with success");
		System.out.println("company:" + obj.getCompany());
	}
}