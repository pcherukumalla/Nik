package com.async.servlet;

import java.io.*;
import java.util.*;
import java.util.logging.*;

import javax.servlet.*;

import com.async.dao.base.*;
import com.async.engine.*;
import com.async.services.*;
import com.async.utils.*;



public class InitAppListener implements ServletContextListener {
	public void	contextInitialized(ServletContextEvent ce) {
		try {
			// init the DAO utils...
			DAOUtils.initUtils(ce.getServletContext());
			Constants.LOGGER.info("Generic AsyncAdaptor - DAOUtils initialized.");
			System.out.println("*** Generic AsyncAdaptor - DAOUtils initialized.");
			
			// init the service...
			AsyncAdaptorService.initService(ce.getServletContext());
			AsyncAdaptorService.getInstance().createAsyncAdaptorConfigDAO(); 
			AsyncAdaptorService.getInstance().createAsyncAdaptorDAO(); 
			Constants.LOGGER.info("Generic AsyncAdaptor - System initialized.");
			
			// load NGWS related properties...
			String strFilename = ce.getServletContext().getRealPath("WEB-INF/" + Constants.PROP_FILENAME);
			if(strFilename == null) {
				strFilename = ce.getServletContext().getResource("/WEB-INF").getFile() + Constants.PROP_FILENAME;
			}
			Properties p = new Properties();
			p.load(new FileInputStream(strFilename));
			AsyncAdaptorService.getInstance().setProps(p);
			
			// start engine...
			AsyncAdaptorEngine.getInstance().start();
			Constants.LOGGER.info("Generic AsyncAdaptor - Engine started.");
			
			// start control engine...
			AsyncAdaptorControlEngine.getInstance().start();
			Constants.LOGGER.info("Generic AsyncAdaptor - Control Engine started.");
		} catch(Exception e) {
			e.printStackTrace();
			Constants.LOGGER.log(Level.SEVERE, this.getClass().getName() + "contextInitialized - error while initializing the app: " + e.toString());
		}
	}


	
	public void	contextDestroyed(ServletContextEvent ce) {
		// stop the engine...
		AsyncAdaptorEngine.getInstance().setActive(false);

		// stop control engine...
		AsyncAdaptorControlEngine.getInstance().setActive(false);
	}
}


