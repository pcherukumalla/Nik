package com.rogers.mqclient.msc;

public class MscMessageUtils {
	
	// Copy characters from string to char buffer
	public static void copyChars( String str, char[] buffer, int from, int length )
	{
		if ( str != null )
		{
			int nochars = str.length();
			if ( nochars > length ) nochars = length;
			str.getChars( 0, nochars, buffer, from );
		}
	}	
	
    /**
     * Convert numeric value to SS string with leading 0s
     * Returns the buffer
     */
	public static char[] numToSsStr( long value, char[] buffer, int from, int count )
	{
		if ( value < 0 ) value = -value;
		
		int pos = from + count - 1;
		while ( pos >= from )
		{
			buffer[pos--] = (char)('0' + (value % 10));
			value /= 10;
		}
        return buffer;
	}

    /**
     * Convert numeric value to SS string with leading 0s
     */
	public static char[] numToSsStr( long value, int count )
	{
		char[] buffer = new char[count];
		return numToSsStr( value, buffer, 0, count );
	}
	
	 public static byte[] getByteArrFromHex(String hexStrInput)
	 	throws Exception
	 {
	     if (1==hexStrInput.length()%2) {
	    	   System.out.println(new StringBuffer("Hex string need even number of chars.Received:|").append(hexStrInput).append("|").toString());
	           throw(new Exception("Hex string need even number of chars"));
	       }
	   
	       byte[] ba = new byte[hexStrInput.length()/2];
	       for (int i=0;i<hexStrInput.length()/2;i++) {
	           ba[i] = (Integer.decode(
	                   "0x"+hexStrInput.substring(i*2, (i+1)*2))).byteValue();
	       }
	       return ba;
	 }
	 
		// Set MSC Header Data
	public static void setRequestHeader( char[] header, String server, String action, String company, String userid )
	{
		// initialize header
		java.util.Arrays.fill( header, ' ' );

		// "SSIH03<server><action><company><userid><resource><msglen>";
		copyChars( "SSIH", header, 0, 4 );
		copyChars( "03", header,  4, 2 );
		copyChars( server,  header,  6, 8 );
		copyChars( action,  header, 14, 4 );
		copyChars( company, header, 18, 3 );
		copyChars( userid,  header, 21, 8 );
	}	 
}