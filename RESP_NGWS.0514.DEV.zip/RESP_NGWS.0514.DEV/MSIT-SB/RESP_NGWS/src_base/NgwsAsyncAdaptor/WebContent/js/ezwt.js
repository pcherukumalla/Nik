/*
****************************************************************************************************
 ezWebToolkit Library, http://www.ezwebtoolkit.com
****************************************************************************************************
Copyright [2006-2009] [Pro Net Systems Inc., http://www.pronetsystems.com]

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

	http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
***************************************************************************************************
*/



// the js package...
js = function() { }

// the URL...
js.URL = "http://www.ezwebtoolkit.com";
// the version...
js.VERSION = "5.0";

// global logging flag...
js.LOGGING = true;
// default images repository...
js.IMAGES_PATH = "images/";

// the main library script name...
js.MAIN_LIB_SCRIPT_NAME = "ezwt.js";
// the main library script id...
js.MAIN_LIB_SCRIPT_ID = "ezwt.library.id";
// the library path...
js.LIB_PATH = document.getElementById(js.MAIN_LIB_SCRIPT_ID).src.substring(0, document.getElementById(js.MAIN_LIB_SCRIPT_ID).src.indexOf(js.MAIN_LIB_SCRIPT_NAME));
// the library script name...
js.LIB_SCRIPT_NAME = "library.js";



js.load = function(l) {
    var tks = l.split(".");
    var baseFolder = "";
    var libPackage = l;

    for (var i = 0; i < tks.length; i++) {
        baseFolder += tks[i] + "/";
    }

    if (baseFolder.indexOf("*/") != -1) {
        baseFolder = baseFolder.substring(0, baseFolder.length - 2);
        libPackage = libPackage.substring(0, libPackage.length - 2);

        //alert("<script language=\"javascript\" src=\"" + js.LIB_PATH + baseFolder + js.LIB_SCRIPT_NAME + "\"></script>");
        document.write("<script language=\"javascript\" src=\"" + js.LIB_PATH + baseFolder + js.LIB_SCRIPT_NAME + "\"></script>");
    } else {
        // ...................................
    }
}



js.loadPkg = function(pkg) {
    var tks = pkg.namespace.split(".");
    var baseFolder = "";

    for (var i = 0; i < tks.length; i++) {
        baseFolder += tks[i] + "/";
    }

    for (var i = 0; i < pkg.files.length; i++) {
        document.write("<script language=\"javascript\" src=\"" + js.LIB_PATH + baseFolder + pkg.namespace + "." + pkg.files[i] + ".js\"></script>");
    }
}
