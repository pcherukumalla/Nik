package com.rogers.rci.wsl;

import java.rmi.RemoteException;
import javax.ejb.CreateException;
import javax.ejb.EJBHome;

public abstract interface SearchServicesEJBFacadeRemoteHome extends EJBHome
{
  public abstract SearchServicesEJBFacadeRemote create()
    throws CreateException, RemoteException, CreateException;
}