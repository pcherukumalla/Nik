package com.rogers.mqclient.ssc;


import java.lang.reflect.Field ;


public abstract class SscMessageUtils implements java.io.Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Initialize all char[] members with spaces
	 */
	public void initialize()
		throws IllegalAccessException
	{
		Field[]  publicFields = getClass().getFields() ;
		for ( int idx = 0 ; idx < publicFields.length ; idx++ )
		{
			char[] fieldVal = (char[]) publicFields[idx].get( this ) ;
			java.util.Arrays.fill( fieldVal, ' ' );
		}
	}

	/**
	 * Returns a concatenated string with the values of all fields
	 */
	public String createMessage()
		throws IllegalAccessException
	{
		StringBuffer  result = new StringBuffer( 1024 ) ;

		Field[]  publicFields = getClass().getFields() ;
		for ( int idx = 0 ; idx < publicFields.length ; idx++ )
		{
			char[] fieldVal = (char[]) publicFields[idx].get( this ) ;
			result.append( fieldVal ) ;
		}
		return result.toString() ;
	}

	/**
	 * Set the values of all fields based on 'msgstr' content.
	 */
	public void parseMessage( String msgstr, int startpos )
		throws IllegalAccessException
	{
		Field[] publicFields = getClass().getFields() ;
		for ( int idx = 0 ; idx < publicFields.length ; idx++ )
		{
			char[] fieldVal = (char[]) publicFields[idx].get( this ) ;
			msgstr.getChars( startpos, startpos + fieldVal.length, fieldVal, 0 ) ;
			startpos += fieldVal.length;
		}
	}

	/**
	 * Set the values of all fields declared as char[] based
	 * on 'stringArg' content.
	 */
	public void  parseMessage( String msgstr )
		throws IllegalAccessException
	{
		parseMessage( msgstr, 0 );
	}

	/**
	 * Returns the total length of all fields
	 */
	public int  getLength()
		throws IllegalAccessException
	{
		int  length = 0 ;

		Field[]  publicFields = getClass().getFields() ;
		for( int idx = 0 ; idx < publicFields.length ; idx++ )
		{
			char[]  fieldVal = (char[]) publicFields[idx].get( this ) ;
			length += fieldVal.length ;
		}
		return length ;
	}

	/**
	 * Set a field with string value
	 */
	public static void setString( char[] field, String str, int from )
	{
		java.util.Arrays.fill( field, ' ' );
		if ( str != null )
		{
			int nochars = field.length;
			int strlen = str.length() - from;

			if ( nochars > strlen ) nochars = strlen;
			str.getChars( from, nochars, field, 0 );
		}
	}

	/**
	 * Set a field with string value
	 */
	public static void setString( char[] field, String str )
	{
		setString( field, str, 0 );
	}

	/**
	 * Set a field with numeric value
	 */
	public static void setNumber( char[] field, long value )
	{
        numToSsStr( value, field, 0, field.length );
	}

    /**
     * Copy characters from string to char buffer
     */
	public static void copyChars( String str, char[] buffer, int from, int length )
	{
		if ( str != null )
		{
			int nochars = str.length();
			if ( nochars > length ) nochars = length;
			str.getChars( 0, nochars, buffer, from );
		}
	}

    /**
     * Convert numeric value to SS string with leading 0s
     * Returns the buffer
     */
	public static char[] numToSsStr( long value, char[] buffer, int from, int count )
	{
		if ( value < 0 ) value = -value;
		
		int pos = from + count - 1;
		while ( pos >= from )
		{
			buffer[pos--] = (char)('0' + (value % 10));
			value /= 10;
		}
        return buffer;
	}

    /**
     * Convert numeric value to SS string with leading 0s
     */
	public static char[] numToSsStr( long value, int count )
	{
		char[] buffer = new char[count];
		return numToSsStr( value, buffer, 0, count );
	}

}
