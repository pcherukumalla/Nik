package com.rogers.rci.csl;

import java.rmi.RemoteException;
import javax.ejb.EJBObject;

public abstract interface MSCServicesEJBFacadeRemote extends EJBObject
{
  public abstract void sendMSCResponseToMQ(String mscOutMsgBody, String mqconfiguration, boolean resetMqConn, boolean resetMqDetail, String correlationId, String mscMsgReceived, String returnCode)
    throws RemoteException, Exception;
  
  public abstract void resetMSCResponseToMQConnection() 
  	throws RemoteException, Exception;	
  
  public abstract void resetMSCTowardMQConnection()
	throws RemoteException, Exception;

  public abstract String sendMSCRequestToMQ(String mqconfigurationRequest, boolean resetMqConn, boolean resetMqDetail,String mscMsg, String password, String mqconfigurationResponse, String initSessionDataForSSUser)
  	throws RemoteException, Exception;
}