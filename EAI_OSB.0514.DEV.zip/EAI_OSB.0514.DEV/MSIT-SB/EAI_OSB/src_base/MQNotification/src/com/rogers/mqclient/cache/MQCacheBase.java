package com.rogers.mqclient.cache;

public class MQCacheBase 
{
	private com.ibm.mq.MQQueue queue = null;
	private com.ibm.mq.MQQueueManager qManager = null;
	
    private String RESET_MQ_CONN = null;
    private String RESET_MQ_DETAIL = null;
	
    public  com.ibm.mq.MQQueue getQueue() {
		return queue;
	}
	public  void setQueue(com.ibm.mq.MQQueue queue) {
		this.queue = queue;
	}
	public com.ibm.mq.MQQueueManager getQManager() {
		return qManager;
	}
	public void setQManager(com.ibm.mq.MQQueueManager manager) {
		this.qManager = manager;
	}
	public String getRESET_MQ_CONN() {
		return RESET_MQ_CONN;
	}
	public void setRESET_MQ_CONN(String reset_mq_conn) {
		this.RESET_MQ_CONN = reset_mq_conn;
	}
	public String getRESET_MQ_DETAIL() {
		return RESET_MQ_DETAIL;
	}
	public void setRESET_MQ_DETAIL(String reset_mq_detail) {
		this.RESET_MQ_DETAIL = reset_mq_detail;
	}	
}