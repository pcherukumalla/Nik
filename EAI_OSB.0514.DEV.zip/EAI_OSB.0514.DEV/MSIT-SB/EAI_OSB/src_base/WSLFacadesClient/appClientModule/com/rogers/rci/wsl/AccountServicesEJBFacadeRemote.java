package com.rogers.rci.wsl;

import java.rmi.RemoteException;
import javax.ejb.EJBObject;
import org.apache.xmlbeans.XmlObject;

public abstract interface AccountServicesEJBFacadeRemote extends EJBObject
{
  public abstract XmlObject createBAN(XmlObject paramXmlObject)
    throws RemoteException, Exception;
}