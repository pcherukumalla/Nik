package com.rogers.msit.ngws.engine;

import java.util.*;

import com.rogers.msit.ngws.dao.*;
import com.rogers.msit.ngws.services.*;
import com.rogers.msit.ngws.utils.*;



public class AsyncAdaptorControlEngine extends Thread {
	private static AsyncAdaptorControlEngine instance = null;
	
	private boolean active = true;
	
	
	
	private AsyncAdaptorControlEngine() {
		// ...
	}
	
	
	
	public static AsyncAdaptorControlEngine getInstance() {
		if (instance == null) {
			instance = new AsyncAdaptorControlEngine();
		}
		
		return instance;
	}
	
	
	
	public void run() {
		this.setPriority(NORM_PRIORITY);
		
		AsyncAdaptorConfigDAO dao = AsyncAdaptorService.getInstance().getAsyncAdaptorConfigDAO();
		
		// reset...
		try {
			dao.updateNextCommandToBeExecuted("-");
		} catch(Exception e) {
			System.out.println("Error while trying to reset the next command in the control engine: " + e.toString());
		}
		
		Properties params = new Properties();
		while(this.active) {
			// stop control engine if not active anymore...
			try {
				this.active = dao.isControlEngineActive();
				
				if(!this.active) {
					break;
				}
			} catch(Exception e) {
				System.out.println("Error while trying to get the control engine status: " + e.toString());
				
				this.active = false;
				
				break;
			}
			
			// execute the next command if any...
			try {
				this.executeNextCommand();
			} catch(Exception e) {
				System.out.println("Error while trying to execute next command in the control engine: " + e.toString());
			}

			// save engine status...
			try {
				updateEngineStatusParams();
			} catch(Exception e) {
				System.out.println("Error while trying to save engine status in the control engine: " + e.toString());
			}
			
			// pause engine...
			try	{
				Thread.sleep(Constants.ASYNC_ADAPTOR_CONTROL_ENGINE_IDLE_INTERVAL);
			} catch(InterruptedException ie) {
				System.out.println("Error while trying to pause the control engine: " + ie.toString());
			}
		}
	}
	
	
	
	private void updateEngineStatusParams() throws Exception {
		AsyncAdaptorEngine engine = AsyncAdaptorEngine.getInstance();
		
		Properties params = new Properties();
		params.setProperty("ENGINE_ID", "" + engine.getId());
		params.setProperty("IS_ALIVE", "" + engine.isAlive());
		params.setProperty("IS_INTERRUPTED", "" + engine.isInterrupted());
		params.setProperty("IS_ACTIVE", "" + engine.isActive());
		params.setProperty("IS_PAUSED", "" + engine.isPaused());
		params.setProperty("IS_PROCESSING", "" + engine.isProcessing());
		params.setProperty("NR_OF_TOTAL_CYCLES", "" + engine.getNrOfCycles());
		params.setProperty("CYCLE_MESSAGE_LIST_SIZE", "" + engine.getCurrentMessageListSize());
		params.setProperty("CYCLE_GET_MESSAGE_LIST_DURATION", "" + engine.getGetCurrentMessageListDuration());
		params.setProperty("CYCLE_GET_MESSAGE_LIST_IN_PROGRESS", "" + engine.getGetCurrentMessageListInProgress());
		params.setProperty("CYCLE_NR_OF_MESSAGES", "" + engine.getCurrentCycleNrOfMessages());
		params.setProperty("CYCLE_ERROR", engine.getCurrentCycleError());
		params.setProperty("CYCLE_START_TIME", Constants.DEFAULT_DATE_FORMAT.format(new Date(engine.getCurrentCycleStartTime())));
		params.setProperty("CYCLE_FIRST_MESSAGE_ID", "" + engine.getCurrentCycleFirstMessageId());
		
		AsyncAdaptorService.getInstance().getAsyncAdaptorConfigDAO().updateEngineStatusParams(params);
	}
	
	
	
	private String executeStop() throws Exception {
		String strResult = "";
    	
		try {
        	AsyncAdaptorEngine engine = AsyncAdaptorEngine.getInstance();
        		        	
        	if(engine.isActive()) {
        		engine.setActive(false);
        		
        		if(engine.getThreadPool() != null) {
        			engine.getThreadPool().close();
        		}
        		
        		strResult = "OK";
        	} else {
        		strResult = "Engine already stopped.";
        	}
    	} catch(Exception e2) {
    		strResult = "ERROR while executing STOP: " + e2.toString();
    	}
    	
    	return strResult;
	}
	
	
	
	private String executeStart() throws Exception {
		String strResult = "";
    	
		try {
        	AsyncAdaptorEngine engine = AsyncAdaptorEngine.getInstance();
        		        	
        	if(!engine.isActive() && !engine.isAlive()) {
        		AsyncAdaptorEngine.cleanUp();
        		
        		AsyncAdaptorEngine.getInstance().start();
        		
        		strResult = "OK";
        	} else {
        		strResult = "Can not start the engine because current instance is active/alive.";
        	}
    	} catch(Exception e2) {
    		strResult = "ERROR: " + e2.toString();
    	}
    	
    	return strResult;
	}
	
	
	
	private String executePause() throws Exception {
		String strResult = "";
    	
		try {
        	AsyncAdaptorEngine engine = AsyncAdaptorEngine.getInstance();

    		if(!engine.isPaused()) {
    			engine.setPaused(true);
        		
        		strResult = "OK";
        	} else {
        		strResult = "Engine already paused.";
        	}
    	} catch(Exception e2) {
    		strResult = "ERROR: " + e2.toString();
    	}
    	
    	return strResult;
	}
	
	
	
	private String executeResume() throws Exception {
		String strResult = "";
    	
		try {
        	AsyncAdaptorEngine engine = AsyncAdaptorEngine.getInstance();

    		if(engine.isPaused()) {
    			engine.setPaused(false);
        		
        		strResult = "OK";
        	} else {
        		strResult = "Engine already resumed.";
        	}
    	} catch(Exception e2) {
    		strResult = "ERROR: " + e2.toString();
    	}
    	
    	return strResult;
	}
	
	
	
	private String executeRefreshConfigValues() throws Exception {
		String strResult = "OK";
    	
		try {
        	AsyncAdaptorEngine.getInstance().refreshConfigurationValues(true);
    	} catch(Exception e2) {
    		strResult = "ERROR: " + e2.toString();
    	}
    	
    	return strResult;
	}
	
	
	
	private void executeNextCommand() throws Exception {
		AsyncAdaptorConfigDAO dao = AsyncAdaptorService.getInstance().getAsyncAdaptorConfigDAO();
		
		// check if anything to be executed...
		String strCommand = dao.getNextCommandToBeExecuted();
		if("-".equals(strCommand)) {
			return;
		}
		
		// update status to executing...
		dao.updateNextCommandToBeExecuted("EXECUTING - " + strCommand);
		
		// execute...
		String strResult = "-";
		try {
			if("REFRESH_CONFIG_VALUES".equals(strCommand)) {
				strResult = this.executeRefreshConfigValues();
			} else if("STOP".equals(strCommand)) {
				strResult = this.executeStop();
			} else if("START".equals(strCommand)) {
				strResult = this.executeStart();
			} else if("PAUSE".equals(strCommand)) {
				strResult = this.executePause();
			} else if("RESUME".equals(strCommand)) {
				strResult = this.executeResume();
			}
		} catch(Exception e) {
			System.out.println("Error while trying to execute command: " + strCommand + "\n" + e.toString());
		}
		
		// update command result...
		dao.updateLastCommandResult(strCommand, strResult);
		// update status to waiting for new command...
		dao.updateNextCommandToBeExecuted("-");
	}
}


