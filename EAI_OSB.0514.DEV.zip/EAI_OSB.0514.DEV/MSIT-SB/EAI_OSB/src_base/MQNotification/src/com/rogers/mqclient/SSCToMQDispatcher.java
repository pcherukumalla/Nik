package com.rogers.mqclient;


import com.rogers.logger.utility.UtilityLogger;
import com.rogers.mqclient.send.SendNativeSSCToMQ;
import com.rogers.mqclient.send.SendSSCInterface;

public class SSCToMQDispatcher implements SendSSCInterface
{
    private static SendSSCInterface sendInterface = new SendNativeSSCToMQ();

    /*
     * Usage sample: setPrerequisites( "<mq_details_string>", false, true
     * On flows that work with messages first boolean flag can be false.
     * On flows that work with messages second boolean flag can be false even on first call since code will determine that it is a first call
     */
    public void setPrerequisites(String mqconfiguration, boolean resetMqConn, boolean resetMqDetail, String correlationId, String mscMsgReceived, String returnCode)
    	throws Exception
    {
    	sendInterface.setPrerequisites( mqconfiguration, resetMqConn, resetMqDetail, correlationId, mscMsgReceived, returnCode);
    }

    /**
     * @param txtMessage (message including MSC header)
     * @throws Exception
     */
	public void putMessage( String txtMessage )
        throws Exception
	{
	  long startTime = System.currentTimeMillis();

	  sendInterface.putMessage( txtMessage );

	  UtilityLogger.getLogger().info("Duration (msec):" + (System.currentTimeMillis() - startTime));
    }

    public void resetConnection()
    {
    	sendInterface.resetConnection();
    }

	public void setAdditionalHeaderDetails(String applicationName, String appStructID, String company, String action) {
		sendInterface.setAdditionalHeaderDetails(applicationName, appStructID, company, action);
	}
}