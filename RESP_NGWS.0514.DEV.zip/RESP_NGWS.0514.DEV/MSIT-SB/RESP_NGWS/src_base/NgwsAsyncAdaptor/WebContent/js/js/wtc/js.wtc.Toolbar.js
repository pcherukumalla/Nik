/*
****************************************************************************************************
 ezWebToolkit Library, http://ezwt.blogspot.com
****************************************************************************************************
Copyright [2006-2008] [Pro Net Systems Inc., http://www.pronetsystems.com]

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

	http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
***************************************************************************************************
*/



/*
------------------------------------------------------------------------------------------
Toolbar
------------------------------------------------------------------------------------------
*/
js.wtc.Toolbar = function() {
	js.wtc.Table.call(this);
	
	this.size = -1;

	this.objectType = "js.wtc.Toolbar";
}
js.wtc.Toolbar.prototype = new js.wtc.Table();
js.wtc.Toolbar.prototype.constructor = js.wtc.Toolbar;



js.wtc.Toolbar.prototype.addControl = function(o, idx) {
	var nIndex = -1;
	if(idx) {
		nIndex = idx;
	}

	this.size++;
	if(this.size == 0) {
		this.generate(1, 1);
	} else {
		this.insertCol(nIndex);
	}
	
	o.set("position", "");
	
	if(nIndex == -1) {
		this.append(o, this.cell(0, this.size));
	} else {
		this.append(o, this.cell(0, nIndex));
	}
}



js.wtc.Toolbar.prototype.addSpace = function(w, idx) {
	var nIndex = -1;
	if(idx) {
		nIndex = idx;
	}

	this.size++;
	if(this.size == 0) {
		this.generate(1, 1);
	} else {
		this.insertCol(nIndex);
	}
	
	if(nIndex == -1) {
		this.cell(0, this.size).style.width = w;
	} else {
		this.cell(0, nIndex).style.width = w;
	}
}
