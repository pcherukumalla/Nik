package com.rogers.sspmw.mask;

import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.xmlbeans.XmlObject;

public class MaskRegEx {
	private static final String maskString = "********************************************************************************************************************************************************************************************************";
	private static final String pattern1 = "(?s)<(([A-Za-z0-9]*:)?(";
	private static final String pattern2 = "))\\b[^>]*>(.*?)</\\1>";
	
	/**
	 * Mask XML with predefined pattern.
	 * @param xml
	 * @return masked XML
	 */
	public static String mask(XmlObject configXML, String xml) {
		Map<String,String> config = MaskConfigParser.getConfig(configXML);
		return mask(config, xml);
	}
	
	public static String mask(Map<String, String> maskConfg, String xml) {
		StringBuffer sb = new StringBuffer(xml.length());
		processMask(maskConfg, xml, "MaskConfiguration", sb);
		return sb.toString();
	}


	/**
	 * Using Regular Expression to mask XML
	 * @param xml
	 * @param patternMap
	 * @param key pattern key
	 * @param sb output buffer
	 */
	private static void processMask(Map<String,String> config, String xml, String key, StringBuffer sb) {
		String pattern = pattern1 + config.get(key) + pattern2;
		String value = null;
		Pattern p = Pattern.compile(pattern);
		Matcher m = p.matcher(xml);
		int pointer = 0;
		
		while (m.find()) {
			value = m.group(4);
			int s = m.start(4);
			int e = m.end(4);

			String currentTag= key.concat("/").concat(m.group(3));
			if(config.containsKey(currentTag)) {
				sb.append(xml.substring(pointer, s));
				processMask(config,value,currentTag,sb);
				sb.append(xml.substring(e, m.end(0)));
				pointer = m.end(0);
			} else {
				sb.append(xml.substring(pointer, s));
				sb.append((value.length() < 200)? maskString .substring(0, value.length()): "***");
				pointer = m.end(4);
			}
		}
		if (pointer < xml.length()) {
			sb.append(xml.substring(pointer));
		}
	}


}
