/*
------------------------------------------------------------------------------------------
Application
------------------------------------------------------------------------------------------
*/
com.rogers.rci.ngws.Application = function() {
    this.applicationTitle = "MSIT - ELMS AsyncAdaptor Admin Tool";
    this.version = "1.0";
    
    this.loadingDataContentPanel = null;
    this.libraryLogo = null;
    this.topContentPanel = null;
    
    this.inviteListWindow = null;
    this.reportingWindow = null;
    
    this.appServicesURL = "ngws.do";
    
    this.typeOfSearch = "main";
    this.properties = null;
    this.userID = "";
    this.width = 1024;
    this.height = 784;
}



com.rogers.rci.ngws.Application.prototype.initDocumentBody = function() {
	document.body.style.marginTop = "0px";
	document.body.style.marginLeft = "0px";
	document.body.style.marginRight = "0px";
	document.body.style.marginBottom = "0px";
	
	document.body.style.fontFamily = "Arial";
	document.body.style.fontSize = "12px";
	
	document.title = this.applicationTitle;
}



com.rogers.rci.ngws.Application.prototype.init = function() {
	// init the document body...
	this.initDocumentBody();
	
	// init the results content panel...
	this.resultsContentPanel = new com.rogers.rci.ngws.ResultsContentPanel(this);
	this.resultsContentPanel.init();
	
	// init the top content panel...
	this.topContentPanel = new com.rogers.rci.ngws.TopContentPanel(this);
	this.topContentPanel.init();
	
	// init the loading content panel...
	this.loadingDataContentPanel = new com.rogers.rci.ngws.LoadingContentPanel();
	this.loadingDataContentPanel.init();
	
	// init the details window...
	this.detailsWindow = new com.rogers.rci.ngws.DetailsWindow(this);
	this.detailsWindow.init();
	
	// init the login window...
	this.loginWindow = new com.rogers.rci.ngws.LoginWindow(this);
	this.loginWindow.init();
	
	// init the engine admin window...
	this.engineAdminWindow = new com.rogers.rci.ngws.EngineAdminWindow(this);
	this.engineAdminWindow.init();
	
	// init the noRecords window...
	this.noRecordsWindow = new com.rogers.rci.ngws.NoRecordsWindow(this);
	this.noRecordsWindow.init();
}



com.rogers.rci.ngws.Application.prototype.showLibraryLogo = function() {
	var SELF = this;

	this.libraryLogo = new js.wtc.ContentPanel();
	this.libraryLogo.init();
	
	// ezWebToolkit library description...
	var libraryText = new js.wtc.Text("<i>powered&nbsp;&nbsp;&nbsp;by&nbsp;&nbsp;&nbsp;<b>ezWebToolkit</b></i>");
	libraryText.init();
	libraryText.set("left", "652px");
	libraryText.set("top", "563px");
	libraryText.set("color", "#707079");
	libraryText.set("cursor", "pointer");
	libraryText.set("fontSize", "11px");
	libraryText.set("title", "go to ezWebToolkit website");
	libraryText.addEventListener("onclick", function(){window.open(com.ezwt.url, "", "")});
	this.libraryLogo.append(libraryText);

	var logo1 = new com.rogers.rci.ngws.LibraryLogoContentPanel();
	logo1.init();
	logo1.set("backgroundColor", "#9DCEFF");
	this.libraryLogo.append(logo1);
	
	var logo2 = new com.rogers.rci.ngws.LibraryLogoContentPanel();
	logo2.init();
	logo2.set("backgroundColor", "#5BADFF");
	this.libraryLogo.append(logo2);
	
	var logo3 = new com.rogers.rci.ngws.LibraryLogoContentPanel();
	logo3.init();
	logo3.set("backgroundColor", "#178BFF");
	this.libraryLogo.append(logo3);
	
	var logo4 = new com.rogers.rci.ngws.LibraryLogoContentPanel();
	logo4.init();
	logo4.set("backgroundColor", "#0075EA");
	this.libraryLogo.append(logo4);
	
	var anim = new js.anim.Animator();
	anim.addSubject(function(){SELF.libraryLogo.show();logo1.show();logo2.show();logo3.show();logo4.show();libraryText.show();});
	anim.addSubject(new js.anim.SequentialPropertyActor(logo1, "left", 1000, 650));
	anim.addSubject(new js.anim.SequentialPropertyActor(logo2, "left", 1000, 690));
	anim.addSubject(new js.anim.SequentialPropertyActor(logo3, "left", 1000, 730));
	anim.addSubject(new js.anim.SequentialPropertyActor(logo4, "left", 1000, 770));
	anim.addSubject(new js.anim.SequentialPropertyActor(libraryText, "left", 1000, 652));
	
	setTimeout(function(){anim.play()}, 700);
	setTimeout(function(){SELF.libraryLogo.hide()}, 5000);
}



com.rogers.rci.ngws.Application.prototype.show = function() {
	// show the login window...
	this.loginWindow.show();
	//this.engineAdminWindow.show();
}



com.rogers.rci.ngws.Application.prototype.start = function() {
	// init...
	this.init();
	
	// show the library logo...
	this.showLibraryLogo();
	
	// show...
	this.show();
	
	// get properties...
	this.getProperties();
}



com.rogers.rci.ngws.Application.prototype.getMessageType = function(id) {
	var ret = null;
	
	for(var i = 0; i < this.properties.types.length; i++) {
		if(this.properties.types[i].MSGTYPE_ID == id) {
			ret = this.properties.types[i];
			break;
		}
	}
	
	return ret;
}



com.rogers.rci.ngws.Application.prototype.getError = function(cd) {
	var ret = null;
	
	for(var i = 0; i < this.properties.errors.length; i++) {
		if(this.properties.errors[i].ERR_CD == cd) {
			ret = this.properties.errors[i];
			break;
		}
	}
	
	if(ret == null) {
		ret = {};
		ret.ERR_CD = cd;
		ret.ERR_NAME = cd;
	}
	
	return ret;
}



com.rogers.rci.ngws.Application.prototype.getStatus = function(id) {
	var ret = null;
	
	for(var i = 0; i < this.properties.statuses.length; i++) {
		if(this.properties.statuses[i].STATUS_IN == id) {
			ret = this.properties.statuses[i];
			break;
		}
	}
	
	return ret;
}



com.rogers.rci.ngws.Application.prototype.getProperties = function() {
	// fix Firefox...
    if (js.util.Browser.isFirefox) {
        try {
            netscape.security.PrivilegeManager.enablePrivilege("UniversalBrowserRead");
        } catch (e) {
            //alert("Permission UniversalBrowserRead denied.");
        }
    }
    
    // TO DO...
    var xmlHttpRequest = new js.ajax.XMLHttpRequest();
    xmlHttpRequest.set("url", this.appServicesURL);
    xmlHttpRequest.setVar("cmd", "getProperties");
    xmlHttpRequest.object = this;
    xmlHttpRequest.open();

    xmlHttpRequest.onComplete = function() {
        //alert(this.response);
        
        // eval the JSON data...
        var data = null;
        eval("data = " + this.response);
        
        // ...
        this.object.properties = data;
    }
    xmlHttpRequest.onError = function() {
        alert("ERROR while executing getProperties: " + this.response);
    }

	try {
    	xmlHttpRequest.send();
	} catch(e) {
		alert("ERROR (getProperties):\n\n" + e);
	}
}