package com.rogers.mqclient.cache;

public class MQSSCToMQCacheVO extends MQCacheBase
{
	private static MQCacheBase mqCacheVO = null;
	
	public static MQCacheBase getInstance()
	{
		synchronized( MQSSCToMQCacheVO.class )
		{
			if ( mqCacheVO == null ) mqCacheVO = new MQCacheBase();
		}
		return mqCacheVO;
	}
	
}
