package com.rogers.rci.wsl;

import javax.ejb.SessionBean;
import javax.naming.InitialContext;

import weblogic.ejb.GenericSessionBean;
import weblogic.ejbgen.Session;
import weblogic.ejbgen.JndiName;
import weblogic.ejbgen.FileGeneration;
import weblogic.ejbgen.Constants;
import weblogic.ejbgen.RemoteMethod;

import com.rogers.wireless.schemas.activateSubscriber.request.ActivateSubscriberRequestDocument;
import com.rogers.wireless.schemas.activateSubscriber.response.ActivateSubscriberResponseDocument;
import com.rogers.wireless.schemas.addCallingCard.request.AddCallingCardRequestDocument;
import com.rogers.wireless.schemas.addCallingCard.response.AddCallingCardResponseDocument;
import com.rogers.wireless.schemas.bulkReleaseNumber.request.BulkReleaseNumberRequestDocument;
import com.rogers.wireless.schemas.bulkReleaseNumber.response.BulkReleaseNumberResponseDocument;
import com.rogers.wireless.schemas.bulkReserveNumber.request.BulkReserveNumberRequestDocument;
import com.rogers.wireless.schemas.bulkReserveNumber.response.BulkReserveNumberResponseDocument;
import com.rogers.wireless.schemas.cancelSubscriber.request.CancelSubscriberRequestDocument;
import com.rogers.wireless.schemas.cancelSubscriber.response.CancelSubscriberResponseDocument;
import com.rogers.wireless.schemas.changePortedInSubscriberNumber.request.ChangePortedInSubscriberNumberRequestDocument;
import com.rogers.wireless.schemas.changePortedInSubscriberNumber.response.ChangePortedInSubscriberNumberResponseDocument;
import com.rogers.wireless.schemas.changeSubscriberNumber.request.ChangeSubscriberNumberRequestDocument;
import com.rogers.wireless.schemas.changeSubscriberNumber.response.ChangeSubscriberNumberResponseDocument;
import com.rogers.wireless.schemas.checkCvmNumber.CheckCvmNumberRequestDocument;
import com.rogers.wireless.schemas.checkCvmNumber.CheckCvmNumberResponseDocument;
import com.rogers.wireless.schemas.consolidate.request.ConsolidateRequestDocument;
import com.rogers.wireless.schemas.consolidate.response.ConsolidateResponseDocument;
import com.rogers.wireless.schemas.consolidateX.request.ConsolidateXRequestDocument;
import com.rogers.wireless.schemas.consolidateX.response.ConsolidateXResponseDocument;
import com.rogers.wireless.schemas.deconsolidate.request.DeconsolidateRequestDocument;
import com.rogers.wireless.schemas.deconsolidate.response.DeconsolidateResponseDocument;
import com.rogers.wireless.schemas.extendAgingPeriod.request.ExtendAgingPeriodRequestDocument;
import com.rogers.wireless.schemas.extendAgingPeriod.response.ExtendAgingPeriodResponseDocument;
import com.rogers.wireless.schemas.portOutTelephoneNumber.request.PortOutTelephoneNumberRequestDocument;
import com.rogers.wireless.schemas.portOutTelephoneNumber.response.PortOutTelephoneNumberResponseDocument;
import com.rogers.wireless.schemas.releaseNumber.request.ReleaseNumberRequestDocument;
import com.rogers.wireless.schemas.releaseNumber.response.ReleaseNumberResponseDocument;
import com.rogers.wireless.schemas.removeCallingCard.request.RemoveCallingCardRequestDocument;
import com.rogers.wireless.schemas.removeCallingCard.response.RemoveCallingCardResponseDocument;
import com.rogers.wireless.schemas.reserveNumber.request.ReserveNumberRequestDocument;
import com.rogers.wireless.schemas.reserveNumber.response.ReserveNumberResponseDocument;
import com.rogers.wireless.schemas.resetCvmPassword.ResetCvmPasswordRequestDocument;
import com.rogers.wireless.schemas.resetCvmPassword.ResetCvmPasswordResponseDocument;
import com.rogers.wireless.schemas.retrieveAvailableNumbers.request.RetrieveAvailableNumbersRequestDocument;
import com.rogers.wireless.schemas.retrieveAvailableNumbers.response.RetrieveAvailableNumbersResponseDocument;
import com.rogers.wireless.schemas.retrieveBanEligibility.request.RetrieveBanEligibilityRequestDocument;
import com.rogers.wireless.schemas.retrieveBanEligibility.response.RetrieveBanEligibilityResponseDocument;
import com.rogers.wireless.schemas.retrieveCallingCards.request.RetrieveCallingCardsRequestDocument;
import com.rogers.wireless.schemas.retrieveCallingCards.response.RetrieveCallingCardsResponseDocument;
import com.rogers.wireless.schemas.retrieveCvmConfiguration.RetrieveCvmConfigurationRequestDocument;
import com.rogers.wireless.schemas.retrieveCvmConfiguration.RetrieveCvmConfigurationResponseDocument;
import com.rogers.wireless.schemas.retrieveCvmNumberList.RetrieveCvmNumberListRequestDocument;
import com.rogers.wireless.schemas.retrieveCvmNumberList.RetrieveCvmNumberListResponseDocument;
import com.rogers.wireless.schemas.retrieveEquipmentWarranty.request.RetrieveEquipmentWarrantyRequestDocument;
import com.rogers.wireless.schemas.retrieveEquipmentWarranty.response.RetrieveEquipmentWarrantyResponseDocument;
import com.rogers.wireless.schemas.retrieveRollOverUsage.request.RetrieveRollOverUsageRequestDocument;
import com.rogers.wireless.schemas.retrieveRollOverUsage.response.RetrieveRollOverUsageResponseDocument;
import com.rogers.wireless.schemas.retrieveTelephoneNumberListInfo.request.RetrieveTelephoneNumberListInfoRequestDocument;
import com.rogers.wireless.schemas.retrieveTelephoneNumberListInfo.response.RetrieveTelephoneNumberListInfoResponseDocument;
import com.rogers.wireless.schemas.retrieveTelephoneNumberStatus.request.RetrieveTelephoneNumberStatusRequestDocument;
import com.rogers.wireless.schemas.retrieveTelephoneNumberStatus.response.RetrieveTelephoneNumberStatusResponseDocument;
import com.rogers.wireless.schemas.saveCvmConfiguration.SaveCvmConfigurationRequestDocument;
import com.rogers.wireless.schemas.saveCvmConfiguration.SaveCvmConfigurationResponseDocument;
import com.rogers.wireless.schemas.serviceRequest.ServiceRequestDocument;
import com.rogers.wireless.schemas.serviceRequest.ServiceResponseDocument;
import com.rogers.wireless.schemas.setBsnCancelIndicator.request.SetBsnCancelIndicatorRequestDocument;
import com.rogers.wireless.schemas.setBsnCancelIndicator.response.SetBsnCancelIndicatorResponseDocument;
import com.rogers.wireless.schemas.setPrimaryDPN.request.SetPrimaryDPNRequestDocument;
import com.rogers.wireless.schemas.setPrimaryDPN.response.SetPrimaryDPNResponseDocument;
import com.rogers.wireless.schemas.subscriberDiscount.GetSubscriberDiscountRequestDocument;
import com.rogers.wireless.schemas.subscriberDiscount.GetSubscriberDiscountResponseDocument;
import com.rogers.wireless.schemas.verifyPhoneNumberAgainstAddress.request.VerifyPhoneNumberAgainstAddressRequestDocument;
import com.rogers.wireless.schemas.verifyPhoneNumberAgainstAddress.response.VerifyPhoneNumberAgainstAddressResponseDocument;
import com.rogers.wireless.schemas.verifyPortedInNumberEligibility.request.VerifyPortedInNumberEligibilityRequestDocument;
import com.rogers.wireless.schemas.verifyPortedInNumberEligibility.response.VerifyPortedInNumberEligibilityResponseDocument;

/**
 * GenericSessionBean subclass automatically generated by Workshop.
 *
 * Please complete the ejbCreate method as needed to properly initialize new instances of your bean and add
 * all required business methods. Also, review the Session, JndiName and FileGeneration annotations
 * to ensure the settings match the bean's intended use.
 */
@Session(ejbName = "SubscriberServicesEJBFacade", initialBeansInFreePool="4", maxBeansInFreePool="10", transTimeoutSeconds="30", isClusterable=Constants.Bool.FALSE, methodsAreIdempotent=Constants.Bool.FALSE)
@JndiName(remote = "ejb/wsl/SubscriberServicesEJBFacadeRemoteHome")
@FileGeneration(remoteClass = Constants.Bool.TRUE, remoteHome = Constants.Bool.TRUE, localClass = Constants.Bool.FALSE, localHome = Constants.Bool.FALSE)
public class SubscriberServicesEJBFacade extends GenericSessionBean implements
		SessionBean {
	private static final long serialVersionUID = 1L;

	/* (non-Javadoc)
	 * @see weblogic.ejb.GenericSessionBean#ejbCreate()
	 */
	public void ejbCreate() {
		// IMPORTANT: Add your code here
	}

	private static final String GET_SWITCH_EJB_JNDI = "ejb/wsl/GetSwitchForNewTNEJB";

	// IMPORTANT: Add business methods
	//TODO: replace usage of it with OSB code
 	//private com.rogers.rci.icm.SubscriberServicesICMHelper subsServ;

@RemoteMethod
public org.apache.xmlbeans.XmlObject retrieveAvailableNumbers( org.apache.xmlbeans.XmlObject xmldata )
	throws Exception
{
	WSLLogger.getLogger().info("retrieveAvailableNumbers(): request for ban subscribers");
	long startTime = System.currentTimeMillis();

	RetrieveAvailableNumbersResponseDocument response = com.rogers.rci.wsl.services.subscriberservices.AvailableNumbers.availableNumbers( RetrieveAvailableNumbersRequestDocument.Factory.parse( xmldata.xmlText()) );
	WSLLogger.getLogger().info("retrieveAvailableNumbers(): request for ban subscribers duration: " + (System.currentTimeMillis() - startTime));

	return response;
}


	@RemoteMethod
public org.apache.xmlbeans.XmlObject releaseNumber( org.apache.xmlbeans.XmlObject xmldata )
	throws Exception
{
	WSLLogger.getLogger().info("releaseNumber(): request for release number");
	long startTime = System.currentTimeMillis();

	ReleaseNumberResponseDocument response = com.rogers.rci.wsl.services.subscriberservices.ReleaseNumber.releaseNumber( ReleaseNumberRequestDocument.Factory.parse( xmldata.xmlText()) );
	WSLLogger.getLogger().info("releaseNumber(): request for release number duration: " + (System.currentTimeMillis() - startTime));

	return response;
}



	@RemoteMethod
public org.apache.xmlbeans.XmlObject reserveNumber( org.apache.xmlbeans.XmlObject xmldata )
	throws Exception
{
	WSLLogger.getLogger().info("reserveNumber(): request for reserve number");
	long startTime = System.currentTimeMillis();

	ReserveNumberResponseDocument response = com.rogers.rci.wsl.services.subscriberservices.ReserveNumber.reserveNumber( ReserveNumberRequestDocument.Factory.parse( xmldata.xmlText()) );
	WSLLogger.getLogger().info("reserveNumber(): request for reserve number duration: " + (System.currentTimeMillis() - startTime));

	return response;
}


	@RemoteMethod
public org.apache.xmlbeans.XmlObject verifyPortedInNumberEligibility( org.apache.xmlbeans.XmlObject xmldata )
	throws Exception
{
	WSLLogger.getLogger().info("verifyPortedInNumberEligibility(): request for release number");
	long startTime = System.currentTimeMillis();

	VerifyPortedInNumberEligibilityResponseDocument response = com.rogers.rci.wsl.services.subscriberservices.VerifyPortedInNumberEligibility.verifyPortedInNumberEligibility( VerifyPortedInNumberEligibilityRequestDocument.Factory.parse( xmldata.xmlText()) );
	WSLLogger.getLogger().info("verifyPortedInNumberEligibility(): request for release number duration: " + (System.currentTimeMillis() - startTime));

	return response;
}


	@RemoteMethod
public org.apache.xmlbeans.XmlObject activateSubscriber(org.apache.xmlbeans.XmlObject xmldata )
	throws Exception
{
	WSLLogger.getLogger().info("activateSubscriber(): request activate subscriber");
	long startTime = System.currentTimeMillis();

	ActivateSubscriberResponseDocument response = com.rogers.rci.wsl.services.subscriberservices.ActivateSubscriber.activateSubscriber( ActivateSubscriberRequestDocument.Factory.parse( xmldata.xmlText()) );
	WSLLogger.getLogger().info("activateSubscriber(): request activate subscriber duration: " + (System.currentTimeMillis() - startTime));

	// ICM: it will log interaction
	//TODO: move into OSB
    //subsServ.createActivateSubscriber(xmldata, response);

	return response;
}


	@RemoteMethod
public org.apache.xmlbeans.XmlObject setPrimaryDPN( org.apache.xmlbeans.XmlObject xmldata )
	throws Exception
{
	WSLLogger.getLogger().info("setPrimaryDPN(): request to set primary DPN");
	long startTime = System.currentTimeMillis();

	SetPrimaryDPNResponseDocument response = com.rogers.rci.wsl.services.subscriberservices.SetPrimaryDPN.setPrimaryDPN( SetPrimaryDPNRequestDocument.Factory.parse( xmldata.xmlText()) );
	WSLLogger.getLogger().info("setPrimaryDPN(): request to set primary DPN duration: " + (System.currentTimeMillis() - startTime));

	return response;
}



	@RemoteMethod
public org.apache.xmlbeans.XmlObject setBsnCancelIndicator( org.apache.xmlbeans.XmlObject xmldata )
	throws Exception
{
	WSLLogger.getLogger().info("setBsnCancelIndicator(): request");
	long startTime = System.currentTimeMillis();

	SetBsnCancelIndicatorResponseDocument response = com.rogers.rci.wsl.services.subscriberservices.SetBsnCancelIndicator.setBsnCancelIndicator( SetBsnCancelIndicatorRequestDocument.Factory.parse( xmldata.xmlText()) );
	WSLLogger.getLogger().info("setBsnCancelIndicator(): request duration: " + (System.currentTimeMillis() - startTime));

	return response;
}


	@RemoteMethod
public org.apache.xmlbeans.XmlObject verifyPhoneNumberAgainstAddress( org.apache.xmlbeans.XmlObject xmldata )
	throws Exception
{
	WSLLogger.getLogger().info("verifyPhoneNumberAgainstAddress(): request");
	long startTime = System.currentTimeMillis();

	VerifyPhoneNumberAgainstAddressResponseDocument response = com.rogers.rci.wsl.services.subscriberservices.VerifyPhoneNumberAgainstAddress.verifyPhoneNumberAgainstAddress( VerifyPhoneNumberAgainstAddressRequestDocument.Factory.parse( xmldata.xmlText()) );
	WSLLogger.getLogger().info("verifyPhoneNumberAgainstAddress(): request duration: " + (System.currentTimeMillis() - startTime));

	return response;
}



	@RemoteMethod
public org.apache.xmlbeans.XmlObject portOutTelephoneNumber( org.apache.xmlbeans.XmlObject xmldata )
	throws Exception
{
	WSLLogger.getLogger().info("portOutTelephoneNumber(): request");
	long startTime = System.currentTimeMillis();

	PortOutTelephoneNumberResponseDocument response = com.rogers.rci.wsl.services.subscriberservices.PortOutTelephoneNumber.portOutTelephoneNumber( PortOutTelephoneNumberRequestDocument.Factory.parse( xmldata.xmlText()) );
	WSLLogger.getLogger().info("portOutTelephoneNumber(): request duration: " + (System.currentTimeMillis() - startTime));

	return response;
}



	@RemoteMethod
public org.apache.xmlbeans.XmlObject cancelSubscriber( org.apache.xmlbeans.XmlObject xmldata )
	throws Exception
{
	WSLLogger.getLogger().info("cancelSubscriber(): request");
	long startTime = System.currentTimeMillis();

	CancelSubscriberResponseDocument response = com.rogers.rci.wsl.services.subscriberservices.CancelSubscriber.cancelSubscriber( CancelSubscriberRequestDocument.Factory.parse( xmldata.xmlText()) );
	WSLLogger.getLogger().info("cancelSubscriber(): request duration: " + (System.currentTimeMillis() - startTime));

	// ICM: it will log interaction
	//TODO: move inside OSB
    //subsServ.createCancelSubscriber(xmldata, response);

	return response;
}



	@RemoteMethod
public org.apache.xmlbeans.XmlObject changeSubscriberNumber( org.apache.xmlbeans.XmlObject xmldata )
	throws Exception
{
	WSLLogger.getLogger().info("changeSubscriberNumber(): request");
	long startTime = System.currentTimeMillis();

	ChangeSubscriberNumberResponseDocument response = com.rogers.rci.wsl.services.subscriberservices.ChangeSubscriberNumber.changeSubscriberNumber( ChangeSubscriberNumberRequestDocument.Factory.parse( xmldata.xmlText()) );
	WSLLogger.getLogger().info("changeSubscriberNumber(): request duration: " + (System.currentTimeMillis() - startTime));

	// ICM: it will log interaction
	//TODO: move inside OSB
    //subsServ.createChangeSubscriberNumberInteraction(xmldata, response);

	return response;
}



	@RemoteMethod
public org.apache.xmlbeans.XmlObject changePortedInSubscriberNumber( org.apache.xmlbeans.XmlObject xmldata )
	throws Exception
{
	WSLLogger.getLogger().info("changePortedInSubscriberNumber(): request");
	long startTime = System.currentTimeMillis();

	ChangePortedInSubscriberNumberResponseDocument response = com.rogers.rci.wsl.services.subscriberservices.ChangePortedInSubscriberNumber.changePortedInSubscriberNumber( ChangePortedInSubscriberNumberRequestDocument.Factory.parse( xmldata.xmlText()) );
	WSLLogger.getLogger().info("changePortedInSubscriberNumber(): request duration: " + (System.currentTimeMillis() - startTime));

	// ICM: it will log interaction
	//TODO: Move inside OSB
    //subsServ.createChangePortedInSubscriberNumber(xmldata, response);

	return response;
}


	@RemoteMethod
public org.apache.xmlbeans.XmlObject retrieveTelephoneNumberStatus( org.apache.xmlbeans.XmlObject xmldata )
	throws Exception
{
	WSLLogger.getLogger().info("retrieveTelephoneNumberStatus(): request");
	long startTime = System.currentTimeMillis();

	RetrieveTelephoneNumberStatusResponseDocument response = com.rogers.rci.wsl.services.subscriberservices.TelephoneNumberStatus.retrieveTelephoneNumberStatus( RetrieveTelephoneNumberStatusRequestDocument.Factory.parse( xmldata.xmlText()) );
	WSLLogger.getLogger().info("retrieveTelephoneNumberStatus(): request duration: " + (System.currentTimeMillis() - startTime));

	return response;
}



	@RemoteMethod
public org.apache.xmlbeans.XmlObject addCallingCard( org.apache.xmlbeans.XmlObject xmldata )
	throws Exception
{
	WSLLogger.getLogger().info("addCallingCard(): request");
	long startTime = System.currentTimeMillis();

	AddCallingCardResponseDocument response = com.rogers.rci.wsl.services.subscriberservices.AddCallingCard.addCallingCard( AddCallingCardRequestDocument.Factory.parse( xmldata.xmlText()) );
	WSLLogger.getLogger().info("addCallingCard(): request duration: " + (System.currentTimeMillis() - startTime));

	return response;
}

	@RemoteMethod
public org.apache.xmlbeans.XmlObject retrieveCallingCards( org.apache.xmlbeans.XmlObject xmldata )
	throws Exception
{
	WSLLogger.getLogger().info("retrieveCallingCards(): request");
	long startTime = System.currentTimeMillis();

	RetrieveCallingCardsResponseDocument response = com.rogers.rci.wsl.services.subscriberservices.RetrieveCallingCard.retrieveCallingCard( RetrieveCallingCardsRequestDocument.Factory.parse( xmldata.xmlText()) );
	WSLLogger.getLogger().info("retrieveCallingCards(): request duration: " + (System.currentTimeMillis() - startTime));

	return response;
}


	@RemoteMethod
public org.apache.xmlbeans.XmlObject removeCallingCard( org.apache.xmlbeans.XmlObject xmldata )
	throws Exception
{
	WSLLogger.getLogger().info("removeCallingCard(): request");
	long startTime = System.currentTimeMillis();

	RemoveCallingCardResponseDocument response = com.rogers.rci.wsl.services.subscriberservices.RemoveCallingCard.removeCallingCard( RemoveCallingCardRequestDocument.Factory.parse( xmldata.xmlText()) );
	WSLLogger.getLogger().info("removeCallingCard(): request duration: " + (System.currentTimeMillis() - startTime));

	return response;
}


	@RemoteMethod
public org.apache.xmlbeans.XmlObject extendAgingPeriod( org.apache.xmlbeans.XmlObject xmldata )
	throws Exception
{
	WSLLogger.getLogger().info("extendAgingPeriod(): request");
	long startTime = System.currentTimeMillis();

	ExtendAgingPeriodResponseDocument response = com.rogers.rci.wsl.services.subscriberservices.ExtendAgingPeriod.extendAgingPeriod( ExtendAgingPeriodRequestDocument.Factory.parse( xmldata.xmlText()) );
	WSLLogger.getLogger().info("extendAgingPeriod(): request duration: " + (System.currentTimeMillis() - startTime));

	return response;
}



	@RemoteMethod
public org.apache.xmlbeans.XmlObject deconsolidate( org.apache.xmlbeans.XmlObject xmldata )
	throws Exception
{
	WSLLogger.getLogger().info("deconsolidate(): request");
	long startTime = System.currentTimeMillis();

	DeconsolidateResponseDocument response = com.rogers.rci.wsl.services.subscriberservices.ConsolidateAccount.deConsolidate( DeconsolidateRequestDocument.Factory.parse( xmldata.xmlText()) );
	WSLLogger.getLogger().info("deconsolidate(): request duration: " + (System.currentTimeMillis() - startTime));

	//TODO: Move to OSB
	// ICM: it will log interaction
    // BT project, R0710-01, for V21 decon with BT subscriber, add "~" to subscriber# at the end
	/**
	DeconsolidateRequestDocument xmldata1 = DeconsolidateRequestDocument.Factory.parse( xmldata.xmlText());
	String reqSubNum = xmldata1.getDeconsolidateRequest().getSubscriberNumber();
    if ( reqSubNum!= null && reqSubNum.indexOf("~") > 0 && reqSubNum.length() == 15 ) {
    	xmldata1.getDeconsolidateRequest().setSubscriberNumber(reqSubNum.substring(0, reqSubNum.indexOf("~")));
    }
    subsServ.createDeconsolidate(xmldata1, response);
	*/
	return response;
}



	@RemoteMethod
public org.apache.xmlbeans.XmlObject consolidate( org.apache.xmlbeans.XmlObject xmldata )
	throws Exception
{
	WSLLogger.getLogger().info("consolidate(): request");
	long startTime = System.currentTimeMillis();

	ConsolidateResponseDocument response = com.rogers.rci.wsl.services.subscriberservices.ConsolidateAccount.consolidate( ConsolidateRequestDocument.Factory.parse( xmldata.xmlText()) );
	WSLLogger.getLogger().info("consolidate(): request duration: " + (System.currentTimeMillis() - startTime));

	// ICM: it will log interaction
	//TODO: Move to OSB
    //subsServ.createConsolidate(xmldata, response);

	return response;
}



	@RemoteMethod
public org.apache.xmlbeans.XmlObject setAlternativeNumber( org.apache.xmlbeans.XmlObject xmldata )
	throws Exception
{
	WSLLogger.getLogger().info( "setAlternativeNumber(): request" );
	long startTime = System.currentTimeMillis();

	ServiceResponseDocument response = com.rogers.rci.wsl.services.subscriberservices.SetAlternativeNumber.setAlternativeNumber( ServiceRequestDocument.Factory.parse( xmldata.xmlText()) );
	WSLLogger.getLogger().info( "setAlternativeNumber(): request duration: " + (System.currentTimeMillis() - startTime));

	return response;
}


	@RemoteMethod
public org.apache.xmlbeans.XmlObject retrieveCVMConfiguration(  org.apache.xmlbeans.XmlObject xmldata )
	throws Exception
{
	WSLLogger.getLogger().info( "retrieveCVMConfiguration(): request" );
	long startTime = System.currentTimeMillis();

	RetrieveCvmConfigurationResponseDocument response = com.rogers.rci.wsl.services.subscriberservices.CvmServices.retrieveCvmConfiguration( RetrieveCvmConfigurationRequestDocument.Factory.parse( xmldata.xmlText()) );;
	WSLLogger.getLogger().info( "retrieveCVMConfiguration(): request duration: " + (System.currentTimeMillis() - startTime));

	return response;
}


	@RemoteMethod
public org.apache.xmlbeans.XmlObject saveCVMConfiguration(  org.apache.xmlbeans.XmlObject xmldata )
	throws Exception
{
	WSLLogger.getLogger().info( "saveCVMConfiguration(): request" );
	long startTime = System.currentTimeMillis();

	SaveCvmConfigurationResponseDocument response = com.rogers.rci.wsl.services.subscriberservices.CvmServices.saveCvmConfiguration( SaveCvmConfigurationRequestDocument.Factory.parse( xmldata.xmlText()) );
	WSLLogger.getLogger().info( "saveCVMConfiguration(): request duration: " + (System.currentTimeMillis() - startTime));

	return response;
}

	@RemoteMethod
public org.apache.xmlbeans.XmlObject deleteCVMConfiguration(  org.apache.xmlbeans.XmlObject xmldata )
	throws Exception
{
	WSLLogger.getLogger().info( "deleteCVMConfiguration(): request" );
	long startTime = System.currentTimeMillis();

	ServiceResponseDocument response = com.rogers.rci.wsl.services.subscriberservices.CvmServices.removeCvmConfiguration( ServiceRequestDocument.Factory.parse( xmldata.xmlText()) );
	WSLLogger.getLogger().info( "deleteCVMConfiguration(): request duration: " + (System.currentTimeMillis() - startTime));

	return response;
}


	@RemoteMethod
public org.apache.xmlbeans.XmlObject retrieveCVMNumberList(  org.apache.xmlbeans.XmlObject xmldata )
	throws Exception
{
	WSLLogger.getLogger().info( "retrieveCVMNumberList(): request" );
	long startTime = System.currentTimeMillis();

	RetrieveCvmNumberListResponseDocument response = com.rogers.rci.wsl.services.subscriberservices.CvmServices.retrieveCvmNumberList( RetrieveCvmNumberListRequestDocument.Factory.parse( xmldata.xmlText()) );
	WSLLogger.getLogger().info( "retrieveCVMNumberList(): request duration: " + (System.currentTimeMillis() - startTime));

	return response;
}


	@RemoteMethod
public org.apache.xmlbeans.XmlObject checkCVMNumberStatus( org.apache.xmlbeans.XmlObject xmldata )
	throws Exception
{
	WSLLogger.getLogger().info( "checkCVMNumberStatus(): request" );
	long startTime = System.currentTimeMillis();

	CheckCvmNumberResponseDocument response = com.rogers.rci.wsl.services.subscriberservices.CvmServices.checkCvmSubscriber( CheckCvmNumberRequestDocument.Factory.parse( xmldata.xmlText()) );
	WSLLogger.getLogger().info( "checkCVMNumberStatus(): request duration: " + (System.currentTimeMillis() - startTime));

	return response;
}


	@RemoteMethod
public org.apache.xmlbeans.XmlObject resetCVMPassword( org.apache.xmlbeans.XmlObject xmldata )
	throws Exception
{
	WSLLogger.getLogger().info( "resetCVMPassword(): request" );
	long startTime = System.currentTimeMillis();

	ResetCvmPasswordResponseDocument response = com.rogers.rci.wsl.services.subscriberservices.CvmServices.resetCvmPassword( ResetCvmPasswordRequestDocument.Factory.parse( xmldata.xmlText()) );
	WSLLogger.getLogger().info( "resetCVMPassword(): request duration: " + (System.currentTimeMillis() - startTime));

	return response;
}

	@RemoteMethod
public org.apache.xmlbeans.XmlObject resetVMProvisioning(  org.apache.xmlbeans.XmlObject xmldata )
	throws Exception
{
	WSLLogger.getLogger().info( "resetVMProvisioning(): request" );
	long startTime = System.currentTimeMillis();

	ServiceResponseDocument response = com.rogers.rci.wsl.services.subscriberservices.CvmServices.resetVMProvisioning( ServiceRequestDocument.Factory.parse( xmldata.xmlText()) );
	WSLLogger.getLogger().info( "resetVMProvisioning(): request duration: " + (System.currentTimeMillis() - startTime));

	return response;
}


	@RemoteMethod
public java.lang.String retrieveSwitchForNewTN(java.lang.String rateCentre, java.lang.String existingPhoneNumber, java.lang.String numberType)
	throws Exception
{
		//GetSwitchForNewTNEJBFacade instance = null;
		GetSwitchForNewTNEJBFacadeLocal instance = null;
		String response = null;

		try
		{
			Object ejbobject = lookup( GET_SWITCH_EJB_JNDI );

			GetSwitchForNewTNEJBFacadeLocalHome home = (GetSwitchForNewTNEJBFacadeLocalHome)ejbobject;
			instance = home.create();
			response = instance.retrieveSwitchForNewTN(rateCentre, existingPhoneNumber, numberType);
//			instance = (GetSwitchForNewTNEJBFacade)ejbobject;
//			response = instance.retrieveSwitchForNewTN(rateCentre, existingPhoneNumber, numberType);
		}
		catch (Exception ex){
			//ex.printStackTrace();
			WSLLogger.getLogger().logException(ex);
			throw ex;
		}

		return response;
}

	//-----cloned retrieveSwitchForNewTN() to pass provinceCd toward APILINK ----- Jan 2011
@RemoteMethod
public java.lang.String retrieveSwitchWithProvForNewTN(java.lang.String rateCentre, java.lang.String existingPhoneNumber, java.lang.String numberType, java.lang.String provCd2Ch)
	throws Exception
{
	GetSwitchForNewTNEJBFacadeLocal instance = null;
	String response = null;

	try
	{
		Object ejbobject = lookup( GET_SWITCH_EJB_JNDI );

		GetSwitchForNewTNEJBFacadeLocalHome home = (GetSwitchForNewTNEJBFacadeLocalHome)ejbobject;
		instance = home.create();
		response = instance.retrieveSwitchForNewTNWithProv(rateCentre, existingPhoneNumber, numberType, provCd2Ch);
	}
	catch (Exception ex){
		//ex.printStackTrace();
		WSLLogger.getLogger().logException(ex);
		throw ex;
	}

	return response;
}


@RemoteMethod
public org.apache.xmlbeans.XmlObject retrieveRollOverUsage(org.apache.xmlbeans.XmlObject xmldata)
	throws Exception
{
    WSLLogger.getLogger().info( "retrieveRollOverUsage(): request" );
    long startTime = System.currentTimeMillis();

    RetrieveRollOverUsageResponseDocument response = com.rogers.rci.wsl.services.subscriberservices.RetrieveRollOverUsage.getRollOverUsage( RetrieveRollOverUsageRequestDocument.Factory.parse( xmldata.xmlText()) );
    WSLLogger.getLogger().info( "retrieveRollOverUsage(): request duration: " + (System.currentTimeMillis() - startTime));

    return response;
}



@RemoteMethod
public org.apache.xmlbeans.XmlObject retrieveEquipmentWarranty( org.apache.xmlbeans.XmlObject xmldata )
	throws Exception
{
    WSLLogger.getLogger().info( "retrieveEquipmentWarranty(): request" );
    long startTime = System.currentTimeMillis();

    RetrieveEquipmentWarrantyResponseDocument response = com.rogers.rci.wsl.services.subscriberservices.RetrieveEquipmentWarranty.retrieveEquipmentWarranty(RetrieveEquipmentWarrantyRequestDocument.Factory.parse( xmldata.xmlText()));
    WSLLogger.getLogger().info( "retrieveEquipmentWarranty(): request duration: " + (System.currentTimeMillis() - startTime));

    return response;
}


	@RemoteMethod
public org.apache.xmlbeans.XmlObject retrieveTelephoneNumberListInfo(org.apache.xmlbeans.XmlObject xmldata)
	throws Exception
{
    WSLLogger.getLogger().info( "retrieveTelephoneNumberListInfo(): request" );
	long startTime = System.currentTimeMillis();

    RetrieveTelephoneNumberListInfoResponseDocument response = com.rogers.rci.wsl.services.subscriberservices.TelephoneNumberListInfo.telephoneNumberListInfo(RetrieveTelephoneNumberListInfoRequestDocument.Factory.parse( xmldata.xmlText()));
    WSLLogger.getLogger().info( "retrieveTelephoneNumberListInfo(): request duration: " + (System.currentTimeMillis() - startTime));

    return response;
}


	@RemoteMethod
public org.apache.xmlbeans.XmlObject retrieveBanEligibility(org.apache.xmlbeans.XmlObject xmldata)
	throws Exception
{
    WSLLogger.getLogger().info( "retrieveBanEligibility(): request" );
	long startTime = System.currentTimeMillis();

    RetrieveBanEligibilityResponseDocument response = com.rogers.rci.wsl.services.subscriberservices.BanEligibility.banEligibility(RetrieveBanEligibilityRequestDocument.Factory.parse( xmldata.xmlText()));
    WSLLogger.getLogger().info( "retrieveBanEligibility(): request duration: " + (System.currentTimeMillis() - startTime));

    return response;

}


	@RemoteMethod
public org.apache.xmlbeans.XmlObject bulkReserveTelephoneNumber(org.apache.xmlbeans.XmlObject xmldata)
	throws Exception
{
    WSLLogger.getLogger().info( "bulkReserveTelephoneNumber(): request" );
	long startTime = System.currentTimeMillis();

    BulkReserveNumberResponseDocument response = com.rogers.rci.wsl.services.subscriberservices.BulkReserveNumber.bulkReserveNumber(BulkReserveNumberRequestDocument.Factory.parse( xmldata.xmlText()));
    WSLLogger.getLogger().info( "bulkReserveTelephoneNumber(): request duration: " + (System.currentTimeMillis() - startTime));

    return response;
}


	@RemoteMethod
public org.apache.xmlbeans.XmlObject bulkReleaseTelephoneNumber(org.apache.xmlbeans.XmlObject xmldata)
	throws Exception
{

    WSLLogger.getLogger().info( "bulkReleaseTelephoneNumber(): request" );
	long startTime = System.currentTimeMillis();

    BulkReleaseNumberResponseDocument response = com.rogers.rci.wsl.services.subscriberservices.BulkReleaseNumber.bulkReleaseNumber(BulkReleaseNumberRequestDocument.Factory.parse( xmldata.xmlText()));
    WSLLogger.getLogger().info( "bulkReleaseTelephoneNumber(): request duration: " + (System.currentTimeMillis() - startTime));

    return response;

}


	@RemoteMethod
public org.apache.xmlbeans.XmlObject consolidateX( org.apache.xmlbeans.XmlObject xmldata )
	throws Exception
{
	WSLLogger.getLogger().info("consolidateX(): request");
	long startTime = System.currentTimeMillis();

	   ConsolidateXRequestDocument xmldatax = ConsolidateXRequestDocument.Factory.parse( xmldata.xmlText() );
	   ConsolidateRequestDocument consolidateRequest = ConsolidateRequestDocument.Factory.newInstance();
       consolidateRequest.addNewConsolidateRequest();

       consolidateRequest.getConsolidateRequest().setBAN(xmldatax.getConsolidateXRequest().getBAN());
       consolidateRequest.getConsolidateRequest().setChannelId( xmldatax.getConsolidateXRequest().getChannelId() );
       consolidateRequest.getConsolidateRequest().setInteractionId( xmldatax.getConsolidateXRequest().getInteractionId() );
       consolidateRequest.getConsolidateRequest().setSubscriberNumber( xmldatax.getConsolidateXRequest().getSubscriberNumber() );
       consolidateRequest.getConsolidateRequest().setTransactionId( xmldatax.getConsolidateXRequest().getTransactionId() );

       ConsolidateResponseDocument consolidateResponse = ConsolidateResponseDocument.Factory.newInstance();
       consolidateResponse.addNewConsolidateResponse();
       ConsolidateXResponseDocument consolidateXResponse = ConsolidateXResponseDocument.Factory.newInstance();
       consolidateXResponse.addNewConsolidateXResponse();

       String subscriberSourceSystem = (xmldatax.getConsolidateXRequest()!=null && xmldatax.getConsolidateXRequest().getSubscriberSourceSystem() !=null ) ? xmldatax.getConsolidateXRequest().getSubscriberSourceSystem().toString() : "SS";

       if ( "SS".equalsIgnoreCase( subscriberSourceSystem ))
       {

           consolidateResponse = (ConsolidateResponseDocument)consolidate( consolidateRequest );
           consolidateXResponse.getConsolidateXResponse().setError( consolidateResponse.getConsolidateResponse().getError() );
           consolidateXResponse.getConsolidateXResponse().setInteractionId(consolidateResponse.getConsolidateResponse().getInteractionId() );
           consolidateXResponse.getConsolidateXResponse().setTransactionId( consolidateResponse.getConsolidateResponse().getTransactionId() );

       }
       else if ( "BT".equalsIgnoreCase( subscriberSourceSystem ))
       {
           consolidateXResponse = com.rogers.rci.wsl.services.subscriberservices.ConsolidateAccount.consolidate( xmldatax );
           WSLLogger.getLogger().info("consolidateX(): request duration: " + (System.currentTimeMillis() - startTime));
           // ICM: it will log interaction

           consolidateResponse.getConsolidateResponse().setError( consolidateXResponse.getConsolidateXResponse().getError() );
           consolidateResponse.getConsolidateResponse().setInteractionId(consolidateXResponse.getConsolidateXResponse().getInteractionId() );
           consolidateResponse.getConsolidateResponse().setTransactionId( consolidateXResponse.getConsolidateXResponse().getTransactionId() );

       }

     //TODO: move into OSB
     //  subsServ.createConsolidate(consolidateRequest, consolidateResponse );

		return consolidateXResponse;
}



@RemoteMethod
public org.apache.xmlbeans.XmlObject retrieveSubscriberDiscountInfo( org.apache.xmlbeans.XmlObject xmldata )
	throws Exception
{
    WSLLogger.getLogger().info( "retrieveSubscriberDiscountInfo(): request" );
    long startTime = System.currentTimeMillis();

    GetSubscriberDiscountResponseDocument response = com.rogers.rci.wsl.services.subscriberservices.RetrieveSubscriberDiscountInfo.retrieveSubscriberDiscountInfo( GetSubscriberDiscountRequestDocument.Factory.parse( xmldata.xmlText()) );
    WSLLogger.getLogger().info( "retrieveSubscriberDiscountInfo(): request duration: " + (System.currentTimeMillis() - startTime));

    return response;
}

private Object lookup( String jndiname )
	throws javax.naming.NamingException
{
	javax.naming.Context ctx = null;

	try {
		ctx = new InitialContext();
		return ctx.lookup( jndiname );
	}
	finally
	{
		close( ctx );
	}
}

private void close( javax.naming.Context ctx )
{
	try {
		if ( ctx != null ) ctx.close();
	}
		catch ( Exception exc ) {}
	}
}