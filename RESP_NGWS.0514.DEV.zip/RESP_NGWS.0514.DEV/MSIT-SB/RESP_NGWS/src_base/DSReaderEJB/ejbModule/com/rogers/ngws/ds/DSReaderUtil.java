package com.rogers.ngws.ds;
import com.rogers.msit.ngws.common.services.AsyncAdaptorService;

public class DSReaderUtil {
	private static final String ELMS_OPERATION = "ELMS_OPERATION";
	private static final String ELMS_ECID = "ELMS_ECID";
	private static final String ECID_MATCH = "ECID>";
	
	public static void processMessage(javax.jms.Message msg)
		throws Exception
	{
		String msgReceived = null;		
		
		if (msg instanceof javax.jms.TextMessage)
		{
			javax.jms.TextMessage textMessage = (javax.jms.TextMessage) msg;
			msgReceived = textMessage.getText();
		}
		if (msg instanceof javax.jms.BytesMessage)
		{
		    javax.jms.BytesMessage textMessage = (javax.jms.BytesMessage) msg;
		    byte[] bytes = new byte[(int) textMessage.getBodyLength()];
		    textMessage.readBytes(bytes);

		    msgReceived = new String(bytes, "UTF-8");			    
		}
		
		//store to DB:
		AsyncAdaptorService.push( getOpType( msg ),getSzKey(msg, msgReceived), msgReceived  );
	}
	
	private static int getOpType( javax.jms.Message msg )
		throws Exception
	{
		String opType = msg.getStringProperty( ELMS_OPERATION );
		//System.out.println("operation:" + opType);
		
		int returnval = ( opType != null ? Integer.valueOf(opType).intValue(): 999); //if no parameter set then 'unknown' the 999 value is assumed
		return returnval;
	}	

	private static String getSzKey( javax.jms.Message msg, String sourceForSzKey )
		throws Exception
	{
		String szKey = msg.getStringProperty( ELMS_ECID );
		//System.out.println("szKeyFromHeader:" + szKey);
		
		if (szKey == null)
		{
			szKey = getSzKeyFromSource( sourceForSzKey );
			System.out.println("BLUE: DS did not provide ELMS_ECID in header");
		}
		return szKey;
	}
	
	private static String getSzKeyFromSource( String sourceForSzKey )
	throws Exception
	{
		String szKey = "";
		int startpoz = sourceForSzKey.indexOf( ECID_MATCH );
		int endpoz = sourceForSzKey.indexOf(ECID_MATCH, startpoz+1);
		
		if  (startpoz != -1 && endpoz != -1 )
		{			
			szKey = sourceForSzKey.substring(startpoz, endpoz);
			szKey = szKey.replaceAll( "[^0-9]", "" );
		}
		
		if ("".equalsIgnoreCase( szKey )) throw new Exception("BLUE: DS did not provide mandatory ECID value in JMS header AND message body");
		
		return szKey;
	}	
}