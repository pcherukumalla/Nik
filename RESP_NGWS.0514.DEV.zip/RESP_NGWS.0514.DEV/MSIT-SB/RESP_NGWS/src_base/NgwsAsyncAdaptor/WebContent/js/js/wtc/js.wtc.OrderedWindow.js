/*
****************************************************************************************************
 ezWebToolkit Library, http://ezwt.blogspot.com
****************************************************************************************************
Copyright [2006-2008] [Pro Net Systems Inc., http://www.pronetsystems.com]

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

	http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
***************************************************************************************************
*/



/*
------------------------------------------------------------------------------------------
OrderedWindow
------------------------------------------------------------------------------------------
*/
js.wtc.OrderedWindow = function() {
	js.wtc.Window.call(this);

	this.manager = null;
	
	this.objectType = "js.wtc.OrderedWindow";
}
js.wtc.OrderedWindow.prototype = new js.wtc.Window();
js.wtc.OrderedWindow.prototype.constructor = js.wtc.OrderedWindow;



js.wtc.OrderedWindow.prototype.init = function() {
	js.wtc.Window.prototype.init.call(this);

	if(this.resizeIn) {
		this.resize.onDrag = function(x, y) {
			if(parseInt(this.get("left")) < parseInt(this.parent.minWidth)) {
				this.set("left", parseInt(this.parent.minWidth) + "px");
			}
			if(parseInt(this.get("top")) < parseInt(this.parent.minHeight)) {
				this.set("top", parseInt(this.parent.minHeight) + "px");
			}
		
			this.parent.setWidth((parseInt(this.get("left")) + 10) + "px");
			this.parent.setHeight((parseInt(this.get("top")) + 10) + "px");
			
			this.parent.manager.recalc();
		};
	}
}



js.wtc.OrderedWindow.prototype.onDragStart = function(x, y) {
	//var SELF = js.wtc.Manager.childByViewport(this);
	//SELF.manager.onDragStart(SELF);
	this.manager.onDragStart(this);
}



js.wtc.OrderedWindow.prototype.onDragEnd = function(x, y) {
	//var SELF = js.wtc.Manager.childByViewport(this);
	//SELF.manager.onDragEnd(SELF);
	this.manager.onDragEnd(this);
}



js.wtc.OrderedWindow.prototype.show = function() {
	js.wtc.Window.prototype.show.call(this);

	this.manager.reorder();
	this.manager.recalc();
}



js.wtc.OrderedWindow.prototype.hide = function() {
	js.wtc.Window.prototype.hide.call(this);

	this.manager.recalc();
}



js.wtc.OrderedWindow.prototype.onMinRestore = function() {
	js.wtc.Window.prototype.onMinRestore.call(this);

	this.manager.recalc();
}



// deprecated now...
/*js.wtc.OrderedWindow.prototype.whenResize = function() {
	js.wtc.Window.prototype.whenResize.call(this);

	var SELF = js.wtc.Manager.childByViewport(this);
	SELF.parent.manager.recalc();
}*/
