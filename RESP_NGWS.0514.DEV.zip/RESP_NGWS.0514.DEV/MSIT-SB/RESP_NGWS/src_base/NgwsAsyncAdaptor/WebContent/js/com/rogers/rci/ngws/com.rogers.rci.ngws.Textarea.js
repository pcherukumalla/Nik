/*
------------------------------------------------------------------------------------------
Textarea
------------------------------------------------------------------------------------------
*/
com.rogers.rci.ngws.Textarea = function() {
	js.wtc.Textarea.call(this);
}
com.rogers.rci.ngws.Textarea.prototype = new js.wtc.Textarea();
com.rogers.rci.ngws.Textarea.prototype.constructor = com.rogers.rci.ngws.Textarea;



com.rogers.rci.ngws.Textarea.prototype.init = function() {
	js.wtc.Textarea.prototype.init.call(this);

	// set attributes...
	this.set("width", "180px");
	this.set("height", "17px");
	this.set("border", "1px solid rgb(120,172,255)");
}
