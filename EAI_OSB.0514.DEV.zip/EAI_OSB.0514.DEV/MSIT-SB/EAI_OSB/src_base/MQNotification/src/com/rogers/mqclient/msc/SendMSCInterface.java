package com.rogers.mqclient.msc;

import com.rogers.mqclient.send.SendInterface;

public interface SendMSCInterface  extends SendInterface
{
    public byte[] putMSCMessage (String txtMessage, String session, String typeOfCall ) throws Exception;
}
