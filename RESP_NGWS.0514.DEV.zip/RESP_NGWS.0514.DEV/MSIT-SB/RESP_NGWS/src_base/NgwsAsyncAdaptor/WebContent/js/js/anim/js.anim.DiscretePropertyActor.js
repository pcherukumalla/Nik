/*
****************************************************************************************************
 ezWebToolkit Library, http://www.ezwebtoolkit.com
****************************************************************************************************
Copyright [2006-2008] [Pro Net Systems Inc., http://www.pronetsystems.com]

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

	http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
***************************************************************************************************
*/



// Animates discrete styles, i.e. ones that do not scale but have discrete values
// that can't be interpolated
js.anim.DiscretePropertyActor = function(els, property, from, to, threshold) {
	this.els = js.anim.Animator.makeArray(els);
	this.property = js.anim.Animator.camelize(property);
	this.from = from;
	this.to = to;
	this.threshold = threshold || 0.5;

	this.objectType = "js.anim.DiscretePropertyActor";
}

js.anim.DiscretePropertyActor.prototype = {
	setState: function(state) {
		var j=0;
		for (var i=0; i<this.els.length; i++) {
			this.els[i].style[this.property] = state <= this.threshold ? this.from : this.to; 
		}
	},
	inspect: function() {
		return "\t" + this.property + "(" + this.from + " to " + this.to + " @ " + this.threshold + ")\n";
	}
}