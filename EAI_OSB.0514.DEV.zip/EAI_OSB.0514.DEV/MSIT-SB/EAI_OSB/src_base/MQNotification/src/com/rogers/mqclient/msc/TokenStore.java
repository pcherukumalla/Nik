package com.rogers.mqclient.msc;

import java.nio.charset.Charset;

import com.rogers.logger.utility.UtilityLogger;

public class TokenStore 
{
	private static final String FILE_PREFIX="Token_";
	
	private static TokenStore instance = null;

	public static TokenStore getInstance()
	{
		if ( TokenStore.instance == null ) 
		{
			synchronized( TokenStore.class )
			{
				TokenStore.instance =  new TokenStore();
			}
		}
		
		return TokenStore.instance;
	}
	
	private static String token = null;
	private static int scount = 0;
	private static String userid = null;

	public  String getToken() {
		return token;
	}
	public  int getScount() {
		return scount;
	}
	public  String getUserid() {
		return userid;
	}
	public  void setInstance(TokenStore instance) {
		TokenStore.instance = instance;
	}
	public  void setToken(String token) {
		TokenStore.token = token;
	}
	public  void setScount(int scount) {
		TokenStore.scount = scount;
	}
	public  void setUserid(String userid) {
		TokenStore.userid = userid;
	}
	
	public synchronized void setTokenStore( String userid, String token, int scount )
	{
		setToken( token);
		setScount( scount);
		setUserid( userid);
		
		storeTokenToFile(userid, token);
	}
	
	private void storeTokenToFile( String userid, String token )
	{
		try
		{
			java.io.File fileToken = new java.io.File(TokenStore.FILE_PREFIX+userid);
			if( fileToken.exists() && !fileToken.isDirectory() )
			{
				fileToken.delete();			
			}
			UtilityLogger.getLogger().info( "Token to store:" + token);	
			//byte dataToWrite[] = token.getBytes(Charset.forName("UTF-8"));
			byte dataToWrite[] = token.getBytes();
			java.io.FileOutputStream out = new java.io.FileOutputStream( TokenStore.FILE_PREFIX+userid );
			out.write(dataToWrite);
			out.close();			
		}
		catch (Exception ex)
		{
			Throwable ee = ex;
			UtilityLogger.getLogger().info("Exception storing token to file:");
			UtilityLogger.getLogger().logException( ee );
		}
	}
	
	public synchronized String getTokenFromFile(String userid)
	{
		String token = "";
		try
		{
			java.io.File fileToken = new java.io.File(TokenStore.FILE_PREFIX+userid);
			if( fileToken.exists() && !fileToken.isDirectory() )
			{
				token = new StringBuffer("").append(new java.util.Scanner(new java.io.File(TokenStore.FILE_PREFIX+userid)).useDelimiter("").next()).toString();
			}
			else
			{
				//DO Nothing .. it will return an empty string
			}
		}
		catch (Exception ex)
		{
			Throwable ee = ex;
			UtilityLogger.getLogger().info("Exception geting token from file:");
			UtilityLogger.getLogger().logException( ee );			
		}
		return token.trim();
	}
}
