package com.rogers.mqclient.ssc;

public class SscHeaderType
{
	public static final SscHeaderType source = new SscHeaderType( "SCSH" );
	public static final SscHeaderType reply = new SscHeaderType( "STRH" );
	public static final SscHeaderType status = new SscHeaderType( "SSST" );
	public static final SscHeaderType confirmation = new SscHeaderType( "SSRH" );
	
	// get the string representation of type
	public String toString()
	{
		return _value;
	}

	private String _value;

	// private constructor - instance creation not permitted
	private SscHeaderType( String value )
	{
		_value = value;
	}
}
