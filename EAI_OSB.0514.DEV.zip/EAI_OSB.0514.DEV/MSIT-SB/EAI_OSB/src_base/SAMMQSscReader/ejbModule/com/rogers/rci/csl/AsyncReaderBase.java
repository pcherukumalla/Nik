package com.rogers.rci.csl;

import java.util.Random;

public class AsyncReaderBase 
{
	/**
	 * SHOULD be 1 only upper case char (0..9 or A..Z), no special chars or non printable chars allowed
	 */
	public static final String FILTER_KEY_FLAG = "FILTERKEY"; 	
	public static final String MSGTYPE_FLAG = "MSGTYPE";
	public static final String BLOCK_KEY_FLAG = "SZKEY";
	public static final String JMS_CORRELATION_FLAG = "JMSCorrelationID";
	public static final String DELIMITER = "e##e";
	/**
	 * Use to set on publisher the msgBackCorrelationIndicators using a predefined delimiter, 
	 * example: SendBackMsgId=Xyze##eSendBackToDestination=yzessde##eOtherSendBackKey=truee##e ..... etc
	 */
	public static final String MSG_CORRELATION_LIST_FLAG = "CORRLIST"; 	
	
	/**
	 * to be used to set the FILTERKEY in case that received SZKEY does not have alpha-numeric values within or is a constant
	 */
	private static char[] randomBeanArray = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'};	
	public static String getRandomBeanFilter()
	{
		return ( String.valueOf( AsyncReaderBase.randomBeanArray[new Random().nextInt( AsyncReaderBase.randomBeanArray.length )] ) );
	}		
}
