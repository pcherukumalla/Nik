package com.rogers.sspmw.tdvLogPolicy;

import java.text.SimpleDateFormat;
import java.util.Date;

public class MessageBean {
	private String msgId;
	private String operationName;
	private String message;
	private String messageTime;

	public MessageBean(String msgId, String operationName, String message) {
		super();
		this.msgId = msgId;
		this.operationName = operationName;
		this.message = message;
		this.messageTime = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ").format(new Date());
	}

	public String getMsgId() {
		return msgId;
	}

	public void setMsgId(String msgId) {
		this.msgId = msgId;
	}

	public String getOperationName() {
		return operationName;
	}

	public void setOperationName(String operationName) {
		this.operationName = operationName;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getMessageTime() {
		return messageTime;
	}

	public void setMessageTime(String messageTime) {
		this.messageTime = messageTime;
	}

	public String getTDVSoapMessage() {
		StringBuffer sb = new StringBuffer();

		sb.append("<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\">");
		sb.append("<soapenv:Header/>");
		sb.append("<soapenv:Body>");
		sb.append("<msit:logToTDV xmlns:msit=\"http://rci.rogers.com/msit\">");
		sb.append(getTDVMessage());
		sb.append("</msit:logToTDV>");
		sb.append("</soapenv:Body>");
		sb.append("</soapenv:Envelope>");

		return sb.toString();
	}
	
	public String getTDVMessage() {
		StringBuffer sb = new StringBuffer();

		sb.append("<msit:TDVRequest xmlns:msit=\"http://rci.rogers.com/msit\">");
		sb.append("<msit:processID>");
		sb.append(this.msgId);
		sb.append("</msit:processID>");
		sb.append("<msit:logDateTime>");
		sb.append(this.messageTime);
		sb.append("</msit:logDateTime>");
		sb.append("<msit:operationName>");
		sb.append(this.operationName);
		sb.append("</msit:operationName>");
		sb.append("<msit:message><![CDATA[");
		sb.append(this.message);
		sb.append("]]></msit:message>");
		sb.append("</msit:TDVRequest>");

		return sb.toString();
	}
}
