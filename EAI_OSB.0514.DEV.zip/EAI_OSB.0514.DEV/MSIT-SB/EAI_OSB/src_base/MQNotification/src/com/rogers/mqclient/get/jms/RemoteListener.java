package com.rogers.mqclient.get.jms;

import java.util.Date;

import javax.jms.Connection;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.ObjectMessage;
import javax.jms.QueueSession;
import javax.jms.TextMessage;

import com.rogers.logger.utility.UtilityLogger;

public class RemoteListener implements MessageListener {

	  private Connection connection = null;
	  private QueueSession ses = null;

	  public RemoteListener( Connection conn, QueueSession s )
	  {
	    this.connection = conn;
	    this.ses = s;
	  }

	  public void onMessage(Message msg)
	  {
	    UtilityLogger.getLogger().info("New Message Received -----------------------");
	    try
	    {
	      UtilityLogger.getLogger().info("Date: " + new Date().toString());

	      if( msg instanceof TextMessage )
	      {
	    	UtilityLogger.getLogger().info("message ID: "+msg.getJMSMessageID());
	    	UtilityLogger.getLogger().info("correlation ID: "+msg.getJMSCorrelationID());
	        UtilityLogger.getLogger().info("message: "+ ((TextMessage)msg).getText());
	      }
	      else if ( msg instanceof com.ibm.jms.JMSBytesMessage)
	      {
	    	  com.ibm.jms.JMSBytesMessage jmsByteMsg =  (com.ibm.jms.JMSBytesMessage)msg;
	    	  UtilityLogger.getLogger().info("message ID: "+ jmsByteMsg.getJMSMessageID());
	    	  com.ibm.jms.JMSMessage jmsMsg = (com.ibm.jms.JMSMessage)jmsByteMsg;
	    	  UtilityLogger.getLogger().info("To String: " + jmsMsg.toString());
	      }
	      else
	      {
	        Object obj = ((ObjectMessage)msg).getObject();
	        UtilityLogger.getLogger().info("This message has a wrong Type:" +obj.getClass());
	      }
	      //ses.commit();
	    }
	    catch( JMSException je )
	    {
	      UtilityLogger.getLogger().info("JMSException occurred in RemoteListener! The system will shut down!");
	      je.printStackTrace();
	      if( connection!=null )
	      {
	        try
	        {
	          connection.close();
	        }
	        catch( JMSException je2 )
	        {}
	      }
	    }
	  }
	}
