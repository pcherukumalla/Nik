/*
------------------------------------------------------------------------------------------
LoginWindow
------------------------------------------------------------------------------------------
*/
com.rogers.rci.ngws.LoginWindow = function(p) {
	js.wtc.Window.call(this);
	
	this.app = p;
	
	this.emailTextbox = null;
	this.passwordTextbox = null;
	this.loginButton = null;
}
com.rogers.rci.ngws.LoginWindow.prototype = new js.wtc.Window();
com.rogers.rci.ngws.LoginWindow.prototype.constructor = com.rogers.rci.ngws.LoginWindow;



com.rogers.rci.ngws.LoginWindow.prototype.init = function() {
	this.set("minres", false);
	this.set("resize", false);
	js.wtc.Window.prototype.init.call(this);
	
	var SELF = this;
	
	// set attributes...
	this.set("left", (screen.width/2 - 150) + "px");
	//this.set("left", "380px");
	this.set("top", "200px");
	this.set("width", "300px");
	this.set("height", "130px");
	this.set("fontSize", "11px");
	this.set("title", "AsyncAdator Admin Tool - Login");
	this.body().set("backgroundColor", "#EFEFEF");
	
	// init the login button...
	this.loginButton = new com.rogers.rci.ngws.Button("Login");
	this.loginButton.init();
	this.loginButton.set("width", "60px");
	this.loginButton.set("position", "");
	this.loginButton.viewport().onclick = function() {
			SELF.login();
	}
	
	// init the email textbox...
	this.emailTextbox = new com.rogers.rci.ngws.Textbox();
	this.emailTextbox.init();
	this.emailTextbox.set("position", "");
	this.emailTextbox.set("width", "200px");
	
	// try to get the value from a cookie...
    var strEmail = js.util.Cookies.getCookie("ELMSUSERID");
    if(strEmail != null) {
    	this.emailTextbox.set("value", strEmail);
    } else {
    	this.emailTextbox.set("value", "");
    }
	
	// init the password textbox...
	this.passwordTextbox = new com.rogers.rci.ngws.Textbox();
	this.passwordTextbox.set("password", true);
	this.passwordTextbox.init();
	this.passwordTextbox.set("value", "");
	this.passwordTextbox.set("position", "");
	this.passwordTextbox.set("width", "200px");
		
	// layout table...
	this.layoutTable = new js.wtc.Table();
	this.layoutTable.init();
	this.layoutTable.set("left", "5px");
	this.layoutTable.set("top", "5px");
	this.layoutTable.set("cellPadding", "3");
	this.layoutTable.set("cellSpacing", "1");
	this.layoutTable.generate(3, 2);
	
	// buttons layout table...
	var tbl = new js.wtc.Table();
	tbl.init();
	tbl.set("left", "5px");
	tbl.set("top", "5px");
	tbl.set("cellPadding", "2");
	tbl.set("cellSpacing", "1");
	tbl.set("position", "");
	tbl.generate(1, 2);
	
	// add labels...
	this.layoutTable.cell(0, 0).innerHTML = "User ID:";
	this.layoutTable.cell(1, 0).innerHTML = "Password:";
	
	// append the email textbox... 
	this.layoutTable.append(this.emailTextbox, this.layoutTable.cell(0, 1));
	// append the password textbox... 
	this.layoutTable.append(this.passwordTextbox, this.layoutTable.cell(1, 1));
	// append the login button...
	tbl.append(this.loginButton, tbl.cell(0, 0));
	// append the "small table"...
	this.layoutTable.append(tbl, this.layoutTable.cell(2, 1));
	
	// append layout table...
	this.body().append(this.layoutTable);
}



com.rogers.rci.ngws.LoginWindow.prototype.login = function() {
	if(this.emailTextbox.get("value") == "") {
		alert("Please enter your User ID.");
		return;
	}
	if(this.passwordTextbox.get("value") == "") {
		alert("Please enter your Password.");
		return;
	}
	
	var bOK = false;
	for(var i = 0; i < this.app.properties.users.length; i++) {
		if((this.app.properties.users[i].uid == this.emailTextbox.get("value")) && (this.app.properties.users[i].pwd == this.passwordTextbox.get("value"))) {
			bOK = true;
			this.app.adminIn = this.app.properties.users[i].adminIn;
			
			break;
		}
	}

	if(bOK) {	
		// save the email in a cookie...
	    var expireDate = new Date();
	    expireDate.setMonth(expireDate.getMonth() + 1);
	    js.util.Cookies.setCookie("ELMSUSERID", this.emailTextbox.get("value"), expireDate);
	    
	    // save the user ID...
	    this.app.userID = this.emailTextbox.get("value");
	   
	    // hide this window...
	    this.hide();
	    
	    // update & show the app's panels...
	    if(this.app.adminIn) {
	    	this.app.topContentPanel.engineAdminButton.set("backgroundColor", "rgb(130, 190, 130)");
	    	this.app.topContentPanel.engineAdminButton.set("disabled", false);
	    }
	    this.app.topContentPanel.show();
		this.app.resultsContentPanel.show();
	} else {
		alert("Wrong User ID or/and Password.");
	}
}
