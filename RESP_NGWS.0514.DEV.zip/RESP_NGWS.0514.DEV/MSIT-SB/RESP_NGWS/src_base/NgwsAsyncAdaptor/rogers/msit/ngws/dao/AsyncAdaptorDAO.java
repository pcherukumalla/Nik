package com.rogers.msit.ngws.dao;

import java.sql.*;
import java.util.*;
import java.util.logging.*;

import com.rogers.msit.ngws.dao.base.*;
import com.rogers.msit.ngws.utils.*;



public class AsyncAdaptorDAO extends BaseDAO {
	public List getNextMessageList(int nListSize, String nextMessageListSQL) throws AsyncAdaptorDAOException {
		List ret = null;
		
		// params...

		// get data...
		Connection conn = null;
		try {
			conn = getConnection();

			// params...
			Object[] params = new Object[1];
			params[0] = new Integer(nListSize + 1);
			
			// get list...
			ret = getDAOObjectList(conn, nextMessageListSQL, params);
			
			// get the actual message as string for each record in the list...
			DAOObject o = null;
			for(int i = 0; i < ret.size(); i ++) {
				o = (DAOObject)ret.get(i);
				
				try {
					o.set("MSG_DATA_STR", o.getBlobAsString("MSG_DATA"));
				} catch(Exception e2) {
					Constants.LOGGER.log(Level.SEVERE,  this.getClass().getName() + ".getNextMessageList get BLOB as String error: " + o.get("MSGID") + " - " + e2.toString());
				}
			}
		} catch(Exception e) {
			Constants.LOGGER.log(Level.SEVERE,  this.getClass().getName() + ".getNextMessageList error: " + e.toString());
			throw new AsyncAdaptorDAOException(e);
		} finally {
			closeConnection(conn);
		}
		
		return ret;
	}
	/*
	public List getNextMessageList(int nListSize, int nGetListBatchSize, String minMessageIdSQL, String nextMessageListSQL) throws AsyncAdaptorDAOException {
		List ret = null;
		
		// params...

		// get data...
		Connection conn = null;
		try {
			conn = getConnection();

			// get min message ID...
			long nMinMessageId = 0;
			DAOObject m = getDAOObject(conn, minMessageIdSQL, null);
			if(m != null) {
				nMinMessageId = m.getLong("MIN_MSGID");
			}
			// get max message ID...
			long nMaxMessageId = nMinMessageId + nGetListBatchSize;
						
			// params...
			Object[] params = new Object[4];
			params[0] = new Long(nMinMessageId);
			params[1] = new Long(nMaxMessageId);
			params[2] = new Long(nMaxMessageId);
			params[3] = new Integer(nListSize + 1);
			
			// get list...
			ret = getDAOObjectList(conn, nextMessageListSQL, params);
			
			// get the actual message as string for each record in the list...
			DAOObject o = null;
			for(int i = 0; i < ret.size(); i ++) {
				o = (DAOObject)ret.get(i);
				
				try {
					o.set("MSG_DATA_STR", o.getBlobAsString("MSG_DATA"));
				} catch(Exception e2) {
					Constants.LOGGER.log(Level.SEVERE,  this.getClass().getName() + ".getNextMessageList get BLOB as String error: " + o.get("MSGID") + " - " + e2.toString());
				}
			}
		} catch(Exception e) {
			Constants.LOGGER.log(Level.SEVERE,  this.getClass().getName() + ".getNextMessageList error: " + e.toString());
			throw new AsyncAdaptorDAOException(e);
		} finally {
			closeConnection(conn);
		}
		
		return ret;
	}
	*/
	
	
	
	public int updateMessageForProcessing(long msgId) throws AsyncAdaptorDAOException {
		int nRet = -1;
		
		// params...

		// get data...
		Connection conn = null;
		PreparedStatement st = null;
		try {
			conn = getConnection();
			
			st = conn.prepareStatement(DAOUtils.getInstance().getQueries().getProperty("sql.UPDATE_MESSAGE_FOR_PROCESSING_SQL"));
			st.setLong(1, msgId);
			
			nRet = st.executeUpdate();
		} catch(Exception e) {
			Constants.LOGGER.log(Level.SEVERE,  this.getClass().getName() + ".updateMessageForProcessing error: " + e.toString());
			throw new AsyncAdaptorDAOException(e);
		} finally {
			closeStatement(st);
			closeConnection(conn);
		}
		
		return nRet;
	}
	
	
	
	public int updateMessageAfterProcessing(long msgId, int statusIn, String errorCd, String errorDesc, int nMoveToHist, String statsDate) throws AsyncAdaptorDAOException {
		int nRet = -1;
		
		// params...

		// get data...
		Connection conn = null;
		PreparedStatement st = null;
		PreparedStatement st1 = null;
		PreparedStatement st2 = null;
		PreparedStatement st3 = null;
		PreparedStatement st4 = null;
		PreparedStatement st5 = null;
		ResultSet res = null;
		try {
			conn = getConnection();
			conn.setAutoCommit(false);
			
			// update message...
			st = conn.prepareStatement(DAOUtils.getInstance().getQueries().getProperty("sql.UPDATE_MESSAGE_AFTER_PROCESSING_SQL"));
			st.setInt(1, statusIn);
			st.setString(2, errorCd);
			st.setString(3, errorDesc);
			st.setLong(4, msgId);
			nRet = st.executeUpdate();
			
			if(nMoveToHist == 0) {
				// insert into history table...
				st2 = conn.prepareStatement(DAOUtils.getInstance().getQueries().getProperty("sql.INSERT_MESSAGE_TO_HISTORY_SQL"));
				st2.setLong(1, msgId);
				nRet = st2.executeUpdate();
				
				// delete message...
				st3 = conn.prepareStatement(DAOUtils.getInstance().getQueries().getProperty("sql.DELETE_MESSAGE_SQL"));
				st3.setLong(1, msgId);
				nRet = st3.executeUpdate();
			} else if(nMoveToHist > 0) {
				// get number of retries...
				st1 = conn.prepareStatement(DAOUtils.getInstance().getQueries().getProperty("sql.GET_MESSAGE_NR_OF_RETRIES_SQL"));
				st1.setLong(1, msgId);
				res = st1.executeQuery();
				
				int nNrOfRetries = -1;
				if(res.next()) {
					nNrOfRetries = res.getInt("NR_OF_RETRIES");
				}
				
				if(nNrOfRetries >= nMoveToHist) {
					// insert into history table...
					st2 = conn.prepareStatement(DAOUtils.getInstance().getQueries().getProperty("sql.INSERT_MESSAGE_TO_HISTORY_SQL"));
					st2.setLong(1, msgId);
					nRet = st2.executeUpdate();
					
					// delete message...
					st3 = conn.prepareStatement(DAOUtils.getInstance().getQueries().getProperty("sql.DELETE_MESSAGE_SQL"));
					st3.setLong(1, msgId);
					nRet = st3.executeUpdate();
				}
			}
			
			// *****************************************************************************************************************
			// store stats about this event...
			st4 = conn.prepareStatement(DAOUtils.getInstance().getQueries().getProperty("sql.UPDATE_STATS"));
			st4.setString(1, statsDate);
			int nUpdateStatsRet = st4.executeUpdate();
			
			// if no row exists for this day of year then insert one and then update again...
			if(nUpdateStatsRet == 0) {
				st5 = conn.prepareStatement(DAOUtils.getInstance().getQueries().getProperty("sql.INSERT_STATS"));
				st5.setString(1, statsDate);
				st5.executeUpdate();
				
				st4.executeUpdate();
			}
			// *****************************************************************************************************************
			
			conn.commit();
			conn.setAutoCommit(true);
		} catch(Exception e) {
			try {
				conn.rollback();
			} catch(SQLException sqle) {
				Constants.LOGGER.log(Level.SEVERE,  this.getClass().getName() + ".updateMessageAfterProcessing rollback error: " + sqle.toString());
			}
			Constants.LOGGER.log(Level.SEVERE,  this.getClass().getName() + ".updateMessageAfterProcessing error: " + e.toString());
			throw new AsyncAdaptorDAOException(e);
		} finally {
			closeResultSet(res);
			closeStatement(st);
			closeStatement(st1);
			closeStatement(st2);
			closeStatement(st3);
			closeStatement(st4);
			closeStatement(st5);
			closeConnection(conn);
		}
		
		return nRet;
	}
	
	
	
	public DAOObject getMessageByPK(long id) throws AsyncAdaptorDAOException {
		DAOObject ret = null;
		
		// params...
		Object[] params = new Object[1];
		params[0] = new Long(id);

		// get data...
		Connection conn = null;
		try {
			conn = getConnection();
			
			ret = getDAOObject(conn, DAOUtils.getInstance().getQueries().getProperty("sql.GET_MESSAGE_BY_PK_SQL"), params);
			
			try {
				ret.set("MSG_DATA_STR", ret.getBlobAsString("MSG_DATA"));
			} catch(Exception e2) {
				Constants.LOGGER.log(Level.SEVERE,  this.getClass().getName() + ".getMessagesBySzKey get BLOB as String error: " + ret.get("MSGID") + " - " + e2.toString());
			}
		} catch(Exception e) {
			Constants.LOGGER.log(Level.SEVERE,  this.getClass().getName() + ".getMessageByPK error: " + e.toString());
			throw new AsyncAdaptorDAOException(e);
		} finally {
			closeConnection(conn);
		}
		
		return ret;
	}
	
	
	
	public DAOObject getTempMessageByPK(long id) throws AsyncAdaptorDAOException {
		DAOObject ret = null;
		
		// params...
		Object[] params = new Object[1];
		params[0] = new Long(id);

		// get data...
		Connection conn = null;
		try {
			conn = getConnection();
			
			ret = getDAOObject(conn, DAOUtils.getInstance().getQueries().getProperty("sql.GET_TEMP_MESSAGE_BY_PK_SQL"), params);
			
			try {
				ret.set("MSG_DATA_STR", ret.getBlobAsString("MSG_DATA"));
			} catch(Exception e2) {
				Constants.LOGGER.log(Level.SEVERE,  this.getClass().getName() + ".getMessagesBySzKey get BLOB as String error: " + ret.get("MSGID") + " - " + e2.toString());
			}
		} catch(Exception e) {
			Constants.LOGGER.log(Level.SEVERE,  this.getClass().getName() + ".getTempMessageByPK error: " + e.toString());
			throw new AsyncAdaptorDAOException(e);
		} finally {
			closeConnection(conn);
		}
		
		return ret;
	}
	
	
	
	public List getMessagesBySzKey(String szKey) throws AsyncAdaptorDAOException {
		List ret = null;
		
		// params...
		Object[] params = new Object[2];
		params[0] = szKey;
		params[1] = szKey;

		// get data...
		Connection conn = null;
		try {
			conn = getConnection();
			
			ret = getDAOObjectList(conn, DAOUtils.getInstance().getQueries().getProperty("sql.GET_MESSAGES_BY_SZKEY_SQL"), params, Constants.MAX_NR_OF_RECORDS);
			
			// get the actual message as string for each record in the list...
			DAOObject o = null;
			for(int i = 0; i < ret.size(); i ++) {
				o = (DAOObject)ret.get(i);
				
				try {
					o.set("MSG_DATA_STR", o.getBlobAsString("MSG_DATA"));
				} catch(Exception e2) {
					Constants.LOGGER.log(Level.SEVERE,  this.getClass().getName() + ".getMessagesBySzKey get BLOB as String error: " + o.get("MSGID") + " - " + e2.toString());
				}
			}
		} catch(Exception e) {
			Constants.LOGGER.log(Level.SEVERE,  this.getClass().getName() + ".getMessagesBySzKey error: " + e.toString());
			throw new AsyncAdaptorDAOException(e);
		} finally {
			closeConnection(conn);
		}
		
		return ret;
	}
	
	
	
	public List getHistoryMessagesBySzKey(String szKey) throws AsyncAdaptorDAOException {
		List ret = null;
		
		// params...
		Object[] params = new Object[1];
		params[0] = szKey;

		// get data...
		Connection conn = null;
		try {
			conn = getConnection();
			
			ret = getDAOObjectList(conn, DAOUtils.getInstance().getQueries().getProperty("sql.GET_HISTORY_MESSAGES_BY_SZKEY_SQL"), params, Constants.MAX_NR_OF_RECORDS);
			
			// get the actual message as string for each record in the list...
			DAOObject o = null;
			for(int i = 0; i < ret.size(); i ++) {
				o = (DAOObject)ret.get(i);
				
				try {
					o.set("MSG_DATA_STR", o.getBlobAsString("MSG_DATA"));
				} catch(Exception e2) {
					Constants.LOGGER.log(Level.SEVERE,  this.getClass().getName() + ".getHistoryMessagesBySzKey get BLOB as String error: " + o.get("MSGID") + " - " + e2.toString());
				}
			}
		} catch(Exception e) {
			Constants.LOGGER.log(Level.SEVERE,  this.getClass().getName() + ".getHistoryMessagesBySzKey error: " + e.toString());
			throw new AsyncAdaptorDAOException(e);
		} finally {
			closeConnection(conn);
		}
		
		return ret;
	}
	
	
	
	public List getMessageTypes() throws AsyncAdaptorDAOException {
		List ret = null;
		
		// params...

		// get data...
		Connection conn = null;
		try {
			conn = getConnection();
			
			ret = getDAOObjectList(conn, DAOUtils.getInstance().getQueries().getProperty("sql.GET_MESSAGE_TYPES"), null);
		} catch(Exception e) {
			Constants.LOGGER.log(Level.SEVERE,  this.getClass().getName() + ".getMessageTypes error: " + e.toString());
			throw new AsyncAdaptorDAOException(e);
		} finally {
			closeConnection(conn);
		}
		
		return ret;
	}
	
	
	
	public int moveMessageListForProcessing(int msgListSize, int maxNrOfRecs) throws AsyncAdaptorDAOException {
		int nRet = -1;
		
		// params...

		// get data...
		Connection conn = null;
		PreparedStatement st1 = null;
		PreparedStatement st2 = null;
		PreparedStatement st3 = null;
		PreparedStatement st4 = null;
		PreparedStatement st5 = null;
		ResultSet res1 = null;
		ResultSet res2 = null;
		try {
			conn = getConnection();
			conn.setAutoCommit(false);
						
			// get current nr of records for processing...
			st1 = conn.prepareStatement(DAOUtils.getInstance().getQueries().getProperty("sql.GET_CURRENT_NR_OF_RECORDS_FOR_PROCESSING"));
			res1 = st1.executeQuery();
			
			int nCurrentNrOfRecords = -1;
			if(res1.next()) {
				nCurrentNrOfRecords = res1.getInt("NR_OF_RECS");
			}
			//System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> " + nCurrentNrOfRecords);
			
			// move the next list of messages for processing from the buffer table to the processing table...
			if(nCurrentNrOfRecords < maxNrOfRecs) {
				st2 = conn.prepareStatement(DAOUtils.getInstance().getQueries().getProperty("sql.GET_MOVE_FOR_PROCESSING_LAST_MSGID"));
				res2 = st2.executeQuery();
				
				long nLastMsgId = -1;
				if(res2.next()) {
					nLastMsgId = Long.parseLong(res2.getString("CFG_VALUE"));
				}
				
				// set the new message id to be used to select the new list of messages for processing...
				long nNewMsgId = nLastMsgId + msgListSize;
				
				// insert new list of records for processing...
				st3 = conn.prepareStatement(DAOUtils.getInstance().getQueries().getProperty("sql.INSERT_MOVE_FOR_PROCESSING"));
				st3.setLong(1, nNewMsgId);
				nRet = st3.executeUpdate();
				
				// delete new list of records for processing from the buffer table...
				if(nRet > 0) {
					st4 = conn.prepareStatement(DAOUtils.getInstance().getQueries().getProperty("sql.DELETE_MOVE_FOR_PROCESSING"));
					st4.setLong(1, nNewMsgId);
					nRet = st4.executeUpdate();
					
					// save the new message id to be used to select the new list of messages for processing...
					st5 = conn.prepareStatement(DAOUtils.getInstance().getQueries().getProperty("sql.UPDATE_MOVE_FOR_PROCESSING_LAST_MSGID"));
					st5.setString(1, "" + (nLastMsgId + nRet));
					st5.executeUpdate();
				}
			}
			
			conn.commit();
			conn.setAutoCommit(true);
		} catch(Exception e) {
			try {
				conn.rollback();
			} catch(SQLException sqle) {
				Constants.LOGGER.log(Level.SEVERE,  this.getClass().getName() + ".moveMessageListForProcessing rollback error: " + sqle.toString());
			}
			Constants.LOGGER.log(Level.SEVERE,  this.getClass().getName() + ".moveMessageListForProcessing error: " + e.toString());
			throw new AsyncAdaptorDAOException(e);
		} finally {
			closeResultSet(res1);
			closeResultSet(res2);
			closeStatement(st1);
			closeStatement(st2);
			closeStatement(st3);
			closeStatement(st4);
			closeStatement(st5);
			closeConnection(conn);
		}
		
		return nRet;
	}
	
	
	
	public int updateInProgressOnStart() throws AsyncAdaptorDAOException {
		int nRet = -1;
		
		// params...

		// get data...
		Connection conn = null;
		PreparedStatement st = null;
		try {
			conn = getConnection();
			
			st = conn.prepareStatement(DAOUtils.getInstance().getQueries().getProperty("sql.RESET_IN_PROGRESS_ON_START"));
			
			nRet = st.executeUpdate();
		} catch(Exception e) {
			Constants.LOGGER.log(Level.SEVERE,  this.getClass().getName() + ".updateInProgressOnStart error: " + e.toString());
			throw new AsyncAdaptorDAOException(e);
		} finally {
			closeStatement(st);
			closeConnection(conn);
		}
		
		return nRet;
	}
	
	
	
	public List getMessagesStats(String startDate) throws AsyncAdaptorDAOException {
		List ret = null;
		
		// params...
		Object[] params = new Object[1];
		params[0] = startDate;

		// get data...
		Connection conn = null;
		try {
			conn = getConnection();
			
			// get list...
			ret = getDAOObjectList(conn, DAOUtils.getInstance().getQueries().getProperty("sql.GET_MESSAGES_FLOW_STATS"), params, Constants.MAX_NR_OF_STATS_RECORDS);
		} catch(Exception e) {
			Constants.LOGGER.log(Level.SEVERE,  this.getClass().getName() + ".getMessagesStats error: " + e.toString());
			throw new AsyncAdaptorDAOException(e);
		} finally {
			closeConnection(conn);
		}
		
		return ret;
	}
	
	
	
	public List getMessagesErrorsStats(String startDate) throws AsyncAdaptorDAOException {
		List ret = null;
		
		// params...
		Object[] params = new Object[1];
		params[0] = startDate;

		// get data...
		Connection conn = null;
		try {
			conn = getConnection();
			
			// get list...
			ret = getDAOObjectList(conn, DAOUtils.getInstance().getQueries().getProperty("sql.GET_MESSAGES_ERRORS_STATS"), params, Constants.MAX_NR_OF_STATS_RECORDS);
		} catch(Exception e) {
			Constants.LOGGER.log(Level.SEVERE,  this.getClass().getName() + ".getMessagesErrorsStats error: " + e.toString());
			throw new AsyncAdaptorDAOException(e);
		} finally {
			closeConnection(conn);
		}
		
		return ret;
	}
	
	
	
	public List getMessagesTodayStats(String startDate) throws AsyncAdaptorDAOException {
		List ret = null;
		
		// params...
		Object[] params = new Object[1];
		params[0] = startDate;

		// get data...
		Connection conn = null;
		try {
			conn = getConnection();
			
			// get list...
			ret = getDAOObjectList(conn, DAOUtils.getInstance().getQueries().getProperty("sql.GET_MESSAGES_TODAY_STATS"), params, 1);
		} catch(Exception e) {
			Constants.LOGGER.log(Level.SEVERE,  this.getClass().getName() + ".getMessagesTodayStats error: " + e.toString());
			throw new AsyncAdaptorDAOException(e);
		} finally {
			closeConnection(conn);
		}
		
		return ret;
	}
}





