package com.async.engine.common;

public interface MessageInterface {
	public String getSzKey(String msg) throws Exception;
	public String getSzKey(Object obj) throws Exception;
	public String getOtherInfo(String msgType) throws Exception;
}
