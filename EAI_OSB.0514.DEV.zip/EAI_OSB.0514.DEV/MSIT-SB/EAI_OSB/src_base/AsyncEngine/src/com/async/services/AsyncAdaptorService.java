package com.async.services;

import java.util.*;
import java.util.logging.*;

import javax.servlet.*;
import javax.jms.*;
import javax.naming.*;

import org.apache.commons.lang.*;

import com.async.dao.*;
import com.async.dao.base.*;
import com.async.utils.*;



public class AsyncAdaptorService {
	private static AsyncAdaptorService theInstance = null;
	private static Object refreshConfigValuesSyncObject = new Object();
	
	private static String CONFIG_JNDI_NAME = "";
	private static String DB_JNDI_NAME = "";
	private static String THIS_SERVER_NAME = "";
	static {
		try {
			// get JNDI data source name...
			// -Dae.config.datasource=java:comp/env/jdbc/NgwsConfigDataSource
			CONFIG_JNDI_NAME = System.getProperty(Constants.JNDI_NAME_CONFIG_PARAM);
			// -Dae.db.datasource=java:comp/env/jdbc/NgwsDataSource
			DB_JNDI_NAME = System.getProperty(Constants.DB_JNDI_NAME_CONFIG_PARAM);
			
			// get server name...
			// -DweblogicName=server_name_here
			THIS_SERVER_NAME = System.getProperty(Constants.THIS_SERVER_NAME_CONFIG_PARAM);
		} catch(Exception e) {
			Constants.LOGGER.log(Level.SEVERE, "Unable to get JNDI data source name or/and server name: " + e.toString());
		}
	}
	
	private ServletContext servletContext = null;
	private AsyncAdaptorConfigDAO asyncAdaptorConfigDAO = null;
	private AsyncAdaptorDAO asyncAdaptorDAO = null;
	private Properties props = new Properties();
	
	private long lastConfigValuesRefreshTime = 0;
	private String lastConfigValuesRefreshTimeAsString = ""; // used for  storing the stats in the stats table...
	private Properties configValues = new Properties();
	private HashMap errorMessages = new HashMap();
	private Properties errorDescriptions = new Properties();
	private static HashMap messageTypes = new HashMap();
	private static List mainTables = new ArrayList();
	private static List processSQLs = new ArrayList();
	
	private InitialContext initialContext = null;
	private QueueConnectionFactory queueConnectionFactory = null;
	private javax.jms.Queue queue = null;
	private QueueConnection connection = null;
	private QueueSession session = null;
	private QueueSender sender = null; 
	

	
	private AsyncAdaptorService(ServletContext ctx) {
		try {
			this.servletContext = ctx;
		} catch(Exception e) {
			e.printStackTrace();
			Constants.LOGGER.log(Level.SEVERE, this.getClass().getName() + " ThunderRoadAdminService constructor - error while initializing the app: " + e.toString());
		}
	}
	
	
	
	public static void initService(ServletContext ctx) {
		if(theInstance == null) {
			theInstance = new AsyncAdaptorService(ctx);
		}
	}
	
	
	
	public static AsyncAdaptorService getInstance() {
		return theInstance;
	}
	
	
	
	public ServletContext getServletContext() {
		return servletContext;
	}



	public AsyncAdaptorDAO getAsyncAdaptorDAO() {
		return this.asyncAdaptorDAO;
	}



	public void createAsyncAdaptorDAO() {
		this.asyncAdaptorDAO = new AsyncAdaptorDAO();
		
		try {
			this.asyncAdaptorDAO.setDataSourceByJndiName(DB_JNDI_NAME);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}



	public AsyncAdaptorConfigDAO getAsyncAdaptorConfigDAO() {
		return asyncAdaptorConfigDAO;
	}



	public void createAsyncAdaptorConfigDAO() {
		this.asyncAdaptorConfigDAO = new AsyncAdaptorConfigDAO();
		
		try {
			this.asyncAdaptorConfigDAO.setDataSourceByJndiName(CONFIG_JNDI_NAME);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}



	public Properties getProps() {
		return props;
	}



	public void setProps(Properties props) {
		this.props = props;
		this.props.setProperty("THIS_SERVER_NAME", THIS_SERVER_NAME);
	}
	
	
	
	public List getMainTables() {
		return this.mainTables;
	}
	
	
	
	public List getProcessSQLs() {
		return this.processSQLs;
	}
	
	
	
	public DAOObject getMessageType(int msgTypeId) {
		return (DAOObject)this.messageTypes.get(msgTypeId);
	}
	
	
	
	public String getThisServerName() {
		return THIS_SERVER_NAME;
	}
	
	
	
	public long getLastConfigValuesRefreshTime() {
		return lastConfigValuesRefreshTime;
	}



	public String getLastConfigValuesRefreshTimeAsString() {
		return lastConfigValuesRefreshTimeAsString;
	}



	public void refreshConfigValues(boolean bForceIn) throws Exception {
		long currentTime = System.currentTimeMillis();
		if(bForceIn) {
			lastConfigValuesRefreshTime = currentTime - Constants.CONFIG_VALUES_REFRESH_PERIOD - 100;
		}
		
		// if more then Constants.CONFIG_VALUES_REFRESH_PERIOD minutes have passed then refresh...
		if(currentTime - this.lastConfigValuesRefreshTime > Constants.CONFIG_VALUES_REFRESH_PERIOD) {
			synchronized(refreshConfigValuesSyncObject) {
				// get config values from the database...
				List entries = this.asyncAdaptorConfigDAO.getConfigEntries();
				
				// cache data...
				this.configValues.clear();
				
				DAOObject o = null;
				for(int i = 0; i < entries.size(); i++) {
					o = (DAOObject)entries.get(i);
					
					if(o.get("CFG_VALUE") == null) {
						this.configValues.setProperty(o.getString("CFG_NAME"), "");
					} else {
						this.configValues.setProperty(o.getString("CFG_NAME"), o.getString("CFG_VALUE"));
					}
				}
				
				// get data from the database...
				List errors = this.asyncAdaptorConfigDAO.getErrorMessages();
				List dscs = this.asyncAdaptorConfigDAO.getErrorDescriptions();
				List typs = this.asyncAdaptorConfigDAO.getMessageTypes();
				
				// clear cached data...
				this.errorMessages.clear();
				this.errorDescriptions.clear();
				this.messageTypes.clear();
				this.mainTables.clear();
				this.processSQLs.clear();
				
				
				// cache tables...
				this.mainTables = this.asyncAdaptorConfigDAO.getMainTables();
				
				// cache process sqls...
				this.processSQLs = this.asyncAdaptorConfigDAO.getProcessSQLs();
				
				// cache error messages...
				for(int i = 0; i < errors.size(); i++) {
					o = (DAOObject)errors.get(i);
					
					this.errorMessages.put(o.getString("ERR_CD"), o);
				}
				
				// cache error descriptions...
				for(int i = 0; i < dscs.size(); i++) {
					o = (DAOObject)dscs.get(i);
					
					this.errorDescriptions.setProperty(o.getString("DESCRIPTION"), o.getString("ERR_CD"));
				}
				
				// cache message types...
				DAOObject o2 = null;
				for(int i = 0; i < typs.size(); i++) {
					o2 = (DAOObject)typs.get(i);
					
					this.messageTypes.put(new Integer(o2.getInt("MSGTYPE_ID")), o2);
				}
		
				// store the current time...
				this.lastConfigValuesRefreshTime = currentTime;
				this.lastConfigValuesRefreshTimeAsString = Constants.STATS_DATE_FORMAT.format(new Date(this.lastConfigValuesRefreshTime));
			}
		}
	}
	
	
	
	public String getValue(String configName) {
		String strRet = "";
		try {
			// return config value...
			strRet =  this.configValues.getProperty(configName);
			
			if(strRet == null) {
				strRet = "";
			}
		} catch(Exception e) {
			// ...
		}
		
		return strRet;
	}
	
	
	
	public String getValue(String configName, String strDefault) {
		String strRet = "";
		try {
			// return config value...
			strRet =  this.configValues.getProperty(configName);
			
			if(strRet == null) {
				strRet = strDefault;
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		return strRet;
	}
	
	
	
	public void acknowledgeWhenError(DAOObject msg, String errorCd, String errorDesc) {
		try {
			// get the details for this error and use the default error if the sent one not found in the current configuration...
			DAOObject err = (DAOObject)this.errorMessages.get(errorCd);
			if(err == null) {
				err = this.getErrorByDescription(errorDesc);
			}
			
			// get details for this type of message...
			DAOObject msgType = this.getMessageType(msg.getInt("MSGTYPE_ID"));
			
			// update/move message...
			this.asyncAdaptorDAO.updateMessageWhenError(msg, errorCd, errorDesc, err, msgType, this.lastConfigValuesRefreshTimeAsString);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	
	
	private DAOObject getErrorByDescription(String errorDesc) {
		DAOObject ret = null;
		
		if(this.errorDescriptions.size() > 0) {
			Enumeration enumNames = this.errorDescriptions.propertyNames();
			
			String strName = "";
			while(enumNames.hasMoreElements()) {
				strName = (String)enumNames.nextElement();
				
				if(errorDesc.indexOf(strName) != -1) {
					ret = (DAOObject)this.errorMessages.get(this.errorDescriptions.getProperty(strName));
					
					break;
				}
			}
		}
		
		if(ret == null) {
			ret = (DAOObject)this.errorMessages.get(Constants.ERROR);
		}
		
		return ret;
	}
	
	
	
	public void createJMSContextAndConnection(String initCtxStr) throws Exception {
		if((this.initialContext == null) || (this.queueConnectionFactory == null) || (this.queue == null)) {
			this.refreshConfigValues(false);
			
			if("-".equals(initCtxStr)) {
				this.initialContext = new InitialContext();
			} else {
				// example of PROVIDER_URL     t3://10.1.241.37:7001,10.1.241.38:7001
				Hashtable h = new Hashtable();
				h.put(Context.INITIAL_CONTEXT_FACTORY, "weblogic.jndi.WLInitialContextFactory");
				h.put(Context.PROVIDER_URL, initCtxStr);
				//h.put(Context.SECURITY_PRINCIPAL, this.username);
				//h.put(Context.SECURITY_CREDENTIALS, this.password);
				
				this.initialContext = new InitialContext(h);
			}
			
			this.queueConnectionFactory = (QueueConnectionFactory)this.initialContext.lookup(this.getValue("TEMP_JMS_CONNECTION_FACTORY"));
			this.queue = (javax.jms.Queue)this.initialContext.lookup(this.getValue("TEMP_JMS_QUEUE"));
		}
		
		this.connection = this.queueConnectionFactory.createQueueConnection();
		this.session = this.connection.createQueueSession(true, Session.AUTO_ACKNOWLEDGE);
		this.sender = this.session.createSender(this.queue);
	}
	
	
	
	public void commitAndRemoveJMSConnection() throws Exception {
		this.session.commit();
		
		if(this.sender != null) {
			this.sender.close();
		}
		
		if (this.session != null) {
    		this.session.close();
    	}

        if (this.connection != null) {
        	this.connection.close();
        }
        
        this.sender = null;
        this.session = null;
        this.connection = null;
	}
	
	
	
	private void checkMessageFormat(String msg) throws Exception {
		if(!msg.startsWith("<ROOT") || !msg.endsWith("</ROOT>")) {
			throw new AsyncAdaptorServiceException(Constants.MESSAGE_FORMAT_ERROR);
		}
	}
	
	
	
	public void sendMessage(DAOObject msg) {
		try {
			// check first the message format...
			String strMessage = msg.getString("MSG_DATA_STR");
			this.checkMessageFormat(strMessage);
			
    		// create the message to be sent via JMS...
    		String strMessageToJMS = this.getValue("DISPATCH_TO_PROCESS_INPUT_MESSAGE_VIA_JMS");
    		strMessageToJMS = StringUtils.replace(strMessageToJMS, "[[ID]]", "" + msg.getLong("MSGID"));
    		strMessageToJMS = StringUtils.replace(strMessageToJMS, "[[OP]]", "" + msg.getInt("MSGTYPE_ID"));
    		strMessageToJMS = StringUtils.replace(strMessageToJMS, "[[WFR]]", "" + msg.getInt("WAIT_FOR_REPLY_IN"));
    		strMessageToJMS = StringUtils.replace(strMessageToJMS, "[[MSG]]", strMessage);
            
            BytesMessage message = this.session.createBytesMessage();
            // *******************
            message.setStringProperty("MSGID", "" + msg.getLong("MSGID"));
            message.setStringProperty("MSGTYPE_ID", "" + msg.getInt("MSGTYPE_ID"));
            // *******************
            message.writeBytes(strMessageToJMS.getBytes());
            this.sender.send(message);
		} catch(Exception e) {
			// update message with failure if necessary...
			try {
				if(Constants.MESSAGE_FORMAT_ERROR.equals(e.getMessage())) {
					this.acknowledgeWhenError(msg, Constants.MESSAGE_FORMAT_ERROR, e.toString());
				} else {
					this.acknowledgeWhenError(msg, Constants.PUSH_FOR_PROCESSING_ERROR, e.toString());
				}
			} catch(Exception e2) {
				// ...
			}
		}
	}
}


