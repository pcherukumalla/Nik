package com.rogers.mqclient;

import com.rogers.logger.utility.UtilityLogger;
import com.rogers.mqclient.get.ReadFromMQ;

public class WorkWithMQLoad {

	static String[] params = null;

	/**
	 * SAMPLE USAGE:
	 * @param args
	 */
	public static void main(String[] args) {
		try
		{
			String source = args[0];
			String[] pars = source.split("###");
			UtilityLogger.getLogger().info("No of parameters: " + pars.length);
			if ( pars.length == 2 && "GET".equalsIgnoreCase(pars[0]) )
			{
				ReadFromMQ.getMessage(pars[1]);
			}
			else
			{
				int threadNo = Integer.parseInt(pars[4].toString());
				int msgPerThread = Integer.parseInt(pars[5].toString());;
				int threadInUse = 0;
				long startTM = System.currentTimeMillis();

				MSCReplyToMQDispatcher[] dispatcher =  new MSCReplyToMQDispatcher[threadNo];
				for (int threadCount=0;threadCount<threadNo;threadCount++)
				{
					dispatcher[threadCount] = new MSCReplyToMQDispatcher();
				}

				//dispatcher.setPrerequisites(mqconfiguration, Boolean.parseBoolean(resetMqConn), Boolean.parseBoolean(resetMqDetail), correlationId, mscMsgReceived, returnCode);                             correlationId, mscMsgReceived, returnCode);
				dispatcher[0].setPrerequisites(pars[1], Boolean.parseBoolean(pars[2]), Boolean.parseBoolean(pars[3]),pars[6], pars[7].replaceAll("_"," "), pars[8].replaceAll("_"," "));
				for (int msgCount=0; msgCount<msgPerThread; msgCount++)
				{
					threadInUse = (msgCount % threadNo);
					UtilityLogger.getLogger().info("MSCReplyToMQDispatcher instance #: " + threadInUse + " Msg #:" + msgCount);
					dispatcher[threadInUse].putMessage(pars[0].replaceAll("_"," ") );
					UtilityLogger.getLogger().info("-----------------------");

				}
				UtilityLogger.getLogger().info("Total duration: " + (System.currentTimeMillis() - startTM));
			}
		}
		catch (Exception ex)
		{
				UtilityLogger.getLogger().info("Suggested usage: WorkWithMQLoad <mqmessage>###<mqdetails>###resetMqConn###resetMqDetail###threadNo###msgToSend###correlationId###mscMsgReceived###returnCode)");
				UtilityLogger.getLogger().info("Sample mqdetail: HOST=mvsd.rogers.com;PORT=1434;QMANAGER=MQDY;CHANNEL=MSC_ER_CLIENT_01;CCSID=819;QUEUE=SS_SERVICE_REPLY2;SYS_USER=");
				UtilityLogger.getLogger().info("./testmq_load.sh '230456789012CM123456789AVvv21BalanceCurrentCLMPotentialCRSuNoAssessmeDDUDUDUPAsses_______________________________________________________________________________###HOST=mvsd.rogers.com;PORT=1434;QMANAGER=MQDY;CHANNEL=MSC_ER_CLIENT_01;CCSID=819;QUEUE=SS_SERVICE_REPLY2;SYS_USER=###false###false###10###100###ID:1E22443FF57###SSIH03SSERGCRECRED230DEVMG4______000050230308272404698151602###_' >> nohup.out &");
				UtilityLogger.getLogger().info("-----------------------");
				UtilityLogger.getLogger().info("Got exception:");

			ex.printStackTrace();
		}
	}
}