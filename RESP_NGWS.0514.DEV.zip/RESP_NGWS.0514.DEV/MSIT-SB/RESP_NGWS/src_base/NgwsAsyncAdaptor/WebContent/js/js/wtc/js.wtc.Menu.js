/*
****************************************************************************************************
 ezWebToolkit Library, http://ezwt.blogspot.com
****************************************************************************************************
Copyright [2006-2008] [Pro Net Systems Inc., http://www.pronetsystems.com]

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

	http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
***************************************************************************************************
*/



/*
------------------------------------------------------------------------------------------
Menu
------------------------------------------------------------------------------------------
*/
document.write("<style type=\"text/css\">");
document.write(".ezMenuClass {");
document.write("	background-color: #FFFFFF;");
document.write("	border-style: solid;");
document.write("	border-color: rgb(120,172,255);");
document.write("	border-width: 1px;");
document.write("}");
document.write(".clsMenuOptionUnselected {");
document.write("	height: 20px;");
document.write("	background-color: rgb(200,200,200);");
document.write("	color: #FFFFFF;");
document.write("	font-family: Arial;");
document.write("	font-weight: bold;");
document.write("	font-size: 12px;");
document.write("}");
document.write(".clsMenuOptionSelected {");
document.write("	height: 20px;");
document.write("	background-color: rgb(120,172,255);");
document.write("	color: #FFFFFF;");
document.write("	cursor: pointer;");
document.write("	font-family: Arial;");
document.write("	font-weight: bold;");
document.write("	font-size: 12px;");
document.write("}");
document.write("</style>");



js.wtc.Menu = function() {
	js.wtc.ContentPanel.call(this);

	this.menuParent = null;
	this.optionIndex = 0;
	this.ezMenus_array = new Array();
	this.theOPTION = -1;
	this.theMENUOPTION = -1;

	this.hideIn = true;
	this.hideOnSelectionIn = true;
	this.direction = "y";
	this.menuSpacing = 7;

	this.menuClass = "ezMenuClass";
	this.optionSelectedClass = "clsMenuOptionSelected";
	this.optionUnselectedClass = "clsMenuOptionUnselected";

	this.objectType = "js.wtc.Menu";
}
js.wtc.Menu.prototype = new js.wtc.ContentPanel();
js.wtc.Menu.prototype.constructor = js.wtc.Menu;



js.wtc.Menu.prototype.init = function() {
	// create the main div...
	this.theViewport = document.createElement("TABLE");
	this.theViewport.cellPadding = "1";
	this.theViewport.cellSpacing = "1";
	this.theViewport.className = this.menuClass;

	if(this.direction == "x") {
		var row = this.theViewport.insertRow(-1);
		row.id = "div_ezMenuTR" + this.index + "_opts";

		var cell = row.insertCell(-1);
		cell.id = "div_ezMenuTD" + this.index + "_end";
		cell.style.width = "100%";
		cell.className = this.optionUnselectedClass;
	}

	// instrument the new node...
	this.instrumentViewport();
}



js.wtc.Menu.prototype.hideChildren = function() {
	if(this.theOPTION != -1) {
		js.wtc.Manager.descendants[this.theOPTION].hide();
		js.wtc.Manager.descendants[this.theOPTION].hideChildren();
	}
}



js.wtc.Menu.prototype.hideParent = function() {
	// unselect the parent's highlighted menu option...
	if((this.menuParent != null) && (this.menuParent.theMENUOPTION != -1)) {
		var oTD = document.getElementById("div_ezMenuOption" + this.menuParent.index + "_" + this.menuParent.theMENUOPTION);
		oTD.className =  this.menuParent.optionUnselectedClass;
	}


	if((this.menuParent != null) && this.menuParent.hideIn) {
		this.menuParent.hide();
		this.menuParent.hideParent();
	}
}



js.wtc.Menu.prototype.show = function() {
	if(this.menuParent != null) {
		var pos = com.ezwt.utils.Position.get(document.getElementById("div_ezMenuOption" + this.menuParent.index + "_" + this.optionIndex));

		if(this.menuParent.direction == "y") {
			this.set("left", (pos.left + pos.width - 5) + "px");
			this.set("top", (pos.top - 5) + "px");
		} else {
			if(document.all) {
				this.set("left", (pos.left - 2) + "px");
				this.set("top", (pos.top + pos.height - 2) + "px");
			} else {
				this.set("left", pos.left + "px");
				this.set("top", (pos.top + pos.height) + "px");
			}
		}

		// update z-index...
		var nZIndex = this.menuParent.get("zIndex");
		if(nZIndex == "") {
			nZIndex = "0";
		}
		this.set("zIndex","" + (parseInt(nZIndex) + 1));
	}

	js.wtc.ContentPanel.prototype.show.call(this);
}



js.wtc.Menu.prototype.addOption = function(o) {
    o.index = this.ezMenus_array.push(o) - 1;
    o.parent = this;

    // if this option points to another menu then pass some attributes to that menu...
    if (o.action.index) {
        o.action.menuParent = this;
        o.action.optionIndex = o.index;
    }

    // create the HTML...
    var td = document.createElement("TD");
    td.id = "div_ezMenuOption" + this.index + "_" + o.index;

    // set the inner html...
    if (typeof o.name == "string") {
        var strSpace = "";
        for (var i = 0; i < this.menuSpacing; i++) {
            strSpace += "&nbsp;";
        }
    
        var strInnerHtml = "<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" height=\"100%\" width=\"100%\"><tr><td width=\"100%\">&nbsp;" + o.name.replace(/ /gi, "&nbsp;") + "</td><td>" + strSpace + "</td>";
        if (o.action.index) {
            if (this.direction == "y") {
                strInnerHtml += "<td align=\"right\">&gt;&nbsp;</td></tr></table>";
            } else {
                strInnerHtml += "</tr></table>";
            }
        } else {
            strInnerHtml += "</tr></table>";
        }
        td.innerHTML = strInnerHtml;
    } else {
        this.append(o.name, td);
    }
    

    // set title if any...
    if (o.title != "") {
        td.title = o.title;
    }
    // set class...
    td.className = this.optionUnselectedClass;

    // add events...
    var SELF = this;
    if (document.all) {
        eval("doUnselectMenuOption" + this.index + "_" + o.index + " = function() {SELF.mouseLeave(" + o.index + ");}");
        eval("td.attachEvent(\"onmouseout\", doUnselectMenuOption" + this.index + "_" + o.index + ")");

        if (o.action.index) {
            eval("doSelectMenuOption" + this.index + "_" + o.index + " = function() {SELF.showMenu(" + o.index + ", " + o.action.index + ")}");
        } else {
            eval("doSelectMenuOption" + this.index + "_" + o.index + " = function() {SELF.showMenu(" + o.index + ")}");
        }
        eval("td.attachEvent(\"onmouseover\", doSelectMenuOption" + this.index + "_" + o.index + ")");

        if (!o.action.index) {
            if (this.hideOnSelectionIn) {
                if (typeof (o.action) == "function") {
                    eval("doActionMenuOption" + this.index + "_" + o.index + " = function() {SELF.hideMenu(); o.action()}");
                } else {
                    eval("doActionMenuOption" + this.index + "_" + o.index + " = function() {SELF.hideMenu(); " + o.action + "}");
                }
            } else {
                if (typeof (o.action) == "function") {
                    eval("doActionMenuOption" + this.index + "_" + o.index + " = o.action");
                } else {
                    eval("doActionMenuOption" + this.index + "_" + o.index + " = function() {" + o.action + "}");
                }
            }

            eval("td.attachEvent(\"onclick\", doActionMenuOption" + this.index + "_" + o.index + ")");
        }
    } else {
        td.onmouseout = eval("function(e) {SELF.mouseLeave(" + o.index + ", e);}");

        if (o.action.index) {
            td.onmouseover = eval("function() {SELF.showMenu(" + o.index + ", " + o.action.index + ")}");
        } else {
            td.onmouseover = eval("function() {SELF.showMenu(" + o.index + ")}");
        }

        if (!o.action.index) {
            if (this.hideOnSelectionIn) {
                if (typeof (o.action) == "function") {
                    td.onclick = eval("function() {SELF.hideMenu(); o.action() }");
                } else {
                    td.onclick = eval("function() {SELF.hideMenu(); " + o.action + "}");
                }
            } else {
                if (typeof (o.action) == "function") {
                    td.onclick = o.action;
                } else {
                    td.onclick = eval("function() {" + o.action + "}");
                }
            }
        }
    }

    // append to the menu shape...
    if (this.direction == "x") {
        var oTR = document.getElementById("div_ezMenuTR" + this.index + "_opts");
        var oEnd = document.getElementById("div_ezMenuTD" + this.index + "_end");
        oTR.insertBefore(td, oEnd);
    } else {
        var tr = this.viewport().insertRow(-1);
        tr.appendChild(td);
    }
}



js.wtc.Menu.prototype.mouseLeave = function(oidx, e) {
	var evt = null;
	if(document.all) {
		evt = window.event;
	} else {
		evt = e;
	}

	// check if the cursor is on a child...
	var oTD = null;
	var bOnChild = false;
	var pos = null;
	for(var i = 0; i < this.ezMenus_array.length; i++) {
		if(this.ezMenus_array[i].action.index && this.ezMenus_array[i].action.showIn) {
			//pos = com.ezwt.utils.Position.get(this.descendants[idx].ezMenus_array[i].action.htmlView().childNodes.item(0));
			pos = com.ezwt.utils.Position.get(this.ezMenus_array[i].action.viewport());

			//if(js.wtc.Manager.isInRectangle(evt.clientX, evt.clientY, pos.left, pos.top, pos.width, pos.height)) {
			if(js.wtc.Manager.isInRectangle(evt.clientX + js.wtc.Manager.scrollLeft(), evt.clientY + js.wtc.Manager.scrollTop(), pos.left, pos.top, pos.width, pos.height)) {
				bOnChild = true;
				break;
			}
		}
	}

	// if is not on a child...
	if(!bOnChild) {
		// unselect this highlighted menu option...
		oTD = document.getElementById("div_ezMenuOption" + this.index + "_" + oidx);
		oTD.className =  this.optionUnselectedClass;

		// check to see if the menu(s) should be hidden...
		//pos = com.ezwt.utils.Position.get(this.descendants[idx].htmlView().childNodes.item(0));
		pos = com.ezwt.utils.Position.get(this.viewport());
		//if(!js.wtc.Manager.isInRectangle(evt.clientX, evt.clientY, pos.left+2, pos.top+2, pos.width-5, pos.height-5)) {
		if(!js.wtc.Manager.isInRectangle(evt.clientX + js.wtc.Manager.scrollLeft(), evt.clientY + js.wtc.Manager.scrollTop(), pos.left+2, pos.top+2, pos.width-5, pos.height-5)) {
			// hide children...
			this.hideChildren();
	
			// hide current menu...
			if(this.hideIn) {
				this.hide();
			}
	
			// check if the cursor is on the parent menu...
			var bOnParent = false;
			if(this.menuParent != null) {
				//pos = com.ezwt.utils.Position.get(document.getElementById("div_ezView" + this.descendants[idx].menuParent.index).childNodes.item(0));
				pos = com.ezwt.utils.Position.get(document.getElementById("div_ezView" + this.menuParent.index));
				//if(js.wtc.Manager.isInRectangle(evt.clientX, evt.clientY, pos.left, pos.top, pos.width, pos.height)) {
				if(js.wtc.Manager.isInRectangle(evt.clientX + js.wtc.Manager.scrollLeft(), evt.clientY + js.wtc.Manager.scrollTop(), pos.left, pos.top, pos.width, pos.height)) {
					bOnParent = true;
				}
			}
	
			// hide ancestors...
			if(!bOnParent) {
				this.hideParent();
			} else {
				// unselect the parent's highlighted menu option...
				if(this.menuParent != null) {
					if(this.menuParent.theMENUOPTION != -1) {
						oTD = document.getElementById("div_ezMenuOption" + this.menuParent.index + "_" + this.menuParent.theMENUOPTION);
						oTD.className =  this.menuParent.optionUnselectedClass;
					}
				}
			}
		}
	}
}



js.wtc.Menu.prototype.showMenu = function(oidx, moidx) {
	// highlight menu option...
	var oTD = document.getElementById("div_ezMenuOption" + this.index + "_" + oidx);
	oTD.className =  this.optionSelectedClass;

	// hide the previous selected submenus if any...
	if(this.theOPTION != -1) {
		js.wtc.Manager.descendants[this.theOPTION].hide();
		js.wtc.Manager.descendants[this.theOPTION].hideChildren();
	}

	// show the new submenu if any...
	if(moidx) {
		js.wtc.Manager.descendants[moidx].show();

		this.theOPTION = moidx;
	} else {
		this.theOPTION = -1;
	}

	// set the new selected menu option...
	this.theMENUOPTION = oidx;
}



js.wtc.Menu.prototype.hideMenu = function() {
	this.hide();
	this.hideChildren();
	this.hideParent();
}



js.wtc.Menu.prototype.set = function(name, value) {
	if(name == "direction") { // before init...
		this.direction = value;
	} else if(name == "hide") { // before init...
		this.hideIn = value;
	} else if(name == "hideOnSelection") { // before init...
		this.hideOnSelectionIn = value;
	} else if(name == "menuSpacing") { // before init...
		this.menuSpacing = value;
	} else if(name == "selectedStyle") { // before init...
		this.optionSelectedClass = value;
	} else if(name == "unselectedStyle") { // before init...
		this.optionUnselectedClass = value;
	} else if(name == "menuStyle") {
		this.menuClass = value;
		this.viewport().className = value;
	} else {
		js.wtc.ContentPanel.prototype.set.call(this, name, value);
	}
}



js.wtc.Menu.prototype.get = function(name) {
	if(name == "direction") {
		return this.direction;
	} else if(name == "hide") {
		return this.hideIn;
	} else if(name == "hideOnSelection") {
		return this.hideOnSelectionIn;
	} else if(name == "menuSpacing") {
		return this.menuSpacing;
	} else if(name == "selectedStyle") {
		return this.optionSelectedClass;
	} else if(name == "unselectedStyle") {
		return this.optionUnselectedClass;
	} else if(name == "menuStyle") {
		return this.menuClass;
	} else {
		return js.wtc.ContentPanel.prototype.get.call(this, name);
	}
}
