package com.rogers.eaiosb.aync;

public class XMLWrapperConstants
{
	public static final String DELIMITER = "####";
	public static final String ELEMENT_DELIMITER = "eyyyye";
	public static final String ROOT_NODE = "<ROOT xml:space='preserve'>####</ROOT>";
	public static final String ELEMENT_NODE="<eyyyye>####</eyyyye>";
	public static final String MSG_NODE="<MESSAGE xml:space='preserve'>####</MESSAGE>";

	public static final String DB_MSGTYPE_ID_COLUMN = "MSGTYPE_ID";
}
