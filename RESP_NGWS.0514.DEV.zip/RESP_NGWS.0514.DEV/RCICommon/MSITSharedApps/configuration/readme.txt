SharedApps

PREREQUSITES:

1. Make sure that the 2 following startup arguments are added on each managed server of ICMProfiles domain

-Deai.config.datasource=<YOUR_TDV_JNDI_DATASOUCE_NAME> -Dappl.config.datasource=<YOUR_EAI_APPL_CONFIG_JNDI_DATASOURCE_NAME>

2. Check in ICMProfiles weblogic console if TDV related queue and queue Factory are created.


INSTALLATION:

1. import common-services.sbconfig.jar using the sbconsole

2. change common-services.CustomizationFile.xml customization file:
	- replace <YOUR_MANAGED_SERVER1_IP:PORT,YOUR_MANAGED_SERVER2_IP:PORT> with your corresponding value

3. apply common-services.CustomizationFile.xml in corresponding OSB domain