package com.rogers.mqclient.ssc;

public class SscHeaderFields implements java.io.Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public SscHeaderFields( String header )
	{
		_header = header;
	}

	public SscHeaderType getHeaderType()
	{
		String value = _header.substring( 0, 4 );
		if ( value.equals( SscHeaderType.confirmation.toString() ) ) return SscHeaderType.confirmation;
		if ( value.equals( SscHeaderType.status.toString() ) ) return SscHeaderType.status;
		if ( value.equals( SscHeaderType.reply.toString() ) ) return SscHeaderType.reply;
		return SscHeaderType.source;  // default
	}

	public String getUserId()
	{
		return _header.substring( 6, 14 );
	}

	public String getSourceSystem()
	{
		return _header.substring( 14, 24 );
	}

	public String getSubSystem()
	{
		return _header.substring( 24, 32 );
	}

	public String getApplication()
	{
		return _header.substring( 32, 40 );
	}

	public String getStructureId()
	{
		return _header.substring( 40, 48 );
	}

	public String getCompletionCode()
	{
		return _header.substring( 48, 50 );
	}

	public String getReasonCode()
	{
		return _header.substring( 50, 54 );
	}

	public String getActionCode()
	{
		return _header.substring( 54, 56 );
	}

	public SsConfirmationType getConfirmationType()
	{
		String value = _header.substring( 62, 66 );
		if ( value.equals( SsConfirmationType.audit.toString() ) ) return SsConfirmationType.audit;
		if ( value.equals( SsConfirmationType.coc.toString() ) ) return SsConfirmationType.coc;
		if ( value.equals( SsConfirmationType.cod.toString() ) ) return SsConfirmationType.cod;
		return SsConfirmationType.none;
	}

	public String getConfirmationNumber()
	{
		return _header.substring( 66, 90 );
	}

	public String getSerialNumber()
	{
		return _header.substring( 90, 102 );
	}

	public String getCompany()
	{
		return _header.substring( 102, 105 );
	}

	private String _header;
}
