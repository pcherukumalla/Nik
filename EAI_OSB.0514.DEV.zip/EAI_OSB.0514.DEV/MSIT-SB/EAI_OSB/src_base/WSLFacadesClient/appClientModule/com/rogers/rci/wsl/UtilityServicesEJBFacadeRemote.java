package com.rogers.rci.wsl;

import java.rmi.RemoteException;
import javax.ejb.EJBObject;
import org.apache.xmlbeans.XmlObject;

public abstract interface UtilityServicesEJBFacadeRemote extends EJBObject
{
  public abstract XmlObject verifyAddress(XmlObject paramXmlObject)
    throws RemoteException, Exception;
}