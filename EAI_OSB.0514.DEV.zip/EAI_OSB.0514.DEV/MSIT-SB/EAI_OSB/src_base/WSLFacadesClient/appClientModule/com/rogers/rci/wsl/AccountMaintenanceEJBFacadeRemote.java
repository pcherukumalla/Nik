package com.rogers.rci.wsl;

import java.rmi.RemoteException;
import javax.ejb.EJBObject;
import org.apache.xmlbeans.XmlObject;

public abstract interface AccountMaintenanceEJBFacadeRemote extends EJBObject
{
  public abstract XmlObject addBillingAddressParameters(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject adjustBan(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject applyOneTimeCharge(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject createMemo(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject creditEvaluation(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject deleteBillingAddressParameters(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject makeOneTimePayment(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject modifyBillingAddressParameters(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject performDuplicateCheck(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject retrieveAvailableBanPricePlans(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject retrieveAvailableBillCycleList(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject retrieveBalances(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject retrieveBanInfo(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject retrieveBanServices(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject retrieveBanSubscribers(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject retrieveBillList(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject retrieveBilledCharges(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject retrieveBillingAddressParameters(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject retrieveCreditEvaluation(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject retrieveCustomerBalance(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject retrieveEbppInfo(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject retrieveEnhancedProductServices(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject retrieveFirstBillEstimate(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject retrieveLastPayment(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject retrieveMemos(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject retrievePaymentHistory(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject submitEnhancedProductServices(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject updateBanInfo(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject updateCreditClass(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject updateCreditEvaluation(XmlObject paramXmlObject)
    throws RemoteException, Exception;
}