package com.async.dao.base;

import java.io.*;
import java.sql.*;
import java.util.*;
import java.util.logging.*;
import javax.servlet.*;

import org.json.*;

import com.async.utils.*;



public class DAOUtils {
	private static DAOUtils theInstance = null;
	private static Properties queries = new Properties();
	
	
	
	private DAOUtils(ServletContext ctx) {
		try {
			// get configuration file location...
			String strFilename = ctx.getRealPath("WEB-INF/" + Constants.DAO_PROP_FILENAME);
			if(strFilename == null) {
				strFilename = ctx.getResource("/WEB-INF").getFile() + Constants.DAO_PROP_FILENAME;
			}
			
			// load DAO queries...
			queries.load(new FileInputStream(strFilename));
		} catch(Exception e) {
			e.printStackTrace();
			Constants.LOGGER.log(Level.SEVERE, this.getClass().getName() + "  DAOUtils constructor - error while initializing the app: " + e.toString());
		}
	}
	
	
	
	public static void initUtils(ServletContext ctx) {
		if(theInstance == null) {
			theInstance = new DAOUtils(ctx);
		}
	}
	
	
	public static DAOUtils getInstance() {
		return theInstance;
	}
	
	
	
	public Properties getQueries() {
		return queries;
	}
	
	
	
	public JSONObject objectToJSONObject(DAOObject o) throws Exception {
		return new JSONObject(o.getAll());
	}
	
	
	
	public JSONArray listToJSONArray(List lst) throws Exception {
		JSONArray ret = new JSONArray();
		
    	DAOObject o = null;
    	for(Iterator it = lst.iterator(); it.hasNext();) {
    		o = (DAOObject)it.next();
    		
    		ret.put(objectToJSONObject(o));
    	}
		
		return ret;
	}
		
	
	
	public String getBlobAsString(Blob blob) throws BaseDAOException {
		String strRet = "";
		
		if(blob != null) {
			try {
				BufferedReader br = new BufferedReader(new InputStreamReader(blob.getBinaryStream()));
	            
	            String strLine = "";
	            while((strLine = br.readLine()) != null) {
	            	strRet += strLine + "\n";
	            }
	            if(!"".equals(strRet)) {
	            	strRet = strRet.substring(0, strRet.length() - 1);
	            }
	            
	            br.close();
			} catch(Exception e) {
				strRet = null;
				Constants.LOGGER.log(Level.SEVERE, this.getClass().getName() + ".getBlobAsString error: " + e.toString());
			}
		}
		
		return strRet;
	}
}
