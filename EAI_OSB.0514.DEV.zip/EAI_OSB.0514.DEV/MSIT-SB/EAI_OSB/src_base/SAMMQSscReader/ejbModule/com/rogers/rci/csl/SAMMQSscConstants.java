package com.rogers.rci.csl;

public class SAMMQSscConstants 
{
	public static final String JMS_CONNECTION_FACTORY_JNDI = "AsyncMsgsConnectionFactory";
	public static final String JMS_DESTINATION_QUEUE_JNDI = "ASYNC_REQUESTS_QUEUE";
	public static final String JMS_ERROR_DESTINATION_QUEUE_JNDI = "ASYNC_REQUESTS_QUEUE_ERROR";
}
