/*
------------------------------------------------------------------------------------------
NoRecordsWindow
------------------------------------------------------------------------------------------
*/
com.rogers.rci.ngws.NoRecordsWindow = function(p) {
	js.wtc.Window.call(this);
	
	this.app = p;
	
	this.loginButton = null;
}
com.rogers.rci.ngws.NoRecordsWindow.prototype = new js.wtc.Window();
com.rogers.rci.ngws.NoRecordsWindow.prototype.constructor = com.rogers.rci.ngws.NoRecordsWindow;



com.rogers.rci.ngws.NoRecordsWindow.prototype.init = function() {
	this.set("minres", false);
	this.set("resize", false);
	js.wtc.Window.prototype.init.call(this);
	
	var SELF = this;
	
	// set attributes...
	this.set("left", (screen.width/2 - 150) + "px");
	this.set("top", "200px");
	this.set("width", "300px");
	this.set("height", "130px");
	this.set("fontSize", "11px");
	this.set("title", "Warning - No Records Found");
	this.body().set("backgroundColor", "#EFEFEF");
	
	var txt = new js.wtc.Text("No matches found for this searching criteria in the main table. Do you want to search the 'history' table?");
	txt.init();
	txt.set("left", "20px");
	txt.set("top", "20px");
	txt.set("width", "260px");
	txt.set("height", "40px");
	this.body().append(txt);
	
	
	// init the close button...
	this.closeButton = new com.rogers.rci.ngws.Button("Close");
	this.closeButton.init();
	this.closeButton.set("left", "160px");
	this.closeButton.set("top", "70px");
	this.closeButton.set("width", "60px");
	this.closeButton.viewport().onclick = function() {
		SELF.hide();
	}
	this.body().append(this.closeButton);
	
	// init the history button...
	this.historyButton = new com.rogers.rci.ngws.Button("History");
	this.historyButton.init();
	this.historyButton.set("left", "80px");
	this.historyButton.set("top", "70px");
	this.historyButton.set("width", "70px");
	this.historyButton.viewport().onclick = function() {
		SELF.hide();
		
		SELF.app.topContentPanel.searchHistory();
	}
	this.body().append(this.historyButton);
}
