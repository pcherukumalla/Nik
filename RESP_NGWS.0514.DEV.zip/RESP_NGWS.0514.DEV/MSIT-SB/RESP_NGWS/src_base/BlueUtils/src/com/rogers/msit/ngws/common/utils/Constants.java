package com.rogers.msit.ngws.common.utils;

import java.text.*;



public class Constants {
	public static final String DATA_SOURCE_CONFIG_NAME = "ngws.config.datasource";
	public static final String DEFAULT_DATA_SOURCE_JNDI_NAME = "cgDataSource";
	
	public static final long ERROR_MESSAGES_REFRESH_PERIOD = 600000;
	
	public static final String OK = "OK";
	public static final String ERROR = "99999";
	public static final String ELMS_DOWN_ERROR = "99995";
	public static final String TIMEOUT_ERROR = "99994";
	
	public static final java.util.logging.Logger LOGGER = java.util.logging.Logger.getLogger("");
	
	public static final SimpleDateFormat STATS_DATE_FORMAT = new SimpleDateFormat("MMddyyyy");

	
	
	public static final String GET_ERROR_MESSAGES_SQL = "SELECT e.err_cd, e.status_in, s.move_to_hist_in FROM ngws_retry_message_errors e, ngws_retry_message_statuses s WHERE e.status_in = s.status_in";

	public static final String INSERT_MESSAGE_SQL = "INSERT INTO ngws_retry_messages (msgtype_id, szkey, msg_data, set_id) values (?, ?, ?, ?)";
	public static final String INSERT_MESSAGE_TO_HISTORY_SQL = "INSERT INTO ngws_retry_messages_hist (MSGID, SZKEY, MSG_DATA, START_TIME_TS, STATUS_IN, ERR_CD, ERR_DESC, WHEN_CREATED_TS, SET_ID, MSGTYPE_ID, END_TIME_TS, NR_OF_RETRIES) SELECT MSGID, SZKEY, MSG_DATA, START_TIME_TS, STATUS_IN, ERR_CD, ERR_DESC, WHEN_CREATED_TS, SET_ID, MSGTYPE_ID, END_TIME_TS, NR_OF_RETRIES FROM ngws_retry_messages_temp WHERE msgid = ?";
	public static final String DELETE_MESSAGE_SQL = "DELETE FROM ngws_retry_messages_temp WHERE msgid = ?";
	public static final String UPDATE_MESSAGE_AFTER_PROCESSING_SQL = "UPDATE ngws_retry_messages_temp SET status_in = ?, err_cd = ?, err_desc= ?, end_time_ts = SYSDATE, nr_of_retries = nr_of_retries + 1 WHERE msgid = ?";
	public static final String GET_MESSAGE_NR_OF_RETRIES_SQL = "SELECT nr_of_retries FROM ngws_retry_messages_temp WHERE msgid = ?";
	
	public static final String UPDATE_NR_OF_MSG_STATS_SQL = "UPDATE NGWS_RETRY_MESSAGES_STATS SET NR_OF_MSG = NR_OF_MSG + 1 WHERE day_of_year = ?";
	public static final String UPDATE_NR_OF_MSG_OTHER_ERRORS_STATS_SQL = "UPDATE NGWS_RETRY_MESSAGES_STATS SET NR_OF_MSG_OTHER_ERRORS = NR_OF_MSG_OTHER_ERRORS + 1 WHERE day_of_year = ?";
	public static final String UPDATE_NR_OF_MSG_OK_STATS_SQL = "UPDATE NGWS_RETRY_MESSAGES_STATS SET NR_OF_MSG_OK = NR_OF_MSG_OK + 1 WHERE day_of_year = ?";
	public static final String UPDATE_NR_OF_MSG_ELMS_DOWN_STATS_SQL = "UPDATE NGWS_RETRY_MESSAGES_STATS SET NR_OF_MSG_ELMS_DOWN = NR_OF_MSG_ELMS_DOWN + 1 WHERE day_of_year = ?";
	public static final String UPDATE_NR_OF_MSG_ELMS_TIMEOUT_STATS_SQL = "UPDATE NGWS_RETRY_MESSAGES_STATS SET NR_OF_MSG_ELMS_TIMEOUT = NR_OF_MSG_ELMS_TIMEOUT + 1 WHERE day_of_year = ?";
	public static final String INSERT_STATS_SQL = "INSERT INTO NGWS_RETRY_MESSAGES_STATS (day_of_year) VALUES (?)";
}
