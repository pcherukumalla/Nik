package com.rogers.mqclient.send;

import com.ibm.mq.MQC;
import com.ibm.mq.MQEnvironment;
import com.ibm.mq.MQMessage;
import com.ibm.mq.MQPutMessageOptions;
import com.ibm.mq.MQQueueManager;
import com.rogers.logger.utility.UtilityLogger;
import com.rogers.mqclient.cache.MQCacheBase;
import com.rogers.mqclient.cache.MQMSCOutCacheVO;
import com.rogers.mqclient.env.MSCOutEnvDetail;
import com.rogers.mqclient.msc.MscHeaderFields;
import com.rogers.mqclient.msc.MscReplyToSSHeader;
import com.rogers.mqclient.msc.MscMessageUtils;

public class SendNativeMSCReplyToMQ implements SendInterface
{
	private String TEXT = "";
	private MscHeaderFields mscHeaderFields = null;
	private String correlationId = null;
	private String returnCode = null;
	private char retstat;
	private MQCacheBase mqCache = null;
	private final long refreshDuration = 3 * 60 * 1000; //miliseconds
	private long lastRefresh = System.currentTimeMillis(); //set initial value

    public void setPrerequisites(String mqconfiguration, boolean resetMqConn, boolean resetMqDetail, String correlationId, String mscMsgReceived, String returnCode)
		throws Exception
	{
    	mqCache = MQMSCOutCacheVO.getInstance();

		//set the environment variables:
		if ( resetMqDetail || mqCache.getRESET_MQ_DETAIL() == null )
		{
			synchronized ( MSCOutEnvDetail.class )
			{
				new MSCOutEnvDetail( mqconfiguration );
			}
			//UtilityLogger.getLogger().info("Loaded config: " + MSCOutEnvDetail.LAST_GOOD_MQ_DETAILS);
			synchronized ( mqCache )
			{
				if (MSCOutEnvDetail.CCSID > 0 && MSCOutEnvDetail.QMGR != null ) mqCache.setRESET_MQ_DETAIL( "SET" );
			}
		}		
		this.mscHeaderFields = new MscHeaderFields( mscMsgReceived );
		this.correlationId = (""+correlationId).trim(); //received from msc request's message id		
		if ( this.correlationId != null && this.correlationId.startsWith( "ID:" ) )
		{
			// the id is JMS id, need to get the native format
			this.correlationId = this.correlationId.substring( 3 );
		}
		this.returnCode = (returnCode != null ) ? returnCode : "";
		if ( this.returnCode.trim().equalsIgnoreCase("") ) this.returnCode = "0000";
		this.retstat = ( this.returnCode == "0000" )? 'G' : 'B';

		if ( resetMqConn || refreshNow()) resetConnection();
	}

	private boolean refreshNow()
	{
		long timenow = System.currentTimeMillis();
		boolean doRefresh = false;
		if (( timenow - this.lastRefresh ) > this.refreshDuration )
		{
			doRefresh = true;
			this.lastRefresh = System.currentTimeMillis();
		}
		return doRefresh;
	}

    public void resetConnection()
    {
        try
        {
			synchronized ( mqCache )
			{
	            if ( mqCache.getQueue() != null ) mqCache.getQueue().close();
	            mqCache.setQueue( null );
	
	            if ( mqCache.getQManager() != null) mqCache.getQManager().disconnect();
	            mqCache.setQManager( null );
			}

        } catch ( Exception ex ){}
    }

    public void putMessage (String txtMessage )
		throws Exception
	{

	  if ( mqCache.getRESET_MQ_DETAIL() == null )
		  throw new Exception ("Set first prerequisites!");

      	  if (txtMessage != null )
      	  {
      		  //add msc out header to out message
      		  TEXT = new StringBuffer( String.valueOf( getAdjustedMscOutHeader( txtMessage.length() ) ) ).append( txtMessage ).toString();
      		  UtilityLogger.getLogger().info( "MSCAdapter.sendResponse: " + TEXT);
      	  }
          //UtilityLogger.getLogger().info("Using MQ detail:" + MSCOutEnvDetail.LAST_GOOD_MQ_DETAILS);

      	  try{
	          //populate the Environment
	          MQEnvironment.hostname = MSCOutEnvDetail.HOST;
	          MQEnvironment.port = new Integer(MSCOutEnvDetail.PORT).intValue();
	          MQEnvironment.channel = MSCOutEnvDetail.CHANNEL;

	          // use IBM API only!
	          int openOptions = MQC.MQOO_OUTPUT ; //MQC.MQOO_INPUT_AS_Q_DEF | MQC.MQOO_OUTPUT - if same queue used for 'read' as well
	          synchronized (mqCache)
	          {
	        	  //UtilityLogger.getLogger().info("MSCOutEnvDetail.QMGR " + MSCOutEnvDetail.QMGR);
	        	  //UtilityLogger.getLogger().info(" MSCOutEnvDetail.QNAME " +  MSCOutEnvDetail.QNAME);

	        	  if ( mqCache.getQManager() == null || (!mqCache.getQManager().isConnected()))
	        		  mqCache.setQManager( new MQQueueManager( MSCOutEnvDetail.QMGR ) );
	        	  if ( mqCache.getQueue() == null)
	        		  mqCache.setQueue ( mqCache.getQManager().accessQueue(  MSCOutEnvDetail.QNAME, openOptions, null, null, null ));
	          }
	          MQMessage sendMessage = new MQMessage();
	          sendMessage.format = MQC.MQFMT_STRING;
	          sendMessage.messageType =  120001; //MQC.MQMT_REQUEST;
	          sendMessage.expiry = 300; //600 msec -- initially from eai but IBM MQ sets expiry in 'tenths' of second on native communication
	          sendMessage.characterSet = 819;
	          sendMessage.correlationId = MscMessageUtils.getByteArrFromHex( this.correlationId );
	          sendMessage.messageId = MscMessageUtils.getByteArrFromHex( this.correlationId );
	          sendMessage.persistence = MQC.MQPER_NOT_PERSISTENT;

	          UtilityLogger.getLogger().info( "Ready .." );
	          //UtilityLogger.getLogger().info( "Default charset on system: " + Charset.defaultCharset());

	          //sendMessage.writeUTF( TEXT );
	          sendMessage.writeString( TEXT );

	          MQPutMessageOptions pmo = new MQPutMessageOptions();

	          mqCache.getQueue().put( sendMessage, pmo );
      	  }
      	  catch (Exception ex)
      	  {
      		  Throwable e1 = ex;
      		  while (e1.getCause() != null ) e1=e1.getCause();
      		  if ((e1 instanceof com.ibm.mqservices.MQInternalException) || (e1 instanceof com.ibm.mq.MQException))
      		  {
      			resetConnection();
      			mqCache.setRESET_MQ_CONN( null );
      		  }
      		  throw new Exception(e1);
      	  }
          UtilityLogger.getLogger().info("Pushed to MQ:" + TEXT);

          if ( mqCache.getRESET_MQ_CONN() == null) mqCache.setRESET_MQ_CONN( "SET" );
	}

    private char[] getAdjustedMscOutHeader(long msgLength )
    	throws Exception
    {
    	 if  (mscHeaderFields.getLengthReceived() == 0 )
    	 {
    		 throw new Exception( "MSC response header not defined" );
    	 }
		  //append the message header
		  MscReplyToSSHeader  mscToSSHeader = new MscReplyToSSHeader();
		  mscToSSHeader.setResponseInfo(mscHeaderFields.getServerId(), mscHeaderFields.getCompany(), mscHeaderFields.getUserId(), this.retstat, this.returnCode);
		  char[] respHeader = mscToSSHeader.getMscOutHeader();

		  // adjust/correct the message header
		  MscMessageUtils.numToSsStr( msgLength, respHeader, 29, 6 );
		  return respHeader;
    }
}