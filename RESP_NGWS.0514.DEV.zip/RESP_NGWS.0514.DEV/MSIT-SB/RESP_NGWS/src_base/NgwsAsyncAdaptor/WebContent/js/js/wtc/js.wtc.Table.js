/*
****************************************************************************************************
 ezWebToolkit Library, http://ezwt.blogspot.com
****************************************************************************************************
Copyright [2006-2008] [Pro Net Systems Inc., http://www.pronetsystems.com]

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

	http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
***************************************************************************************************
*/



/*
------------------------------------------------------------------------------------------
Table
------------------------------------------------------------------------------------------
*/
js.wtc.Table = function() {
	js.wtc.ContentPanel.call(this);

	this.objectType = "js.wtc.Table";
}
js.wtc.Table.prototype = new js.wtc.ContentPanel();
js.wtc.Table.prototype.constructor = js.wtc.Table;



js.wtc.Table.prototype.init = function() {
	// create the main div...
	this.theViewport = document.createElement("TABLE");
	
	// instrument the new node...
	this.instrumentViewport();
}



js.wtc.Table.prototype.createTHead = function() {
	return this.viewport().createTHead();
}



js.wtc.Table.prototype.deleteTHead = function() {
	this.viewport().deleteTHead();
}



js.wtc.Table.prototype.createTFoot = function() {
	return this.viewport().createTFoot();
}



js.wtc.Table.prototype.deleteTFoot = function() {
	this.viewport().deleteTFoot();
}



js.wtc.Table.prototype.appendTBody = function() {
	var oTBody = document.createElement("TBODY");
	this.viewport().appendChild(oTBody);

	return oTBody;
}



js.wtc.Table.prototype.generate = function(nRows, nCols, dv) {
	var tbody = this.appendTBody();

	var row = null
	var cell = null;
	for(var j = 0; j < nRows; j++) {
		row = tbody.insertRow(-1);
	
		for(var i = 0; i < nCols; i++) {
			cell = row.insertCell(-1);

			if(dv) {
				cell.innerHTML = dv;
			}
		}
	}
}



js.wtc.Table.prototype.row = function(idxRow) {
	return this.viewport().tBodies[0].rows[idxRow];
}



js.wtc.Table.prototype.addRowHighlighting = function(idxRow, color, bkcolor) {
	for(var k = 0; k < this.row(idxRow).cells.length; k++) {
        this.row(idxRow).cells[k].onmouseover = function() {
        	for(var i = 0; i < this.parentNode.cells.length; i++) {
        		this.parentNode.cells[i].BK_COLOR = this.parentNode.cells[i].style.backgroundColor;
        		this.parentNode.cells[i].FK_COLOR = this.parentNode.cells[i].style.color;
        		
        		this.parentNode.cells[i].style.backgroundColor = bkcolor;
        		this.parentNode.cells[i].style.color = color;
        	}
        }
        
        this.row(idxRow).cells[k].onmouseout = function() {
        	for(var i = 0; i < this.parentNode.cells.length; i++) {
        		this.parentNode.cells[i].style.backgroundColor = this.parentNode.cells[i].BK_COLOR;
        		this.parentNode.cells[i].style.color = this.parentNode.cells[i].FK_COLOR;
        	}
        }
	}
}



js.wtc.Table.prototype.cell = function(idxRow, idxCol) {
	return this.viewport().tBodies[0].rows[idxRow].cells[idxCol];
}



js.wtc.Table.prototype.insertRow = function(idx, dv) {
	var ret = null;

	// insert tbody if neccessary...
	if(this.viewport().tBodies.length == 0) {
		this.appendTBody();
	}

	// if is a valid index...
	if((idx >= -1) && (idx < this.viewport().tBodies[0].rows.length)) {
		// find the index of the template row...
		var nTmplIndex = -1;
		if(this.viewport().tBodies[0].rows.length > 0) {
			if(idx == 0) {
				nTmplIndex = 0;
			} else if(idx == -1) {
				nTmplIndex = this.viewport().tBodies[0].rows.length - 1;
			} else {
				nTmplIndex = idx - 1;
			}
		}
	
		// insert the new row...
		if(nTmplIndex != -1) {
			var tmplRow = this.viewport().tBodies[0].rows[nTmplIndex];
			ret = this.viewport().tBodies[0].insertRow(idx);
	
			var cell = null;
			for(var i = 0; i < tmplRow.cells.length; i++) {
				cell = ret.insertCell(-1);

				if(dv) {
					cell.innerHTML = dv;
				}
			}
		} else {
			ret = this.viewport().tBodies[0].insertRow(-1);
		}
	}

	return ret;
}



js.wtc.Table.prototype.insertCol = function(idx, dv) {
	if(idx < -1) {
		return;
	}

	// insert tbody if neccessary...
	if(this.viewport().tBodies.length == 0) {
		this.appendTBody();
	}

	// create cells...
	var nNrOfRows = this.viewport().tBodies[0].rows.length;
	if(nNrOfRows > 0) {
		var row = null;
		var cell = null;
		for(var i = 0; i < nNrOfRows; i++) {
			row = this.viewport().tBodies[0].rows[i];
			cell = row.insertCell(idx);

			if(dv) {
				cell.innerHTML = dv;
			}
		}
	}
}



js.wtc.Table.prototype.set = function(name, value) {
	if(name == "cellPadding") {
		this.viewport().cellPadding = value;
	} else if(name == "cellSpacing") {
		this.viewport().cellSpacing = value;
	} else if(name == "border") {
		this.viewport().border = value;
	} else if(name == "borderColor") {
		this.viewport().borderColor = value;
	} else if(name == "borderColorDark") {
		this.viewport().borderColorDark = value;
	} else if(name == "borderColorLight") {
		this.viewport().borderColorLight = value;
	} else {
		js.wtc.ContentPanel.prototype.set.call(this, name, value);
	}
}



js.wtc.Table.prototype.get = function(name) {
	if(name == "cellPadding") {
		return this.viewport().cellPadding;
	} else if(name == "cellSpacing") {
		return this.viewport().cellSpacing;
	} else if(name == "border") {
		return this.viewport().border;
	} else if(name == "borderColor") {
		return this.viewport().borderColor;
	} else if(name == "borderColorDark") {
		return this.viewport().borderColorDark;
	} else if(name == "borderColorLight") {
		return this.viewport().borderColorLight;
	} else {
		return js.wtc.ContentPanel.prototype.get.call(this, name);
	}
}
