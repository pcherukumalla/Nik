/*
****************************************************************************************************
ezWebToolkit Library, http://www.ezwebtoolkit.com
****************************************************************************************************
Copyright [2006-2009] [Pro Net Systems Inc., http://www.pronetsystems.com]

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
***************************************************************************************************
*/



/*
------------------------------------------------------------------------------------------
ColorPicker
------------------------------------------------------------------------------------------
*/
js.wtc.ColorPicker = function() {
    js.wtc.ContentPanel.call(this);

    this.webSafePalette = new Array();

    this.selectedColor = "#000000";
    this.selectedRedColor = 0;
    this.selectedGreenColor = 0;
    this.selectedBlueColor = 0;

    this.selectedColorContentPanel = null;
    this.redTextbox = null;
    this.greenTextbox = null;
    this.blueTextbox = null;

    this.objectType = "js.wtc.ColorPicker";
}
js.wtc.ColorPicker.prototype = new js.wtc.ContentPanel();
js.wtc.ColorPicker.prototype.constructor = js.wtc.ColorPicker;



js.wtc.ColorPicker.prototype.hex2dec = function(hexNumber) {
    // If only it were this easy to convert into other bases :)
    var decNumber = parseInt(hexNumber, 16);

    // If the conversion produced a non-number value, return 0
    if (isNaN(decNumber)) {
        return 0;
    }

    return decNumber;
}



js.wtc.ColorPicker.prototype.dec2hex = function(decNumber) {
    // The allowed hex characters
    var hexChars = '0123456789ABCDEF';

    // If the parameter we were passed is not a number,
    // then we will return zero and not process any further.
    if (isNaN(decNumber)) {
        return 0;
    }

    // Get the first hex character
    var hexNumber = hexChars.substr(decNumber & 15, 1);

    // Loop through and get the rest of the hex characters
    while (decNumber > 15) {
        // Shift the bits to the right
        decNumber >>= 4;

        // Get the hex value
        hexNumber = hexChars.substr(decNumber & 15, 1) + hexNumber;
    }

    // If the length of the hex character is less than 2, we will
    // left pad the value with a zero.
    if (hexNumber.length < 2) {
        hexNumber = '0' + hexNumber;
    }

    // Return our hex value
    return hexNumber;
}



js.wtc.ColorPicker.prototype.generateWebSafePalette = function() {
    // Declare our red, green, and blue variables.
    var decRed = 0;
    var decGreen = 0;
    var decBlue = 0;

    // Start off with our black color
    this.webSafePalette[0] = this.dec2hex(decRed) + this.dec2hex(decGreen) + this.dec2hex(decBlue);

    // i is incremented in steps of 51; j is our array index
    for (var i = 0, j = 1; i < 256; i += 51, j++) {
        if ((decRed == 255 && decGreen == 255 && decBlue == 255)) {
            // Once we've reached our final color (white), we stop looping
            break;
        }

        if (decGreen > 255) {
            // Increment our red value
            decRed += 51;

            // Roll green back to zero, along with the step iterator
            decGreen = i = 0;

            // Store the current color
            this.webSafePalette[j++] = this.dec2hex(decRed) + this.dec2hex(decGreen) + this.dec2hex(decBlue);
        }

        if (decBlue >= 255) {
            // Increment our green value
            decGreen += 51;

            // If the above causes the green to go above our threshold,
            // then we have to increment the red and reset the green.
            // We will lose colors if we don't do this.
            if (decGreen > 255) {
                decRed += 51;
                decGreen = 0;
            }

            // Roll blue back to zero, along with the step iterator
            decBlue = i = 0;

            // Store the current color, and increment our array index
            // If we don't increment the array index here we will lose 25 colors.
            this.webSafePalette[j++] = this.dec2hex(decRed) + this.dec2hex(decGreen) + this.dec2hex(decBlue);
        }

        // Increment our blue value
        decBlue += 51;

        // Store the current color
        this.webSafePalette[j] = this.dec2hex(decRed) + this.dec2hex(decGreen) + this.dec2hex(decBlue);
    }
}



js.wtc.ColorPicker.prototype.decomposeColor = function() {
    var colorOnly = "";

    if (!com.ezwt.sys.Browser.isIE) {
        colorOnly = this.selectedColor.substring(4, this.selectedColor.length - 1);
        colorOnly = colorOnly.replace(/ /gi, "");
        var colors = colorOnly.split(",");

        this.selectedRedColor = colors[0];
        this.selectedGreenColor = colors[1];
        this.selectedBlueColor = colors[2];
    } else {
        colorOnly = this.selectedColor.substring(1, this.selectedColor.length);

        this.selectedRedColor = "" + this.hex2dec(colorOnly.substring(0, 2));
        this.selectedGreenColor = "" + this.hex2dec(colorOnly.substring(2, 4));
        this.selectedBlueColor = "" + this.hex2dec(colorOnly.substring(4, 6));
    }
}



js.wtc.ColorPicker.prototype.composeColor = function() {
    this.selectedColor = "#" + this.dec2hex(this.redTextbox.get("value"))
                             + this.dec2hex(this.greenTextbox.get("value"))
                             + this.dec2hex(this.blueTextbox.get("value"));
}



js.wtc.ColorPicker.prototype.initSelectedColorContentPanel = function() {
    this.selectedColorContentPanel = new js.wtc.ContentPanel();
    this.selectedColorContentPanel.init();

    // set attributes...
    this.selectedColorContentPanel.set("left", "230px");
    this.selectedColorContentPanel.set("top", "0px");
    this.selectedColorContentPanel.set("width", "40px");
    this.selectedColorContentPanel.set("height", "40px");
    this.selectedColorContentPanel.set("border", "1px solid #000000");
    this.selectedColorContentPanel.set("backgroundColor", "#000000");

    // append it...
    this.append(this.selectedColorContentPanel);
}



js.wtc.ColorPicker.prototype.initColorTextboxes = function() {
    var SELF = this;


    // red...
    this.redTextbox = new js.wtc.Textbox();
    this.redTextbox.init();

    // set attributes
    this.redTextbox.set("left", "230px");
    this.redTextbox.set("top", "52px");
    this.redTextbox.set("width", "38px");
    this.redTextbox.set("height", "17px");
    this.redTextbox.set("border", "1px solid #000000");
    this.redTextbox.set("value", this.selectedRedColor);
    this.redTextbox.viewport().onblur = function() {
        SELF.selectedRedColor = this.value;
        SELF.composeColor();
        SELF.selectedColorContentPanel.set("backgroundColor", SELF.selectedColor);
    }

    // append it...
    this.append(this.redTextbox);


    // green...
    this.greenTextbox = new js.wtc.Textbox();
    this.greenTextbox.init();

    // set attributes
    this.greenTextbox.set("left", "230px");
    this.greenTextbox.set("top", "82px");
    this.greenTextbox.set("width", "38px");
    this.greenTextbox.set("height", "17px");
    this.greenTextbox.set("border", "1px solid #000000");
    this.greenTextbox.set("value", this.selectedGreenColor);
    this.greenTextbox.viewport().onblur = function() {
        SELF.selectedGreenColor = this.value;
        SELF.composeColor();
        SELF.selectedColorContentPanel.set("backgroundColor", SELF.selectedColor);
    }

    // append it...
    this.append(this.greenTextbox);


    // blue...
    this.blueTextbox = new js.wtc.Textbox();
    this.blueTextbox.init();

    // set attributes
    this.blueTextbox.set("left", "230px");
    this.blueTextbox.set("top", "112px");
    this.blueTextbox.set("width", "38px");
    this.blueTextbox.set("height", "17px");
    this.blueTextbox.set("border", "1px solid #000000");
    this.blueTextbox.set("value", this.selectedBlueColor);
    this.blueTextbox.viewport().onblur = function() {
        SELF.selectedBlueColor = this.value;
        SELF.composeColor();
        SELF.selectedColorContentPanel.set("backgroundColor", SELF.selectedColor);
    }

    // append it...
    this.append(this.blueTextbox);
}



js.wtc.ColorPicker.prototype.initPalette = function() {
    var SELF = this;

    // create the layout table...
    var tbl1 = new js.wtc.Table();
    tbl1.init();
    tbl1.set("left", "0px");
    tbl1.set("top", "0px");
    tbl1.set("cellPadding", "0");
    tbl1.set("cellSpacing", "0");
    tbl1.set("border", "1");
    tbl1.set("cursor", "pointer");
    tbl1.generate(12, 18);

    // set the table cells...
    var idx = 0;
    for (var i = 0; i < 18; i++) {
        for (var j = 0; j < 12; j++) {
            tbl1.cell(j, i).innerHTML = "<img src=\"images/empty10.gif\" width=\"10\" height=\"10\">";
            tbl1.cell(j, i).style.backgroundColor = "#" + this.webSafePalette[idx];
            tbl1.cell(j, i).onclick = function() {
                SELF.selectedColor = this.style.backgroundColor;

                SELF.decomposeColor();
                SELF.redTextbox.set("value", SELF.selectedRedColor);
                SELF.greenTextbox.set("value", SELF.selectedGreenColor);
                SELF.blueTextbox.set("value", SELF.selectedBlueColor);
            }
            tbl1.cell(j, i).onmouseover = function() {
                SELF.selectedColorContentPanel.set("backgroundColor", this.style.backgroundColor);
            }
            tbl1.cell(j, i).onmouseout = function() {
                SELF.selectedColorContentPanel.set("backgroundColor", SELF.selectedColor);
            }

            idx++;
        }
    }

    // append the layout table...
    this.append(tbl1);
}



js.wtc.ColorPicker.prototype.init = function() {
    js.wtc.ContentPanel.prototype.init.call(this);

    // init the selected color content panel...
    this.initSelectedColorContentPanel();

    // init the color textboxes...
    this.initColorTextboxes();

    // generate the web safe color palette...
    this.generateWebSafePalette();

    // init palette...
    this.initPalette();
}
