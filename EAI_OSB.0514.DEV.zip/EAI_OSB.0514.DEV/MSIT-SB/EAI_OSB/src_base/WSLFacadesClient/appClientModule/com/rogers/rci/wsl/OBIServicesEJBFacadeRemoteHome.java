package com.rogers.rci.wsl;

import java.rmi.RemoteException;
import javax.ejb.CreateException;
import javax.ejb.EJBHome;

public abstract interface OBIServicesEJBFacadeRemoteHome extends EJBHome
{
  public abstract OBIServicesEJBFacadeRemote create()
    throws CreateException, RemoteException, CreateException;
}