package com.rogers.rci.nrm.sam.header;

import com.rogers.rci.nrm.AsyncReaderBase;

public class NRMServiceabilityReqInterface extends com.async.engine.common.DefaultMessageInterface
{
	//TODO: Check if this interface is used for something different than getting szkey/msgtype...for JMS szkey is in JMS headers
	
	private String msgType= null;
	
	/**
	 * @param message - expects whole message with JMS header
	 */
	
	public String getSzKey ( javax.jms.Message jmsMsg ) 
		throws Exception 
	{		
		setMsgType( jmsMsg.getStringProperty(AsyncReaderBase.MSGTYPE_FLAG) );

		//get szkey:
		String tmp = jmsMsg.getStringProperty(AsyncReaderBase.BLOCK_KEY_FLAG)!=null?jmsMsg.getStringProperty(AsyncReaderBase.BLOCK_KEY_FLAG).trim():""; //remove all unexpected type of chars
		
		return tmp;
	}
	
	public void setMsgType(String value)
	{
		this.msgType = value;
	}	
	private String getMsgType()
	{
		return ("" + this.msgType);
	}
}