package com.rogers.msit.ngws.common.services;



public class AsyncAdaptorServiceException extends Exception {
final private static long serialVersionUID = 1L;
	
	
	
	public AsyncAdaptorServiceException() {
		super();
	}
	
	
	
	public AsyncAdaptorServiceException(String message) {
		super(message);
	}
	
	
	
	public AsyncAdaptorServiceException(String message, Throwable cause) {
		super(message, cause);
	}
	
	
	
	public AsyncAdaptorServiceException(Throwable cause) {
		super(cause);
	}
}
