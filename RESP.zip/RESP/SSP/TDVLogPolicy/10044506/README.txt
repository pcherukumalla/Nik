===============================
One-off Patch for Bug: 10044506
===============================

Date: Sep 27, 2011
----------------------------------
Platform Patch for	: Generic
Product Patched		: Web Services
Product Version		: 11.1.1.5.0 
-auto enabled		: No	


Bugs Fixed by this patch:
-------------------------
10044506 - [OSB-OWSM INTEG] - MANAGMENT LOGGING POLICY IS COMPLETELY IGNORED


Prerequisites:
--------------

1. Before applying non-mandatory patches, check whether you have the exact symptoms 
   described in the bug.
   
   
2. Review and download the latest version of OPatch 11.1.x via Bug 6880880.
   (OPatch version 11.1.0.8.2 or higher)
      
   Oracle recommends that all customers be on the latest version of OPatch.
   Please review the following My Oracle Support note and follow the instructions
   to update to the latest version if needed:
  
   Note 224346.1  - Opatch - Where Can I Find the Latest Version of Opatch?
         
   For FMW Opatch usage, please refer the doc at :
   http://www.oracle.com/technology/software/products/ias/files/fmw_opatch.htm


3. Verify the OUI Inventory.

   OPatch needs access to a valid OUI inventory to apply patches. 
   Validate the OUI inventory with the following command:
   - opatch lsinventory

   If the command errors out, contact Oracle Support and work to validate
   and verify the inventory setup before proceeding.


4. Confirm executables appear in your system PATH.

   The patching process will use the unzip and the opatch executables. After
   setting the ORACLE_HOME environment, confirm both of these exist before
   continuing:

   - "which opatch"
   - "which unzip"

   If either of these executables do not show in the PATH, correct the problem
   before proceeding.


5. Create a location for storing the unzipped patch. This location
   will be referred to later in the document as PATCH_TOP.


  
Pre Install Instructions:
-------------------------
- Set the ORACLE_HOME environment variable to "oracle_common" Home, 
  for example "[MW_HOME]/oracle_common" directory.


Install Instructions:
---------------------

1. Unzip the patch zip file into the PATCH_TOP.

   unzip -d PATCH_TOP p10044506_111140_Generic.zip

2. Set your current directory to the directory where the patch is located.

   cd PATCH_TOP/10044506

3. Run OPatch to apply the patch.

   Run following command:
   - opatch apply
   

When OPatch starts, it will validate the patch and make sure there
are no conflicts with the software already installed in the ORACLE_HOME.
OPatch categorizes two types of conflicts:

  (a) Conflicts with a patch already applied to the ORACLE_HOME
  In this case, please stop the patch installation and contact
  Oracle Support Services.

  (b) Conflicts with subset patch already applied to the ORACLE_HOME
  In this case, please continue the install, as the new patch
  contains all the fixes from the existing patch in the ORACLE_HOME.
  The subset patch will automatically be rolled back prior to the
  installation of the new patch.


 
Post Install Instructions:
--------------------------
- Restart all servers (AdminServer and all Managed server(s))


Deinstallation Instructions:
----------------------------
If you experience any problems after installing this patch, remove the patch as follows:

1. Make sure to follow the same Prerequisites or pre-install steps (if any) when deinstalling a patch.  
   This includes setting up any environment variables like ORACLE_HOME and verifying the OUI inventory
   before deinstalling.

2. Change to the directory where the patch was unzipped.
   cd PATCH_TOP/10044506

3. Run OPatch to deinstall the patch.

   Run following command:       
   - opatch rollback -id 10044506



Post Deinstallation Instructions:
---------------------------------
- Restart all servers (AdminServer and all Managed server(s))

   
   


DISCLAIMER:
===========
This one-off patch has undergone only basic unit testing. It has not been through the complete 
test cycle that is generally followed for a production patch set. Though the fix in this one-off 
patch rectifies the bug, Oracle Corporation will not be responsible for other issues that may arise 
due to this fix. Oracle Corporation recommends that you upgrade to the next production patch set, 
when it is available. Applying this one-off patch could overwrite other one-off patches applied
since the last patch set. Customers need to request Oracle Support for a patch that includes those 
fixes as well as inform Oracle Support about all the PSE installed when an SR is opened. 
Please download, test, and provide feedback as soon as possible to assist in the timely resolution
of this problem.
