/*
****************************************************************************************************
 ezWebToolkit Library, http://www.ezwebtoolkit.com
****************************************************************************************************
Copyright [2006-2008] [Pro Net Systems Inc., http://www.pronetsystems.com]

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

	http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
***************************************************************************************************
*/
// try to create the XMLHttpRequest function if it doesn't exist yet...
if (typeof XMLHttpRequest == "undefined") {
    XMLHttpRequest = function() {
        try { return new ActiveXObject("Msxml2.XMLHTTP.6.0"); } catch (e) { };
        try { return new ActiveXObject("Msxml2.XMLHTTP.3.0"); } catch (e) { };
        try { return new ActiveXObject("Msxml2.XMLHTTP"); } catch (e) { };
        try { return new ActiveXObject("Microsoft.XMLHTTP"); } catch (e) { };

        throw new Error("This browser does not support XMLHttpRequest or XMLHTTP.");
    }
}




js.ajax.XMLHttpRequest = function() {
    this.xmlhttp = null;
    this.method = "POST";
    this.url = "";
    this.async = true;
    this.username = null;
    this.password = null;
    this.encodeURIString = true;
    this.submit = true;

    this.queryStringSeparator = "?";
    this.argumentSeparator = "&";
    this.URLString = "";
    this.vars = new Object();

    /*
    0 = uninitialized
    1 = loading
    2 = loaded
    3 = interactive
    4 = complete
    */
    this.onLoading = function() { };
    this.onLoaded = function() { };
    this.onInteractive = function() { };
    this.onComplete = function() { };
    this.onError = function(e) { };

    this.response = null;
    this.responseXML = null;
    this.responseBody = null;
    this.status = null; ;
    this.statusDescription = null;

    // init this...
    this.initXMLHttpRequest
    this.init();

    this.objectType = "js.ajax.XMLHttpRequest";
}



js.ajax.XMLHttpRequest.prototype.init = function() {
    // obtain an instance...
    try {
        this.xmlhttp = new XMLHttpRequest();
    } catch (e) {
        this.xmlhttp = null;
    }

}



js.ajax.XMLHttpRequest.prototype.isValid = function() {
	return (this.xmlhttp != null);
}



js.ajax.XMLHttpRequest.prototype.open = function() {
    var totalurlstring = this.url;

    this.createURLString();

    if (this.method == "GET") {
        totalurlstring = this.url + this.queryStringSeparator + this.URLString;
    }

    if (this.username == null) {
        this.xmlhttp.open(this.method, totalurlstring, this.async);
    } else {
        this.xmlhttp.open(this.method, totalurlstring, this.async, this.user, this.password);
    }

    if (this.submit && (this.method == "POST")) {
        this.xmlhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    }
}



js.ajax.XMLHttpRequest.prototype.send = function(b) {
	var SELF = this;

	if(this.async) {
		this.xmlhttp.onreadystatechange = function() {
			switch(SELF.xmlhttp.readyState) {
				case 1:
					SELF.onLoading();
					break;
				case 2:
					SELF.onLoaded();
					break;
				case 3:
					SELF.onInteractive();
					break;
				case 4:
					try {
						SELF.response = SELF.xmlhttp.responseText;
						SELF.responseXML = SELF.xmlhttp.responseXML;
						SELF.responseBody = SELF.xmlhttp.responseBody;
						SELF.status = SELF.xmlhttp.status;
						SELF.statusDescription = SELF.xmlhttp.statusText;
						
						if (SELF.status == "200") {
							SELF.onComplete();
						} else {
							var err = new Error(SELF.status + " - " + SELF.statusDescription);
							err.description = SELF.response;
						
							SELF.onError(err);
						}
					} catch(e) {
						SELF.onError(e);
					}
					
					this.URLString = null;
					break;
			}
		}
		
		if(this.submit) {
			this.xmlhttp.send(this.URLString);
		} else {
			this.xmlhttp.send(b);
		}
	} else {
		this.onLoading();

		if(this.submit) {
			this.xmlhttp.send(this.URLString);
		} else {
			this.xmlhttp.send(b);
		}
		
		this.response = this.xmlhttp.responseText;
		this.responseXML = this.xmlhttp.responseXML;
		this.responseBody = this.xmlhttp.responseBody;
		this.status = this.xmlhttp.status;
		this.statusDescription = this.xmlhttp.statusText;
		
		if (this.status == "200") {
			this.onComplete();
		} else {
			var err = new Error(this.status + " - " + this.statusDescription);
			err.description = this.response;
					
			this.onError(err);
		}
		
		this.URLString = null;
	}
}



js.ajax.XMLHttpRequest.prototype.setRequestHeader = function(p, v) {
	this.xmlhttp.setRequestHeader(p, v);
}



js.ajax.XMLHttpRequest.prototype.setVar = function(name, value) {
	this.vars[name] = Array(value, false);
}



js.ajax.XMLHttpRequest.prototype.encVar = function(name, value, returnvars) {
	if (true == returnvars) {
		return Array(encodeURIComponent(name), encodeURIComponent(value));
	} else {
		this.vars[encodeURIComponent(name)] = Array(encodeURIComponent(value), true);
	}
}



js.ajax.XMLHttpRequest.prototype.processURLString = function(string, encode) {
	encoded = encodeURIComponent(this.argumentSeparator);
	regexp = new RegExp(this.argumentSeparator + "|" + encoded);
	varArray = string.split(regexp);

	for (i = 0; i < varArray.length; i++){
		urlVars = varArray[i].split("=");
		if (true == encode){
			this.encVar(urlVars[0], urlVars[1]);
		} else {
			this.setVar(urlVars[0], urlVars[1]);
		}
	}
}



js.ajax.XMLHttpRequest.prototype.createURLString = function() {
	if (this.encodeURIString && this.URLString.length) {
		this.processURLString(this.URLString, true);
	}

	// prevents caching of URLString...
	this.setVar("rndval", new Date().getTime());

	urlstringtemp = new Array();
	for (key in this.vars) {
		if (false == this.vars[key][1] && true == this.encodeURIString) {
			encoded = this.encVar(key, this.vars[key][0], true);
			delete this.vars[key];
			this.vars[encoded[0]] = Array(encoded[1], true);
			key = encoded[0];
		}

		urlstringtemp[urlstringtemp.length] = key + "=" + this.vars[key][0];
	}

	this.URLString += urlstringtemp.join(this.argumentSeparator);
}



/*js.ajax.XMLHttpRequest.prototype.submit = function() {
	this.createURLString();
	
	this.totalurlstring = this.url;
	if(this.method == "GET") {
		this.totalurlstring = this.url + this.queryStringSeparator + this.URLString;
	}

	this.send(this.URLString);
}*/



js.ajax.XMLHttpRequest.prototype.set = function(p, v) {
	if(p == "method") {
		this.method = v;
	} else if(p == "url") {
		this.url = v;
	} else if(p == "async") {
		this.async = v;
	} else if(p == "username") {
		this.username = v;
	} else if(p == "password") {
		this.password = v;
	} else if(p == "encodeURIString") {
		this.encodeURIString = v;
	} else if(p == "submit") {
		this.submit = v;
	}
}



js.ajax.XMLHttpRequest.prototype.get = function(p) {
	if(p == "method") {
		return this.method;
	} else if(p == "url") {
		return this.url;
	} else if(p == "async") {
		return this.async;
	} else if(p == "username") {
		return this.username;
	} else if(p == "password") {
		return this.password;
	} else if(p == "encodeURIString") {
		return this.encodeURIString;
	} else if(p == "submit") {
		return this.submit;
	}
}


