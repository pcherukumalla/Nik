package com.rogers.msit.common.config;

import java.net.*;
import java.util.*;
import java.text.*;
import java.util.logging.*;

import com.rogers.msit.common.utils.*;
import com.rogers.msit.common.dao.base.*;



public class Config extends CommonBase {
	private static long refreshPeriod = Constants.CONFIG_REFRESH_PERIOD;
	private static long lastRefreshTime = 0;
	private static Properties props = new Properties();
		
	private static Object syncObject = new Object();

	// get the local IP address...
	private static String localIPAddr = "";
	static {
		try {
			localIPAddr = InetAddress.getLocalHost().getHostAddress();
		} catch(Exception e) {
			Constants.LOGGER.log(Level.SEVERE, Constants.GET_IP_ADDR_ERROR + e.toString());
		}
	}
	
	
	
	public static String getUniqueId() {
		return localIPAddr + "-" + UUID.randomUUID().toString();
	}
	
	
	
	public static String formatCurrentDateTime(String pattern) {
		String strRet = "";
		
		SimpleDateFormat sdf = new SimpleDateFormat(pattern);
		strRet = sdf.format(new java.util.Date());
		
		return strRet;
	}
	
	
	
	public static String getValue(String applicationId, String configName) {
		String strRet = "";
		try {
			// refresh data from the database if expired...
			refreshData();
		
			// return config value...
			strRet =  props.getProperty(applicationId + "^" + configName);
			
			if(strRet == null) {
				strRet = "";
			}
		} catch(Exception e) {
			// ...
		}
		
		return strRet;
	}
	
	
	
	public static String getValue(String applicationId, String configName, String strDefault) {
		String strRet = "";
		try {
			// refresh data from the database if expired...
			refreshData();
		
			// return config value...
			strRet =  props.getProperty(applicationId + "^" + configName);
			
			if(strRet == null) {
				strRet = strDefault;
			}
		} catch(Exception e) {
			// ...
		}
		
		return strRet;
	}
	
	
	
	private static void refreshData() throws Exception {
		long currentTime = Calendar.getInstance().getTimeInMillis();
		
		// if more then 10 minutes have passed then refresh...
		if(currentTime - lastRefreshTime > refreshPeriod) {
			synchronized(syncObject) {
				// get data from the database...
				List entries = applCommonDAOComponent.getConfigEntries();
				
				// cache data...
				props.clear();
				
				DAOObject o = null;
				for(int i = 0; i < entries.size(); i++) {
					o = (DAOObject)entries.get(i);
					
					if(o.get("CFG_VALUE") == null) {
						props.setProperty(o.getString("APPLICATION_ID") + "^" + o.getString("CFG_NAME"), "");
					} else {
						props.setProperty(o.getString("APPLICATION_ID") + "^" + o.getString("CFG_NAME"), o.getString("CFG_VALUE"));
					}
				}
		
				// store the current time...
				lastRefreshTime = currentTime;
			}
		}
	}
}
