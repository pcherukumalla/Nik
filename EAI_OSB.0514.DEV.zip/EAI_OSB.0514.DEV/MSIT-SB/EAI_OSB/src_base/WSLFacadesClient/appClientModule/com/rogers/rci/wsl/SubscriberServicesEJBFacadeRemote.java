package com.rogers.rci.wsl;

import java.rmi.RemoteException;
import javax.ejb.EJBObject;
import org.apache.xmlbeans.XmlObject;

public abstract interface SubscriberServicesEJBFacadeRemote extends EJBObject
{
  public abstract XmlObject activateSubscriber(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject addCallingCard(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject bulkReleaseTelephoneNumber(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject bulkReserveTelephoneNumber(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject cancelSubscriber(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject changePortedInSubscriberNumber(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject changeSubscriberNumber(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject checkCVMNumberStatus(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject consolidate(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject consolidateX(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject deconsolidate(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject deleteCVMConfiguration(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject extendAgingPeriod(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject portOutTelephoneNumber(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject releaseNumber(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject removeCallingCard(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject reserveNumber(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject resetCVMPassword(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject resetVMProvisioning(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject retrieveAvailableNumbers(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject retrieveBanEligibility(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject retrieveCVMConfiguration(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject retrieveCVMNumberList(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject retrieveCallingCards(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject retrieveEquipmentWarranty(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject retrieveRollOverUsage(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject retrieveSubscriberDiscountInfo(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract String retrieveSwitchForNewTN(String paramString1, String paramString2, String paramString3)
    throws RemoteException, Exception;

  public abstract String retrieveSwitchWithProvForNewTN(String paramString1, String paramString2, String paramString3, String paramString4)
    throws RemoteException, Exception;

  public abstract XmlObject retrieveTelephoneNumberListInfo(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject retrieveTelephoneNumberStatus(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject saveCVMConfiguration(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject setAlternativeNumber(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject setBsnCancelIndicator(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject setPrimaryDPN(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject verifyPhoneNumberAgainstAddress(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject verifyPortedInNumberEligibility(XmlObject paramXmlObject)
    throws RemoteException, Exception;
}