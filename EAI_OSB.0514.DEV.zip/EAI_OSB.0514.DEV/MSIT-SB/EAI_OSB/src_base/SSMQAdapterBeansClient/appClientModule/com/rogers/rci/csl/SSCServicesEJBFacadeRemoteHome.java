package com.rogers.rci.csl;

import java.rmi.RemoteException;
import javax.ejb.CreateException;
import javax.ejb.EJBHome;

public abstract interface SSCServicesEJBFacadeRemoteHome extends EJBHome
{
  public abstract SSCServicesEJBFacadeRemote create()
    throws CreateException, RemoteException, CreateException;
}