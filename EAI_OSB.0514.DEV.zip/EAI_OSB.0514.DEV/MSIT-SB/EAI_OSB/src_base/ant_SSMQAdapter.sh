#!/bin/sh
. ${WL_HOME}/server/bin/setWLSEnv.sh
. ${ANT_HOME}/bin/ant -f SSMQAdapter/build.xml $*