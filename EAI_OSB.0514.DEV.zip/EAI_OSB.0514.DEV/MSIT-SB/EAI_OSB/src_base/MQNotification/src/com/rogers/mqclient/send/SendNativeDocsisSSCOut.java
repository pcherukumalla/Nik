package com.rogers.mqclient.send;

import com.ibm.mq.MQC;
import com.ibm.mq.MQEnvironment;
import com.ibm.mq.MQMessage;
import com.ibm.mq.MQPutMessageOptions;
import com.ibm.mq.MQQueueManager;
import com.rogers.logger.utility.UtilityLogger;
import com.rogers.mqclient.cache.MQCacheBase;
import com.rogers.mqclient.cache.DocsisSSCOutCacheVO;
import com.rogers.mqclient.env.DocsisSSCOutEnvDetail;

import com.rogers.mqclient.ssc.DocsisSSCOutHeader;
//import com.rogers.mqclient.ssc.SscHeaderFields;
import com.rogers.mqclient.ssc.SscHeaderType;
import com.rogers.mqclient.ssc.SscMessageUtils;

public class SendNativeDocsisSSCOut implements SendSSCInterface
{
	private String TEXT = "";
	//private SscHeaderFields sscHeaderFields = null;
	//private String correlationId = null;
	private static final int reasonCode = 0;
	private static final int completionCode = 0;
	private String user = "";
	private String applicationName = "";
	private String appStructID = "";
	private String company ="";
	private String action = "";

	private MQCacheBase mqCache = null;
	private final long refreshDuration = 3 * 60 * 1000; //miliseconds
	private long lastRefresh = System.currentTimeMillis(); //set initial value

    public void setPrerequisites(String mqconfiguration, boolean resetMqConn, boolean resetMqDetail, String correlationId, String mscMsgReceived, String returnCode)
		throws Exception
	{
    	mqCache = DocsisSSCOutCacheVO.getInstance();

		//set the environment variables:
		if ( resetMqDetail || mqCache.getRESET_MQ_DETAIL() == null )
		{
			synchronized ( DocsisSSCOutEnvDetail.class )
			{
				new DocsisSSCOutEnvDetail( mqconfiguration );
			}
			//UtilityLogger.getLogger().info("Loaded config: " + DocsisSSCOutEnvDetail.LAST_GOOD_MQ_DETAILS);
			synchronized ( mqCache )
			{
				if (DocsisSSCOutEnvDetail.CCSID > 0 && DocsisSSCOutEnvDetail.QMGR != null ) mqCache.setRESET_MQ_DETAIL( "SET" );
			}
		}
		this.user = DocsisSSCOutEnvDetail.SYS_USER;

		//this can be used mainly to determine if an akn to send back is required in relation to a SSC 'in' message
		//this.sscHeaderFields = new SscHeaderFields( mscMsgReceived );

		if ( resetMqConn || refreshNow()) resetConnection();
	}

    /**
     * Note: if not used, the call will send all these parameters using default value, ""
     * @param applicationName
     * @param appStructID
     * @param action
     */
    public void setAdditionalHeaderDetails( String applicationName, String appStructID, String company, String action)
    {
    	this.applicationName = applicationName;
    	this.appStructID = appStructID;
    	this.company = company;
    	this.action = action;
    }

	private boolean refreshNow()
	{
		long timenow = System.currentTimeMillis();
		boolean doRefresh = false;
		if (( timenow - this.lastRefresh ) > this.refreshDuration )
		{
			doRefresh = true;
			this.lastRefresh = System.currentTimeMillis();
		}
		return doRefresh;
	}

    public void resetConnection()
    {
        try
        {
			synchronized ( mqCache )
			{
	            if ( mqCache.getQueue() != null ) mqCache.getQueue().close();
	            mqCache.setQueue( null );
	
	            if ( mqCache.getQManager() != null) mqCache.getQManager().disconnect();
	            mqCache.setQManager( null );
			}

        } catch ( Exception ex ){}
    }

    public void putMessage (String txtMessage )
		throws Exception
	{

	  if ( mqCache.getRESET_MQ_DETAIL() == null )
		  throw new Exception ("Set first prerequisites!");

      	  if (txtMessage != null ) TEXT = "";

          //add ssc out header to out message
		  DocsisSSCOutHeader  sscOutHeader = new DocsisSSCOutHeader();
      	  TEXT = new StringBuffer( String.valueOf( getAdjustedSSCOutHeader( txtMessage.length(), sscOutHeader )  ) ).append( txtMessage ).toString();

      	  // !TEST ONLY!: to force send a test message without another header
      	  //TEXT = "SCTH01DEVPL1  SAM       SAM     SAM     SS-SAM  00    A 000074NONEMY0002136012205034357713000000000000230STREETMAST" + TEXT;

      	  UtilityLogger.getLogger().info( "SscDocsisAdapter.sendMessage: " + TEXT);
          //UtilityLogger.getLogger().info("Using MQ detail:" + DocsisSSCOutEnvDetail.LAST_GOOD_MQ_DETAILS);

      	  try{
	          //populate the Environment

	          MQEnvironment.hostname = DocsisSSCOutEnvDetail.HOST;
	          MQEnvironment.port = new Integer(DocsisSSCOutEnvDetail.PORT).intValue();
	          MQEnvironment.channel = DocsisSSCOutEnvDetail.CHANNEL;

	          // use IBM API only!
	          int openOptions = MQC.MQOO_OUTPUT ; //MQC.MQOO_INPUT_AS_Q_DEF | MQC.MQOO_OUTPUT - if same queue used for 'read' as well
	          synchronized (mqCache)
	          {
	        	  if ( mqCache.getQManager() == null || (!mqCache.getQManager().isConnected()))
	        		  mqCache.setQManager( new MQQueueManager( DocsisSSCOutEnvDetail.QMGR ) );
	        	  if ( mqCache.getQueue() == null)
	        		  mqCache.setQueue ( mqCache.getQManager().accessQueue(  DocsisSSCOutEnvDetail.QNAME, openOptions, null, null, null ));
	          }
	          MQMessage sendMessage = new MQMessage();
	          sendMessage.format = MQC.MQFMT_STRING;
	          sendMessage.messageType =  Integer.parseInt(sscOutHeader.getMessageType()); //MQC.MQMT_REQUEST;
	          sendMessage.expiry = 432000; //IBM MQ sets expiry in 'tenths' of a second on native communication //set it to 12 hours
	          sendMessage.characterSet = 819;

	          sendMessage.persistence = MQC.MQPER_PERSISTENT;

	          UtilityLogger.getLogger().info( "Ready .." );

	          //sendMessage.writeUTF( TEXT );
	          sendMessage.writeString( TEXT );

	          MQPutMessageOptions pmo = new MQPutMessageOptions();

	          mqCache.getQueue().put( sendMessage, pmo );

	          if ( sendMessage.messageId != null && sendMessage.messageId.length > 0)
	          {
	        	  UtilityLogger.getLogger().info("MsgId: " + new String( sendMessage.messageId ));
	          }
	          else
	          {
	        	  UtilityLogger.getLogger().info("MsgId could not be retrieved");
	          }
      	  }
      	  catch (Exception ex)
      	  {
      		  Throwable e1 = ex;
      		  while (e1.getCause() != null ) e1=e1.getCause();
      		  if ((e1 instanceof com.ibm.mqservices.MQInternalException) || (e1 instanceof com.ibm.mq.MQException))
      		  {
      			resetConnection();
      			mqCache.setRESET_MQ_CONN( null );
      		  }
      		  throw new Exception(e1);
      	  }
          UtilityLogger.getLogger().info("Pushed to MQ:" + TEXT);

          if ( mqCache.getRESET_MQ_CONN() == null) mqCache.setRESET_MQ_CONN( "SET" );
	}

    private char[] getAdjustedSSCOutHeader(long msgLength, DocsisSSCOutHeader  sscOutHeader )
    	throws Exception
    {
		  // message type to send
		  SscHeaderType sscHeaderType = SscHeaderType.source;

		  //append the message header
		  sscOutHeader.setServerInfo(sscHeaderType, "ADDR", applicationName, appStructID);
		  sscOutHeader.setUser( this.user, this.company );
		  sscOutHeader.setMessageCodes( SendNativeDocsisSSCOut.completionCode, SendNativeDocsisSSCOut.reasonCode, this.action );
		  char[] requestHeader = sscOutHeader.getSSCOutRequestHeader();

		  // adjust/correct the message header
		  SscMessageUtils.numToSsStr( msgLength, requestHeader, 56, 6 );

		  return requestHeader;
    }
}