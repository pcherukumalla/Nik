package com.rogers.sspmw.mask;

import java.util.HashMap;
import java.util.Map;

import org.apache.xmlbeans.XmlObject;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class MaskConfigParser {

	private static void parseConfig(Node e, Map<String,String> map, String current) {
		StringBuffer sb = new StringBuffer();
		NodeList list = e.getChildNodes();
		int size = list.getLength();
		for (int i=0; i<size; i++) {
			Node node = list.item(i);
			if(node instanceof Element) {
				parseConfig(node, map, current.concat("/").concat(node.getNodeName()));
				sb.append("|");
				sb.append(node.getNodeName());
			}
		}
		if(sb.length() > 0) {
			sb.delete(0, 1);
			map.put(current, sb.toString());
		}
	}
	
	public static Map<String,String> getConfig(XmlObject config) {
		Map<String,String> map = new HashMap<String,String>();
		Node root = config.getDomNode().getFirstChild();
		
		parseConfig(root, map, root.getNodeName());
		
		return map;
	}
}
