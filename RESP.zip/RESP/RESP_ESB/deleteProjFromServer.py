from java.util import HashMap
from java.util import HashSet
from java.util import ArrayList

from java.io import FileInputStream
from java.util import Collections

from com.bea.wli.sb.util import Refs
from com.bea.wli.config import Ref
from com.bea.wli.sb.management.configuration import ALSBConfigurationMBean

from com.bea.wli.sb.management.configuration import SessionManagementMBean

from com.bea.wli.sb.util import Refs
from com.bea.wli.config.customization import Customization
from com.bea.wli.sb.management.importexport import ALSBImportOperation

from com.bea.wli.sb.management.configuration import ALSBConfigurationMBean
from com.bea.wli.sb.management.configuration import SessionManagementMBean
import sys
#=======================================================================================
# Entry function to deploy project configuration and resources
# into a ALSB domain
#=======================================================================================

def undeployFromALSBDomain(importConfigFile):

    try:
        ProjStatus=None
	sessionName=None
        print 'Loading Deployment config from :', importConfigFile

        exportConfigProp = loadProps(importConfigFile)



        adminUrl = exportConfigProp.get("adminUrl")
        configFile = exportConfigProp.get("configFile")
        keyFile = exportConfigProp.get("keyFile")
        project_1 = exportConfigProp.get("project_1")
        project_2 = exportConfigProp.get("project_2")
        project_3 = exportConfigProp.get("project_3")
        project_4 = exportConfigProp.get("project_4")
        project_5 = exportConfigProp.get("project_5")
        project_6 = exportConfigProp.get("project_6")

        print 'adminUrl=', adminUrl


	print 'Connecting to server ', adminUrl
        connect(userConfigFile=configFile, userKeyFile=keyFile, url=adminUrl)

        domainRuntime()
	print 'Connected!'
 
        sessionName = String("Customization"+Long(System.currentTimeMillis()).toString())
        SessionMBean = findService("SessionManagement", "com.bea.wli.sb.management.configuration.SessionManagementMBean")
        SessionMBean.createSession(sessionName)
        

         
#        SessionMBean = findService("SessionManagement", "com.bea.wli.sb.management.configuration.SessionManagementMBean")

#        print "SessionMBean started session"

#        SessionMBean.createSession(sessionName)
#        print 'Created session<', sessionName, '>'
        ALSBConfigurationMBean = findService("ALSBConfiguration." + sessionName.toString(), "com.bea.wli.sb.management.configuration.ALSBConfigurationMBean")

############################
#       Removing Project_1 #
############################
        print "Trying to remove " + project_1
        projectRef = Ref(Ref.PROJECT_REF, Ref.DOMAIN, project_1)

        if ALSBConfigurationMBean.exists(projectRef):
            print "#### removing OSB project: " + project_1
            ALSBConfigurationMBean.delete(Collections.singleton(projectRef))
        else:
            print "OSB project <" + project_1 + "> does not exist"               
            failed = "OSB project <" + project_1 + "> does not exist"
            raise Failure(failed)

        print "#### removed project: " + project_1
        print

############################
#       Removing Project_2 #
############################
        print "Trying to remove " + project_2
        projectRef = Ref(Ref.PROJECT_REF, Ref.DOMAIN, project_2)
        if ALSBConfigurationMBean.exists(projectRef):
            print "#### removing OSB project: " + project_2
            ALSBConfigurationMBean.delete(Collections.singleton(projectRef))

            ProjStatus = true
        else:
            print "OSB project <" + project_2 + "> does not exist"               
            failed = "OSB project <" + project_2 + "> does not exist"
            raise Failure(failed)

        print "#### removed project: " + project_2
        print

############################
#       Removing Project_3 #
############################
        print "Trying to remove " + project_3
        projectRef = Ref(Ref.PROJECT_REF, Ref.DOMAIN, project_3)
        if ALSBConfigurationMBean.exists(projectRef):
            print "#### removing OSB project: " + project_3
            ALSBConfigurationMBean.delete(Collections.singleton(projectRef))

            ProjStatus = true
        else:
            print "OSB project <" + project_3 + "> does not exist"               
            failed = "OSB project <" + project_3 + "> does not exist"
            raise Failure(failed)

        print "#### removed project: " + project_3
        print

############################
#       Removing Project_4 #
############################
        print "Trying to remove " + project_4
        projectRef = Ref(Ref.PROJECT_REF, Ref.DOMAIN, project_4)
        if ALSBConfigurationMBean.exists(projectRef):
            print "#### removing OSB project: " + project_4
            ALSBConfigurationMBean.delete(Collections.singleton(projectRef))

            ProjStatus = true
        else:
            print "OSB project <" + project_4 + "> does not exist"               
            failed = "OSB project <" + project_4 + "> does not exist"
            raise Failure(failed)

        print "#### removed project: " + project_4
        print
        

############################
#       Removing Project_5 #
############################
        print "Trying to remove " + project_5
        projectRef = Ref(Ref.PROJECT_REF, Ref.DOMAIN, project_5)
        if ALSBConfigurationMBean.exists(projectRef):
            print "#### removing OSB project: " + project_5
            ALSBConfigurationMBean.delete(Collections.singleton(projectRef))

            ProjStatus = true
        else:
            print "OSB project <" + project_5 + "> does not exist"               
            failed = "OSB project <" + project_5 + "> does not exist"
            raise Failure(failed)

        print "#### removed project: " + project_5
        print

############################
#       Removing Project_6 #
############################
        print "Trying to remove " + project_6
        projectRef = Ref(Ref.PROJECT_REF, Ref.DOMAIN, project_6)
        if ALSBConfigurationMBean.exists(projectRef):
            print "#### removing OSB project: " + project_6
            ALSBConfigurationMBean.delete(Collections.singleton(projectRef))

            ProjStatus = true
        else:
            print "OSB project <" + project_6 + "> does not exist"               
            failed = "OSB project <" + project_6 + "> does not exist"
            raise Failure(failed)

        print "#### removed project: " + project_6
        print

        if ProjStatus ==true :
            SessionMBean.activateSession(sessionName, "Complete project removal with customization using wlst")

    except:
          print "Error whilst removing project:", sys.exc_info()[0]
          discardSession(SessionMBean, sessionName)
          raise

def discardSession(SessionMBean, sessionName):
     if SessionMBean != None:
          if SessionMBean.sessionExists(sessionName):
               SessionMBean.discardSession(sessionName)
               print "Session discarded"


#===================================================================
# Utility function to load properties from a config file
#===================================================================

def loadProps(configPropFile):
    propInputStream = FileInputStream(configPropFile)
    configProps = Properties()
    configProps.load(propInputStream)
    return configProps



# IMPORT script init
try:

    undeployFromALSBDomain(sys.argv[1])

except:
    print "Unexpected error: ", sys.exc_info()[0]
    dumpStack()
    raise 