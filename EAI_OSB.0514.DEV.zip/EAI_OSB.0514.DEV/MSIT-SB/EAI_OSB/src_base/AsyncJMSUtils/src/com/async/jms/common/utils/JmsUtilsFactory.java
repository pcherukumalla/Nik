package com.async.jms.common.utils;

public class JmsUtilsFactory 
{	
	private static JmsUtils jmsUtilWorker = new JmsUtils();
	private static final long refreshDuration = 1 * 60 * 1000; //miliseconds
	private static long lastRefresh = System.currentTimeMillis(); //set initial value	
	
	/**
	 * to use JMSUtilsFactory:
	 * in client do: 
	 * JmsUtils jmsUtilWorker = null;
	 * jmsUtilWorker = JmsUtilsFactory.getInstance( String jmsConnFactoryJNDI, String jmsQueueJNDI );
	 * jmsUtilWorker.sendMessage(String strMsg, String correlationID, java.util.HashMap<String, String> paramsMap)
	 * -- the map contains JMS attributes to push further (name/value) --
	 */
	
	public static JmsUtils getInstance( String jmsConnFactoryJNDI, String jmsQueueJNDI ) 
		throws Exception
	{
		synchronized ( JmsUtilsFactory.jmsUtilWorker )
		{
			if (JmsUtilsFactory.jmsUtilWorker == null || refreshNow() || isOtherJMSConfig(jmsConnFactoryJNDI, jmsQueueJNDI) )
			{
				JmsUtilsFactory.jmsUtilWorker = new JmsUtils();
				JmsUtilsFactory.jmsUtilWorker.commitClose();												
			}	
			//initialize configuration
			JmsUtilsFactory.jmsUtilWorker.setJMS_CONN_FACTORY_JNDI( jmsConnFactoryJNDI );
			JmsUtilsFactory.jmsUtilWorker.setJMS_QUEUE_JNDI( jmsQueueJNDI );				
		}
		
		JmsUtilsFactory.jmsUtilWorker.prepareSupportJMSArtifacts();
		
		return JmsUtilsFactory.jmsUtilWorker;
	}
	
	private static boolean isOtherJMSConfig( String jmsConnFactoryJNDI, String jmsQueueJNDI )
		throws Exception
	{
		boolean respVal = false;
		if ( jmsConnFactoryJNDI == null || jmsQueueJNDI == null || jmsConnFactoryJNDI.trim().equalsIgnoreCase("") || jmsQueueJNDI.trim().equalsIgnoreCase("") )
			throw new Exception( "Provided JNDI for JMS connection factory or queue is invalid" );
		
		if ( JmsUtilsFactory.jmsUtilWorker.getJMS_CONN_FACTORY_JNDI() != null && JmsUtilsFactory.jmsUtilWorker.getJMS_QUEUE_JNDI() != null )
		{
			respVal =  true; //we received JNDIs for a different factory/queue
		}
		
		return respVal;
	}
	
	private static boolean refreshNow()
	{
		long timenow = System.currentTimeMillis();
		boolean doRefresh = false;
		if (( timenow - JmsUtilsFactory.lastRefresh ) > JmsUtilsFactory.refreshDuration )
		{
			doRefresh = true;
			JmsUtilsFactory.lastRefresh = System.currentTimeMillis();
		}
		return doRefresh;
	}	
}
