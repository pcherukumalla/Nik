package com.rogers.mqclient;

import com.rogers.logger.utility.UtilityLogger;

public class WorkWithMSC {

	static String[] params = null;

	/**
	 * SAMPLE USAGE:
	 * @param args
	 */
	public static void main(String[] args) {
		try
		{
			String[] pars = args[0].split("###");
			UtilityLogger.getLogger().info("No of params received: " + pars.length);

			if ( pars.length < 8  )
				throw new Exception("This operation requires more parameters. Check params and try again.");

				WorkWithMSC.sendMSCRequestToMQ( args[0] );

		}
		catch (Exception ex)
		{						
				UtilityLogger.getLogger().info("Suggested usage: WorkWithMSC <mqmessage>###<mqdetails>###resetMqConn###resetMqDetail###correlationId###mscMsgReceived###password###mqdetailsResponse###initSessionDataForSSUser)");
				
				UtilityLogger.getLogger().info("Sample mqdetail: HOST=mvsd.rogers.com;PORT=1434;QMANAGER=MQDY;CHANNEL=MSC_ER_CLIENT_01;CCSID=819;QUEUE=SS_SERVICE_REPLY2;SYS_USER=");
				UtilityLogger.getLogger().info("initSessionDataForSSUser sample: sstart=xx;company=xy;passwd=yy;pstarttime=uu;pwd_updated=ii;days_valid=yythk;scount=15;token=jhsd9k");
				UtilityLogger.getLogger().info("Request data is expected in the mscMsgReceived field");
				UtilityLogger.getLogger().info("-----------------------");
				UtilityLogger.getLogger().info("Got this exception");

			ex.printStackTrace();
		}
	}
	
	public static void sendMSCRequestToMQ(String mscOutMsgBody, String mqconfigurationRequest, String resetMqConn, String resetMqDetail, String correlationId, String mscMsgReceived, String password, String mqconfigurationResponse, String initSessionDataForSSUser)
		throws Exception
	{
		String respMSC = MSCDispatchAssembler.sendMSCRequestToMQ(mscOutMsgBody, mqconfigurationRequest, resetMqConn, resetMqDetail, correlationId, mscMsgReceived, password, mqconfigurationResponse, initSessionDataForSSUser);
		System.out.println("MSC response:" + respMSC);
	}

	public static void sendMSCRequestToMQ(String delimitedParams)
		throws Exception
	{
		//delimitedParams=delimitedParams.replaceAll("_"," ");
		UtilityLogger.getLogger().info("Received delimitedParams: " + delimitedParams);
		WorkWithMSC.params = delimitedParams.split("###");
		UtilityLogger.getLogger().info("After split I got # of params: " + WorkWithMSC.params.length);
		//                      String mscOutMsgBody, String mqconfigurationRequest, String resetMqConn, String resetMqDetail, String correlationId, String mscMsgReceived, String password, String mqconfigurationResponse, String initSessionDataForSSUser
		WorkWithMSC.sendMSCRequestToMQ( params[0].replaceAll("_"," "), params[1], params[2], params[3], params[4], params[5].replaceAll("_"," "), params[6].replaceAll("_"," "),params[7],params[8].replaceAll("_"," "));
	}
}