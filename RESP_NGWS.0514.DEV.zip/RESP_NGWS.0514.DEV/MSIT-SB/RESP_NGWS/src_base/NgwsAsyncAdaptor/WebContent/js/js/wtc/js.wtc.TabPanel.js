/*
****************************************************************************************************
 ezWebToolkit Library, http://ezwt.blogspot.com
****************************************************************************************************
Copyright [2006-2008] [Pro Net Systems Inc., http://www.pronetsystems.com]

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

	http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
***************************************************************************************************
*/



/*
------------------------------------------------------------------------------------------
TabPanel
------------------------------------------------------------------------------------------
*/
document.write("<style type=\"text/css\">");
document.write(".clsTabSelected {");
document.write("	height: 20px;");
document.write("	background-color: rgb(120,172,255);");
document.write("	color: #FFFFFF;");
document.write("	cursor: pointer;");
document.write("	font-family: Arial;");
document.write("	font-weight: bold;");
document.write("	font-size: 12px;");
document.write("	border-right-style: solid;");
document.write("	border-right-width: 1px;");
document.write("	border-right-color: #FFFFFF;");
document.write("}");
document.write(".clsTabUnselected {");
document.write("	height: 20px;");
document.write("	background-color: rgb(200,200,200);");
document.write("	color: #FFFFFF;");
document.write("	cursor: pointer;");
document.write("	font-family: Arial;");
document.write("	font-weight: bold;");
document.write("	font-size: 12px;");
document.write("	border-right-style: solid;");
document.write("	border-right-width: 1px;");
document.write("	border-right-color: #FFFFFF;");
document.write("	border-bottom-style: solid;");
document.write("	border-bottom-width: 1px;");
document.write("	border-bottom-color: #FFFFFF;");
document.write("}");
document.write(".clsTabEnd {");
document.write("	height: 20px;");
document.write("	width: 100%;");
document.write("}");
document.write(".clsTabLine {");
document.write("	height: 5px;");
document.write("	background-color: rgb(120,172,255);");
document.write("}");
document.write(".clsTabBackground {");
document.write("	border-bottom-style: solid;");
document.write("	border-bottom-width: 1px;");
document.write("	border-bottom-color: rgb(120,172,255);");
document.write("	border-right-style: solid;");
document.write("	border-right-width: 1px;");
document.write("	border-right-color: rgb(120,172,255);");
document.write("	border-left-style: solid;");
document.write("	border-left-width: 1px;");
document.write("	border-left-color: rgb(120,172,255);");
document.write("}");
document.write("</style>");



js.wtc.TabPanel = function() {
    js.wtc.ContentPanel.call(this);

    this.optionsIndex = -1;
    this.theOPTION = -1;
    this.closeIn = true; // global close indicator...

    // options...
    this.header = null;
    this.area = null;

    this.endCell = null;
    this.lineCell = null;
    

    this.tabSelectedClass = "clsTabSelected";
    this.tabUnselectedClass = "clsTabUnselected";
    this.tabLineClass = "clsTabLine";
    this.tabEndClass = "clsTabEnd";
    this.tabBackgroundClass = "clsTabBackground";
    this.closeImg = js.IMAGES_PATH + "delete.gif";
    this.areaOffsetY = "26px"; // set before init....

    this.objectType = "js.wtc.TabPanel";
}
js.wtc.TabPanel.prototype = new js.wtc.ContentPanel();
js.wtc.TabPanel.prototype.constructor = js.wtc.TabPanel;



js.wtc.TabPanel.prototype.init = function() {
    js.wtc.ContentPanel.prototype.init.call(this);

    // set the header content panel attributes...
    this.header = new js.wtc.Table();
    this.header.init();
    this.header.set("cellPadding", "0");
    this.header.set("cellSpacing", "0");
    var tbody = this.header.appendTBody();

    // insert the options row and the empty last cell...
    var row = tbody.insertRow(-1);
    var cell = row.insertCell(-1);
    //cell.id = "div_ezTab_end" + this.index;
    cell.className = this.tabEndClass;
    this.endCell = cell;

    // insert the "line" row...
    row = tbody.insertRow(-1);
    cell = row.insertCell(-1);
    //cell.id = "div_ezTab_line" + this.index;
    cell.className = this.tabLineClass;
    this.lineCell = cell;

    // append it to the content panel...
    this.append(this.header);

    // create the body/area content panel...
    this.area = new js.wtc.ContentPanel();
    this.area.init();
    this.area.set("className", this.tabBackgroundClass);
    this.area.set("left", "0px");
    this.area.set("top", this.areaOffsetY);

    // append it to the content panel...
    this.append(this.area);
}



js.wtc.TabPanel.prototype.headerLastCell = function() {
    //return document.getElementById("div_ezTab_end" + this.index);
    return this.endCell;
}



js.wtc.TabPanel.prototype.headerLineCell = function() {
    //return document.getElementById("div_ezTab_line" + this.index);
    return this.lineCell;
}


js.wtc.TabPanel.prototype.headerOptionCell = function(idx) {
    //return document.getElementById("div_ezTab" + this.index + "_" + idx);
    return this.getOptionByIndex(idx).cell;
}



js.wtc.TabPanel.prototype.addOption = function(text, o) {
    var SELF = this;

    // create new cell...
    var row = this.header.viewport().tBodies[0].rows[0];
    var cell = document.createElement("TD");
    row.insertBefore(cell, this.headerLastCell());
    cell.className = this.tabUnselectedClass;

    // add the cell to the cells array...
    this.optionsIndex++;
    var idx = this.optionsIndex;

    // set cell attributes...
    //cell.id = "div_ezTab" + this.index + "_" + this.optionsIndex;

    // create the header option title...
    var ho = new js.wtc.TabPanelHeaderOption(text, this.closeIn, this.closeImg, function() { SELF.removeOptionByIndex(idx) });
    ho.init();
    ho.addEventListener("onclick", function() { SELF.selectOptionByIndex(idx) });
    this.header.append(ho, cell);

    // fix the header line...
    this.headerLineCell().colSpan = this.headerLineCell().colSpan + 1;

    // append to the control panel...
    o.cell = cell;
    o.tabOptionIndex = this.optionsIndex; // save the index within the control panel itself...
    //o.set("left", "0px");
    o.set("left", "1px");
    o.set("top", this.area.get("top"));
    o.set("width", this.area.get("width"));
    o.set("height", this.area.get("height"));
    this.append(o);
}



js.wtc.TabPanel.prototype.showOptionByIndex = function(idx) {
	for(var i = 0; i < this.descendents.length; i++) {
		if(this.descendents[i].tabOptionIndex == idx) {
			this.descendents[i].show();
		}
	}
}



js.wtc.TabPanel.prototype.hideOptionByIndex = function(idx) {
	for(var i = 0; i < this.descendents.length; i++) {
		if(this.descendents[i].tabOptionIndex == idx) {
			this.descendents[i].hide();
		}
	}
}



js.wtc.TabPanel.prototype.selectOptionByIndex = function(idx) {
    if (this.getOptionByIndex(idx) == null) {
        return;
    }

    if (this.theOPTION != -1) {
        this.hideOptionByIndex(this.theOPTION);
        this.headerOptionCell(this.theOPTION).className = this.tabUnselectedClass;
    }

    this.showOptionByIndex(idx);
    this.headerOptionCell(idx).className = this.tabSelectedClass;
    this.theOPTION = idx;
}



js.wtc.TabPanel.prototype.selectOption = function(o) {
	this.selectOptionByIndex(o.tabOptionIndex);
}



js.wtc.TabPanel.prototype.removeOptionByIndex = function(idx) {
    // select the new active tab option...
    var nIndex = this.getNextIndex(idx);
    if (nIndex != -1) {
        this.selectOptionByIndex(nIndex);
    } else {
        nIndex = this.getPreviousIndex(idx);
        if (nIndex != -1) {
            this.selectOptionByIndex(nIndex);
        } else {
            this.theOPTION = -1;
            this.hide();
        }
    }

    // remove cell from header...
    var row = this.header.viewport().tBodies[0].rows[0];
    row.removeChild(this.headerOptionCell(idx));

    // fix tab panel line...
    this.headerLineCell().colSpan = this.headerLineCell().colSpan - 1;

    // hide option...
    this.hideOptionByIndex(idx);

    // execute onClose...
    var obj = this.getOptionByIndex(idx);
    obj.onClose();

    // remove option as a descendant...
    this.remove(obj);
}



js.wtc.TabPanel.prototype.removeOption = function(o) {
	this.removeOptionByIndex(o.tabOptionIndex);
}



js.wtc.TabPanel.prototype.getOptionByIndex = function(idx) {
	var ret = null;
	
	for(var i = 0; i < this.descendents.length; i++) {
		if(this.descendents[i].tabOptionIndex == idx) {
			ret = this.descendents[i];
			break;
		}
	}

	return ret;
}



js.wtc.TabPanel.prototype.getNextIndex = function(idx) {
	var ret = -1;
    
	for(var i = 0; i < this.descendents.length; i++) {
		if((this.descendents[i].tabOptionIndex != null) && (this.descendents[i].tabOptionIndex > idx)) {
			ret = this.descendents[i].tabOptionIndex;
			break;
		}
	}
	
	return ret;
}



js.wtc.TabPanel.prototype.getPreviousIndex = function(idx) {
	var ret = -1;
    
	for(var i = this.descendents.length - 1; i >= 0; i--) {
		if((this.descendents[i].tabOptionIndex != null) && (this.descendents[i].tabOptionIndex < idx)) {
			ret = this.descendents[i].tabOptionIndex;
			break;
		}
	}
	
	return ret;
}



js.wtc.TabPanel.prototype.getLength = function() {
	var ret = 0;

	for(var i = 0; i < this.descendents.length; i++) {
		if(this.descendents[i].tabOptionIndex != null) {
			ret++;
		}
	}
	
	return ret;
}



js.wtc.TabPanel.prototype.getOptions = function() {
	var ret = new Array();

	for(var i = 0; i < this.descendents.length; i++) {
		if(this.descendents[i].tabOptionIndex != null) {
			ret.push(this.descendents[i]);
		}
	}
	
	return ret;
}



js.wtc.TabPanel.prototype.show = function() {
    // append to the document if no parent...
    if ((this.theViewport.parentNode == null) || (this.theViewport.parentNode.nodeName == "#document-fragment")) {
        document.body.appendChild(this.theViewport);
    }

    if (this.theViewport != null) {
        this.theViewport.style.display = "block";
    }
    this.showIn = true;
    
    for (var i = 0; i < this.descendents.length; i++) {
        if (this.descendents[i].tabOptionIndex == null) {
            this.descendents[i].show();
        }
    }
}



js.wtc.TabPanel.prototype.hide = function() {
	var oView = this.viewport();
	if(oView != null) {
		oView.style.display = "none";
	}
	this.showIn = false;

	for(var i = 0; i < this.descendents.length; i++) {
		if(this.descendents[i].tabOptionIndex == null) {
			this.descendents[i].hide();
		}
	}
}



js.wtc.TabPanel.prototype.updateOptionsSize = function(s) {
	for(var i = 0; i < this.descendents.length; i++) {
		if(this.descendents[i].tabOptionIndex != null) {
			this.descendents[i].set(s, this.area.get(s));
		}
	}
}



js.wtc.TabPanel.prototype.set = function(name, value) {
	if(name == "width") {
		this.area.set("width", value);
		this.header.set("width", (parseInt(value) + 2) + "px");
		this.updateOptionsSize("width");
	} else if(name == "height") {
		this.area.set("height", (parseInt(value) - parseInt(this.areaOffsetY) + 1) + "px");
		this.updateOptionsSize("height");
	} else if(name == "close") {
		this.closeIn = value;
	} else if(name == "areaOffsetY") { // set before init....
		this.areaOffsetY = value;
	} else {
		js.wtc.ContentPanel.prototype.set.call(this, name, value);
	}
}



js.wtc.TabPanel.prototype.get = function(name) {
	if(name == "width") {
		return this.area.get("width");
	} else if(name == "height") {
		return this.area.get("height");
	} else if(name == "close") {
		return this.closeIn;
	} else if(name == "areaOffsetY") {
		return this.areaOffsetY;
	} else {
		return js.wtc.ContentPanel.prototype.get.call(this, name);
	}
}
