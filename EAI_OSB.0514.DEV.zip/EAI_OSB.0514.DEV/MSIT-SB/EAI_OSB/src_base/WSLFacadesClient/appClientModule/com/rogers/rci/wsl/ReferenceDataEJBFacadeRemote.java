package com.rogers.rci.wsl;

import java.rmi.RemoteException;
import java.util.Date;
import javax.ejb.EJBObject;
import org.apache.xmlbeans.XmlObject;

public abstract interface ReferenceDataEJBFacadeRemote extends EJBObject
{
  public abstract XmlObject retrieveBanAdjustReasonCodeList(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject retrieveCLMOptionInfo(String paramString)
    throws RemoteException, Exception;

  public abstract String retrieveCLMTagByOption(String paramString1, String paramString2)
    throws RemoteException, Exception;

  public abstract XmlObject retrieveCancelProductReasonCodeList(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject retrieveCarrierList(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject retrieveCvmAltNumTypes()
    throws RemoteException, Exception;

  public abstract XmlObject retrieveCvmOptions(String paramString)
    throws RemoteException, Exception;

  public abstract Date retrieveLogicalDate()
    throws RemoteException, Exception;

  public abstract XmlObject retrievePenaltyAdjustReasonCodeList(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject retrieveReturnDepositMethodList(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject retrieveWaiveReasonCodeList(XmlObject paramXmlObject)
    throws RemoteException, Exception;
}