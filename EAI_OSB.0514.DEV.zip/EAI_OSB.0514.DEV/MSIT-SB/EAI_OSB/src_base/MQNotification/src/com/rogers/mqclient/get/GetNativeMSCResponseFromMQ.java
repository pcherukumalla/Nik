package com.rogers.mqclient.get;

import com.ibm.mq.MQC;
import com.ibm.mq.MQEnvironment;
import com.ibm.mq.MQGetMessageOptions;
import com.ibm.mq.MQMessage;
import com.ibm.mq.MQQueueManager;
import com.rogers.logger.utility.UtilityLogger;
import com.rogers.mqclient.cache.MQCacheBase;
import com.rogers.mqclient.cache.MQMSCRespCacheVO;
import com.rogers.mqclient.env.MSCRespEnvDetail;
import com.rogers.mqclient.msc.GetMSCResponseInterface;

public class GetNativeMSCResponseFromMQ implements GetMSCResponseInterface
{
	//public static final int maxSessions = 20;

	private MQCacheBase mqCache = null;
	private final long refreshDuration = 3 * 60 * 1000; //miliseconds
	private long lastRefresh = System.currentTimeMillis(); //set initial value

    public void setPrerequisites(String mqconfiguration, boolean resetMqConn, boolean resetMqDetail, String correlationId, String mscMsgReceived, String password)
		throws Exception
	{
    	mqCache = MQMSCRespCacheVO.getInstance();

		//set the environment variables:
		if ( resetMqDetail || mqCache.getRESET_MQ_DETAIL() == null )
		{
			synchronized ( MSCRespEnvDetail.class )
			{
				new MSCRespEnvDetail( mqconfiguration );
			}

			synchronized ( mqCache )
			{
				if (MSCRespEnvDetail.CCSID > 0 && MSCRespEnvDetail.QMGR != null ) mqCache.setRESET_MQ_DETAIL( "SET" );
			}
		}		
		
		if ( resetMqConn || refreshNow()) resetConnection();
	}

	private boolean refreshNow()
	{
		long timenow = System.currentTimeMillis();
		boolean doRefresh = false;
		if (( timenow - this.lastRefresh ) > this.refreshDuration )
		{
			doRefresh = true;
			this.lastRefresh = System.currentTimeMillis();
		}
		return doRefresh;
	}

    public void resetConnection()
    {
        try
        {
            if ( mqCache.getQueue() != null ) mqCache.getQueue().close();
            mqCache.setQueue( null );

            if ( mqCache.getQManager() != null) mqCache.getQManager().disconnect();
            mqCache.setQManager( null );

        } catch ( Exception ex ){}
    }

    public String getMSCResponse (byte[] correlationId )
		throws Exception
	{  
      String  mqMscResponse = null;
	  if ( mqCache.getRESET_MQ_DETAIL() == null )
		  throw new Exception ("Set first prerequisites!");

      	  try{
	          //populate the Environment
	          MQEnvironment.hostname = MSCRespEnvDetail.HOST;
	          MQEnvironment.port = new Integer(MSCRespEnvDetail.PORT).intValue();
	          MQEnvironment.channel = MSCRespEnvDetail.CHANNEL;

	          // use IBM API only!
	          int openOptions = MQC.MQOO_INPUT_AS_Q_DEF | MQC.MQOO_OUTPUT; // - if same queue used for 'read' as well
	          synchronized (mqCache)
	          {	        	
	        	  if ( mqCache.getQManager() == null || (!mqCache.getQManager().isConnected()))
	        		  mqCache.setQManager( new MQQueueManager( MSCRespEnvDetail.QMGR ) );
	        	  if ( mqCache.getQueue() == null)
	        		  mqCache.setQueue ( mqCache.getQManager().accessQueue(  MSCRespEnvDetail.QNAME, openOptions, null, null, null ));
	          }
	          MQMessage receiveMessage = new MQMessage();
	          receiveMessage.format = MQC.MQFMT_STRING;
	          //receiveMessage.characterSet = 819;

	          receiveMessage.persistence = MQC.MQPER_NOT_PERSISTENT;

	          UtilityLogger.getLogger().info( "Ready to get MSC response .." );

	          receiveMessage.correlationId = correlationId;

	          MQGetMessageOptions gmo = new MQGetMessageOptions();	          
	          gmo.options = MQC.MQGMO_WAIT | MQC.MQGMO_CONVERT;
	          
	          // Specify the wait interval for the message in milliseconds
			  gmo.waitInterval = 300000;
				
	          mqCache.getQueue().get( receiveMessage, gmo );
	          
	          // Find and store message length
			  int  msglen = receiveMessage.getMessageLength();
			  
			  byte [] reply = new byte[ msglen ];
			  receiveMessage.readFully( reply );
	          mqMscResponse = new String( reply, "ISO-8859-1");			  
      	  }
      	  catch (Exception ex)
      	  {
      		  Throwable e1 = ex;
      		  while (e1.getCause() != null ) e1=e1.getCause();
      		  if ((e1 instanceof com.ibm.mqservices.MQInternalException) || (e1 instanceof com.ibm.mq.MQException))
      		  {
      			resetConnection();
      			mqCache.setRESET_MQ_CONN( null );
      		  }
      		  throw new Exception(e1);
      	  }
          UtilityLogger.getLogger().info("Got MSC from MQ:" + mqMscResponse);

          if ( mqCache.getRESET_MQ_CONN() == null) mqCache.setRESET_MQ_CONN( "SET" );
         
          return mqMscResponse;
	}
    
    public void putMessage (String txtMessage ) throws Exception
    {
    	throw new Exception("Not to be used in a sync MSC context!");
    }
}