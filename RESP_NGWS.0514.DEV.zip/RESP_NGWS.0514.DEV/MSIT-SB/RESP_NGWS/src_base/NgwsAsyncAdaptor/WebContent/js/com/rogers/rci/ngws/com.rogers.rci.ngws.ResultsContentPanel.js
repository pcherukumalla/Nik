/*
------------------------------------------------------------------------------------------
ResultsContentPanel
------------------------------------------------------------------------------------------
*/
com.rogers.rci.ngws.ResultsContentPanel = function(p) {
	js.wtc.ContentPanel.call(this);
	
	this.app = p;
	this.layoutTable = null;
	this.statsChart = null;
}
com.rogers.rci.ngws.ResultsContentPanel.prototype = new js.wtc.ContentPanel();
com.rogers.rci.ngws.ResultsContentPanel.prototype.constructor = com.rogers.rci.ngws.ResultsContentPanel;



com.rogers.rci.ngws.ResultsContentPanel.prototype.init = function() {
	js.wtc.ContentPanel.prototype.init.call(this);
	
	var SELF = this;

	// set attributes...
	this.set("left", "30px");
	this.set("top", "99px");
	this.set("width", (this.app.width - 75) + "px");
	this.set("height", (this.app.height - 280) + "px");
	this.set("backgroundColor", "#FFFFFF");
	this.set("border", "1px solid rgb(120,172,255)");
	this.set("overflowY", "scroll");
	this.set("overflowX", "auto");
	
	// ...
}



com.rogers.rci.ngws.ResultsContentPanel.prototype.resetData = function() {
	if(this.layoutTable != null) {
		this.remove(this.layoutTable);
		
		this.set("innerHTML", "");
		this.layoutTable = null;
	}
	
	if(this.statsChart != null) {
		this.statsChart.clearChart();
	}
}



com.rogers.rci.ngws.ResultsContentPanel.prototype.buildStatsData = function(data, erIn) {
	/*var data = google.visualization.arrayToDataTable([
	                                         		    ['Day', 	'SUCCESS',		'ELMS TIMEOUT', 	'ELMS DOWN', 	'OTHER ERRORS'],
	                                         		    ['0102',	100000,			9000,				6000, 			6000],
	                                         		    ['0103',  	117000,			16000,				3000, 			7000],
	                                         		    ['0104',  	66000,			6000,				2000, 			5000],
	                                         		    ['0105',  	103000,			9000,				4000, 			8000],
	                                         		 	['0106',	100000,			9000,				1000, 			5000],
	                                         		 	['0107',  	117000,			1600,				2000, 			3000],
	                                         		 	['0108',  	66000,			6000,				3000, 			6000],
	                                         		    ['0106',	100000,			9000,				1000, 			5000],
	                                         		 	['0107',  	117000,			1600,				2000, 			3000],
	                                         		 	['0108',  	66000,			6000,				3000, 			6000]
	                                         		]);*/
	                                      	
	var chartData = google.visualization.arrayToDataTable(data);
	
	var options = null;
	if(!erIn) {
		options = {
			title: '<DataSync to ELMS> Messages',
			hAxis: {title: 'Day', titleTextStyle: {color: 'grey'}},
			colors: ["#3694E0", "#05A81B", "#FF0000"]
		};
	} else {
		options = {
				title: '<DataSync to ELMS> Messages (Errors Only)',
				hAxis: {title: 'Day', titleTextStyle: {color: 'grey'}},
				colors: ["#FF0000", "#FF9900", "#871BE0"]
			};
	}
	
	this.statsChart = new google.visualization.ColumnChart(this.viewport());
	this.statsChart.draw(chartData, options);
}



com.rogers.rci.ngws.ResultsContentPanel.prototype.buildTodayStatsData = function(data, dt) {
	var chartData = google.visualization.arrayToDataTable(data);
	
	var options = {
			title: '<DataSync to ELMS> Messages (Today Only)',
			//vAxis: {title: 'Day', titleTextStyle: {color: 'grey'}},
			vAxis: {textStyle: {color: 'white'}},
			colors: ["#3694E0", "#05A81B", "#FF0000", "#FF9900", "#871BE0"]
		};
		
	this.statsChart = new google.visualization.BarChart(this.viewport());
	this.statsChart.draw(chartData, options);
	
	
	this.app.topContentPanel.detailsContentPanel.NR_OF_MSG.set("text", dt.NR_OF_MSG);
	this.app.topContentPanel.detailsContentPanel.NR_OF_MSG_OK.set("text", dt.NR_OF_MSG_OK);
	this.app.topContentPanel.detailsContentPanel.NR_OF_MSG_ELMS_TIMEOUT.set("text", dt.NR_OF_MSG_ELMS_TIMEOUT);
	this.app.topContentPanel.detailsContentPanel.NR_OF_MSG_ELMS_DOWN.set("text", dt.NR_OF_MSG_ELMS_DOWN);
	this.app.topContentPanel.detailsContentPanel.NR_OF_MSG_OTHER_ERRORS.set("text", dt.NR_OF_MSG_OTHER_ERRORS);
	
	this.app.topContentPanel.detailsContentPanel.show();
}



com.rogers.rci.ngws.ResultsContentPanel.prototype.buildData = function(data, bHist) {
	if(data.items.length > 0) {
		var SELF = this;
		
		// create the table layout...
		this.layoutTable = new js.wtc.Table();
		this.layoutTable.init();
		this.layoutTable.set("left", "0px");
		this.layoutTable.set("top", "0px");
		this.layoutTable.set("cellPadding", "1");
		this.layoutTable.set("cellSpacing", "1");
		this.layoutTable.generate(1 + data.items.length, 11);
		// append it...
		this.append(this.layoutTable);
		
		var cell = null;
		for(var i = 0; i < 11; i++) {
			cell = this.layoutTable.cell(0, i);
			cell.style.backgroundColor = "rgb(120,172,255)";
			cell.style.color = "#FFFFFF";
			cell.align = "center";
			cell.style.width = "80px";
			
			// icon...
			if(i == 0) {
				cell.innerHTML = "-";
				cell.style.width = "20px";
			}
			
			// MSGID...
			if(i == 1) {
				cell.innerHTML = "MSGID";
			}
			
			// SZKEY...
			if(i == 2) {
				cell.innerHTML = "ECID";
			}
			
			// MSGTYPE_ID...
			if(i == 3) {
				cell.innerHTML = "TYPE";
				cell.style.width = "100px";
			}
			
			// WHEN_CREATED_TS_FORMATTED...
			if(i == 4) {
				cell.innerHTML = "CREATE_TS";
			}
			
			// STATUS_IN description...
			if(i == 5) {
				cell.innerHTML = "STATUS";
			}
			// NR_OF_RETRIES...
			if(i == 6) {
				cell.innerHTML = "RETRIES";
			}
			
			// START_TIME_TS_FORMATTED...
			if(i == 7) {
				cell.innerHTML = "START_TS";
			}
			
			// END_TIME_TS_FORMATTED...
			if(i == 8) {
				cell.innerHTML = "END_TS";
			}
			
			// ERR_CD name...
			if(i == 9) {
				cell.innerHTML = "ERROR";
				cell.style.width = "218px";
			}
			
			// RECORD_LOCATION name...
			if(i == 10) {
				cell.innerHTML = "LOCATION";
			}
		}
				
		var strColor = "";
		for(var i = 0; i < data.items.length; i++) {
			if(strColor == "#EFEFEF") {
				strColor = "";
			} else {
				strColor = "#EFEFEF";
			}
			
			// icon...
			cell = this.layoutTable.cell(i + 1, 0);
			cell.align = "center";
			cell.style.backgroundColor = strColor;
			cell.thebgcolor = strColor;
			cell.style.cursor = "pointer";
			cell.title = "click for details";
			if((data.items[i].ERR_CD != null) && (data.items[i].ERR_CD != "") && (data.items[i].ERR_CD != "OK")) {
				cell.style.backgroundColor = "red";
				cell.thebgcolor = "red";
			} else {
				cell.style.backgroundColor = "rgb(130, 190, 130)";
				cell.thebgcolor = "rgb(130, 190, 130)";
			}
			cell.msg = data.items[i];
			cell.onclick = function() {
				if(this.msg.RECORD_LOCATION == "history") {
					SELF.app.detailsWindow.loadData(this.msg);
					SELF.app.detailsWindow.show();
				} else {
					SELF.app.detailsWindow.getMessage(this.msg);
				}
			}
			cell.onmouseover = function() {
				this.style.backgroundColor = "rgb(120,172,255)";
			}
			cell.onmouseout = function() {
				this.style.backgroundColor = this.thebgcolor;
			}
			
			
			// MSGID...
			cell = this.layoutTable.cell(i + 1, 1);
			cell.innerHTML = data.items[i].MSGID;
			cell.align = "center";
			cell.style.backgroundColor = strColor;
			
			// SZKEY...
			cell = this.layoutTable.cell(i + 1, 2);
			cell.innerHTML = data.items[i].SZKEY;
			cell.align = "center";
			cell.style.backgroundColor = strColor;
			
			// MSGTYPE_ID...
			cell = this.layoutTable.cell(i + 1, 3);
			cell.innerHTML = this.app.getMessageType(data.items[i].MSGTYPE_ID).DESCRIPTION;
			cell.title = data.items[i].MSGTYPE_ID;
			cell.align = "center";
			cell.style.backgroundColor = strColor;
			
			// WHEN_CREATED_TS_FORMATTED...
			cell = this.layoutTable.cell(i + 1, 4);
			cell.innerHTML = data.items[i].WHEN_CREATED_TS_FORMATTED;
			cell.align = "center";
			cell.style.backgroundColor = strColor;
			
			// STATUS_IN...
			cell = this.layoutTable.cell(i + 1, 5);
			cell.innerHTML = this.app.getStatus(data.items[i].STATUS_IN).DESCRIPTION;
			cell.title = "status_in = " + data.items[i].STATUS_IN;
			if((data.items[i].STATUS_IN == 2) || (data.items[i].STATUS_IN == 3)) {
				cell.style.color = "red";
			} else if(data.items[i].STATUS_IN == 1) {
				cell.style.color = "navy";
			} else if(data.items[i].STATUS_IN == 4) {
				cell.style.color = "green";
			}
			cell.align = "center";
			cell.style.backgroundColor = strColor;
			
			// NR_OF_RETRIES...
			cell = this.layoutTable.cell(i + 1, 6);
			cell.innerHTML = data.items[i].NR_OF_RETRIES;
			cell.align = "center";
			cell.style.backgroundColor = strColor;
			
			// START_TIME_TS_FORMATTED...
			cell = this.layoutTable.cell(i + 1, 7);
			if(data.items[i].START_TIME_TS_FORMATTED != null) {
				cell.innerHTML = data.items[i].START_TIME_TS_FORMATTED;
			} else {
				cell.innerHTML = "-";
			}
			cell.align = "center";
			cell.style.backgroundColor = strColor;
			
			// END_TIME_TS_FORMATTED...
			cell = this.layoutTable.cell(i + 1, 8);
			if(data.items[i].END_TIME_TS_FORMATTED != null) {
				cell.innerHTML = data.items[i].END_TIME_TS_FORMATTED;
			} else {
				cell.innerHTML = "-";
			}
			cell.align = "center";
			cell.style.backgroundColor = strColor;
			
			// NOTES...
			cell = this.layoutTable.cell(i + 1, 9);
			if(data.items[i].ERR_CD != null) {
				var strErrName = this.app.getError(data.items[i].ERR_CD).ERR_NAME;
				if(strErrName.length < 20) {
					cell.innerHTML = strErrName
					cell.title = "err_cd = " + data.items[i].ERR_CD;
				} else {
					cell.innerHTML = strErrName.substring(0, 20) + "...";
					cell.title = "err_cd = " + data.items[i].ERR_CD + ", err_name = " + strErrName;
				}
				
				if(data.items[i].ERR_CD != "OK") {
					cell.style.color = "red";
				}
			} else {
				cell.innerHTML = "-";
			}
			cell.align = "center";
			cell.style.backgroundColor = strColor;
			
			// RECORD_LOCATION...
			cell = this.layoutTable.cell(i + 1, 10);
			cell.innerHTML = data.items[i].RECORD_LOCATION;
			cell.align = "center";
			cell.style.backgroundColor = strColor;
		}
	} else {
		if(this.app.typeOfSearch == "main") {
			this.app.noRecordsWindow.show();
		} else {
			alert("No matches found for this searching criteria.");
		}
	}
}
