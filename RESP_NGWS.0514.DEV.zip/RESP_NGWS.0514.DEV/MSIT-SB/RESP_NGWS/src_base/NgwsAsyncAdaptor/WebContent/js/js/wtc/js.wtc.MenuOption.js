/*
****************************************************************************************************
 ezWebToolkit Library, http://ezwt.blogspot.com
****************************************************************************************************
Copyright [2006-2008] [Pro Net Systems Inc., http://www.pronetsystems.com]

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

	http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
***************************************************************************************************
*/



/*
------------------------------------------------------------------------------------------
MenuOption
------------------------------------------------------------------------------------------
*/
js.wtc.MenuOption = function(name, action) {
    this.index = -1;
    this.parent = null;
    this.name = name;
    this.title = "";
    this.action = action;

    this.objectType = "js.wtc.MenuOption";
}



js.wtc.MenuOption.prototype.viewport = function() {
    return document.getElementById("div_ezMenuOption" + this.parent.index + "_" + this.index);
}



js.wtc.MenuOption.prototype.set = function(name, value) {
    if (name == "title") {
        this.title = value;
        this.viewport().title = this.title;
    } else if (name == "name") {
        this.name = value;
        if (typeof this.name == "string") {
            var strSpace = "";
            for (var i = 0; i < this.parent.menuSpacing; i++) {
                strSpace += "&nbsp;";
            }

            var strInnerHtml = "<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" height=\"100%\" width=\"100%\"><tr><td width=\"100%\">&nbsp;" + this.name.replace(/ /gi, "&nbsp;") + "</td><td>" + strSpace + "</td>";
            if (this.action.index) {
                if (this.direction == "y") {
                    strInnerHtml += "<td align=\"right\">&gt;&nbsp;</td></tr></table>";
                } else {
                    strInnerHtml += "</tr></table>";
                }
            } else {
                strInnerHtml += "</tr></table>";
            }
            this.viewport().innerHTML = strInnerHtml;
        } else {
            this.viewport().innerHTML = "";
            this.parent.append(this.name, this.viewport());
        }
    } else {
        eval("this.viewport().style." + name + " = \"" + value + "\"");
    }
}



js.wtc.MenuOption.prototype.get = function(name) {
    if (name == "name") {
        return this.name;
    } else if (name == "title") {
        return this.title;
    } else {
        return eval("this.viewport().style." + name);
    }
}

