package com.rogers.rci.csl;

public class XMLWrapperConstants 
{
	public static final String DELIMITER = "####";
	public static final String ELEMENT_DELIMITER = "eyyyye";
	public static final String ROOT_NODE = "<processMessage xmlns='http://www.openuri.org/'>####</processMessage>";
	public static final String ELEMENT_NODE="<eyyyye>####</eyyyye>";
	public static final String MSG_NODE="<msgdata xml:space='preserve'><![CDATA[####]]></msgdata>";	
	
	public static final String JMS_CORRELATION_FLAG = "mesgId";
	public static final String MSG_CATEGORY = "MSG_CATEGORY";
	public static final String MSG_CURRENT_CATEGORY = "MSC";
}
