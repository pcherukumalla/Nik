package com.rogers.msit.ngws.engine;

import com.rogers.msit.ngws.dao.base.*;
import com.rogers.msit.ngws.services.*;
import com.rogers.msit.ngws.utils.*;



public class AsyncAdaptorAuxThread implements Runnable {
	private DAOObject msg = null;
	
	
	
	public AsyncAdaptorAuxThread(DAOObject msg) {
		this.msg = msg;
	}
	
	
	
	public void run() {
		long nMessageId = msg.getLong("MSGID");
		
		try {
						//long nStart = System.currentTimeMillis();
			AsyncAdaptorService.getInstance().pushMessageForProcessing(nMessageId, msg.getInt("MSGTYPE_ID"), msg.getString("MSG_DATA_STR"));
						//System.out.println("markAndPushAll: " + (System.currentTimeMillis() - nStart));
		} catch(Exception e) {
			// update message with failure if necessary...
			try {
				if(Constants.MESSAGE_FORMAT_ERROR.equals(e.getMessage())) {
					AsyncAdaptorService.getInstance().acknowledge(nMessageId, Constants.MESSAGE_FORMAT_ERROR, e.toString());
				} else {
					AsyncAdaptorService.getInstance().acknowledge(nMessageId, Constants.PUSH_FOR_PROCESSING_ERROR, e.toString());
				}
			} catch(Exception e2) {
				// ...
			}
		}
	}
}
