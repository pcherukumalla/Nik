package com.rogers.mqclient.cache;

public class MQMSCOutCacheVO extends MQCacheBase
{
	private static MQCacheBase mqCacheVO = null;
	
	public static MQCacheBase getInstance()
	{
		synchronized( MQMSCOutCacheVO.class )
		{
			if ( mqCacheVO == null ) mqCacheVO = new MQCacheBase();
		}
		return mqCacheVO;
	}
	
}
