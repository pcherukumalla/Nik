package com.rogers.rci.wsl;

import javax.ejb.EJBObject;

public abstract interface GetSwitchForNewTNEJBFacadeRemote extends EJBObject
{
}