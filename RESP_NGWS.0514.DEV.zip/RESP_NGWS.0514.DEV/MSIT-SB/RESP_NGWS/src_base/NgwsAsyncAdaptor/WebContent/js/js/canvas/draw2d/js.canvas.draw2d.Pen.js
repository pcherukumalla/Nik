/*
****************************************************************************************************
ezWebToolkit Library, http://www.ezwebtoolkit.com
****************************************************************************************************
Copyright [2006-2009] [Pro Net Systems Inc., http://www.pronetsystems.com]

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
***************************************************************************************************
*/



/*
------------------------------------------------------------------------------------------
Pen
This class holds the drawing pen/stroke information.
Mainly it holds the color and width values to be used for 2D drawing. 
All draw methods take jsPen object as a parameter. Acts like a pen for drawing.
------------------------------------------------------------------------------------------
*/
js.canvas.draw2d.Pen = function(color, width) {
    this.color = new js.canvas.draw2d.Color(); //color proprty of jsColor type
    this.width = "1px"; 		//width property with 1px default value

    if (arguments.length > 0) {
        this.color = color;
    }
    if (arguments.length >= 2) {
        this.width = width;
    }
    if (!isNaN(width)) {
        this.width = width + "px";
    }
}