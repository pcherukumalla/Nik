/*
****************************************************************************************************
 ezWebToolkit Library, http://www.ezwebtoolkit.com
****************************************************************************************************
Copyright [2006-2008] [Pro Net Systems Inc., http://www.pronetsystems.com]

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

	http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
***************************************************************************************************
*/



// ************************************************************************************************
// position & dimensions library
// ************************************************************************************************
js.util.Position = function() {
    this.version = "1.0";

    this.objectType = "js.util.Position";
}


// resolve a string identifier to an object...
js.util.Position.prototype.resolveObject = function(s) {
    if (document.getElementById && document.getElementById(s) != null) {
        return document.getElementById(s);
    } else if (document.all && document.all[s] != null) {
        return document.all[s];
    } else if (document.anchors && document.anchors.length && document.anchors.length > 0 && document.anchors[0].x) {
        for (var i = 0; i < document.anchors.length; i++) {
            if (document.anchors[i].name == s) {
                return document.anchors[i];
            }
        }
    }
}



// retrieve the position and size of an object...
js.util.Position.prototype.get = function(o) {
    var fixBrowserQuirks = true;
    // if a string is passed in instead of an object ref, resolve it...
    if (typeof (o) == "string") {
        o = this.resolveObject(o);
    } else if (o.viewport) {
        o = o.viewport();
    }

    if (o == null) {
        return null;
    }

    var left = 0;
    var top = 0;
    var width = 0;
    var height = 0;
    var parentNode = null;
    var offsetParent = null;


    offsetParent = o.offsetParent;
    var originalObject = o;
    var el = o; // "el" will be nodes as we walk up, "o" will be saved for offsetParent references
    while (el.parentNode != null) {
        el = el.parentNode;
        if (el.offsetParent == null) {
        }
        else {
            var considerScroll = true;
            /*
            In Opera, if parentNode of the first object is scrollable, then offsetLeft/offsetTop already 
            take its scroll position into account. If elements further up the chain are scrollable, their 
            scroll offsets still need to be added in. And for some reason, TR nodes have a scrolltop value
            which must be ignored.
            */
            if (fixBrowserQuirks && window.opera) {
                if (el == originalObject.parentNode || el.nodeName == "TR") {
                    considerScroll = false;
                }
            }
            if (considerScroll) {
                if (el.scrollTop && el.scrollTop > 0) {
                    top -= el.scrollTop;
                }
                if (el.scrollLeft && el.scrollLeft > 0) {
                    left -= el.scrollLeft;
                }
            }
        }
        // if this node is also the offsetParent, add on the offsets and reset to the new offsetParent
        if (el == offsetParent) {
            left += o.offsetLeft;
            if (el.clientLeft && el.nodeName != "TABLE") {
                left += el.clientLeft;
            }
            top += o.offsetTop;
            if (el.clientTop && el.nodeName != "TABLE") {
                top += el.clientTop;
            }
            o = el;
            if (o.offsetParent == null) {
                if (o.offsetLeft) {
                    left += o.offsetLeft;
                }
                if (o.offsetTop) {
                    top += o.offsetTop;
                }
            }
            offsetParent = o.offsetParent;
        }
    }


    if (originalObject.offsetWidth) {
        width = originalObject.offsetWidth;
    }
    if (originalObject.offsetHeight) {
        height = originalObject.offsetHeight;
    }

    return { 'left': left, 'top': top, 'width': width, 'height': height };
}



// get a "singleton"...
js.util.Position = new js.util.Position();
