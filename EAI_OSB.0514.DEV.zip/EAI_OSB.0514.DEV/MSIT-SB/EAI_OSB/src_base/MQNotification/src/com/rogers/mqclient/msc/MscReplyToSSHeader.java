package com.rogers.mqclient.msc;

public class MscReplyToSSHeader {
	
	// message header for request messages
	private char[] messageHeader = null;
	static final int responseHeaderLength = 60;
	static final String respStructId = "SSOH";
	static final String version  = "03";
	
	public char[] getMscOutHeader()
	{
		return this.messageHeader;
	}
	
	public void setResponseInfo( String server, String company, String userid, char status, String retcode )
	{
		// set header with info provided
		messageHeader = new char[responseHeaderLength];
		java.util.Arrays.fill( messageHeader, ' ' );

		// "SSOH03<server><company><userid><resource><msglen>";
		MscMessageUtils.copyChars( respStructId, messageHeader, 0, 4 );
		MscMessageUtils.copyChars( version, messageHeader,  4, 2 );
		MscMessageUtils.copyChars( server,  messageHeader,  6, 8 );
		MscMessageUtils.copyChars( company, messageHeader, 14, 3 );
		MscMessageUtils.copyChars( userid,  messageHeader, 17, 8 );
		MscMessageUtils.copyChars( retcode, messageHeader, 35, 4 );
		messageHeader[39] = status;
	}
	
}
