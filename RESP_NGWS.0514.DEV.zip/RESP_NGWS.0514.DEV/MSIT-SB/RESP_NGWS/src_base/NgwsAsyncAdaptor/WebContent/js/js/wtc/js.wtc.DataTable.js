/*
****************************************************************************************************
 ezWebToolkit Library, http://ezwt.blogspot.com
****************************************************************************************************
Copyright [2006-2008] [Pro Net Systems Inc., http://www.pronetsystems.com]

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

	http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
***************************************************************************************************
*/



/*
------------------------------------------------------------------------------------------
DataTable
------------------------------------------------------------------------------------------
*/
document.write("<style type=\"text/css\">");
document.write(".ezDataTableClass {");
document.write("	color: rgb(255,255,255);");
document.write("	background-color: rgb(120,172,255);");
document.write("}");
document.write("}");
document.write("</style>");



js.wtc.DataTable = function() {
	js.wtc.Table.call(this);
	
	this.cols = null
	this.data = null;
	
	this.headerClass = "ezDataTableClass";
	this.showHeaderIn = true;
}
js.wtc.DataTable.prototype = new js.wtc.Table();
js.wtc.DataTable.prototype.constructor = js.wtc.DataTable;



js.wtc.DataTable.prototype.build = function() {
	var cell = null;

	this.set("cellPadding", "4");
	this.set("cellSpacing", "1");
	this.set("width", "100%");
	if(this.showHeaderIn) {
		this.generate(this.data.length + 1, this.cols.length);
	} else {
		this.generate(this.data.length, this.cols.length);
	}
	
	// generate header...
	if(this.showHeaderIn) {
		for(var i = 0; i < this.cols.length; i++) {
			cell = this.cell(0, i);
			
			//cell.style.color = "#FFFFFF";
			//cell.style.backgroundColor = "rgb(120,172,255)";
			cell.className = this.headerClass;
			cell.innerHTML = this.cols[i].display;
		}
	}
	
	// generate data...
	var bkColor = "#FFFFFF";
	for(var i = 0; i < this.data.length; i++) {
		// set cells background color...
		if(bkColor == "#EFEFEF") {
			bkColor = "#FFFFFF";
		} else {
			bkColor = "#EFEFEF";
		}
		
		for(var j = 0; j < this.cols.length; j++) {
			if(this.showHeaderIn) {
				cell = this.cell(i + 1, j);
			} else {
				cell = this.cell(i, j);
			}
			
			cell.style.color = "#7F7F7F";
			cell.style.backgroundColor = bkColor;
			cell.innerHTML = eval("this.data[i]." + this.cols[j].name);
		}
	}
}



js.wtc.DataTable.prototype.set = function(name, value) {
	if(name == "cols") {
		this.cols = value;
	} else if(name == "data") {
		this.data = value;
	} else if(name == "showHeader") {
		this.showHeaderIn = value;
	} else if(name == "headerClass") { // before init...
		this.headerClass = value;
	} else {
		js.wtc.Table.prototype.set.call(this, name, value);
	}
}



js.wtc.DataTable.prototype.get = function(name) {
	if(name == "cols") {
		return this.cols;
	} else if(name == "data") {
		return this.data;
	} else if(name == "showHeader") {
		return this.showHeaderIn;
	} else if(name == "headerClass") {
		return this.headerClass;
	} else {
		return js.wtc.Table.prototype.get.call(this, name);
	}
}
