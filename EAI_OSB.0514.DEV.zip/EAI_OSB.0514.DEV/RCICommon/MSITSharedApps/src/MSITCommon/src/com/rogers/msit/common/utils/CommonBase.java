package com.rogers.msit.common.utils;

import java.util.logging.*;

import javax.sql.*;
import javax.naming.*;

import com.rogers.msit.common.dao.*;



public class CommonBase {
	// init the CommonDAOComponent...
	protected static CommonDAOComponent commonDAOComponent = null;
	// init the application CommonDAOComponent...
	protected static CommonDAOComponent applCommonDAOComponent = null;
	static {
		try {
			// get the datasource name...
			// try first to get from a java runtime system property (-Dmsit.config.datasource=mydatasource)...
			String strDataSourceName = System.getProperty(Constants.DATA_SOURCE_CONFIG_NAME);
			// if no one found then use the default one...
			if(strDataSourceName == null) {
				Constants.LOGGER.log(Level.WARNING, Constants.GET_DATA_SOURCE_CONFIG_WARNING);
				strDataSourceName = Constants.DEFAULT_DATA_SOURCE_JNDI_NAME;
			}
			
			// obtain initial context...
			InitialContext ctx = new InitialContext();
			// get data source...
			DataSource dataSource = (DataSource)ctx.lookup(strDataSourceName);
			if(dataSource == null) {
				throw new CommonException("No data source found with this name: " + strDataSourceName);
			}
			
			// create the DAO component and set the datasource...
			commonDAOComponent = new CommonDAOComponent();
			commonDAOComponent.setDataSource(dataSource);
			
			
			
			
			
			
			
			// get the application datasource name...
			// try first to get from a java runtime system property (-Dmsit.config.datasource=mydatasource)...
			String strApplDataSourceName = System.getProperty(Constants.DATA_SOURCE_APPL_CONFIG_NAME);
			// if no one found then use the default one...
			if(strApplDataSourceName == null) {
				Constants.LOGGER.log(Level.WARNING, Constants.GET_DATA_SOURCE_CONFIG_WARNING);
				strApplDataSourceName = strDataSourceName;
			}
			
			// get data source...
			DataSource applDataSource = (DataSource)ctx.lookup(strApplDataSourceName);
			if(applDataSource == null) {
				throw new CommonException("No data source found with this name: " + strApplDataSourceName);
			}
			
			// create the DAO component and set the datasource...
			applCommonDAOComponent = new CommonDAOComponent();
			applCommonDAOComponent.setDataSource(applDataSource);
		} catch(Exception e) {
			Constants.LOGGER.log(Level.SEVERE, Constants.GET_DATA_SOURCE_ERROR + e.toString());
		}
	}
}
