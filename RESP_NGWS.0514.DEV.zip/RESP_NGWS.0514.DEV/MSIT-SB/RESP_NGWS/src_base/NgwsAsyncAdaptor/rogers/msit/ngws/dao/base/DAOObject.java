package com.rogers.msit.ngws.dao.base;

import java.io.*;
import java.util.*;
import java.math.*;
import java.sql.*;
import java.util.logging.*;

import com.rogers.msit.ngws.utils.*;



public class DAOObject {
	protected HashMap attrs = new HashMap();

	
	
	public Object get(String strAttrName) {
		return attrs.get(strAttrName);
	}
	
	
	
	public DAOObject getObjectDAO(String strAttrName) {
		return (DAOObject)attrs.get(strAttrName);
	}
	
	
	
	public boolean getBoolean(String strAttrName) {
		return ((Boolean) attrs.get(strAttrName)).booleanValue();
	}
	
	
	
	public byte getByte(String strAttrName) {
		byte nRet = 0;
		
		if(attrs.get(strAttrName) instanceof Short) {
			nRet = ((Short) attrs.get(strAttrName)).byteValue();
		} else if (attrs.get(strAttrName) instanceof Integer) {
			nRet = ((Integer) attrs.get(strAttrName)).byteValue();
		} else if(attrs.get(strAttrName) instanceof Long) {
			nRet = ((Long) attrs.get(strAttrName)).byteValue();
		} if(attrs.get(strAttrName) instanceof Byte) {
			nRet = ((Byte) attrs.get(strAttrName)).byteValue();
		} else if(attrs.get(strAttrName) instanceof BigDecimal) {
			nRet = ((BigDecimal) attrs.get(strAttrName)).byteValue();
		}
		
		return nRet;
	}
	
	
	
	public short getShort(String strAttrName) {
		short nRet = 0;
		
		if(attrs.get(strAttrName) instanceof Short) {
			nRet = ((Short) attrs.get(strAttrName)).shortValue();
		} else if (attrs.get(strAttrName) instanceof Integer) {
			nRet = ((Integer) attrs.get(strAttrName)).shortValue();
		} else if(attrs.get(strAttrName) instanceof Long) {
			nRet = ((Long) attrs.get(strAttrName)).shortValue();
		} if(attrs.get(strAttrName) instanceof Byte) {
			nRet = ((Byte) attrs.get(strAttrName)).shortValue();
		} else if(attrs.get(strAttrName) instanceof BigDecimal) {
			nRet = ((BigDecimal) attrs.get(strAttrName)).shortValue();
		}
		
		return nRet;
	}

	
	
	public int getInt(String strAttrName) {
		int nRet = 0;
		
		if(attrs.get(strAttrName) instanceof Short) {
			nRet = ((Short) attrs.get(strAttrName)).intValue();
		} else if (attrs.get(strAttrName) instanceof Integer) {
			nRet = ((Integer) attrs.get(strAttrName)).intValue();
		} else if(attrs.get(strAttrName) instanceof Long) {
			nRet = ((Long) attrs.get(strAttrName)).intValue();
		} if(attrs.get(strAttrName) instanceof Byte) {
			nRet = ((Byte) attrs.get(strAttrName)).intValue();
		} else if(attrs.get(strAttrName) instanceof BigDecimal) {
			nRet = ((BigDecimal) attrs.get(strAttrName)).intValue();
		}
		
		return nRet;
	}

	
	
	public long getLong(String strAttrName) {
		long nRet = 0;
		
		if(attrs.get(strAttrName) instanceof Short) {
			nRet = ((Short) attrs.get(strAttrName)).longValue();
		} else if (attrs.get(strAttrName) instanceof Integer) {
			nRet = ((Integer) attrs.get(strAttrName)).longValue();
		} else if(attrs.get(strAttrName) instanceof Long) {
			nRet = ((Long) attrs.get(strAttrName)).longValue();
		} if(attrs.get(strAttrName) instanceof Byte) {
			nRet = ((Byte) attrs.get(strAttrName)).longValue();
		} else if(attrs.get(strAttrName) instanceof BigDecimal) {
			nRet = ((BigDecimal) attrs.get(strAttrName)).longValue();
		}
		
		return nRet;
	}

	
	
	public double getDouble(String strAttrName) {
		double nRet = 0;
		
		if(attrs.get(strAttrName) instanceof Double) {
			nRet = ((Short) attrs.get(strAttrName)).doubleValue();
		} else if(attrs.get(strAttrName) instanceof BigDecimal) {
			nRet = ((BigDecimal) attrs.get(strAttrName)).doubleValue();
		}
		
		return nRet;
	}
	
	

	public Timestamp getTimestamp(String strAttrName) {
		Timestamp ret = null;
		
		if(attrs.get(strAttrName) instanceof Timestamp) {
			ret = (Timestamp) attrs.get(strAttrName);
		} else if(attrs.get(strAttrName) instanceof java.sql.Date) {
			ret = new Timestamp(((java.sql.Date) attrs.get(strAttrName)).getTime());
		}
		
		return ret;
	}

	
	
	public java.util.Date getDate(String strAttrName) {
		return (java.util.Date) attrs.get(strAttrName);
	}
	
	
	
	public Clob getClob(String strAttrName) {
		return (Clob)attrs.get(strAttrName);
	}
	
	
	
	public String getClobAsString(String strAttrName) throws BaseDAOException {
		String strRet = null;
		
		Clob clob = getClob(strAttrName);
		if(clob != null) {
			try {
				BigInteger len = new BigInteger("" + clob.length());
				strRet = clob.getSubString(1, len.intValue());
			} catch(Exception e) {
				Constants.LOGGER.log(Level.SEVERE, this.getClass().getName() + ".getClobAsString error: " + e.toString());
			}
		}
		
		return strRet;
	}
	
	
	
	public Blob getBlob(String strAttrName) {
		return (Blob)attrs.get(strAttrName);
	}
	
	
	
	public String getBlobAsString(String strAttrName) throws BaseDAOException {
		String strRet = "";
		
		Blob blob = getBlob(strAttrName);
		if(blob != null) {
			try {
				BufferedReader br = new BufferedReader(new InputStreamReader(blob.getBinaryStream()));
	            
	            String strLine = "";
	            while((strLine = br.readLine()) != null) {
	            	strRet += strLine + "\n";
	            }
	            if(!"".equals(strRet)) {
	            	strRet = strRet.substring(0, strRet.length() - 1);
	            }
	            
	            br.close();
			} catch(Exception e) {
				strRet = null;
				Constants.LOGGER.log(Level.SEVERE, this.getClass().getName() + ".getBlobAsString error: " + e.toString());
			}
		}
		
		return strRet;
	}
	
	
	
	public String getString(String strAttrName) throws BaseDAOException {
		String strRet = null;
		
		if(attrs.get(strAttrName) instanceof String) {
			strRet = (String) attrs.get(strAttrName);
		} else if(attrs.get(strAttrName) instanceof Clob) {
			strRet = getClobAsString(strAttrName);
		}
		
		return strRet;
	}

	
	
	public void set(String strAttrName, Object value) {
		if (attrs.containsKey(strAttrName)) {
			attrs.remove(strAttrName);
		}

		attrs.put(strAttrName, value);
	}

	
	
	public HashMap getAll() {
		return attrs;
	}
}