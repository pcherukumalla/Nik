package com.async.engine;

import java.util.*;
import java.util.logging.*;

import com.async.dao.base.*;
import com.async.services.*;
import com.async.utils.*;



public class AsyncAdaptorEngine extends Thread {
	private static AsyncAdaptorEngine instance = null;
	
	private boolean resetInProgressOnStart = false;
	private boolean active = true;
	private boolean paused = false;
	private boolean processing = false;
	private long nrOfCycles = 0;
	private int currentMessageListSize = 0;
	private long getCurrentMessageListDuration = 0;
	private boolean getCurrentMessageListInProgress = false;
	private String currentCycleError = "";
	private long currentCycleStartTime = 0;
	private long currentCycleFirstMessageId = 0;
	
	private int maxNrOfRecsInProcessingTable = 0;
	private int runInterval = 0;
	private String initialContextStr = "";
	
	
	
	private AsyncAdaptorEngine() {
		// ...
	}
	
	
	
	public static AsyncAdaptorEngine getInstance() {
		if (instance == null) {
			instance = new AsyncAdaptorEngine();
		}
		
		return instance;
	}
	
	
	
	public static void cleanUp() {
		instance = null;
	}
	
	
	
	public void run() {
		this.setPriority(NORM_PRIORITY);
		
		while(this.active) {
			// no current cycle error
			this.currentCycleError = "";
			// get current cycle start time...
			this.currentCycleStartTime = System.currentTimeMillis();
			
			if(!this.paused) {
				// refresh & get new configuration values...
				boolean bRefreshConfigValuesOK = true;
				try {
					this.refreshConfigurationValues(false);
					
					// you can deactivate this engine by setting manually the "this.active" attribute
					// as also if the server name attribute in the configuration table is not equal  
					// with the current server/machine name this code is running...
					boolean bActiveServerName = AsyncAdaptorService.getInstance().getThisServerName().equals(AsyncAdaptorService.getInstance().getValue("ACTIVE_SERVER_NAME"));
					if(!bActiveServerName) {
						this.currentCycleError = "This server/machine name not equal with the one in the configuration table. The engine will be stopped.";
						
						this.active = false;
						break;
					} else {
						// reset all those messages that are stucked as "IN_PROGRESS" in the "temp/processing" table...
						if(!this.resetInProgressOnStart) {
							AsyncAdaptorService.getInstance().getAsyncAdaptorDAO().updateInProgressOnStart();
							
							this.resetInProgressOnStart = true;
						}
					}
				} catch(Exception e) {
					e.printStackTrace();
					
					Constants.LOGGER.log(Level.SEVERE, "Error while trying to refresh the config values from the configuration table: " + e.toString());
					this.currentCycleError = "Error while trying to refresh the config values from the configuration table: " + e.toString();
					bRefreshConfigValuesOK = false;
				}
				

				
				// start processing cycle...
				if(bRefreshConfigValuesOK) {
					// set as running...
					this.processing = true;
					

					// move the new list of messages for processing from the main/buffer table to the processing/temp table...
					this.moveMessageListsForProcessing();
										
					// get the next message list to be processed...
					List messageList = this.getNextMessageList();
										
					// process current message list to be processed...
					if("".equals(this.currentCycleError)) {
						this.processMessageList(messageList);
					}
					
					
					// set as not running...
					this.processing = false;
										
					// pause/idle engine...
					if(this.active) {
						try {
							if(this.paused) {
								Thread.sleep(Constants.ASYNC_ADAPTOR_ENGINE_IDLE_INTERVAL);
							} else {
								Thread.sleep(this.runInterval);
							}
						} catch(InterruptedException ie) {
							this.currentCycleError += "\n\n" + "Error while trying to pause or idle the engine: " + ie.toString();
						}
					}
				} else {
					// set as not running...
					this.processing = false;
					
					// pause engine...
					try	{
						Thread.sleep(Constants.ASYNC_ADAPTOR_ENGINE_IDLE_INTERVAL);
					} catch(InterruptedException ie) {
						if(this.currentCycleError.indexOf("ELMS servers are down") != -1) {
							this.currentCycleError += "\n\n" + "Error while trying to pause the engine because of 'refresh config values error': " + ie.toString();
						}
					}
				}
			} else {
				// set as not running...
				this.processing = false;
				
				// pause engine...
				try	{
					Thread.sleep(Constants.ASYNC_ADAPTOR_ENGINE_IDLE_INTERVAL);
				} catch(InterruptedException ie) {
					this.currentCycleError += "\n\n" + "Error while trying to pause the engine: " + ie.toString();
				}
			}
		}
	}
	
	
	
	private void moveMessageListsForProcessing() {
		List tbls = AsyncAdaptorService.getInstance().getMainTables();
		
		String strTableName = "";
		int nTableActiveIn = 0;
		DAOObject tbl = null;
		for(int i = 0; i < tbls.size(); i++) {
			// if engine has been stopped or paused in the meantime then break the "for" loop...
			if(!this.active || this.paused) {
				break;
			}
			
			tbl = (DAOObject)tbls.get(i);
			
			// get table name and active indicator...
			try {
				strTableName = tbl.getString("MAIN_TABLE_NAME");
				nTableActiveIn = tbl.getInt("ACTIVE_IN");
			} catch(Exception et) {
				Constants.LOGGER.log(Level.SEVERE, "Error while trying to get main table name: " + et.toString());
				this.currentCycleError = "\n\n" + "Error while trying to get main table name: " + et.toString();
			}
			
			// try to move messages if active...
			if(nTableActiveIn == 1) {
				try {
					AsyncAdaptorService.getInstance().getAsyncAdaptorDAO().moveMessageListForProcessing(strTableName, this.maxNrOfRecsInProcessingTable);
				} catch(Exception e) {
					Constants.LOGGER.log(Level.SEVERE, "Error while moving the message list to be processed (" + strTableName + "): " + e.toString());
					this.currentCycleError = "\n\n" + "Error while moving the message list to be processed (" + strTableName + "): " + e.toString();
				}
			}
		}
	}
	
	
	
	private List getNextMessageList() {
		List ret = new ArrayList();
		List sqls = AsyncAdaptorService.getInstance().getProcessSQLs();
		
		this.getCurrentMessageListInProgress = true;
		long nStartRunSQL = System.currentTimeMillis();
		String strSQL = "";
		String strSQLName = "";
		int nSqlActiveIn = 0;
		int nCycleSize = 0;
		DAOObject sql = null;
		for(int i = 0; i < sqls.size(); i++) {
			// if engine has been stopped or paused in the meantime then break the "for" loop...
			if(!this.active || this.paused) {
				break;
			}
			
			sql = (DAOObject)sqls.get(i);
			
			// get SQL attributes...
			try {
				strSQL = sql.getString("SQL_NAME");
				
				strSQL = sql.getString("DESCRIPTION");
				nSqlActiveIn = sql.getInt("ACTIVE_IN");
				nCycleSize = sql.getInt("CYCLE_SIZE");
			} catch(Exception et) {
				Constants.LOGGER.log(Level.SEVERE, "Error while trying to get SQL: " + et.toString());
				this.currentCycleError = "\n\n" + "Error while trying to get SQL: " + et.toString();
			}
			
			// try to get messages to be processed by this SQL...
			if(nSqlActiveIn == 1) {
				try {
					ret.addAll(AsyncAdaptorService.getInstance().getAsyncAdaptorDAO().getNextMessageList(strSQL, nCycleSize));
				} catch(Exception e) {
					Constants.LOGGER.log(Level.SEVERE, "Error while getting the next message list to be processed (" + strSQLName + "): " + e.toString());
					this.currentCycleError = "\n\n" + "Error while getting the next message list to be processed (" + strSQLName + "): " + e.toString();
				}
			}
		}
		this.getCurrentMessageListInProgress = false;
		// store the duration...
		this.getCurrentMessageListDuration = System.currentTimeMillis() - nStartRunSQL;
		// store the list size...
		this.currentMessageListSize = ret.size();
		// in case of no records selected then there will be no processing performed...
		if(this.currentMessageListSize == 0) {
			this.currentCycleError = "\n\n" + "No messages were found to be processed in this cycle.";
		}
		
		return ret;
	}
	
	
	
	public void processMessageList(List messageList) {
		// if no messages in this cycle then return right away...
		if(this.currentMessageListSize == 0) {
			return;
		}
		
		// go through the list...
		DAOObject msg = null;
		DAOObject msgType = null;
									//long nStart = System.currentTimeMillis();
		// create JMS context and connection...
		try {
			AsyncAdaptorService.getInstance().createJMSContextAndConnection(this.initialContextStr);
		} catch(Exception e2) {
			// get/save error...
			this.currentCycleError += "\n\n" + "Error while trying to create JMS context & connection: " + e2.toString();
		}
									
		for(int i = 0; i < messageList.size(); i++) {
			// if engine has been stopped or paused in the meantime then break the "for" loop...
			if(!this.active || this.paused) {
				break;
			}
			
			// get the next message...
			msg = (DAOObject)messageList.get(i);
			
			// store the first message ID... 
			if(i == 0) {
				this.currentCycleFirstMessageId = msg.getLong("MSGID"); 
			}
										
			// update/mark message for processing...
			String strCurrentMessageError = "";
			boolean bSendToProcess = true;
			try {
				msgType = AsyncAdaptorService.getInstance().getMessageType(msg.getInt("MSGTYPE_ID"));
				
				bSendToProcess = AsyncAdaptorService.getInstance().getAsyncAdaptorDAO().updateMessageForProcessing(msg, msgType);
			} catch(Exception e2) {
				// get/save error...
				strCurrentMessageError = this.getErrorMessage(e2, msg.getLong("MSGID"), Constants.UPDATE_FOR_PROCESSING);
				this.currentCycleError += "\n\n" + strCurrentMessageError;
			}
			
			// if no error so far for this message then push the message for processing...
			if("".equals(strCurrentMessageError) && bSendToProcess) {
				AsyncAdaptorService.getInstance().sendMessage(msg);
			}
		}
		
		// remove JMS connection...
		try {
			AsyncAdaptorService.getInstance().commitAndRemoveJMSConnection();
		} catch(Exception e2) {
			// get/save error...
			this.currentCycleError += "\n\n" + "Error while trying to commit & remove JMS connection: " + e2.toString();
		}
								//System.out.println("markAndPushAll: " + (System.currentTimeMillis() - nStart));
								
		// set the new number of processing cycles...
		this.nrOfCycles++;
	}
	
	
	
	public void refreshConfigurationValues(boolean bForceIn) throws Exception {
		AsyncAdaptorService srv = AsyncAdaptorService.getInstance();
		srv.refreshConfigValues(bForceIn);
		
		// get the engine run interval...
		this.runInterval = Integer.parseInt(srv.getValue("ASYNC_ADAPTOR_ENGINE_RUN_INTERVAL"));
		// max number of records in the processing table...
		this.maxNrOfRecsInProcessingTable = Integer.parseInt(srv.getValue("MAX_NR_OF_RECORDS_FOR_PROCESSING"));
		// jndi initial context string...
		this.initialContextStr = srv.getValue("JNDI_INITIAL_CONTEXT");
	}
	
	
	
	private Throwable getRootException(Exception e) {
		Throwable err = e;
		
		while (err.getCause() != null) {
			err = err.getCause();								
		}
		
		return err;
	}
	
	
	
	private String getErrorMessage(Exception e, long msgId, int actionType) {
		String strRet = "";
		Throwable err = null; 
		
		try {
			// get root exception...
			err = getRootException(e);
			
			if(actionType == Constants.UPDATE_FOR_PROCESSING) {
				strRet = "Error while marking message " + msgId + " for processing: " + err.toString();
			} else if(actionType == Constants.PUSH_FOR_PROCESSING) {
				strRet = "Error while pushing message " + msgId + " for processing: " + err.toString();
			} else if(actionType == Constants.AFTER_PUSH_FOR_PROCESSING) {
				strRet = "Error while updating message " + msgId + " after push for processing: " + err.toString();
			} else {
				strRet = "Error for message " + msgId + ": " + err.toString();
			}
		} catch(Exception e2) {
			if(actionType == Constants.UPDATE_FOR_PROCESSING) {
				strRet = "Error while marking message for processing: " + err.toString();
			} else if(actionType == Constants.PUSH_FOR_PROCESSING) {
				strRet = "Error while pushing message for processing: " + err.toString();
			} else if(actionType == Constants.AFTER_PUSH_FOR_PROCESSING) {
				strRet = "Error while updating message after push for processing: " + err.toString();
			} else {
				strRet = "Error: " + err.toString();
			}
		}
		
		return strRet;
	}

	
	
	public boolean isActive() {
		return active;
	}

	
	
	public synchronized void setActive(boolean active) {
		this.active = active;
	}

	
	
	public boolean isProcessing() {
		return processing;
	}

	
	
	public long getNrOfCycles() {
		return nrOfCycles;
	}

	
	
	public boolean isPaused() {
		return paused;
	}

	
	
	public synchronized void setPaused(boolean paused) {
		this.paused = paused;
	}



	public String getCurrentCycleError() {
		return currentCycleError;
	}



	public int getCurrentMessageListSize() {
		return currentMessageListSize;
	}



	public int getRunInterval() {
		return runInterval;
	}



	public String getInitialContextStr() {
		return initialContextStr;
	}



	public long getCurrentCycleStartTime() {
		return currentCycleStartTime;
	}



	public long getGetCurrentMessageListDuration() {
		return getCurrentMessageListDuration;
	}



	public long getCurrentCycleFirstMessageId() {
		return currentCycleFirstMessageId;
	}
	
	
	
	public boolean getGetCurrentMessageListInProgress() {
		return getCurrentMessageListInProgress;
	}



	public int getMaxNrOfRecsInProcessingTable() {
		return maxNrOfRecsInProcessingTable;
	}
}


