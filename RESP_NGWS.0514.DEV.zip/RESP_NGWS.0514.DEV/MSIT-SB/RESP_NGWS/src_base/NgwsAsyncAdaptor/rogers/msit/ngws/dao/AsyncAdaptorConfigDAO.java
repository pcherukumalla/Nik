package com.rogers.msit.ngws.dao;

import java.sql.*;
import java.util.*;
import java.util.logging.*;

import com.rogers.msit.ngws.dao.base.*;
import com.rogers.msit.ngws.utils.*;



public class AsyncAdaptorConfigDAO extends BaseDAO {
	public List getConfigEntries() throws AsyncAdaptorDAOException {
		List ret = null;
		
		// params...

		// get data...
		Connection conn = null;
		try {
			conn = getConnection();
			ret = getDAOObjectList(conn, DAOUtils.getInstance().getQueries().getProperty("sql.GET_CONFIG_ENTRIES"), null);
		} catch(Exception e) {
			Constants.LOGGER.log(Level.SEVERE,  this.getClass().getName() + ".getConfigEntries error: " + e.toString());
			throw new AsyncAdaptorDAOException(e);
		} finally {
			closeConnection(conn);
		}
		
		return ret;
	}
	
	
	
	public List getErrorMessages() throws AsyncAdaptorDAOException {
		List ret = null;
		
		// params...

		// get data...
		Connection conn = null;
		try {
			conn = getConnection();
			ret = getDAOObjectList(conn, DAOUtils.getInstance().getQueries().getProperty("sql.GET_ERROR_MESSAGES"), null);
		} catch(Exception e) {
			Constants.LOGGER.log(Level.SEVERE,  this.getClass().getName() + ".getErrorMessages error: " + e.toString());
			throw new AsyncAdaptorDAOException(e);
		} finally {
			closeConnection(conn);
		}
		
		return ret;
	}
	
	
	
	public List getStatuses() throws AsyncAdaptorDAOException {
		List ret = null;
		
		// params...

		// get data...
		Connection conn = null;
		try {
			conn = getConnection();
			ret = getDAOObjectList(conn, DAOUtils.getInstance().getQueries().getProperty("sql.GET_STATUSES"), null);
		} catch(Exception e) {
			Constants.LOGGER.log(Level.SEVERE,  this.getClass().getName() + ".getStatuses error: " + e.toString());
			throw new AsyncAdaptorDAOException(e);
		} finally {
			closeConnection(conn);
		}
		
		return ret;
	}
}
