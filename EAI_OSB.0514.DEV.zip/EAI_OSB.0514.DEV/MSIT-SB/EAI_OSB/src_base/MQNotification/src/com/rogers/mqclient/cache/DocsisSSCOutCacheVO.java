package com.rogers.mqclient.cache;

public class DocsisSSCOutCacheVO extends MQCacheBase
{
	private static MQCacheBase mqCacheVO = null;
	
	public static MQCacheBase getInstance()
	{
		synchronized( DocsisSSCOutCacheVO.class )
		{
			if ( mqCacheVO == null ) mqCacheVO = new MQCacheBase();
		}
		return mqCacheVO;
	}
	
}
