package com.rogers.rci.wsl;

import javax.ejb.EJBLocalObject;

public abstract interface GetSwitchForNewTNEJBFacadeLocal extends EJBLocalObject
{
  public abstract String retrieveSwitchForNewTN(java.lang.String rateCentre, java.lang.String existingPhoneNumber, java.lang.String numberType)
    throws Exception;

  public abstract String retrieveSwitchForNewTNWithProv(java.lang.String rateCentre, java.lang.String existingPhoneNumber, java.lang.String numberType, java.lang.String provCd2Ch)
    throws Exception;
}