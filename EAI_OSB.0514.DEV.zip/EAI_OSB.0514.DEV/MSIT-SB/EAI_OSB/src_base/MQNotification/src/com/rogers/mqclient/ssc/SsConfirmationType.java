package com.rogers.mqclient.ssc;

public class SsConfirmationType
{
	public static final SsConfirmationType none = new SsConfirmationType( "NONE" );
	public static final SsConfirmationType coc = new SsConfirmationType( "COC" );
	public static final SsConfirmationType cod = new SsConfirmationType( "COD" );
	public static final SsConfirmationType audit = new SsConfirmationType( "AUDT" );

	// get the string representation of type
	public String toString()
	{
		return _value;
	}

	private String _value;

	private SsConfirmationType( String value )
	{
		_value = value;
	}
}
