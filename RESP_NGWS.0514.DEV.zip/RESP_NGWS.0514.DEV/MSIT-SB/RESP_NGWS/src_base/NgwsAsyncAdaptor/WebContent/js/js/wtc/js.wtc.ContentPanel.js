/*
****************************************************************************************************
 ezWebToolkit Library, http://www.ezwebtoolkit.com
****************************************************************************************************
Copyright [2006-2008] [Pro Net Systems Inc., http://www.pronetsystems.com]

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

	http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
***************************************************************************************************
*/



/*
------------------------------------------------------------------------------------------
ContentPanel
------------------------------------------------------------------------------------------
*/
js.wtc.ContentPanel = function() {
    this.index = -1;
    this.descendents = new Array();
    this.parent = null;
    this.handler = null;
    this.theViewport = null;

    // register this component in the global manager...
    js.wtc.Manager.append(this);

    this.showIn = false;
    this.showWhenParentDisplayed = true; // if false then this object won't be displayed when its parent "show" method is called.
    this.opacity = "";

    this.objectType = "js.wtc.ContentPanel";
}



// vc, the second parameter is optional...
// it indicates the DOM element you need to append to
// instead of the object default viewport...
js.wtc.ContentPanel.prototype.append = function(o, vc) {
	this.descendents.push(o);
	o.parent = this;

	try {
		document.removeChild(o.viewport());
	} catch(e) {
		// nothing...
	}
	
	// append to viewport or viewport specified child...
	if(vc) {
		vc.appendChild(o.viewport());
	} else {
		this.theViewport.appendChild(o.viewport());
	}
	
	// show if the parent is visible...
	if(this.showIn) {
		o.show();
	}
	
	// execute onAppend function...
	o.onAppend();
}



js.wtc.ContentPanel.prototype.getItemIndex = function(o) {
	var nIndex = -1;
	for(var i = 0; i < this.descendents.length; i++) {
		if(this.descendents[i] == o) {
			nIndex = i;
			break;
		}
	}
	
	return nIndex;
}



js.wtc.ContentPanel.prototype.remove = function(o) {
	var nIndex = this.getItemIndex(o);
	if(nIndex > -1) {
		// fix the descendants table...
		for(var i = nIndex; i < this.descendents.length - 1; i++) {
			this.descendents[i] = this.descendents[i+1];
		}
		this.descendents.pop();
		
		// remove parent-child link...
		o.parent = null;
		
		// hide and remove the DOM element...
		o.hide();
		o.viewport().parentNode.removeChild(o.viewport());
	}
}



js.wtc.ContentPanel.prototype.instrumentViewport = function() {
	this.theViewport.id = "div_ezView" + this.index;
	this.theViewport.style.position = "absolute";
}



js.wtc.ContentPanel.prototype.init = function() {
	// create the main div...
	this.theViewport = document.createElement("DIV");

	// instrument the new node...
	this.instrumentViewport();
}



js.wtc.ContentPanel.prototype.viewport = function() {
    return this.theViewport;
}



js.wtc.ContentPanel.prototype.show = function() {
	// append to the document if no parent...
	if((this.theViewport.parentNode == null) || (this.theViewport.parentNode.nodeName == "#document-fragment")) {
		document.body.appendChild(this.theViewport);
	}
	
	if(this.theViewport != null) {
		this.theViewport.style.display = "block";
	}
	this.showIn = true;

	for(var i = 0; i < this.descendents.length; i++) {
		if(this.descendents[i].showWhenParentDisplayed) {
			this.descendents[i].show();
		}
	}
}



js.wtc.ContentPanel.prototype.hide = function() {
	if(this.theViewport != null) {
		this.theViewport.style.display = "none";
	}
	this.showIn = false;

	for(var i = 0; i < this.descendents.length; i++) {
		this.descendents[i].hide();
	}
}



js.wtc.ContentPanel.prototype.destroy = function() {
	this.hide();
	
	if(this.theViewport != null) {
		this.theViewport.onmousedown = null;
		document.body.removeChild(this.theViewport);
	}
	
	for(var i = 0; i < this.descendents.length; i++) {
		this.descendents[i].destroy();
	}
}



js.wtc.ContentPanel.prototype.blur = function() {
	this.theViewport.blur();
}



js.wtc.ContentPanel.prototype.click = function() {
	this.theViewport.click();
}



js.wtc.ContentPanel.prototype.focus = function() {
	this.theViewport.focus();
}



js.wtc.ContentPanel.prototype.select = function() {
	this.theViewport.select();
}



js.wtc.ContentPanel.prototype.focusAndSelect = function() {
	this.theViewport.focus();
	this.theViewport.select();
}



js.wtc.ContentPanel.prototype.addEventListener = function(evtname, act) {
	js.wtc.Manager.addEventListener(this.theViewport, evtname, act);
}



js.wtc.ContentPanel.prototype.setEventListener = function(evtname, act) {
	js.wtc.Manager.setEventListener(this.theViewport, evtname, act);
}



js.wtc.ContentPanel.prototype.enableEventListener = function(evtname, bStopPropagation) {
	var SELF = this;
	
	js.wtc.Manager.setEventListener(this.theViewport, evtname.toLowerCase(), function(){eval("SELF." + evtname + "()")}, bStopPropagation);
}



js.wtc.ContentPanel.prototype.onDragStart = function(x, y) {
    // ...
}



js.wtc.ContentPanel.prototype.onDrag = function(x, y) {
    // ...
}



js.wtc.ContentPanel.prototype.onDragEnd = function(x, y) {
    // ...
}



// handler can be a ContentPanel or descendant or a DOM element...
js.wtc.ContentPanel.prototype.draggable = function(b, handler) {
    var elemHandler = null;
    if (handler) {
        if (handler.index != null) {
            elemHandler = handler.viewport();
        } else {
            elemHandler = handler;
        }
    }

    if (b) {
        if (handler) {
            js.util.Drag.init(elemHandler, this.theViewport);
            this.handler = handler;
        } else {
            js.util.Drag.init(this.theViewport);
            this.handler = null;
        }

        var SELF = this;

        this.theViewport.onDragStart = function(x, y) { SELF.onDragStart(x, y) };
        this.theViewport.onDragEnd = function(x, y) { SELF.onDragEnd(x, y) };
        this.theViewport.onDrag = function(x, y) { SELF.onDrag(x, y) };
    } else {
        if (this.handler == null) {
            this.theViewport.onmousedown = null;
        } else {
            this.handler.viewport().onmousedown = null;
            this.handler = null;
        }
    }
}



// this is executed on this object is appended to another...
js.wtc.ContentPanel.prototype.onAppend = function() {
    // ...
}



js.wtc.ContentPanel.prototype.onMessage = function(msg) {
	// do nothing...
}



js.wtc.ContentPanel.prototype.onClose = function() {
	// do nothing...
}



// it is called when set width or/and height...
js.wtc.ContentPanel.prototype.onResize = function() {
	for(var i = 0; i < this.descendents.length; i++) {
		this.descendents[i].onResize();
	}
}



// it is called when set left or/and top...
js.wtc.ContentPanel.prototype.onMove = function() {
    for (var i = 0; i < this.descendents.length; i++) {
        this.descendents[i].onMove();
    }
}



js.wtc.ContentPanel.prototype.set = function(name, value) {
    if (name == "className") {
        this.theViewport.className = value;
    } else if (name == "innerHTML") {
        this.theViewport.innerHTML = value;
    } else if (name == "title") {
        this.theViewport.title = value;
    } else if (name == "disabled") {
        this.theViewport.disabled = value;
    } else if (name == "left") {
        this.theViewport.style.left = value;
        this.onMove();
    } else if (name == "top") {
        this.theViewport.style.top = value;
        this.onMove();
    } else if (name == "width") {
        this.theViewport.style.width = value;
        this.onResize();
    } else if (name == "height") {
        this.theViewport.style.height = value;
        this.onResize();
    } else if (name == "showWhenParentDisplayed") {
        this.showWhenParentDisplayed = value;
    } else if (name == "opacity") {
        this.opacity = value;

        if ((this.opacity != "") && !isNaN(this.opacity)) {
            this.theViewport.style.opacity = (value / 100);
            this.theViewport.style.MozOpacity = (value / 100);
            this.theViewport.style.KhtmlOpacity = (value / 100);
            this.theViewport.style.filter = "alpha(opacity=" + value + ")";
        } else {
            this.theViewport.style.opacity = "";
            this.theViewport.style.MozOpacity = "";
            this.theViewport.style.KhtmlOpacity = "";
            this.theViewport.style.filter = "";
        }
    } else if (name == "draggable") {
        if (value) {
            this.draggable(true);
        } else {
            this.draggable(false);
        }
    } else {
        eval("this.theViewport.style." + name + " = \"" + value + "\"");
    }
}



js.wtc.ContentPanel.prototype.get = function(name) {
    if (name == "className") {
        return this.theViewport.className;
    } else if (name == "innerHTML") {
        return this.theViewport.innerHTML;
    } else if (name == "title") {
        return this.theViewport.title;
    } else if (name == "disabled") {
        return this.theViewport.disabled;
    } else if (name == "pos") {
        // this will return a Position custom object with absolute left, top, width and height...
        return js.util.Position.get(this);
    } else if (name == "showIn") {
        return this.showIn;
    } else if (name == "showWhenParentDisplayed") {
        return this.showWhenParentDisplayed;
    } else if (name == "opacity") {
        return this.opacity;
    } else {
        return eval("this.theViewport.style." + name);
    }
}
