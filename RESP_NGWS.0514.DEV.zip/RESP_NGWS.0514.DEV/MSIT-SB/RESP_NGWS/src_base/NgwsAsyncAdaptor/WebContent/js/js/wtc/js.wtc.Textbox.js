/*
****************************************************************************************************
 ezWebToolkit Library, http://ezwt.blogspot.com
****************************************************************************************************
Copyright [2006-2008] [Pro Net Systems Inc., http://www.pronetsystems.com]

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

	http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
***************************************************************************************************
*/



/*
------------------------------------------------------------------------------------------
Textbox
------------------------------------------------------------------------------------------
*/
js.wtc.Textbox = function() {
	js.wtc.ContentPanel.call(this);
	
	this.passwordIn = false;

	this.objectType = "js.wtc.Textbox";
}
js.wtc.Textbox.prototype = new js.wtc.ContentPanel();
js.wtc.Textbox.prototype.constructor = js.wtc.Textbox;



js.wtc.Textbox.prototype.init = function() {
	// create the main div...
	this.theViewport = document.createElement("INPUT");
	
	if(this.passwordIn) {
		this.theViewport.type = "password";
	} else {
		this.theViewport.type = "text";
	}
	
	// instrument the new node...
	this.instrumentViewport();
}



js.wtc.Textbox.prototype.set = function(name, value) {

	if(name == "value") {
		this.viewport().value = value;
	} else if(name == "maxLength") {
		this.viewport().maxLength = value;
	} else if(name == "size") {
		this.viewport().size = value;
	} else if(name == "password") {
		this.passwordIn = value;
	} else {
		js.wtc.ContentPanel.prototype.set.call(this, name, value);
	}
}



js.wtc.Textbox.prototype.get = function(name) {
	if(name == "value") {
		return this.viewport().value;
	} else if(name == "maxLength") {
		return this.viewport().maxLength;
	} else if(name == "size") {
		return this.viewport().size;
	} else if(name == "password") {
		return this.passwordIn;
	} else {
		return js.wtc.ContentPanel.prototype.get.call(this, name);
	}
}
