package com.rogers.mqclient;

import java.io.IOException;
import java.io.InputStreamReader;

//import com.rogers.mqclient.get.ReadFromMQ;
import com.rogers.logger.utility.UtilityLogger;
import com.rogers.mqclient.get.jms.ReadFromMQviaJMS;

public class WorkWithDocsis {

	static String[] params = null;

	/**
	 * SAMPLE USAGE:
	 * @param args
	 */
	public static void main(String[] args) {
		try
		{
			String[] pars = args[0].split("###");
			UtilityLogger.getLogger().info("No of params received: " + pars.length);

			if ( pars.length == 2 && "GET".equalsIgnoreCase( pars[0]) )
			{
				WorkWithDocsis.readFromMQ( args[0] );
			}
			else
			{
				WorkWithDocsis.sendSSCRequestToSS( args[0] );
			}
		}
		catch (Exception ex)
		{
			if (WorkWithDocsis.params.length == 1)
			{
				UtilityLogger.getLogger().info("Suggested usage: WorkWithDocsis " + "GET###<mqdetails>");
			}
			else
			{
				UtilityLogger.getLogger().info("Suggested usage: WorkWithDocsis <mqmessage>###<mqdetails>###resetMqConn###resetMqDetail###correlationId###mscMsgReceived###returnCode###applicationName###appStructID###company###action");
				UtilityLogger.getLogger().info("Sample mqdetail: HOST=mvsd.rogers.com;PORT=1434;QMANAGER=MQDY;CHANNEL=MSC_ER_CLIENT_01;CCSID=819;QUEUE=SS_SERVICE_REPLY2;SYS_USER=");
				UtilityLogger.getLogger().info("-----------------------");
				UtilityLogger.getLogger().info("Got this exception");
			}
			ex.printStackTrace();
		}
	}

	public static void sendSSCRequestToSS(String mscOutMsgBody, String mqconfiguration, String resetMqConn, String resetMqDetail, String correlationId, String mscMsgReceived, String returnCode, String applicationName, String appStructID, String company, String action)
		throws Exception
	{
		DocsisSSCOutDispatcher dispatcher =  new DocsisSSCOutDispatcher();

		//dispatcher.setSolution( false ); // default is false (no JMS but native solution)

		dispatcher.setPrerequisites(mqconfiguration, Boolean.parseBoolean(resetMqConn), Boolean.parseBoolean(resetMqDetail), correlationId, mscMsgReceived, returnCode);
		dispatcher.setAdditionalHeaderDetails(applicationName, appStructID, company, action);
		dispatcher.putMessage( mscOutMsgBody );
	}

	public static void sendSSCRequestToSS(String delimitedParams)
		throws Exception
	{
		//delimitedParams=delimitedParams.replaceAll("_"," ");
		UtilityLogger.getLogger().info("Received delimitedParams: " + delimitedParams);
		WorkWithDocsis.params = delimitedParams.split("###");
		UtilityLogger.getLogger().info("After split I got # of params: " + WorkWithDocsis.params.length);
		//sendMSCResponseToMQ(String mscOutMsgBody, String mqconfiguration, String resetMqConn, String resetMqDetail, String correlationId, String mscMsgReceived, String returnCode)
		WorkWithDocsis.sendSSCRequestToSS( params[0].replaceAll("_"," "), params[1], params[2], params[3], params[4], params[5].replaceAll("_"," "), params[6].replaceAll("_"," "), params[7].replaceAll("_"," "), params[8].replaceAll("_"," "), params[9].replaceAll("_"," "), params[10].replaceAll("_"," "));
	}

	/*
	 * applicable only for 'GET' action
	 */
	private static void readFromMQ(String delimitedParams)
		throws Exception
	{
		WorkWithDocsis.params = delimitedParams.split("###");

		//TO try using JMS implementation
		MSCReplyToMQDispatcher dispatcher =  new MSCReplyToMQDispatcher(); // to be used just to set the env config
		dispatcher.setSolution( true ); //set to use JMS
		dispatcher.setPrerequisites(params[1], false, false, "","", null); //set MQ params, only mqconfiguration required in this case

		ReadFromMQviaJMS.startReader();

        UtilityLogger.getLogger().info("To end the program enter Q or q then <return>");
        UtilityLogger.getLogger().info("");
        InputStreamReader inputStreamReader = new InputStreamReader(System.in);
        char answer = '\0';
        while(!((answer=='q')||(answer=='Q')))
        {
          try
          {
            answer = (char)inputStreamReader.read();
          }
          catch( IOException ie )
          {
            UtilityLogger.getLogger().info("I/O exception in TestMQSeries in the method get(): "+ie.toString());
          }
        }
	}
}