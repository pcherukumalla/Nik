package com.rogers.rci.wsl;

import java.rmi.RemoteException;
import javax.ejb.CreateException;
import javax.ejb.EJBHome;

public abstract interface SubscriberMaintenanceEJBRemoteHome extends EJBHome
{
  public abstract SubscriberMaintenanceEJBRemote create()
    throws CreateException, RemoteException, CreateException;
}