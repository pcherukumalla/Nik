package com.rogers.mqclient.env;

public interface MQEnvDetailInterface 
{
	    public  static String HOST = "";
	    public  static String PORT = "";
	    public  static String CHANNEL = "";
	    public  static String QNAME = "";
	    public  static String QMGR = "";
	    public  static int CCSID = 0;  
	    public static String SYS_USER = null;
	    
	    public static String LAST_GOOD_MQ_DETAILS = "";	               
	    

		public void setHOST(String host);

		public void setPORT(String port);

		public void setCHANNEL(String channel);

		public void setQNAME(String qname);

		public void setQMGR(String qmgr);

		public void setCCSID(int ccsid);

		public void setSYS_USER(String sysuser);
		
		public void setLAST_GOOD_MQ_DETAILS(String last_good_mq_details);	    
}