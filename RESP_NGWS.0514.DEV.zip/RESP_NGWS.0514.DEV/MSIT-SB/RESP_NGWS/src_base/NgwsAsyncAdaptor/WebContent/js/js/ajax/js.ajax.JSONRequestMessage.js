/*
****************************************************************************************************
 ezWebToolkit Library, http://www.ezwebtoolkit.com
****************************************************************************************************
Copyright [2006-2008] [Pro Net Systems Inc., http://www.pronetsystems.com]

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

	http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
***************************************************************************************************
*/



js.ajax.JSONRequestMessage = function(reqno, url, send, done, timeout, mth, mgr) {
	this.reqno = reqno;
	this.url = url;
	this.send = send;
	this.done = done;
	this.timeout = timeout;
	this.method = mth;
	this.manager = mgr;
	
	this.status = "PENDING";
	this.processingIn = false;

	this.objectType = "js.ajax.JSONRequestMessage";
}



js.ajax.JSONRequestMessage.prototype.error = function(msg) {
	err = new Error(msg);
	err.name = "JSONRequestError";
	
	return err;
}



js.ajax.JSONRequestMessage.prototype.expire = function() {
	if(!this.processingIn) {
		// change status...
		this.status = "TIMEOUT";
	
		// callback function call for a "no response" error...
		var err = this.error("no response");
		err.description = "timeout";
		
		try {
			this.done(this.reqno, null, err);
		} catch(e) {}
	}
}



js.ajax.JSONRequestMessage.prototype.process = function() {
	var SELF = this;
	
	// fix Firefox...
	if(js.util.Browser.isFirefox) {
		try {
			netscape.security.PrivilegeManager.enablePrivilege("UniversalBrowserRead");
		} catch (e) { }
	}
	
	// create and send request...
	var httpRequest = new js.ajax.XMLHttpRequest();
	httpRequest.init();
	// set attributes...
	httpRequest.set("submit", false);
	httpRequest.set("method", this.method);
	httpRequest.set("url", this.url);
	// store a reference to the message object itself...
	httpRequest.object = this;
	// open connection...
	httpRequest.open();
	
	// OK function...
	httpRequest.onComplete = function() {
		this.object.processingIn = true;
		
		// calback function call...
		if(this.object.status == "RUNNING") {
			try {
				this.object.done(this.object.reqno, this.response, null);
			} catch(e) {}
		}

		// change status...
		this.object.status = "PROCESSED";
		
		// make thread available...
		this.object.manager.nrOfConcurrentThreads--;
	}
	
	// ERROR function...
	httpRequest.onError = function() {
		this.object.processingIn = true;
		
		// callback function call for a "no response" error...
		if(this.object.status == "RUNNING") {
			var err = this.object.error("no response");
			err.description = this.response;
			
			try {
				this.object.done(this.object.reqno, null, err);
			} catch(e) {}
		}

		// change status...
		this.object.status = "PROCESSED";
		
		// make thread available...
		this.object.manager.nrOfConcurrentThreads--;
	}
	
	// change status...
	this.status = "RUNNING";
	// start timeout thread...
	setTimeout(function(){SELF.expire()}, SELF.timeout);

	// send request...
	try {
		if(this.method == "POST") {
			httpRequest.send(JSON.stringify(this.send));
		} else {
			httpRequest.send();
		}
	} catch(e) {
		alert(e.name + " - " + e.message + " - " + e.description);
	}
}
