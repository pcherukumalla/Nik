/*
------------------------------------------------------------------------------------------
EngineAdminWindow
------------------------------------------------------------------------------------------
*/
com.rogers.rci.ngws.EngineAdminWindow = function(p) {
	js.wtc.Window.call(this);
	
	this.app = p;
	this.refreshId = -1;
}
com.rogers.rci.ngws.EngineAdminWindow.prototype = new js.wtc.Window();
com.rogers.rci.ngws.EngineAdminWindow.prototype.constructor = com.rogers.rci.ngws.EngineAdminWindow;



com.rogers.rci.ngws.EngineAdminWindow.prototype.init = function() {
	this.set("minres", false);
	this.set("resize", false);
	js.wtc.Window.prototype.init.call(this);
	
	var SELF = this;
	
	// set attributes...
	this.set("left", "280px");
	this.set("top", "140px");
	this.set("width", "600px");
	//this.set("height", "377px");
	this.set("height", "424px");
	this.set("fontSize", "12px");
	this.set("title", "Engine Administrator");
	this.body().set("backgroundColor", "#EFEFEF");
	
	// init the layout content panel...
	this.initLayout();
	
	// init the close button...
	this.closeButton = new com.rogers.rci.ngws.Button("Close");
	this.closeButton.init();
	this.closeButton.set("width", "50px");
	this.closeButton.set("left", (parseInt(this.get("width")) - 52) + "px");
	this.closeButton.set("top", (parseInt(this.get("height")) - 47) + "px");
	this.closeButton.viewport().onclick = function() {
			SELF.hide();
	}
	// append it...
	this.body().append(this.closeButton);
	
	// init the refresh button...
	this.refreshButton = new com.rogers.rci.ngws.Button("Refresh");
	this.refreshButton.init();
	this.refreshButton.set("width", "65px");
	this.refreshButton.set("left", (parseInt(this.get("width")) - 119) + "px");
	this.refreshButton.set("top", (parseInt(this.get("height")) - 47) + "px");
	this.refreshButton.viewport().onclick = function() {
			SELF.getStatus();
	}
	// append it...
	this.body().append(this.refreshButton);
	
	// init the refresh conf button...
	this.refreshConfigButton = new com.rogers.rci.ngws.Button("Reload Configuration");
	this.refreshConfigButton.init();
	this.refreshConfigButton.set("width", "150px");
	this.refreshConfigButton.set("left", (parseInt(this.get("width")) - 271) + "px");
	this.refreshConfigButton.set("top", (parseInt(this.get("height")) - 47) + "px");
	this.refreshConfigButton.viewport().onclick = function() {
			SELF.refreshConfigurationValues();
	}
	// append it...
	this.body().append(this.refreshConfigButton);
	
	// init the resume button...
	this.resumeButton = new com.rogers.rci.ngws.Button("Resume");
	this.resumeButton.init();
	this.resumeButton.set("width", "65px");
	this.resumeButton.set("left", (parseInt(this.get("width")) - 370) + "px");
	this.resumeButton.set("top", (parseInt(this.get("height")) - 47) + "px");
	this.resumeButton.viewport().onclick = function() {
			SELF.resumeEngine();
	}
	// append it...
	this.body().append(this.resumeButton);
	
	// init the pause button...
	this.pauseButton = new com.rogers.rci.ngws.Button("Pause");
	this.pauseButton.init();
	this.pauseButton.set("width", "55px");
	this.pauseButton.set("left", (parseInt(this.get("width")) - 427) + "px");
	this.pauseButton.set("top", (parseInt(this.get("height")) - 47) + "px");
	this.pauseButton.viewport().onclick = function() {
			SELF.pauseEngine();
	}
	// append it...
	this.body().append(this.pauseButton);
	
	// init the start button...
	this.startButton = new com.rogers.rci.ngws.Button("Start");
	this.startButton.init();
	this.startButton.set("width", "50px");
	this.startButton.set("left", (parseInt(this.get("width")) - 479) + "px");
	this.startButton.set("top", (parseInt(this.get("height")) - 47) + "px");
	this.startButton.viewport().onclick = function() {
			SELF.startEngine();
	}
	// append it...
	this.body().append(this.startButton);
	
	// init the stop button...
	this.stopButton = new com.rogers.rci.ngws.Button("Stop");
	this.stopButton.init();
	this.stopButton.set("width", "50px");
	this.stopButton.set("left", (parseInt(this.get("width")) - 531) + "px");
	this.stopButton.set("top", (parseInt(this.get("height")) - 47) + "px");
	this.stopButton.viewport().onclick = function() {
			SELF.stopEngine();
	}
	// append it...
	this.body().append(this.stopButton);
}



com.rogers.rci.ngws.EngineAdminWindow.prototype.initLayout = function() {
	this.layoutContentPanel = new js.wtc.ContentPanel();
	this.layoutContentPanel.init();
	this.layoutContentPanel.set("top", "0px");
	this.layoutContentPanel.set("left", "0px");
	this.layoutContentPanel.set("width", (parseInt(this.get("width")) - 2) + "px");
	this.layoutContentPanel.set("height", (parseInt(this.get("height")) - 53) + "px");
	this.layoutContentPanel.set("border", "1px solid rgb(120,172,255)");
	this.layoutContentPanel.set("backgroundColor", "#FFFFFF");
	this.layoutContentPanel.set("overflowX", "hidden");
	this.layoutContentPanel.set("overflowY", "scroll");
	// append it...
	this.body().append(this.layoutContentPanel);
	
	var nAttrsSize = 24;
	
	// attribute names...
	this.configAttrs = new Array(nAttrsSize);
	this.configAttrs[0] = "JVM_ENGINE_ID";
	this.configAttrs[1] = "JVM_IS_ALIVE";
	this.configAttrs[2] = "JVM_IS_INTERRUPTED";
	this.configAttrs[3] = "IS_ACTIVE";
	this.configAttrs[4] = "IS_PAUSED";
	this.configAttrs[5] = "IS_PROCESSING";
	this.configAttrs[6] = "NR_OF_TOTAL_CYCLES";
	this.configAttrs[7] = "CYCLE_START_TIME";
	this.configAttrs[8] = "CYCLE_MESSAGE_LIST_SIZE";
	this.configAttrs[9] = "CYCLE_FIRST_MESSAGE_ID";
	this.configAttrs[10] = "CYCLE_GET_MESSAGE_LIST_DURATION";
	this.configAttrs[11] = "CYCLE_GET_MESSAGE_LIST_IN_PROG.";
	this.configAttrs[12] = "CYCLE_NR_OF_MESSAGES";
	this.configAttrs[13] = "CYCLE_ERROR";
	this.configAttrs[14] = "LAST_TIME_REFRESH_CONFIG_VALUES";
	this.configAttrs[15] = "ACTIVE_SERVER_NAME";
	this.configAttrs[16] = "SEND_DIRECTLY_TO_JMS";
	this.configAttrs[17] = "ASYNC_ADAPTOR_ENGINE_RUN_INTERVAL";
	this.configAttrs[18] = "NEXT_MESSAGE_LIST_SIZE";
	this.configAttrs[19] = "MOVE_FOR_PROCESSING_LIST_SIZE";
	this.configAttrs[20] = "MAX_NR_OF_RECORDS_FOR_PROCESSING";
	this.configAttrs[21] = "GET_NEXT_MESSAGE_LIST_SQL";
	this.configAttrs[22] = "ELMS_SERVERS_OK";
	this.configAttrs[23] = "DISPATCH_TO_PROCESS_IN_MSG_VIA_JMS";
	
	// values...
	this.configValues = new Array(nAttrsSize);
	for(var i = 0; i < nAttrsSize; i++) {
		if((i == 13) || (i == 21) || (i == 23)) {
			this.configValues[i] = new com.rogers.rci.ngws.Textarea();
		} else {
			this.configValues[i] = new com.rogers.rci.ngws.Textbox();
		}
		
		this.configValues[i].init();
		this.configValues[i].set("position", "");
		
		if((i == 13) || (i == 21) || (i == 23)) {
			this.configValues[i].set("width", "305px");
			this.configValues[i].set("height", "50px");
		} else {
			this.configValues[i].set("width", "310px");
		}
	}
	
	
	// create the table layout...
	this.layoutTable = new js.wtc.Table();
	this.layoutTable.init();
	this.layoutTable.set("left", "0px");
	this.layoutTable.set("top", "0px");
	this.layoutTable.set("cellPadding", "1");
	this.layoutTable.set("cellSpacing", "1");
	this.layoutTable.generate(nAttrsSize, 2);
	// append it...
	this.layoutContentPanel.append(this.layoutTable);
	
	var cell = null;
	for(var i = 0; i < nAttrsSize; i++) {
		cell = this.layoutTable.cell(i, 0);
		if((i == 0) || (i == 1) || (i == 2)) {
			cell.style.backgroundColor = "#F0F0E0";
		} else if((i == 3) || (i == 4) || (i == 5) || (i == 6)) {
			cell.style.backgroundColor = "#E0F0E0";
		} else if((i == 7) || (i == 8) || (i == 9) || (i == 10) || (i == 11) || (i == 12) || (i == 13)) {
			cell.style.backgroundColor = "#E0E0E0";
		} else {
			cell.style.backgroundColor = "#F7F7F7";
		}
		cell.align = "right";
		cell.style.width = "265px";
		cell.innerHTML = this.configAttrs[i] + ":&nbsp;";
		
		cell = this.layoutTable.cell(i, 1);
		this.layoutTable.append(this.configValues[i], cell);
	}
}



com.rogers.rci.ngws.EngineAdminWindow.prototype.setConfigArray = function(data) {
	this.configValues[0].set("value", data.ENGINE_ID);
	this.configValues[1].set("value", data.IS_ALIVE);
	this.configValues[2].set("value", data.IS_INTERRUPTED);
	this.configValues[3].set("value", data.IS_ACTIVE);
	this.configValues[4].set("value", data.IS_PAUSED);
	this.configValues[5].set("value", data.IS_PROCESSING);
	this.configValues[6].set("value", data.NR_OF_TOTAL_CYCLES);
	this.configValues[7].set("value", data.CYCLE_START_TIME);
	this.configValues[8].set("value", data.CYCLE_MESSAGE_LIST_SIZE);
	this.configValues[9].set("value", data.CYCLE_FIRST_MESSAGE_ID);
	this.configValues[10].set("value", data.CYCLE_GET_MESSAGE_LIST_DURATION + "ms");
	this.configValues[11].set("value", data.CYCLE_GET_MESSAGE_LIST_IN_PROGRESS);
	this.configValues[12].set("value", data.CYCLE_NR_OF_MESSAGES);
	this.configValues[13].set("value", data.CYCLE_ERROR);
	this.configValues[14].set("value", data.config.LAST_TIME_REFRESH_CONFIG_VALUES);
	this.configValues[15].set("value", data.config.ACTIVE_SERVER_NAME);
	this.configValues[16].set("value", data.config.SEND_DIRECTLY_TO_JMS);
	this.configValues[17].set("value", data.config.ASYNC_ADAPTOR_ENGINE_RUN_INTERVAL);
	this.configValues[18].set("value", data.config.NEXT_MESSAGE_LIST_SIZE);
	this.configValues[19].set("value", data.config.MOVE_FOR_PROCESSING_LIST_SIZE);
	this.configValues[20].set("value", data.config.MAX_NR_OF_RECORDS_FOR_PROCESSING);
	this.configValues[21].set("value", data.config.GET_NEXT_MESSAGE_LIST_SQL);
	this.configValues[22].set("value", data.config.ELMS_SERVERS_OK);
	this.configValues[23].set("value", data.config.DISPATCH_TO_PROCESS_INPUT_MESSAGE_VIA_JMS);
	
	if(data.IS_ALIVE) {
		this.layoutTable.cell(1, 0).style.backgroundColor = "#F0F0E0";
	} else {
		this.layoutTable.cell(1, 0).style.backgroundColor = "#F0E0F0";
	}
	if(!data.IS_INTERRUPTED) {
		this.layoutTable.cell(2, 0).style.backgroundColor = "#F0F0E0";
	} else {
		this.layoutTable.cell(2, 0).style.backgroundColor = "#F0E0F0";
	}
	
	if(data.IS_ACTIVE) {
		this.layoutTable.cell(3, 0).style.backgroundColor = "#E0F0E0";
	} else {
		this.layoutTable.cell(3, 0).style.backgroundColor = "#F0E0F0";
	}
	if(!data.IS_PAUSED) {
		this.layoutTable.cell(4, 0).style.backgroundColor = "#E0F0E0";
	} else {
		this.layoutTable.cell(4, 0).style.backgroundColor = "#F0E0F0";
	}
	if(data.IS_PROCESSING) {
		this.layoutTable.cell(5, 0).style.backgroundColor = "#E0F0E0";
	} else {
		this.layoutTable.cell(5, 0).style.backgroundColor = "#F0E0F0";
	}
	
	if(data.CYCLE_ERROR == "") {
		this.layoutTable.cell(13, 0).style.backgroundColor = "#E0E0E0";
	} else {
		this.layoutTable.cell(13, 0).style.backgroundColor = "#F0E0F0";
	}
	
	if(data.config.ELMS_SERVERS_OK == "Y") {
		this.layoutTable.cell(22, 0).style.backgroundColor = "#F7F7F7";
	} else {
		this.layoutTable.cell(22, 0).style.backgroundColor = "#F0E0F0";
	}
}



com.rogers.rci.ngws.EngineAdminWindow.prototype.show = function() {
	if(this.refreshId == -1) {
		this.getStatus();
		
		var SELF = this;
		this.refreshId = setInterval(
				function() {
					SELF.getStatus();
				}
				, 3000
		);
	}
	
	js.wtc.Window.prototype.show.call(this);
}



com.rogers.rci.ngws.EngineAdminWindow.prototype.hide = function() {
	js.wtc.Window.prototype.hide.call(this);
	
	clearInterval(this.refreshId);
	this.refreshId = -1;
}



com.rogers.rci.ngws.EngineAdminWindow.prototype.getStatus = function() {
	// fix Firefox...
    if (js.util.Browser.isFirefox) {
        try {
            netscape.security.PrivilegeManager.enablePrivilege("UniversalBrowserRead");
        } catch (e) {
            //alert("Permission UniversalBrowserRead denied.");
        }
    }
    
    // TO DO...
    var xmlHttpRequest = new js.ajax.XMLHttpRequest();
    xmlHttpRequest.set("url", this.app.appServicesURL);
    xmlHttpRequest.setVar("cmd", "getStatus");
    xmlHttpRequest.object = this;
    xmlHttpRequest.open();

    xmlHttpRequest.onComplete = function() {
        //alert(this.response);
        
        // eval the JSON data...
        var data = null;
        eval("data = " + this.response);
        
        // ...
        this.object.setConfigArray(data);
    }
    xmlHttpRequest.onError = function() {
        alert("ERROR while executing getStatus: " + this.response);
    }

	try {
    	xmlHttpRequest.send();
	} catch(e) {
		alert("ERROR (getStatus):\n\n" + e);
	}
}



com.rogers.rci.ngws.EngineAdminWindow.prototype.stopEngine = function() {
	if(!confirm("STOP ENGINE - Are you sure?\nIf yes then press the <OK> button.")) {
		return;
	}
	
	// fix Firefox...
    if (js.util.Browser.isFirefox) {
        try {
            netscape.security.PrivilegeManager.enablePrivilege("UniversalBrowserRead");
        } catch (e) {
            //alert("Permission UniversalBrowserRead denied.");
        }
    }
    
    // TO DO...
    var xmlHttpRequest = new js.ajax.XMLHttpRequest();
    xmlHttpRequest.set("url", this.app.appServicesURL);
    xmlHttpRequest.setVar("cmd", "stop");
    xmlHttpRequest.object = this;
    xmlHttpRequest.open();

    xmlHttpRequest.onComplete = function() {
        //alert(this.response);
        
        // eval the JSON data...
        var data = null;
        eval("data = " + this.response);
        
        // ...
        alert(data.result);
    }
    xmlHttpRequest.onError = function() {
        alert("ERROR while executing stopEngine: " + this.response);
    }

	try {
    	xmlHttpRequest.send();
	} catch(e) {
		alert("ERROR (stopEngine):\n\n" + e);
	}
}



com.rogers.rci.ngws.EngineAdminWindow.prototype.startEngine = function() {
	if(!confirm("START ENGINE - Are you sure?\nIf yes then press the <OK> button.")) {
		return;
	}
	
	// fix Firefox...
    if (js.util.Browser.isFirefox) {
        try {
            netscape.security.PrivilegeManager.enablePrivilege("UniversalBrowserRead");
        } catch (e) {
            //alert("Permission UniversalBrowserRead denied.");
        }
    }
    
    // TO DO...
    var xmlHttpRequest = new js.ajax.XMLHttpRequest();
    xmlHttpRequest.set("url", this.app.appServicesURL);
    xmlHttpRequest.setVar("cmd", "start");
    xmlHttpRequest.object = this;
    xmlHttpRequest.open();

    xmlHttpRequest.onComplete = function() {
        //alert(this.response);
        
        // eval the JSON data...
        var data = null;
        eval("data = " + this.response);
        
        // ...
        alert(data.result);
    }
    xmlHttpRequest.onError = function() {
        alert("ERROR while executing startEngine: " + this.response);
    }

	try {
    	xmlHttpRequest.send();
	} catch(e) {
		alert("ERROR (startEngine):\n\n" + e);
	}
}



com.rogers.rci.ngws.EngineAdminWindow.prototype.pauseEngine = function() {
	if(!confirm("PAUSE ENGINE - Are you sure?\nIf yes then press the <OK> button.")) {
		return;
	}
	
	// fix Firefox...
    if (js.util.Browser.isFirefox) {
        try {
            netscape.security.PrivilegeManager.enablePrivilege("UniversalBrowserRead");
        } catch (e) {
            //alert("Permission UniversalBrowserRead denied.");
        }
    }
    
    // TO DO...
    var xmlHttpRequest = new js.ajax.XMLHttpRequest();
    xmlHttpRequest.set("url", this.app.appServicesURL);
    xmlHttpRequest.setVar("cmd", "pause");
    xmlHttpRequest.object = this;
    xmlHttpRequest.open();

    xmlHttpRequest.onComplete = function() {
        //alert(this.response);
        
        // eval the JSON data...
        var data = null;
        eval("data = " + this.response);
        
        // ...
        alert(data.result);
    }
    xmlHttpRequest.onError = function() {
        alert("ERROR while executing pauseEngine: " + this.response);
    }

	try {
    	xmlHttpRequest.send();
	} catch(e) {
		alert("ERROR (pauseEngine):\n\n" + e);
	}
}



com.rogers.rci.ngws.EngineAdminWindow.prototype.resumeEngine = function() {
	if(!confirm("RESUME ENGINE - Are you sure?\nIf yes then press the <OK> button.")) {
		return;
	}
	
	// fix Firefox...
    if (js.util.Browser.isFirefox) {
        try {
            netscape.security.PrivilegeManager.enablePrivilege("UniversalBrowserRead");
        } catch (e) {
            //alert("Permission UniversalBrowserRead denied.");
        }
    }
    
    // TO DO...
    var xmlHttpRequest = new js.ajax.XMLHttpRequest();
    xmlHttpRequest.set("url", this.app.appServicesURL);
    xmlHttpRequest.setVar("cmd", "resume");
    xmlHttpRequest.object = this;
    xmlHttpRequest.open();

    xmlHttpRequest.onComplete = function() {
        //alert(this.response);
        
        // eval the JSON data...
        var data = null;
        eval("data = " + this.response);
        
        // ...
        alert(data.result);
    }
    xmlHttpRequest.onError = function() {
        alert("ERROR while executing resumeEngine: " + this.response);
    }

	try {
    	xmlHttpRequest.send();
	} catch(e) {
		alert("ERROR (resumeEngine):\n\n" + e);
	}
}



com.rogers.rci.ngws.EngineAdminWindow.prototype.refreshConfigurationValues = function() {
	if(!confirm("RELOAD CONFIGURATION - Are you sure?\nIf yes then press the <OK> button.")) {
		return;
	}
	
	// fix Firefox...
    if (js.util.Browser.isFirefox) {
        try {
            netscape.security.PrivilegeManager.enablePrivilege("UniversalBrowserRead");
        } catch (e) {
            //alert("Permission UniversalBrowserRead denied.");
        }
    }
    
    // TO DO...
    var xmlHttpRequest = new js.ajax.XMLHttpRequest();
    xmlHttpRequest.set("url", this.app.appServicesURL);
    xmlHttpRequest.setVar("cmd", "refreshConfigurationValues");
    xmlHttpRequest.object = this;
    xmlHttpRequest.open();

    xmlHttpRequest.onComplete = function() {
        //alert(this.response);
        
        // eval the JSON data...
        var data = null;
        eval("data = " + this.response);
        
        // ...
        alert(data.result);
    }
    xmlHttpRequest.onError = function() {
        alert("ERROR while executing refreshConfigurationValues: " + this.response);
    }

	try {
    	xmlHttpRequest.send();
	} catch(e) {
		alert("ERROR (refreshConfigurationValues):\n\n" + e);
	}
}


