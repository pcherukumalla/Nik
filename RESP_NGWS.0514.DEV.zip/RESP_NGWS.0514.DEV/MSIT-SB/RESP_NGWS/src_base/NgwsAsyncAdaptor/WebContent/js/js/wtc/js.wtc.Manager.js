/*
****************************************************************************************************
 ezWebToolkit Library, http://ezwt.blogspot.com
****************************************************************************************************
Copyright [2006-2008] [Pro Net Systems Inc., http://www.pronetsystems.com]

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

	http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
***************************************************************************************************
*/



/*
------------------------------------------------------------------------------------------
Manager
------------------------------------------------------------------------------------------
*/
js.wtc.Manager = function() {
	this.descendants = new Array();
	this.openedListbox = null;

	// used to generate uniques ids for the add/setEventListener...
	this.uniqueId = 0;
}



js.wtc.Manager.prototype.append = function(o) {
	o.index = this.descendants.push(o) - 1;
}



// to be used for example in the onDragStart, onDrag and onDragEnd
// functions in order to get the ContentPanel...
js.wtc.Manager.prototype.childByViewport = function(o) {
	return this.descendants[o.id.substring(10, o.id.length)];
}



/*js.wtc.Manager.prototype.addEventListener = function(elem, evtname, act) {
	if(document.all) {
		if(typeof(act) == "function") {
			eval("doActionButton" + this.index + "_" + evtname + " = act");
		} else {
			eval("doActionButton" + this.index + "_" + evtname + " = function() {" + act + "}");
		}
		eval("elem.attachEvent(\"" + evtname + "\", doActionButton" + this.index + "_" + evtname + ")");
	} else {
		// fix Firefox event name...
		evtname = evtname.substring(2, evtname.length);

		if(typeof(act) == "function") {
			eval("elem.addEventListener(\"" + evtname + "\", act, false)");
		} else {
			eval("elem.addEventListener(\"" + evtname + "\", function() {" + act + "}, false)");
		}
	}
}*/
// new version with "stop propagation logic" (just use the last paramater equal 'true' or do not use it at all if otherwise)...
js.wtc.Manager.prototype.addEventListener = function(elem, evtname, act, bStopPropagation) {
	if(document.all) {
		this.uniqueId++;
	
		if(typeof(act) == "function") {
			if(bStopPropagation) {
				eval("doActionButton" + this.uniqueId + "_" + evtname + " = function(){act();event.cancelBubble = true;}");
			} else {
				eval("doActionButton" + this.uniqueId + "_" + evtname + " = act");
			}
		} else {
			if(bStopPropagation) {
				eval("doActionButton" + this.uniqueId + "_" + evtname + " = function() {" + act + ";event.cancelBubble = true;}");
			} else {
				eval("doActionButton" + this.uniqueId + "_" + evtname + " = function() {" + act + "}");
			}
		}
		eval("elem.attachEvent(\"" + evtname + "\", doActionButton" + this.uniqueId + "_" + evtname + ")");
	} else {
		// fix Firefox event name...
		evtname = evtname.substring(2, evtname.length);

		if(typeof(act) == "function") {
			if(bStopPropagation) {
				eval("elem.addEventListener(\"" + evtname + "\", function(e){act(e);js.wtc.Manager.preventEventPropagation(e)}, false)");
			} else {
				eval("elem.addEventListener(\"" + evtname + "\", act, false)");
			}
		} else {
			if(bStopPropagation) {
				eval("elem.addEventListener(\"" + evtname + "\", function(e) {" + act + ";js.wtc.Manager.preventEventPropagation(e)}, false)");
			} else {
				eval("elem.addEventListener(\"" + evtname + "\", function(e) {" + act + "}, false)");
			}
		}
	}
}



// set event listener and stop parent propagation (see "oncontextmenu" event)...
js.wtc.Manager.prototype.setEventListener = function(elem, evtname, act, bStopPropagation) {
	if(document.all) {
		this.uniqueId++;
	
		if(typeof(act) == "function") {
			if(bStopPropagation) {
				eval("doActionButton" + this.uniqueId + "_" + evtname + " = function(){act();event.cancelBubble = true;}");
			} else {
				eval("doActionButton" + this.uniqueId + "_" + evtname + " = act");
			}
		} else {
			if(bStopPropagation) {
				eval("doActionButton" + this.uniqueId + "_" + evtname + " = function() {" + act + ";event.cancelBubble = true;}");
			} else {
				eval("doActionButton" + this.uniqueId + "_" + evtname + " = function() {" + act + "}");
			}
		}
		eval("elem." + evtname + " = function(){doActionButton" + this.uniqueId + "_" + evtname + "(); return false}");
	} else {
		if(typeof(act) == "function") {
			if(bStopPropagation) {
				eval("elem." + evtname + " = function(e){act(e);js.wtc.Manager.preventEventPropagation(e); return false}");
			} else {
				eval("elem." + evtname + " = function(e){act(e); return false;}");
			}
		} else {
			if(bStopPropagation) {
				eval("elem." + evtname + " = function(e){" + act + ";js.wtc.Manager.preventEventPropagation(e); return false}");
			} else {
				eval("elem." + evtname + " = function(e) {" + act + "; return false}");
			}
		}
	}
}



js.wtc.Manager.prototype.preventEventPropagation = function(e) {
	if (typeof e != "undefined") {
		e.stopPropagation();
	} else {
		event.cancelBubble = true;
	}
}



js.wtc.Manager.prototype.getMaxZIndex = function() {
	var ret = 0;

	for(var i = 0; i < this.descendants.length; i++) {
		if((this.descendants[i].viewport() != null) && (parseInt(this.descendants[i].get("zIndex")) > ret)) {
			ret = parseInt(this.descendants[i].get("zIndex"));
		}
	}

	return ret;
}



js.wtc.Manager.prototype.getGlobalWidth = function() {
    var ret = 0;

    var pos = null;
    for (var i = 0; i < this.descendants.length; i++) {
        if (this.descendants[i].viewport() != null) { // this is just to check if is a viewable object...
            pos = this.descendants[i].get("pos");

            if ((pos.left + pos.width) > ret) {
                ret = pos.left + pos.width;
            }
        }
    }

    var winWidth = 0;
    if (document.all) {
        //alert(screen.width + "\n" + document.documentElement.clientWidth + "\n" + document.getElementsByTagName('body')[0].clientWidth);
        //winWidth = document.getElementsByTagName('body')[0].clientWidth;
        winWidth = screen.width;
    } else {
        winWidth = window.innerWidth;
    }

    if (winWidth < ret) {
        return ret + "px";
    } else {
        return winWidth + "px";
    }
}



js.wtc.Manager.prototype.getGlobalHeight = function() {
    var ret = 0;

    var pos = null;
    for (var i = 0; i < this.descendants.length; i++) {
        if (this.descendants[i].viewport() != null) { // this is just to check if is a viewable object...
            pos = this.descendants[i].get("pos");

            if ((pos.top + pos.height) > ret) {
                ret = pos.top + pos.height;
            }
        }
    }

    var winHeight = 0;
    if (document.all) {
        //alert(screen.height + "\n" + document.documentElement.clientHeight + "\n" + document.getElementsByTagName('body')[0].clientHeight);
        //winHeight = document.getElementsByTagName('body')[0].clientHeight;
        winHeight = screen.height;
    } else {
        winHeight = window.innerHeight;
    }

    if (winHeight < ret) {
        return ret + "px";
    } else {
        return winHeight + "px";
    }
}



// returns true if (x, y) point is contained by the (l, t, w, h) rectangle...
js.wtc.Manager.prototype.isInRectangle = function(x, y, l, t, w, h) {
	var bRet = false;
	
	if((x >= l) && (x <= l + w) && (y >= t) && (y <= t + h)) {
		bRet = true;
	}
	
	return bRet;
}



// returns true if there is a non-empty intersection...
js.wtc.Manager.prototype.rectangleIntersection = function(o1, o2) {
	var bRet = true;
	var bS1 = (o2.top + o2.height < o1.top); // top...
	var bS2 = (o2.left + o2.width < o1.left); // left...
	var bS3 = (o2.top > o1.top + o1.height); // bottom...
	var bS4 = (o2.left > o1.left + o1.width); // right...
	
	bRet = !(bS1 || bS2 || bS3 || bS4);
	
	return bRet;
}



js.wtc.Manager.prototype.getMouseX = function(e) {
	var tempX = 0;

	if(document.all) { // grab the x-y pos.s if browser is IE
		tempX = event.clientX + document.body.scrollLeft;
	} else {  // grab the x-y pos.s if browser is NS
		tempX = e.pageX;
	}
	
	return tempX;
}



js.wtc.Manager.prototype.getMouseY = function(e) {
	var tempY = 0;

	if(document.all) { // grab the x-y pos.s if browser is IE
		tempY = event.clientY + document.body.scrollTop;
	} else {  // grab the x-y pos.s if browser is NS
		tempY = e.pageY;
	}
	
	return tempY;
}



// http://www.softcomplex.com/docs/get_window_size_and_scrollbar_position.html
js.wtc.Manager.prototype.clientWidth = function() {
	return this.f_filterResults (
		window.innerWidth ? window.innerWidth : 0,
		document.documentElement ? document.documentElement.clientWidth : 0,
		document.body ? document.body.clientWidth : 0
	);
}



// http://www.softcomplex.com/docs/get_window_size_and_scrollbar_position.html
js.wtc.Manager.prototype.clientHeight = function() {
	return this.f_filterResults (
		window.innerHeight ? window.innerHeight : 0,
		document.documentElement ? document.documentElement.clientHeight : 0,
		document.body ? document.body.clientHeight : 0
	);
}



// http://www.softcomplex.com/docs/get_window_size_and_scrollbar_position.html
js.wtc.Manager.prototype.scrollLeft = function() {
	return this.f_filterResults (
		window.pageXOffset ? window.pageXOffset : 0,
		document.documentElement ? document.documentElement.scrollLeft : 0,
		document.body ? document.body.scrollLeft : 0
	);
}



// http://www.softcomplex.com/docs/get_window_size_and_scrollbar_position.html
js.wtc.Manager.prototype.scrollTop = function() {
	return this.f_filterResults (
		window.pageYOffset ? window.pageYOffset : 0,
		document.documentElement ? document.documentElement.scrollTop : 0,
		document.body ? document.body.scrollTop : 0
	);
}



// http://www.softcomplex.com/docs/get_window_size_and_scrollbar_position.html
js.wtc.Manager.prototype.f_filterResults = function(n_win, n_docel, n_body) {
	var n_result = n_win ? n_win : 0;
	if (n_docel && (!n_result || (n_result > n_docel)))
		n_result = n_docel;
	return n_body && (!n_result || (n_result > n_body)) ? n_body : n_result;
}



// this will be attached to the document.onclick event...
js.wtc.Manager.prototype.closeOpenedListbox = function(e) {
	if((this.openedListbox != null) && this.openedListbox.dropdownIn) {
		var evt = null;
		if(document.all) {
			evt = window.event;
		} else {
			evt = e;
		}
		
		var pos = js.util.Position.get(this.openedListbox.buttonDD.viewport());
		if(!js.wtc.Manager.isInRectangle(evt.clientX + js.wtc.Manager.scrollLeft(), evt.clientY + js.wtc.Manager.scrollTop(), pos.left, pos.top, pos.width, pos.height)) {
			pos = js.util.Position.get(this.openedListbox.optContainer.viewport());
	
			if(!js.wtc.Manager.isInRectangle(evt.clientX + js.wtc.Manager.scrollLeft(), evt.clientY + js.wtc.Manager.scrollTop(), pos.left, pos.top, pos.width, pos.height)) {
				this.openedListbox.optContainer.hide();
				
				this.openedListbox = null;
			}
		}
	}
}




js.wtc.Manager = new js.wtc.Manager(); // singleton...



// add event handling for dropdown menus (combo-boxes)...
js.wtc.Manager.addEventListener(document, "onclick", function(e) {js.wtc.Manager.closeOpenedListbox(e)});
