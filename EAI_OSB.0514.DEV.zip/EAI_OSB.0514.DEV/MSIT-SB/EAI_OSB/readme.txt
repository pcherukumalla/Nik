*********************************************************************************************************

This follow release note is only for MR413.

EAI_OSB deployment:                           
---------------------------------------------------------------------------------
- Get the EAI_OSB_EAIE_sbconfig.jar file from the staging sever
- Import the EAI_OSB_EAIE_sbconfig.jar from OSB admin console
- Deselect all resources and expand the EAIServices
- Select EAIServices/resources/wsdls/eaie/customer_services/CSPerformNegativeFileCheck.wsdl only to import

*********************************************************************************************************