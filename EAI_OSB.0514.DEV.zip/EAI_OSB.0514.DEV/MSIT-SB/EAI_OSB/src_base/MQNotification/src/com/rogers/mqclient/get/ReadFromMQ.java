package com.rogers.mqclient.get;

import com.ibm.mq.MQC;
import com.ibm.mq.MQGetMessageOptions;
import com.ibm.mq.MQMessage;
import com.ibm.mq.MQQueue;
import com.ibm.mq.MQQueueManager;
import com.rogers.logger.utility.UtilityLogger;
import com.rogers.mqclient.MSCReplyToMQDispatcher;
import com.rogers.mqclient.env.MSCOutEnvDetail;

public class ReadFromMQ
{
	/**
	 * Can be used only for verification purposes of utilities in package 'send'
	 * @throws Exception
	 */
	public static void getMessage(String mqconfiguration)
		throws Exception
	{
	      boolean solutionInd = MSCReplyToMQDispatcher.getSolutionTypeIndicator();
	      if (solutionInd) throw new Exception("Only Native solution exists for 'get'! 'send' first using native solution.");

	       (new MSCReplyToMQDispatcher()).setPrerequisites(mqconfiguration, false, false,"","", null);

	       UtilityLogger.getLogger().info ("MSCOutEnvDetail.QNAME " + MSCOutEnvDetail.QNAME);

	      MQQueueManager qMgr = new MQQueueManager(MSCOutEnvDetail.QMGR);

	      // Set up the options on the queue we wish to open
	      int openOptions = MQC.MQOO_INPUT_AS_Q_DEF | MQC.MQOO_OUTPUT;

	      // Now specify the queue that we wish to open and the open options
	      UtilityLogger.getLogger().info("Accessing queue: " + MSCOutEnvDetail.QNAME);
	      MQQueue queue = qMgr.accessQueue(MSCOutEnvDetail.QNAME, openOptions);

		  MQMessage rcvMessage = new MQMessage();

		// Following 2 test lines will cause any message on the queue to be received regardless of
		// whatever message ID or correlation ID it might have
	      rcvMessage.messageId = MQC.MQMI_NONE;
	      rcvMessage.correlationId = MQC.MQCI_NONE;

	      // Specify default get message options
	      MQGetMessageOptions gmo = new MQGetMessageOptions();

	      // Get the message off the queue.
	      UtilityLogger.getLogger().info("Getting the message back");

	      queue.get(rcvMessage, gmo);



	      // And display the message text...
	      String msgText = rcvMessage.readUTF();
	      UtilityLogger.getLogger().info("The message is: |" + msgText + "|");

	      //leverage Close connection code:
	      new MSCReplyToMQDispatcher().resetConnection();

	      UtilityLogger.getLogger().info("Done!");
	}
}
