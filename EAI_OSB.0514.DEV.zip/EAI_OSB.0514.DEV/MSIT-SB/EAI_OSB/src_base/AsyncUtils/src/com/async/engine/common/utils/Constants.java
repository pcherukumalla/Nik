package com.async.engine.common.utils;

import java.text.*;



public class Constants {
	public static final String DATA_SOURCE_CONFIG_NAME = "ae.config.datasource";
	public static final String DEFAULT_DATA_SOURCE_JNDI_NAME = "cgDataSource";
	
	public static final long ERROR_MESSAGES_REFRESH_PERIOD = 600000;
	
	public static final String OK = "OK";
	public static final String ERROR = "ERROR";
	public static final String DOWN_ERROR = "DOWN";
	public static final String TIMEOUT_ERROR = "TIMEOUT";
	
	public static final int UNKNOWN_MESSAGE_TYPE_ID = -1;
	public static final String UNKNOWN_MESSAGE_TYPE = "UNKNOWN";
	
	public static final java.util.logging.Logger LOGGER = java.util.logging.Logger.getLogger("");
	
	public static final SimpleDateFormat STATS_DATE_FORMAT = new SimpleDateFormat("MMddyyyy");

	
	
	public static final String GET_ERROR_MESSAGES_SQL = "SELECT e.err_cd, e.status_in, s.move_to_in FROM ASYNC_RTY_MSGS_ERRORS e, ASYNC_RTY_MSGS_STATUSES s WHERE e.status_in = s.status_in";
	public static final String GET_MESSAGE_TYPES_SQL = "SELECT t.* FROM ASYNC_RTY_MSGS_TYPES t";
	public static final String GET_ERROR_DESCRIPTIONS_SQL = "SELECT d.description, d.err_cd FROM ASYNC_RTY_MSGS_ERR_DSCS d WHERE d.active_in = 1";

	public static final String INSERT_MESSAGE_SQL = "INSERT INTO ~ (msgtype_id, szkey, msg_data, set_id) values (?, ?, ?, ?)";
	public static final String INSERT_UNKNOWN_MESSAGE_SQL = "INSERT INTO ~ (msgtype_id, msgtype, szkey, msg_data, set_id) values (-1, ?, ?, ?, 0)";
	public static final String INSERT_MESSAGE_TO_HISTORY_SQL = "INSERT INTO ~ (MSGID, SZKEY, MSG_DATA, START_TIME_TS, STATUS_IN, ERR_CD, ERR_DESC, WHEN_CREATED_TS, SET_ID, MSGTYPE_ID, END_TIME_TS, NR_OF_RETRIES, CORRELATION_ID) SELECT MSGID, SZKEY, MSG_DATA, START_TIME_TS, STATUS_IN, ERR_CD, ERR_DESC, WHEN_CREATED_TS, SET_ID, MSGTYPE_ID, END_TIME_TS, NR_OF_RETRIES, CORRELATION_ID FROM ASYNC_RTY_MSGS_TEMP WHERE msgid = ?";
	public static final String INSERT_MESSAGE_TO_HOLD_SQL = "INSERT INTO ~ (MSGID, SZKEY, MSG_DATA, START_TIME_TS, STATUS_IN, ERR_CD, ERR_DESC, WHEN_CREATED_TS, SET_ID, MSGTYPE_ID, END_TIME_TS, NR_OF_RETRIES, CORRELATION_ID) SELECT MSGID, SZKEY, MSG_DATA, START_TIME_TS, STATUS_IN, ERR_CD, ERR_DESC, WHEN_CREATED_TS, SET_ID, MSGTYPE_ID, END_TIME_TS, NR_OF_RETRIES, CORRELATION_ID FROM ASYNC_RTY_MSGS_TEMP WHERE msgid = ?";
	public static final String INSERT_MESSAGE_TO_TEMP_SQL = "INSERT INTO ASYNC_RTY_MSGS_TEMP (MSGID, SZKEY, MSG_DATA, START_TIME_TS, STATUS_IN, ERR_CD, ERR_DESC, WHEN_CREATED_TS, SET_ID, MSGTYPE_ID, END_TIME_TS, NR_OF_RETRIES, CORRELATION_ID) SELECT MSGID, SZKEY, MSG_DATA, START_TIME_TS, STATUS_IN, ERR_CD, ERR_DESC, WHEN_CREATED_TS, SET_ID, MSGTYPE_ID, END_TIME_TS, NR_OF_RETRIES, CORRELATION_ID FROM ~ WHERE msgid = ?";
	public static final String DELETE_MESSAGE_SQL = "DELETE FROM ASYNC_RTY_MSGS_TEMP WHERE msgid = ?";
	public static final String DELETE_MESSAGE_FROM_HOLD_SQL = "DELETE FROM ~ WHERE msgid = ?";
	public static final String GET_MESSAGE_FROM_HOLD_BY_CORRELATION_ID_SQL = "SELECT msgid, szkey FROM ~ WHERE correlation_id = ?";
	public static final String GET_OLDEST_MESSAGE_FROM_HOLD_BY_SZKEY_SQL = "select MIN(MSGID) AS min_msgid from ~ WHERE szkey = ?";
	public static final String UPDATE_MESSAGE_AFTER_PROCESSING_SQL = "UPDATE ASYNC_RTY_MSGS_TEMP SET status_in = ?, err_cd = ?, err_desc= ?, correlation_id = ?, end_time_ts = SYSDATE, nr_of_retries = nr_of_retries + 1 WHERE msgid = ?";
	public static final String GET_MESSAGE_NR_OF_RETRIES_SQL = "SELECT nr_of_retries FROM ASYNC_RTY_MSGS_TEMP WHERE msgid = ?";
	
	public static final String UPDATE_NR_OF_MSG_STATS_SQL = "UPDATE ASYNC_RTY_MSGS_STATS SET NR_OF_MSG = NR_OF_MSG + 1 WHERE day_of_year = ? AND msgtype_id = ?";
	public static final String UPDATE_NR_OF_MSG_OTHER_ERRORS_STATS_SQL = "UPDATE ASYNC_RTY_MSGS_STATS SET NR_OF_MSG_OTHER_ERRORS = NR_OF_MSG_OTHER_ERRORS + 1 WHERE day_of_year = ? AND msgtype_id = ?";
	public static final String UPDATE_NR_OF_MSG_OK_STATS_SQL = "UPDATE ASYNC_RTY_MSGS_STATS SET NR_OF_MSG_OK = NR_OF_MSG_OK + 1 WHERE day_of_year = ? AND msgtype_id = ?";
	public static final String UPDATE_NR_OF_MSG_DOWN_STATS_SQL = "UPDATE ASYNC_RTY_MSGS_STATS SET NR_OF_MSG_ELMS_DOWN = NR_OF_MSG_ELMS_DOWN + 1 WHERE day_of_year = ? AND msgtype_id = ?";
	public static final String UPDATE_NR_OF_MSG_TIMEOUT_STATS_SQL = "UPDATE ASYNC_RTY_MSGS_STATS SET NR_OF_MSG_ELMS_TIMEOUT = NR_OF_MSG_ELMS_TIMEOUT + 1 WHERE day_of_year = ? AND msgtype_id = ?";
	public static final String INSERT_STATS_SQL = "INSERT INTO ASYNC_RTY_MSGS_STATS (day_of_year, msgtype_id) VALUES (?, ?)";
}
