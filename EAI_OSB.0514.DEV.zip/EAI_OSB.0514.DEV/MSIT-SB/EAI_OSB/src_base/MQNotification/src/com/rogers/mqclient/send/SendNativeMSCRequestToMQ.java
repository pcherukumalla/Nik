package com.rogers.mqclient.send;

import com.ibm.mq.MQC;
import com.ibm.mq.MQEnvironment;
import com.ibm.mq.MQMessage;
import com.ibm.mq.MQPutMessageOptions;
import com.ibm.mq.MQQueueManager;
import com.rogers.logger.utility.UtilityLogger;
import com.rogers.mqclient.cache.MQCacheBase;
import com.rogers.mqclient.cache.MQMSCReqCacheVO;
import com.rogers.mqclient.env.MSCReqEnvDetail;
import com.rogers.mqclient.msc.MscHeaderFields;
import com.rogers.mqclient.msc.MscMessageUtils;
import com.rogers.mqclient.msc.SendMSCInterface;
import com.rogers.mqclient.msc.SsUserLogon;

public class SendNativeMSCRequestToMQ implements SendMSCInterface
{
	
	private String TEXT = "";
	private MscHeaderFields mscHeaderFields = null;

	private MQCacheBase mqCache = null;
	private final long refreshDuration = 3 * 60 * 1000; //miliseconds
	private long lastRefresh = System.currentTimeMillis(); //set initial value
	private String password = null;

    public void setPrerequisites(String mqconfiguration, boolean resetMqConn, boolean resetMqDetail, String correlationId, String mscMsgReceived, String password)
		throws Exception
	{
    	mqCache = MQMSCReqCacheVO.getInstance();

		//set the environment variables:
		if ( resetMqDetail || mqCache.getRESET_MQ_DETAIL() == null )
		{
			synchronized ( MSCReqEnvDetail.class )
			{
				new MSCReqEnvDetail( mqconfiguration );
			}

			synchronized ( mqCache )
			{
				if (MSCReqEnvDetail.CCSID > 0 && MSCReqEnvDetail.QMGR != null ) mqCache.setRESET_MQ_DETAIL( "SET" );
			}
		}		
		this.mscHeaderFields = new MscHeaderFields( mscMsgReceived );
		this.password = password;
		
		if ( resetMqConn || refreshNow()) resetConnection();
	}

	private boolean refreshNow()
	{
		long timenow = System.currentTimeMillis();
		boolean doRefresh = false;
		if (( timenow - this.lastRefresh ) > this.refreshDuration )
		{
			doRefresh = true;
			this.lastRefresh = System.currentTimeMillis();
		}
		return doRefresh;
	}

    public void resetConnection()
    {
        try
        {
			synchronized ( mqCache )
			{
	            if ( mqCache.getQueue() != null ) mqCache.getQueue().close();
	            mqCache.setQueue( null );
	
	            if ( mqCache.getQManager() != null) mqCache.getQManager().disconnect();
	            mqCache.setQManager( null );
			}

        } catch ( Exception ex ){}
    }

    public byte[] putMSCMessage (String txtMessage, String session, String typeOfCall )
		throws Exception
	{
      byte[] msgid = null;
      
	  if ( mqCache.getRESET_MQ_DETAIL() == null )
		  throw new Exception ("Set first prerequisites!");

      	  if (txtMessage != null )
      	  {
      		  //add msc out header to out message
      		TEXT = new StringBuffer(  getAdjustedMscInHeader( typeOfCall, txtMessage ) ).append( "" ).toString();
      		  UtilityLogger.getLogger().info( "MSCAdapter.sendRequest: " + TEXT);
      	  }
          //UtilityLogger.getLogger().info("Using MQ detail:" + MSCOutEnvDetail.LAST_GOOD_MQ_DETAILS);

      	  try{
	          //populate the Environment
	          MQEnvironment.hostname = MSCReqEnvDetail.HOST;
	          MQEnvironment.port = new Integer(MSCReqEnvDetail.PORT).intValue();
	          MQEnvironment.channel = MSCReqEnvDetail.CHANNEL;

	          // use IBM API only!
	          int openOptions = MQC.MQOO_OUTPUT ; 
	          synchronized (mqCache)
	          {
	        	  //UtilityLogger.getLogger().info("MSCOutEnvDetail.QMGR " + MSCOutEnvDetail.QMGR);
	        	  //UtilityLogger.getLogger().info(" MSCOutEnvDetail.QNAME " +  MSCOutEnvDetail.QNAME);

	        	  if ( mqCache.getQManager() == null || (!mqCache.getQManager().isConnected()))
	        		  mqCache.setQManager( new MQQueueManager( MSCReqEnvDetail.QMGR ) );
	        	  if ( mqCache.getQueue() == null)
	        		  mqCache.setQueue ( mqCache.getQManager().accessQueue(  MSCReqEnvDetail.QNAME, openOptions, null, null, null ));
	          }
	          MQMessage sendMessage = new MQMessage();
	          sendMessage.format = MQC.MQFMT_STRING;
	          sendMessage.messageType =  120001; //MQC.MQMT_REQUEST;	          
	          if ( !typeOfCall.equalsIgnoreCase("LOGN"))
	          {
	        	  sendMessage.applicationIdData = session;
	        	  UtilityLogger.getLogger().info("Set applicationIdData:|" + session + "|");
	          }

	          sendMessage.expiry = 300; //600 msec -- initially from eai but IBM MQ sets expiry in 'tenths' of second on native communication
	          sendMessage.characterSet = 819;

	          sendMessage.persistence = MQC.MQPER_NOT_PERSISTENT;

	          UtilityLogger.getLogger().info( "Ready .." );

	          //sendMessage.writeUTF( TEXT );
	          sendMessage.writeString( TEXT );

	          MQPutMessageOptions pmo = new MQPutMessageOptions();

	          mqCache.getQueue().put( sendMessage, pmo );
	          msgid = sendMessage.messageId;
      	  }
      	  catch (Exception ex)
      	  {
      		  Throwable e1 = ex;
      		  while (e1.getCause() != null ) e1=e1.getCause();
      		  if ((e1 instanceof com.ibm.mqservices.MQInternalException) || (e1 instanceof com.ibm.mq.MQException))
      		  {
      			resetConnection();
      			mqCache.setRESET_MQ_CONN( null );
      		  }
      		  throw new Exception(e1);
      	  }
          UtilityLogger.getLogger().info("Pushed to MQ:" + TEXT);

          if ( mqCache.getRESET_MQ_CONN() == null) mqCache.setRESET_MQ_CONN( "SET" );
          
          return msgid;
	}
    	
	private String getAdjustedMscInHeader( String typeOfCall, String origMessage )
  		throws Exception
  	{
		 if  (this.mscHeaderFields.getLengthReceived() == 0 )
		 {
			 throw new Exception( "MSC request header not defined" );
		 }
		 
		 //append the message header	 
		 if ( typeOfCall.equalsIgnoreCase("LOGN")) 
		 {
			 MscInLOGNFields lognFields = getAdjustedMscInLOGNHeader();
			 return String.valueOf( lognFields.msgheader ) + lognFields.message;
		 }
		 else if (typeOfCall.equalsIgnoreCase("USUAL"))
			 return origMessage;
		 else
			 throw new Exception("Unhandled type of call");
  	}    
  
	private MscInLOGNFields getAdjustedMscInLOGNHeader( )
		throws Exception    
	{
      char [] msgheader = new char[39];
      MscMessageUtils.setRequestHeader( msgheader, SsUserLogon.SERVER, SsUserLogon.ACTION, this.mscHeaderFields.getCompany(), this.mscHeaderFields.getUserId() );

      String message = SsUserLogon.createRequest( this.password, null, SsUserLogon.maxSessions );
      MscMessageUtils.numToSsStr( message.length(), msgheader, 33, 6 );  
      return new MscInLOGNFields(msgheader, message);
	}	
    
    public void putMessage (String txtMessage ) throws Exception
    {
    	throw new Exception("Not to be used in a sync MSC context!");
    }
    
    private class MscInLOGNFields
    {
    	public MscInLOGNFields(char[] msgheader, String message)
    	{
    		this.msgheader = new char[msgheader.length];
    		this.msgheader = msgheader;
    		this.message = message;
    	}
    	public char[] msgheader = null;
    	public String message = null;
    }
}