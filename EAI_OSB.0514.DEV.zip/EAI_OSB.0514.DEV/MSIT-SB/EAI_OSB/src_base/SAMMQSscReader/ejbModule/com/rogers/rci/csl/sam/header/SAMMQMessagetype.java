package com.rogers.rci.csl.sam.header;

import com.rogers.rci.eai.ss.SscHeaderFields;

public class SAMMQMessagetype {
	public static final int SSC_HEADER_LENGTH = 105;
	public static final int MSG_TYPE_LENGTH = 10;
	
	/**
	 * @param message - expects whole message with SSC header
	 * @return
	 * @throws Exception
	 */
	public static String getMsgType(String message)
		throws Exception
	{
		SscHeaderFields messageHeader = null;
		
		if ( message != null && message.length() >= SAMMQMessagetype.SSC_HEADER_LENGTH )
		{
			messageHeader = new SscHeaderFields( message );		
		}
		else
		{
			throw new Exception("Message length is shorter than SSC_HEADER_LENGTH!");
		}
		
		String msgBody = message.substring(SAMMQMessagetype.SSC_HEADER_LENGTH);
		
		System.out.println("StructureId: " + messageHeader.getStructureId().trim());
		return new StringBuffer ( messageHeader.getStructureId().trim() ).append( msgBody.substring(0, SAMMQMessagetype.MSG_TYPE_LENGTH).trim()).toString();
	}
}
