/*
****************************************************************************************************
 ezWebToolkit Library, http://www.ezwebtoolkit.com
****************************************************************************************************
Copyright [2006-2008] [Pro Net Systems Inc., http://www.pronetsystems.com]

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

	http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
***************************************************************************************************
*/



// *****************************************************************************
// MessageManager...
// *****************************************************************************
js.msg.QUEUE_TYPE = "queue";
js.msg.TOPIC_TYPE = "topic";



js.msg.MessageManager = function() {
	this.messageQueues = new Array();
	this.consumers = new Array();
	this.interval = 10;
	this.intervalId = null;

	this.objectType = "js.msg.MessageManager";
}



js.msg.MessageManager.prototype.createMessageQueue = function(name, typ) {
    strType = js.msg.QUEUE_TYPE;
	if(typ) {
		strType = typ;
	}

	var q = new js.msg.MessageQueue(name, strType);
	this.messageQueues.push(q);
	
	return q;
}



js.msg.MessageManager.prototype.getMessageQueue = function(name) {
	var ret = null;

	for(var i = 0; i < this.messageQueues.length; i++) {
		if(this.messageQueues[i].name == name) {
			ret = this.messageQueues[i];
		}
	}

	return ret;
}



js.msg.MessageManager.prototype.registerConsumer = function(newConsumer, queueName) {
	var q = null;
	var qn = null;
	
	if(QueueName) {
		q = this.getMessageQueue(queueName);
		qn = queueName;
	} else {
		q = this.getMessageQueue(js.msg.SYSTEM_QUEUE);
		qn = js.msg.SYSTEM_QUEUE;
	}

	if(q != null) {
		if(this.consumers[qn] != null) {
			this.consumers[qn].push(newConsumer);
		} else {
			this.consumers[qn] = new Array();
			this.consumers[qn].push(newConsumer);
		}
	}
}



js.msg.MessageManager.prototype.onMessage = function() {
	var allConsumers = null;
	var msg = null;

	for(var i = 0; i < this.messageQueues.length; i++) {
		// if this Queue/topic is unlocked then consume messages...
		if(!this.messageQueues[i].locked) {
			// lock this Queue/topic...
			this.messageQueues[i].locked = true;

			// get consumers/subscribers...
			allConsumers = this.consumers[this.messageQueues[i].name];
	
			// consume messages...
			if(allConsumers != null) {
			    if (this.messageQueues[i].type == js.msg.QUEUE_TYPE) {
					if(allConsumers.length > 0) {
						while(this.messageQueues[i].messages.length > 0) {
							msg = this.messageQueues[i].getMessage();
		
							// only one consumer can exist, the first one...
							try {
								allConsumers[0].onMessage(msg);
							} catch(e) {
								// put message back...
								this.messageQueues[i].putMessage(msg);
							}
						}
					}
				} else if(this.messageQueues[i].type == js.msg.TOPIC_TYPE) {
					while(this.messageQueues[i].messages.length > 0) {
						msg = this.messageQueues[i].getMessage();
	
						for(var j = 0; j < allConsumers.length; j++) {
							try {
								allConsumers[j].onMessage(msg);
							} catch(e) {
								// nothing...
							}
						}
					}
				}
			}

			// unlock this queue/topic...
			this.messageQueues[i].locked = false;
		}
	}
}



js.msg.MessageManager.prototype.send = function(msg, queueName) {
	var q = null;
	if(queueName) {
		q = this.getMessageQueue(queueName);
	} else {
		q = this.getMessageQueue(com.ezwt.SYSTEM_QUEUE);
	}

	if(q != null) {
		q.putMessage(msg);
	}
}



js.msg.MessageManager.prototype.setExecInterval = function(v) {
	this.interval = v;
}



js.msg.MessageManager.prototype.start = function() {
	if(this.intervalId != null) {
		clearInterval(this.intervalId);
	}

	var self = this;
	this.intervalId = setInterval(function() {self.onMessage()}, this.interval);
}




js.msg.MessageManager.prototype.stop = function() {
	clearInterval(this.intervalId);
}



// get a "singleton"...
js.msg.MessageManager = new js.msg.MessageManager();
// start the message manager...
js.msg.MessageManager.start();


// define the default queue name...
js.msg.SYSTEM_QUEUE = "_SYSTEM_QUEUE";
// define the default topic name...
js.msg.SYSTEM_TOPIC = "_SYSTEM_TOPIC";


// create the default queue...
js.msg.MessageManager.createMessageQueue(js.msg.SYSTEM_QUEUE, js.msg.QUEUE_TYPE);
// create the default topic...
js.msg.MessageManager.createMessageQueue(js.msg.SYSTEM_TOPIC, js.msg.TOPIC_TYPE);
