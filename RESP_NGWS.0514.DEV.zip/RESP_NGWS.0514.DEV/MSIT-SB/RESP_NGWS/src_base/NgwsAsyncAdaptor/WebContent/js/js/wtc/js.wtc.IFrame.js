/*
****************************************************************************************************
 ezWebToolkit Library, http://ezwt.blogspot.com
****************************************************************************************************
Copyright [2006-2008] [Pro Net Systems Inc., http://www.pronetsystems.com]

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

	http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
***************************************************************************************************
*/



/*
------------------------------------------------------------------------------------------
IFrame
------------------------------------------------------------------------------------------
*/
js.wtc.IFrame = function() {
	js.wtc.ContentPanel.call(this);

	this.objectType = "js.wtc.IFrame";
}
js.wtc.IFrame.prototype = new js.wtc.ContentPanel();
js.wtc.IFrame.prototype.constructor = js.wtc.IFrame;



js.wtc.IFrame.prototype.init = function() {
	// create the main div...
	this.theViewport = document.createElement("IFRAME");
	
	// instrument the new node...
	this.instrumentViewport();
}



js.wtc.IFrame.prototype.set = function(name, value) {
	if(name == "name") {
		this.viewport().name = value;
	} else if(name == "src") {
		this.viewport().src = value;
	} else {
		js.wtc.ContentPanel.prototype.set.call(this, name, value);
	}
}



js.wtc.IFrame.prototype.get = function(name) {
	if(name == "name") {
		return this.viewport().name;
	} else if(name == "src") {
		return this.viewport().src;
	} else {
		return js.wtc.ContentPanel.prototype.get.call(this, name);
	}
}
