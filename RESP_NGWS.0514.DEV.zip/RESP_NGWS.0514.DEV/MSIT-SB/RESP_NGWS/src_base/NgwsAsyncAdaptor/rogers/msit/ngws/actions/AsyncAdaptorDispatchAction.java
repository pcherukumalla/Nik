package com.rogers.msit.ngws.actions;

import java.util.*;
import java.text.*;
import javax.servlet.http.*;

import org.json.*;
import org.apache.struts.action.*;

import com.rogers.msit.ngws.actions.base.*;
import com.rogers.msit.ngws.dao.base.*;
import com.rogers.msit.ngws.engine.*;
import com.rogers.msit.ngws.services.*;
import com.rogers.msit.ngws.utils.*;



public class AsyncAdaptorDispatchAction extends BaseDispatchAction {
	public ActionForward getProperties(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
        try {
            // get parameters...
        	
            
            // action to do...
        	List types = AsyncAdaptorService.getInstance().getAsyncAdaptorDAO().getMessageTypes();
        	List errors = AsyncAdaptorService.getInstance().getAsyncAdaptorConfigDAO().getErrorMessages();
        	List statuses = AsyncAdaptorService.getInstance().getAsyncAdaptorConfigDAO().getStatuses();
        	
        	// export to JSON...
        	JSONObject json = new JSONObject(AsyncAdaptorService.getInstance().getProps().getProperty("NGWS.SETTINGS"));
        	json.put("types", DAOUtils.getInstance().listToJSONArray(types));
        	json.put("errors", DAOUtils.getInstance().listToJSONArray(errors));
        	json.put("statuses", DAOUtils.getInstance().listToJSONArray(statuses));
        	
        	
        	this.send(response, json);
        } catch(Exception e) {
            e.printStackTrace();
            throw new AsyncAdaptorDispatchException(this.getClass().getName() + ".getProperties error: " + e.toString());
        }
        
        return null;
    }
	
	
	
	public ActionForward refreshConfigurationValues(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
        try {
            // get parameters...
        	
            
            // action to do...
        	String strResult = "OK";
        	try {
	        	AsyncAdaptorEngine.getInstance().refreshConfigurationValues(true);
        	} catch(Exception e2) {
        		strResult = "ERROR: " + e2.toString();
        	}
        	
        	
        	// export to JSON...
        	JSONObject json = new JSONObject();
        	json.put("result", strResult);
        	        	
        	this.send(response, json);
        } catch(Exception e) {
            e.printStackTrace();
            throw new AsyncAdaptorDispatchException(this.getClass().getName() + ".refreshConfigurationValues error: " + e.toString());
        }
        
        return null;
    }
	
	
	
	public ActionForward getStatus(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
        try {
            // get parameters...
        	
            
            // action to do...
        	AsyncAdaptorService service = AsyncAdaptorService.getInstance();
        	AsyncAdaptorEngine engine = AsyncAdaptorEngine.getInstance();
        	
        	// export to JSON...
        	JSONObject jsonConfig = new JSONObject();
        	// configuration values stored by the service only...
        	jsonConfig.put("LAST_TIME_REFRESH_CONFIG_VALUES", Constants.DEFAULT_DATE_FORMAT.format(new Date(service.getLastConfigValuesRefreshTime())));
        	jsonConfig.put("ACTIVE_SERVER_NAME", service.getValue("ACTIVE_SERVER_NAME"));
        	jsonConfig.put("DISPATCH_TO_PROCESS_END_POINT", service.getValue("DISPATCH_TO_PROCESS_END_POINT"));
        	jsonConfig.put("ELMS_SERVERS_OK", service.getValue("ELMS_SERVERS_OK"));
        	jsonConfig.put("ASYNC_ADAPTOR_ENGINE_AUX_THREAD_POOL_SIZE", service.getValue("ASYNC_ADAPTOR_ENGINE_AUX_THREAD_POOL_SIZE"));
        	// configuration values stored in the engine itself...
        	jsonConfig.put("ASYNC_ADAPTOR_ENGINE_RUN_INTERVAL", engine.getRunInterval());
        	jsonConfig.put("NEXT_MESSAGE_LIST_SIZE", engine.getNextMessageListSize());
        	jsonConfig.put("GET_NEXT_MESSAGE_LIST_SQL", engine.getNextMessageListSQL());
        	jsonConfig.put("MOVE_FOR_PROCESSING_LIST_SIZE", engine.getMoveListSize());
        	jsonConfig.put("MAX_NR_OF_RECORDS_FOR_PROCESSING", engine.getMaxNrOfRecsInProcessingTable());
        	
        	
        	JSONObject json = new JSONObject();
        	// engine status...
        	json.put("ENGINE_ID", engine.getId());
        	json.put("IS_ALIVE", engine.isAlive());
        	json.put("IS_INTERRUPTED", engine.isInterrupted());
        	json.put("IS_ACTIVE", engine.isActive());
        	json.put("IS_PAUSED", engine.isPaused());
        	json.put("IS_PROCESSING", engine.isProcessing());
        	json.put("NR_OF_TOTAL_CYCLES", engine.getNrOfCycles());
        	json.put("CYCLE_MESSAGE_LIST_SIZE", engine.getCurrentMessageListSize());
        	json.put("CYCLE_GET_MESSAGE_LIST_DURATION", engine.getGetCurrentMessageListDuration());
        	json.put("CYCLE_GET_MESSAGE_LIST_IN_PROGRESS", engine.getGetCurrentMessageListInProgress());
        	json.put("CYCLE_NR_OF_MESSAGES", engine.getCurrentCycleNrOfMessages());
        	json.put("CYCLE_ERROR", engine.getCurrentCycleError());
        	json.put("CYCLE_START_TIME", Constants.DEFAULT_DATE_FORMAT.format(new Date(engine.getCurrentCycleStartTime())));
        	json.put("CYCLE_FIRST_MESSAGE_ID", engine.getCurrentCycleFirstMessageId());
        	// configuration values...
        	json.put("config", jsonConfig);
        	        	
        	        	
        	this.send(response, json);
        } catch(Exception e) {
            e.printStackTrace();
            throw new AsyncAdaptorDispatchException(this.getClass().getName() + ".getStatus error: " + e.toString());
        }
        
        return null;
    }
	
	
	
	public ActionForward stop(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
        try {
            // get parameters...
        	
            
            // action to do...
        	String strResult = "";
        	try {
	        	AsyncAdaptorEngine engine = AsyncAdaptorEngine.getInstance();
	        		        	
	        	if(engine.isActive()) {
	        		engine.setActive(false);
	        		
	        		// ****************************************************************************************************
	        		engine.getThreadPool().close();
	        		// ****************************************************************************************************
	        		
	        		strResult = "OK";
	        	} else {
	        		strResult = "Engine already stopped.";
	        	}
        	} catch(Exception e2) {
        		strResult = "ERROR: " + e2.toString();
        	}
        	
        	
        	// export to JSON...
        	JSONObject json = new JSONObject();
        	json.put("result", strResult);
        	        	
        	this.send(response, json);
        } catch(Exception e) {
            e.printStackTrace();
            throw new AsyncAdaptorDispatchException(this.getClass().getName() + ".stop error: " + e.toString());
        }
        
        return null;
    }
	
	
	
	public ActionForward start(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
        try {
            // get parameters...
        	
            
            // action to do...
        	String strResult = "";
        	try {
	        	AsyncAdaptorEngine engine = AsyncAdaptorEngine.getInstance();
	        		        	
	        	if(!engine.isActive() && !engine.isAlive()) {
	        		AsyncAdaptorEngine.cleanUp();
	        		
	        		// ****************************************************************************************************
	    			com.rogers.msit.ngws.thread.ThreadPool threadPool = new com.rogers.msit.ngws.thread.ThreadPool();
	    			
	    			//threadPool.setPoolSize(Constants.ASYNC_ADAPTOR_ENGINE_AUX_THREAD_POOL_SIZE);
	    			AsyncAdaptorService.getInstance().refreshConfigValues(true);
	    			threadPool.setPoolSize(Integer.parseInt(AsyncAdaptorService.getInstance().getValue("ASYNC_ADAPTOR_ENGINE_AUX_THREAD_POOL_SIZE")));
	    			
	    			threadPool.start();
	    			AsyncAdaptorEngine.getInstance().setThreadPool(threadPool);
	    			// ****************************************************************************************************
	        		
	        		AsyncAdaptorEngine.getInstance().start();
	        		
	        		strResult = "OK";
	        	} else {
	        		strResult = "Can not start the engine because current instance is active/alive.";
	        	}
        	} catch(Exception e2) {
        		strResult = "ERROR: " + e2.toString();
        	}
        	
        	
        	// export to JSON...
        	JSONObject json = new JSONObject();
        	json.put("result", strResult);
        	        	
        	this.send(response, json);
        } catch(Exception e) {
            e.printStackTrace();
            throw new AsyncAdaptorDispatchException(this.getClass().getName() + ".start error: " + e.toString());
        }
        
        return null;
    }
	
	
	
	public ActionForward pause(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
        try {
            // get parameters...
        	
            
            // action to do...
        	String strResult = "";
        	try {
	        	AsyncAdaptorEngine engine = AsyncAdaptorEngine.getInstance();

        		if(!engine.isPaused()) {
        			engine.setPaused(true);
	        		
	        		strResult = "OK";
	        	} else {
	        		strResult = "Engine already paused.";
	        	}
        	} catch(Exception e2) {
        		strResult = "ERROR: " + e2.toString();
        	}
        	
        	
        	// export to JSON...
        	JSONObject json = new JSONObject();
        	json.put("result", strResult);
        	        	
        	this.send(response, json);
        } catch(Exception e) {
            e.printStackTrace();
            throw new AsyncAdaptorDispatchException(this.getClass().getName() + ".pause error: " + e.toString());
        }
        
        return null;
    }
	
	
	
	public ActionForward resume(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
        try {
            // get parameters...
        	
            
            // action to do...
        	String strResult = "";
        	try {
	        	AsyncAdaptorEngine engine = AsyncAdaptorEngine.getInstance();

        		if(engine.isPaused()) {
        			engine.setPaused(false);
	        		
	        		strResult = "OK";
	        	} else {
	        		strResult = "Engine already resumed.";
	        	}
        	} catch(Exception e2) {
        		strResult = "ERROR: " + e2.toString();
        	}
        	
        	
        	// export to JSON...
        	JSONObject json = new JSONObject();
        	json.put("result", strResult);
        	        	
        	this.send(response, json);
        } catch(Exception e) {
            e.printStackTrace();
            throw new AsyncAdaptorDispatchException(this.getClass().getName() + ".resume error: " + e.toString());
        }
        
        return null;
    }
	
	
	
	public ActionForward search(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
        try {
            // get parameters...
        	String strKey = request.getParameter("k"); 
            
            // action to do...
        	List lst = AsyncAdaptorService.getInstance().getAsyncAdaptorDAO().getMessagesBySzKey(strKey);
        	
        	
        	// export to JSON...
        	JSONObject json = new JSONObject();
        	json.put("items", DAOUtils.getInstance().listToJSONArray(lst));
        	        	
        	this.send(response, json);
        } catch(Exception e) {
            e.printStackTrace();
            throw new AsyncAdaptorDispatchException(this.getClass().getName() + ".search error: " + e.toString());
        }
        
        return null;
    }
	
	
	
	public ActionForward searchHistory(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
        try {
            // get parameters...
        	String strKey = request.getParameter("k"); 
            
            // action to do...
        	List lst = AsyncAdaptorService.getInstance().getAsyncAdaptorDAO().getHistoryMessagesBySzKey(strKey);
        	
        	
        	// export to JSON...
        	JSONObject json = new JSONObject();
        	json.put("items", DAOUtils.getInstance().listToJSONArray(lst));
        	        	
        	this.send(response, json);
        } catch(Exception e) {
            e.printStackTrace();
            throw new AsyncAdaptorDispatchException(this.getClass().getName() + ".searchHistory error: " + e.toString());
        }
        
        return null;
    }
	
	
	
	public ActionForward getMessage(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
        try {
            // get parameters...
        	long nId = Long.parseLong(request.getParameter("id"));
        	String strLocation = request.getParameter("l");
            
            // action to do...
        	DAOObject o = null;
        	if("main".equals(strLocation)) {
        		o = AsyncAdaptorService.getInstance().getAsyncAdaptorDAO().getMessageByPK(nId);	
        	} else {
        		o = AsyncAdaptorService.getInstance().getAsyncAdaptorDAO().getTempMessageByPK(nId);
        	}
        	
        	if(o == null) {
        		o = new DAOObject();
        		o.set("MSG_DATA_STR", "Message not found in the table '" + strLocation + "' anymore.");
        	}
        	        	
        	
        	// export to JSON...
        	JSONObject json = new JSONObject();
        	json.put("item", DAOUtils.getInstance().objectToJSONObject(o));
        	        	
        	this.send(response, json);
        } catch(Exception e) {
            e.printStackTrace();
            throw new AsyncAdaptorDispatchException(this.getClass().getName() + ".getMessage error: " + e.toString());
        }
        
        return null;
    }
	
	
	
	public ActionForward stats(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
        try {
            // get parameters...
        	String strDate = request.getParameter("dt"); 
            
            // action to do...
        	if(strDate == null) {
        		strDate = Constants.STATS_DATE_FORMAT.format(new Date());
        	}
        	strDate += " 23:59:59";
        	
        	
        	List lst = AsyncAdaptorService.getInstance().getAsyncAdaptorDAO().getMessagesStats(strDate);
        	
        	JSONArray items = new JSONArray();
        	JSONArray  ar = new JSONArray();
    		ar.put(0, "DAY");
    		ar.put(1, "TOTAL");
    		ar.put(2, "SUCCESS");
    		ar.put(3, "ERRORS");
    		items.put(0, ar);
        	
        	DAOObject o = null;
        	for(int i = 0; i < lst.size(); i++) {
        		o = (DAOObject)lst.get(i);
        		
        		ar = new JSONArray();
        		ar.put(0, o.getString("WHEN_CREATED_FORMATTED").substring(0,  4));
        		ar.put(1, o.getInt("NR_OF_MSG"));
        		ar.put(2, o.getInt("NR_OF_MSG_OK"));
        		ar.put(3, o.getInt("NR_OF_ERRORS"));
        		
        		items.put(i + 1, ar);
        	}
        	
        	
        	// export to JSON...
        	JSONObject json = new JSONObject();
        	json.put("items", items);
        	        	
        	this.send(response, json);
        } catch(Exception e) {
            e.printStackTrace();
            throw new AsyncAdaptorDispatchException(this.getClass().getName() + ".stats error: " + e.toString());
        }
        
        return null;
    }
	
	
	
	public ActionForward statsErrors(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
        try {
            // get parameters...
        	String strDate = request.getParameter("dt"); 
            
            // action to do...
        	if(strDate == null) {
        		strDate = Constants.STATS_DATE_FORMAT.format(new Date());
        	}
        	strDate += " 23:59:59";
        	
        	
        	List lst = AsyncAdaptorService.getInstance().getAsyncAdaptorDAO().getMessagesErrorsStats(strDate);
        	
        	JSONArray items = new JSONArray();
        	JSONArray  ar = new JSONArray();
    		ar.put(0, "DAY");
    		ar.put(1, "ELMS TIMEOUT");
    		ar.put(2, "ELMS DOWN");
    		ar.put(3, "OTHER ERRORS");
    		items.put(0, ar);
        	
        	DAOObject o = null;
        	for(int i = 0; i < lst.size(); i++) {
        		o = (DAOObject)lst.get(i);
        		
        		ar = new JSONArray();
        		ar.put(0, o.getString("WHEN_CREATED_FORMATTED").substring(0,  4));
        		ar.put(1, o.getInt("NR_OF_MSG_ELMS_TIMEOUT"));
        		ar.put(2, o.getInt("NR_OF_MSG_ELMS_DOWN"));
        		ar.put(3, o.getInt("NR_OF_MSG_OTHER_ERRORS"));
        		
        		items.put(i + 1, ar);
        	}
        	
        	
        	// export to JSON...
        	JSONObject json = new JSONObject();
        	json.put("items", items);
        	        	
        	this.send(response, json);
        } catch(Exception e) {
            e.printStackTrace();
            throw new AsyncAdaptorDispatchException(this.getClass().getName() + ".statsErrors error: " + e.toString());
        }
        
        return null;
    }
	
	
	
	public ActionForward statsToday(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
        try {
            // get parameters...
            
            // action to do...
        	List lst = AsyncAdaptorService.getInstance().getAsyncAdaptorDAO().getMessagesTodayStats(Constants.STATS_DATE_FORMAT.format(new Date()));
        	
        	JSONArray items = new JSONArray();
        	JSONArray  ar = new JSONArray();
    		ar.put(0, "DAY");
    		ar.put(1, "TOTAL");
    		ar.put(2, "SUCCESS");
    		ar.put(3, "ELMS TIMEOUT");
    		ar.put(4, "ELMS DOWN");
    		ar.put(5, "OTHER ERRORS");
    		items.put(0, ar);
        	
        	DAOObject o = null;
        	for(int i = 0; i < lst.size(); i++) {
        		o = (DAOObject)lst.get(i);
        		
        		ar = new JSONArray();
        		ar.put(0, o.getString("WHEN_CREATED_FORMATTED").substring(0,  4));
        		ar.put(1, o.getInt("NR_OF_MSG"));
        		ar.put(2, o.getInt("NR_OF_MSG_OK"));
        		ar.put(3, o.getInt("NR_OF_MSG_ELMS_TIMEOUT"));
        		ar.put(4, o.getInt("NR_OF_MSG_ELMS_DOWN"));
        		ar.put(5, o.getInt("NR_OF_MSG_OTHER_ERRORS"));
        		
        		items.put(i + 1, ar);
        	}
        	
        	// export to JSON...
        	JSONObject json = new JSONObject();
        	json.put("items", items);
        	if(o != null) {
        		DecimalFormat df = new DecimalFormat("###,###,###");
        		
        		o.set("NR_OF_MSG", df.format(o.getInt("NR_OF_MSG")));
        		o.set("NR_OF_MSG_OK", df.format(o.getInt("NR_OF_MSG_OK")));
        		o.set("NR_OF_MSG_ELMS_TIMEOUT", df.format(o.getInt("NR_OF_MSG_ELMS_TIMEOUT")));
        		o.set("NR_OF_MSG_ELMS_DOWN", df.format(o.getInt("NR_OF_MSG_ELMS_DOWN")));
        		o.set("NR_OF_MSG_OTHER_ERRORS", df.format(o.getInt("NR_OF_MSG_OTHER_ERRORS")));
        		
        		json.put("item", DAOUtils.getInstance().objectToJSONObject(o));
        	}
        	        	
        	this.send(response, json);
        } catch(Exception e) {
            e.printStackTrace();
            throw new AsyncAdaptorDispatchException(this.getClass().getName() + ".statsToday error: " + e.toString());
        }
        
        return null;
    }
}


