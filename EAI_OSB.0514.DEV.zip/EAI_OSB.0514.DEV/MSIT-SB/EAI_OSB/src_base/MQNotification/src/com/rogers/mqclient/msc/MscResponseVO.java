package com.rogers.mqclient.msc;

public class MscResponseVO implements java.io.Serializable
{
	private static final long serialVersionUID = 1L;
	
	private String mscResponse = null;
	private String retCode = null;
	
	public MscResponseVO(String mscResponse, String retCode)
	{
		this.mscResponse = mscResponse;
		this.retCode =  retCode;		
	}
	
	public String getRetCode()
	{
		return retCode;
	}
	
	public String getMscResponse()
	{
		return mscResponse;
	}
}
