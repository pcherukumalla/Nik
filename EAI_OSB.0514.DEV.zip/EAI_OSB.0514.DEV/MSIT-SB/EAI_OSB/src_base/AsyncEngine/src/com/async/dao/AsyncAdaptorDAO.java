package com.async.dao;

import java.sql.*;
import java.util.*;
import java.util.logging.*;


import com.async.dao.base.*;
import com.async.utils.*;



public class AsyncAdaptorDAO extends BaseDAO {
	public List getNextMessageList(String nextMessageListSQL, int cycleSize) throws AsyncAdaptorDAOException {
		List ret = null;
		
		// params...

		// get data...
		Connection conn = null;
		try {
			conn = getConnection();

			// params...
			Object[] params = null;
			if(cycleSize > 0) {
				params = new Object[1];
				params[0] = new Integer(cycleSize + 1);
			}
			
			// get list...
			ret = getDAOObjectList(conn, nextMessageListSQL, params);
			
			// get the actual message as string for each record in the list...
			DAOObject o = null;
			for(int i = 0; i < ret.size(); i ++) {
				o = (DAOObject)ret.get(i);
				
				try {
					o.set("MSG_DATA_STR", o.getBlobAsString("MSG_DATA"));
				} catch(Exception e2) {
					Constants.LOGGER.log(Level.SEVERE,  this.getClass().getName() + ".getNextMessageList get BLOB as String error: " + o.get("MSGID") + " - " + e2.toString());
				}
			}
		} catch(Exception e) {
			Constants.LOGGER.log(Level.SEVERE,  this.getClass().getName() + ".getNextMessageList error: " + e.toString());
			throw new AsyncAdaptorDAOException(e);
		} finally {
			closeConnection(conn);
		}
		
		return ret;
	}
	
	
	public boolean updateMessageForProcessing(DAOObject msg, DAOObject typ) throws AsyncAdaptorDAOException, BaseDAOException {
		boolean bRet = true;
		int nRet = -1;
		
		// get message attributes...
		long nMessageId = msg.getLong("MSGID");
		String strSzKey = msg.getString("SZKEY");
		int nSetId = msg.getInt("SET_ID");
		
		// get type attributes...
		int nProcessLevelId = typ.getInt("PROCESS_LEVEL_ID");
		String strHoldTableName = typ.getString("HOLD_TABLE_NAME");
		String strHistTableName = typ.getString("HIST_TABLE_NAME");
		
		
		// params...

		// get data...
		Connection conn = null;
		PreparedStatement st = null;
		PreparedStatement st1 = null;
		PreparedStatement st2 = null;
		ResultSet res = null;
		try {
			conn = getConnection();
			conn.setAutoCommit(false);
			
			if(nProcessLevelId == 0) {
				if(nSetId == 0) {
					// update message...
					st = conn.prepareStatement(DAOUtils.getInstance().getQueries().getProperty("sql.UPDATE_MESSAGE_FOR_PROCESSING_SQL"));
					
					st.setLong(1, nMessageId);
					nRet = st.executeUpdate();
				} else {
					// check if any messages in hold already for this szkey...
					st2 = conn.prepareStatement(DAOUtils.getInstance().getQueries().getProperty("sql.GET_IF_ANY_MESSAGE_IN_HOLD_BY_SZKEY_SQL").replaceFirst("~", strHoldTableName));
					st2.setString(1, strSzKey);
					res = st2.executeQuery();
					
					if(res.next()) {
						bRet = false;
						
						// insert to hold table...
						st = conn.prepareStatement(DAOUtils.getInstance().getQueries().getProperty("sql.INSERT_MESSAGE_TO_HOLD_SQL").replaceFirst("~", strHoldTableName));
						
						st.setLong(1, nMessageId);
						nRet = st.executeUpdate();
						
						// delete message...
						st1 = conn.prepareStatement(DAOUtils.getInstance().getQueries().getProperty("sql.DELETE_MESSAGE_SQL"));
						st1.setLong(1, nMessageId);
						nRet = st1.executeUpdate();
					} else {
						// update message...
						st = conn.prepareStatement(DAOUtils.getInstance().getQueries().getProperty("sql.UPDATE_MESSAGE_FOR_PROCESSING_SQL"));
						
						st.setLong(1, nMessageId);
						nRet = st.executeUpdate();
					}
				}
			} else if(nProcessLevelId == 1) {
				bRet = false;
				
				// insert to history table...
				st = conn.prepareStatement(DAOUtils.getInstance().getQueries().getProperty("sql.INSERT_MESSAGE_TO_HISTORY_SQL").replaceFirst("~", strHistTableName));
				
				st.setLong(1, nMessageId);
				nRet = st.executeUpdate();
				
				// delete message...
				st1 = conn.prepareStatement(DAOUtils.getInstance().getQueries().getProperty("sql.DELETE_MESSAGE_SQL"));
				st1.setLong(1, nMessageId);
				nRet = st1.executeUpdate();
			} else if(nProcessLevelId == 2) {
				bRet = false;
				
				// insert to hold table...
				st = conn.prepareStatement(DAOUtils.getInstance().getQueries().getProperty("sql.INSERT_MESSAGE_TO_HOLD_SQL").replaceFirst("~", strHoldTableName));
				
				st.setLong(1, nMessageId);
				nRet = st.executeUpdate();
				
				// delete message...
				st1 = conn.prepareStatement(DAOUtils.getInstance().getQueries().getProperty("sql.DELETE_MESSAGE_SQL"));
				st1.setLong(1, nMessageId);
				nRet = st1.executeUpdate();
			}
			
			conn.commit();
			conn.setAutoCommit(true);
		} catch(Exception e) {
			try {
				conn.rollback();
			} catch(SQLException sqle) {
				Constants.LOGGER.log(Level.SEVERE,  this.getClass().getName() + ".updateMessageForProcessing rollback error: " + sqle.toString());
			}
			Constants.LOGGER.log(Level.SEVERE,  this.getClass().getName() + ".updateMessageForProcessing error: " + e.toString());
			throw new AsyncAdaptorDAOException(e);
		} finally {
			closeResultSet(res);
			closeStatement(st);
			closeStatement(st1);
			closeStatement(st2);
			closeConnection(conn);
		}
		
		return bRet;
	}
	
	
	
	public int updateMessageWhenError(DAOObject msg, String errorCd, String errorDesc, DAOObject err, DAOObject typ, String statsDate) throws AsyncAdaptorDAOException, BaseDAOException {
		int nRet = -1;
		boolean bMoveTo = false;
		
		// get type attributes...
		String strHoldTableName = typ.getString("HOLD_TABLE_NAME");
		String strHistTableName = typ.getString("HIST_TABLE_NAME");
		int nStatsActiveIn = typ.getInt("STATS_ACTIVE_IN");
		
		// get error attributes...
		int nStatusIn = err.getInt("STATUS_IN");
		int nMoveTo = err.getInt("MOVE_TO_IN");
		
		// get message attributes...
		long nMessageId = msg.getLong("MSGID");
		int nMessageTypeId = msg.getInt("MSGTYPE_ID");
		int nSetId = msg.getInt("SET_ID");
		
		// params...

		// get data...
		Connection conn = null;
		PreparedStatement st = null;
		PreparedStatement st1 = null;
		PreparedStatement st2 = null;
		PreparedStatement st3 = null;
		PreparedStatement st4 = null;
		PreparedStatement st5 = null;
		ResultSet res = null;
		try {
			conn = getConnection();
			conn.setAutoCommit(false);
			
			// update message...
			st = conn.prepareStatement(DAOUtils.getInstance().getQueries().getProperty("sql.UPDATE_MESSAGE_AFTER_PROCESSING_SQL"));
			st.setInt(1, nStatusIn);
			st.setString(2, errorCd);
			st.setString(3, errorDesc);
			st.setLong(4, nMessageId);
			nRet = st.executeUpdate();
			
			if(nMoveTo == 0) {
				bMoveTo = true;
			} else if(nMoveTo > 0) {
				// get number of retries...
				st1 = conn.prepareStatement(DAOUtils.getInstance().getQueries().getProperty("sql.GET_MESSAGE_NR_OF_RETRIES_SQL"));
				st1.setLong(1, nMessageId);
				res = st1.executeQuery();
				
				int nNrOfRetries = -1;
				if(res.next()) {
					nNrOfRetries = res.getInt("NR_OF_RETRIES");
				}
				
				if(nNrOfRetries >= nMoveTo) {
					bMoveTo = true;
				}
			}
			
			if(bMoveTo) {
				// insert into history/hold table...
				if(nSetId == 0) {
					st2 = conn.prepareStatement(DAOUtils.getInstance().getQueries().getProperty("sql.INSERT_MESSAGE_TO_HISTORY_SQL").replaceFirst("~", strHistTableName));
				} else {
					st2 = conn.prepareStatement(DAOUtils.getInstance().getQueries().getProperty("sql.INSERT_MESSAGE_TO_HOLD_SQL").replaceFirst("~", strHoldTableName));
				}
				st2.setLong(1, nMessageId);
				nRet = st2.executeUpdate();
				
				// delete message...
				st3 = conn.prepareStatement(DAOUtils.getInstance().getQueries().getProperty("sql.DELETE_MESSAGE_SQL"));
				st3.setLong(1, nMessageId);
				nRet = st3.executeUpdate();
			}
			
			
			// store stats about this event...
			if(nStatsActiveIn == 1) {
				// try to update stats...
				st4 = conn.prepareStatement(DAOUtils.getInstance().getQueries().getProperty("sql.UPDATE_STATS"));
				st4.setString(1, statsDate);
				st4.setInt(2, nMessageTypeId);
				int nUpdateStatsRet = st4.executeUpdate();
				
				// if no row exists for this day of year then insert one and then update again...
				if(nUpdateStatsRet == 0) {
					st5 = conn.prepareStatement(DAOUtils.getInstance().getQueries().getProperty("sql.INSERT_STATS"));
					st5.setString(1, statsDate);
					st5.setInt(2, nMessageTypeId);
					st5.executeUpdate();
					
					st4.executeUpdate();
				}
			}
			
			conn.commit();
			conn.setAutoCommit(true);
		} catch(Exception e) {
			try {
				conn.rollback();
			} catch(SQLException sqle) {
				Constants.LOGGER.log(Level.SEVERE,  this.getClass().getName() + ".updateMessageWhenError rollback error: " + sqle.toString());
			}
			Constants.LOGGER.log(Level.SEVERE,  this.getClass().getName() + ".updateMessageWhenError error: " + e.toString());
			throw new AsyncAdaptorDAOException(e);
		} finally {
			closeResultSet(res);
			closeStatement(st);
			closeStatement(st1);
			closeStatement(st2);
			closeStatement(st3);
			closeStatement(st4);
			closeStatement(st5);
			closeConnection(conn);
		}
		
		return nRet;
	}
	
	
	
	public int moveMessageListForProcessing(String tableName, int maxNrOfRecs) throws AsyncAdaptorDAOException {
		int nRet = -1;
		
		// params...

		// get data...
		Connection conn = null;
		PreparedStatement st1 = null;
		PreparedStatement st2 = null;
		PreparedStatement st3 = null;
		PreparedStatement st4 = null;
		PreparedStatement st5 = null;
		PreparedStatement st6 = null;
		PreparedStatement st7 = null;
		PreparedStatement sts = null;
		ResultSet res1 = null;
		ResultSet res2 = null;
		ResultSet res3 = null;
		ResultSet res4 = null;
		ResultSet ress = null;
		try {
			conn = getConnection();
			conn.setAutoCommit(false);
			
			// get main table config and status...
			st1 = conn.prepareStatement(DAOUtils.getInstance().getQueries().getProperty("sql.GET_MOVE_FOR_PROCESSING_CONFIG_AND_STATUS"));
			st1.setString(1, tableName);
			res1 = st1.executeQuery();
			
			int nHealthIn = 0;
			int nInterval = 0;
			int nMsgListSize = 0;
			long nLastRun = 0;
			long nLastMsgId = -1;
			if(res1.next()) {
				nLastRun = res1.getTimestamp("STATUS_CYCLE_LAST_RUN_TS").getTime();
				nInterval = res1.getInt("CYCLE_INTERVAL");
				nHealthIn = res1.getInt("HEALTH_IN");
				
				nMsgListSize = res1.getInt("CYCLE_SIZE");
				nLastMsgId = res1.getLong("STATUS_CYCLE_LAST_MSGID");
			}
			
			long nStart = (new java.util.Date()).getTime();
			
			// STOP action if system not in valid status or not hit the proper run interval...
			if((nHealthIn == 1) && (nStart - nLastRun > nInterval)) {
				// get current number of records for processing...
				st2 = conn.prepareStatement(DAOUtils.getInstance().getQueries().getProperty("sql.GET_CURRENT_NR_OF_RECORDS_FOR_PROCESSING"));
				res2 = st2.executeQuery();
				
				int nCurrentNrOfRecords = -1;
				if(res2.next()) {
					nCurrentNrOfRecords = res2.getInt("NR_OF_RECS");
				}
				//System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> " + nCurrentNrOfRecords);
				
				// move the next list of messages for processing from the buffer table to the processing table...
				if(nCurrentNrOfRecords < maxNrOfRecs) {
					// set the new message id to be used to select the new list of messages for processing...
					long nNewMsgId = nLastMsgId + nMsgListSize;

					
					StringBuffer strMsgidList = new StringBuffer("0");
					// get main table config and status...
					sts = conn.prepareStatement(DAOUtils.getInstance().getQueries().getProperty("sql.SELECT_MOVE_FOR_PROCESSING").replaceFirst("~", tableName));
					sts.setLong(1, nNewMsgId);
					ress = sts.executeQuery();
					while (ress.next())
					{
						strMsgidList.append(","+ ress.getLong("MSGID"));
					}
/*					
					if(strMsgidList.length()>1)
					{
						System.out.println("**** MESSAGES TO BE MOVED TO TEMP: " + strMsgidList.toString());
					}
*/
					// insert new list of records for processing...
					st3 = conn.prepareStatement(DAOUtils.getInstance().getQueries().getProperty("sql.INSERT_MOVE_FOR_PROCESSING").replaceFirst("~", tableName).replaceFirst("#", strMsgidList.toString()));
					//st3.setLong(1, nNewMsgId);
					nRet = st3.executeUpdate();
					
					// delete new list of records for processing from the buffer table...
					if(nRet > 0) {
						st4 = conn.prepareStatement(DAOUtils.getInstance().getQueries().getProperty("sql.DELETE_MOVE_FOR_PROCESSING").replaceFirst("~", tableName).replaceFirst("#", strMsgidList.toString()));
						//st4.setLong(1, nNewMsgId);
						nRet = st4.executeUpdate();
						
						long nNow = (new java.util.Date()).getTime();
						
						// save the new "last message id" and all the other status info...
						st5 = conn.prepareStatement(DAOUtils.getInstance().getQueries().getProperty("sql.UPDATE_MOVE_FOR_PROCESSING_CONFIG_AND_STATUS"));
						st5.setLong(1, nLastMsgId + nRet);
						st5.setTimestamp(2, new java.sql.Timestamp(nNow));
						st5.setInt(3, nRet);
						st5.setLong(4, nNow - nStart);
						st5.setString(5, tableName);
						st5.executeUpdate();
					} else { // if no records found to be moved for processing then check if there are any records in the main/buffer table...
						st6 = conn.prepareStatement(DAOUtils.getInstance().getQueries().getProperty("sql.GET_IF_ANY_RECORDS_FOR_PROCESSING").replaceFirst("~", tableName));
						res3 = st6.executeQuery();
						
						// if there are any records then get the min MSGID and store that one in the config table to be ready for the next cycle...
						if(res3.next()) {
							st7 = conn.prepareStatement(DAOUtils.getInstance().getQueries().getProperty("sql.GET_MIN_ID_FOR_PROCESSING").replaceFirst("~", tableName));
							res4 = st7.executeQuery();
							
							if(res4.next()) {
								nLastMsgId = res4.getLong(1);
								
								// save the new message id to be used to select the new list of messages for processing...
								st5 = conn.prepareStatement(DAOUtils.getInstance().getQueries().getProperty("sql.UPDATE_MOVE_FOR_PROCESSING_LAST_MSGID").replaceFirst("~", tableName));
								st5.setString(1, "" + nLastMsgId);
								st5.setString(2, tableName);
								st5.executeUpdate();
								System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> fixed MIN MSGID for: " + tableName);
							}
						}
					}
				}
			}
			
			conn.commit();
			conn.setAutoCommit(true);
		} catch(Exception e) {
			try {
				conn.rollback();
			} catch(SQLException sqle) {
				Constants.LOGGER.log(Level.SEVERE,  this.getClass().getName() + ".moveMessageListForProcessing rollback error: " + sqle.toString());
			}
			Constants.LOGGER.log(Level.SEVERE,  this.getClass().getName() + ".moveMessageListForProcessing error: " + e.toString());
			throw new AsyncAdaptorDAOException(e);
		} finally {
			closeResultSet(res1);
			closeResultSet(res2);
			closeResultSet(res3);
			closeResultSet(res4);
			closeResultSet(ress);
			closeStatement(st1);
			closeStatement(st2);
			closeStatement(st3);
			closeStatement(st4);
			closeStatement(st5);
			closeStatement(st6);
			closeStatement(st7);
			closeStatement(sts);
			closeConnection(conn);
		}
		
		return nRet;
	}
	
	
	
	public int updateInProgressOnStart() throws AsyncAdaptorDAOException {
		int nRet = -1;
		
		// params...

		// get data...
		Connection conn = null;
		PreparedStatement st = null;
		try {
			conn = getConnection();
			
			st = conn.prepareStatement(DAOUtils.getInstance().getQueries().getProperty("sql.RESET_IN_PROGRESS_ON_START"));
			
			nRet = st.executeUpdate();
		} catch(Exception e) {
			Constants.LOGGER.log(Level.SEVERE,  this.getClass().getName() + ".updateInProgressOnStart error: " + e.toString());
			throw new AsyncAdaptorDAOException(e);
		} finally {
			closeStatement(st);
			closeConnection(conn);
		}
		
		return nRet;
	}
	
	
	
	public int moveMessageListForProcessingFromHoldBySzKey(String szkey, String holdTableName) throws AsyncAdaptorDAOException {
		int nRet = -1;
		
		// params...

		// get data...
		Connection conn = null;
		PreparedStatement st1 = null;
		PreparedStatement st2 = null;
		PreparedStatement st3 = null;
		PreparedStatement st4 = null;
		PreparedStatement st5 = null;
		PreparedStatement st6 = null;
		PreparedStatement st7 = null;
		try {
			conn = getConnection();
			conn.setAutoCommit(false);
					
			// insert list of records for reprocessing from hold...
			st1 = conn.prepareStatement(DAOUtils.getInstance().getQueries().getProperty("sql.INSERT_MOVE_FOR_REPROCESSING_FROM_HOLD_BY_SZKEY").replaceFirst("~", holdTableName));
			st1.setString(1, szkey);
			nRet = st1.executeUpdate();
					
			// delete from hold table...
			st2 = conn.prepareStatement(DAOUtils.getInstance().getQueries().getProperty("sql.DELETE_MOVE_FOR_REPROCESSING_FROM_HOLD_BY_SZKEY").replaceFirst("~", holdTableName));
			st2.setString(1, szkey);
			nRet = st2.executeUpdate();
						
			conn.commit();
			conn.setAutoCommit(true);
		} catch(Exception e) {
			try {
				conn.rollback();
			} catch(SQLException sqle) {
				Constants.LOGGER.log(Level.SEVERE,  this.getClass().getName() + ".moveMessageListForProcessingFromHoldBySzKey rollback error: " + sqle.toString());
			}
			Constants.LOGGER.log(Level.SEVERE,  this.getClass().getName() + ".moveMessageListForProcessingFromHoldBySzKey error: " + e.toString());
			throw new AsyncAdaptorDAOException(e);
		} finally {
			closeStatement(st1);
			closeStatement(st2);
			closeConnection(conn);
		}
		
		return nRet;
	}
}


