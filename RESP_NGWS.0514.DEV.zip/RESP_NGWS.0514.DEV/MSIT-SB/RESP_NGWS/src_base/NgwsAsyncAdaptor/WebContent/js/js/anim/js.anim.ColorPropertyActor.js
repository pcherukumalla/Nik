/*
****************************************************************************************************
 ezWebToolkit Library, http://www.ezwebtoolkit.com
****************************************************************************************************
Copyright [2006-2008] [Pro Net Systems Inc., http://www.pronetsystems.com]

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

	http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
***************************************************************************************************
*/



// animates a colour based style property between two hex values
js.anim.ColorPropertyActor = function(els, property, from, to) {
	this.els = js.anim.Animator.makeArray(els);
	this.property = js.anim.Animator.camelize(property);
	this.to = this.expandColor(to);
	this.from = this.expandColor(from);
	this.origFrom = from;
	this.origTo = to;

	this.objectType = "js.anim.ColorPropertyActor";
}

js.anim.ColorPropertyActor.prototype = {
	// parse "#FFFF00" to [256, 256, 0]
	expandColor: function(color) {
		var hexColor, red, green, blue;
		hexColor = js.anim.ColorPropertyActor.parseColor(color);
		if (hexColor) {
			red = parseInt(hexColor.slice(1, 3), 16);
			green = parseInt(hexColor.slice(3, 5), 16);
			blue = parseInt(hexColor.slice(5, 7), 16);
			return [red,green,blue]
		}
		if (window.DEBUG) {
			alert("Invalid colour: '" + color + "'");
		}
	},
	getValueForState: function(color, state) {
		return Math.round(this.from[color] + ((this.to[color] - this.from[color]) * state));
	},
	setState: function(state) {
		var color = '#'
				+ js.anim.ColorPropertyActor.toColorPart(this.getValueForState(0, state))
				+ js.anim.ColorPropertyActor.toColorPart(this.getValueForState(1, state))
				+ js.anim.ColorPropertyActor.toColorPart(this.getValueForState(2, state));
		for (var i=0; i<this.els.length; i++) {
			this.els[i].style[this.property] = color;
		}
	},
	inspect: function() {
		return "\t" + this.property + "(" + this.origFrom + " to " + this.origTo + ")\n";
	}
}

// return a properly formatted 6-digit hex colour spec, or false
js.anim.ColorPropertyActor.parseColor = function(string) {
	var color = '#', match;
	if(match = js.anim.ColorPropertyActor.parseColor.rgbRe.exec(string)) {
		var part;
		for (var i=1; i<=3; i++) {
			part = Math.max(0, Math.min(255, parseInt(match[i])));
			color += js.anim.ColorPropertyActor.toColorPart(part);
		}
		return color;
	}
	if (match = js.anim.ColorPropertyActor.parseColor.hexRe.exec(string)) {
		if(match[1].length == 3) {
			for (var i=0; i<3; i++) {
				color += match[1].charAt(i) + match[1].charAt(i);
			}
			return color;
		}
		return '#' + match[1];
	}
	return false;
}
// convert a number to a 2 digit hex string
js.anim.ColorPropertyActor.toColorPart = function(number) {
	if (number > 255) number = 255;
	var digits = number.toString(16);
	if (number < 16) return '0' + digits;
	return digits;
}
js.anim.ColorPropertyActor.parseColor.rgbRe = /^rgb\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)$/i;
js.anim.ColorPropertyActor.parseColor.hexRe = /^\#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/;