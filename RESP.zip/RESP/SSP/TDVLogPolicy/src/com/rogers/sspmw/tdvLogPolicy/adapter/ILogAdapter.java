package com.rogers.sspmw.tdvLogPolicy.adapter;

import java.util.Properties;

import com.rogers.sspmw.tdvLogPolicy.MessageBean;
import com.rogers.sspmw.tdvLogPolicy.exception.TDVException;

public interface ILogAdapter {
	public void initAdapter(Properties properties) throws TDVException;
	public void log(MessageBean message) throws TDVException;
}
