package com.async.engine.common.dao;

public class CommonDAOException extends Exception {
	final private static long serialVersionUID = 1L;
	
	
	
	public CommonDAOException() {
		super();
	}
	
	
	
	public CommonDAOException(String message) {
		super(message);
	}
	
	
	
	public CommonDAOException(String message, Throwable cause) {
		super(message, cause);
	}
	
	
	
	public CommonDAOException(Throwable cause) {
		super(cause);
	}
}
