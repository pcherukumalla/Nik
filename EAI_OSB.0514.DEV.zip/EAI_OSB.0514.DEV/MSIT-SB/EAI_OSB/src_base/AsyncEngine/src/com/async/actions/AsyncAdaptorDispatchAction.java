package com.async.actions;

import java.util.*;
import javax.servlet.http.*;

import org.json.*;
import org.apache.struts.action.*;

import com.async.actions.base.*;
import com.async.dao.base.*;
import com.async.engine.*;
import com.async.services.*;
import com.async.utils.*;



public class AsyncAdaptorDispatchAction extends BaseDispatchAction {
	public ActionForward getProperties(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
        try {
            // get parameters...
        	
            
            // action to do...
        	List types = AsyncAdaptorService.getInstance().getAsyncAdaptorConfigDAO().getMessageTypes();
        	List errors = AsyncAdaptorService.getInstance().getAsyncAdaptorConfigDAO().getErrorMessages();
        	List statuses = AsyncAdaptorService.getInstance().getAsyncAdaptorConfigDAO().getStatuses();
        	
        	// export to JSON...
        	JSONObject json = new JSONObject(AsyncAdaptorService.getInstance().getProps().getProperty("NGWS.SETTINGS"));
        	json.put("types", DAOUtils.getInstance().listToJSONArray(types));
        	json.put("errors", DAOUtils.getInstance().listToJSONArray(errors));
        	json.put("statuses", DAOUtils.getInstance().listToJSONArray(statuses));
        	
        	
        	this.send(response, json);
        } catch(Exception e) {
            e.printStackTrace();
            throw new AsyncAdaptorDispatchException(this.getClass().getName() + ".getProperties error: " + e.toString());
        }
        
        return null;
    }
	
	
	
	public ActionForward refreshConfigurationValues(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
        try {
            // get parameters...
        	
            
            // action to do...
        	String strResult = "OK";
        	try {
	        	AsyncAdaptorEngine.getInstance().refreshConfigurationValues(true);
        	} catch(Exception e2) {
        		strResult = "ERROR: " + e2.toString();
        	}
        	
        	
        	// export to JSON...
        	JSONObject json = new JSONObject();
        	json.put("result", strResult);
        	        	
        	this.send(response, json);
        } catch(Exception e) {
            e.printStackTrace();
            throw new AsyncAdaptorDispatchException(this.getClass().getName() + ".refreshConfigurationValues error: " + e.toString());
        }
        
        return null;
    }
	
	
	
	public ActionForward getStatus(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
        try {
            // get parameters...
        	
            
            // action to do...
        	AsyncAdaptorService service = AsyncAdaptorService.getInstance();
        	AsyncAdaptorEngine engine = AsyncAdaptorEngine.getInstance();
        	
        	// export to JSON...
        	JSONObject jsonConfig = new JSONObject();
        	// configuration values stored by the service only...
        	jsonConfig.put("LAST_TIME_REFRESH_CONFIG_VALUES", Constants.DEFAULT_DATE_FORMAT.format(new Date(service.getLastConfigValuesRefreshTime())));
        	jsonConfig.put("ACTIVE_SERVER_NAME", service.getValue("ACTIVE_SERVER_NAME"));
        	jsonConfig.put("DISPATCH_TO_PROCESS_INPUT_MESSAGE_VIA_JMS", service.getValue("DISPATCH_TO_PROCESS_INPUT_MESSAGE_VIA_JMS"));
        	jsonConfig.put("JNDI_INITIAL_CONTEXT", service.getValue("JNDI_INITIAL_CONTEXT"));
        	jsonConfig.put("TEMP_JMS_CONNECTION_FACTORY", service.getValue("TEMP_JMS_CONNECTION_FACTORY"));
        	jsonConfig.put("TEMP_JMS_QUEUE", service.getValue("TEMP_JMS_QUEUE"));
        	// configuration values stored in the engine itself...
        	jsonConfig.put("ASYNC_ADAPTOR_ENGINE_RUN_INTERVAL", engine.getRunInterval());
        	jsonConfig.put("MAX_NR_OF_RECORDS_FOR_PROCESSING", engine.getMaxNrOfRecsInProcessingTable());
        	
        	JSONObject json = new JSONObject();
        	// engine status...
        	json.put("ENGINE_ID", engine.getId());
        	json.put("IS_ALIVE", engine.isAlive());
        	json.put("IS_INTERRUPTED", engine.isInterrupted());
        	json.put("IS_ACTIVE", engine.isActive());
        	json.put("IS_PAUSED", engine.isPaused());
        	json.put("IS_PROCESSING", engine.isProcessing());
        	json.put("NR_OF_TOTAL_CYCLES", engine.getNrOfCycles());
        	json.put("CYCLE_MESSAGE_LIST_SIZE", engine.getCurrentMessageListSize());
        	json.put("CYCLE_GET_MESSAGE_LIST_DURATION", engine.getGetCurrentMessageListDuration());
        	json.put("CYCLE_GET_MESSAGE_LIST_IN_PROGRESS", engine.getGetCurrentMessageListInProgress());
        	json.put("CYCLE_ERROR", engine.getCurrentCycleError());
        	json.put("CYCLE_START_TIME", Constants.DEFAULT_DATE_FORMAT.format(new Date(engine.getCurrentCycleStartTime())));
        	json.put("CYCLE_FIRST_MESSAGE_ID", engine.getCurrentCycleFirstMessageId());
        	// configuration values...
        	json.put("config", jsonConfig);
        	// main tables...
        	json.put("mainTables", DAOUtils.getInstance().listToJSONArray(service.getAsyncAdaptorConfigDAO().getMainTables()));
        	// types...
        	json.put("messageTypes", DAOUtils.getInstance().listToJSONArray(service.getAsyncAdaptorConfigDAO().getMessageTypes()));
        	// SQLs...
        	json.put("processSQLs", DAOUtils.getInstance().listToJSONArray(service.getAsyncAdaptorConfigDAO().getProcessSQLs()));
        	// errors...
        	json.put("errors", DAOUtils.getInstance().listToJSONArray(service.getAsyncAdaptorConfigDAO().getErrorMessages()));
        	// error descriptions...
        	json.put("errorDescriptions", DAOUtils.getInstance().listToJSONArray(service.getAsyncAdaptorConfigDAO().getErrorDescriptions()));
        	// statuses...
        	json.put("statuses", DAOUtils.getInstance().listToJSONArray(service.getAsyncAdaptorConfigDAO().getStatuses()));
        	        	
        	        	
        	this.send(response, json);
        } catch(Exception e) {
            e.printStackTrace();
            throw new AsyncAdaptorDispatchException(this.getClass().getName() + ".getStatus error: " + e.toString());
        }
        
        return null;
    }
	
	
	
	public ActionForward stop(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
        try {
            // get parameters...
        	
            
            // action to do...
        	String strResult = "";
        	try {
	        	AsyncAdaptorEngine engine = AsyncAdaptorEngine.getInstance();
	        		        	
	        	if(engine.isActive()) {
	        		engine.setActive(false);
	        		
	        		strResult = "OK";
	        	} else {
	        		strResult = "Engine already stopped.";
	        	}
        	} catch(Exception e2) {
        		strResult = "ERROR: " + e2.toString();
        	}
        	
        	
        	// export to JSON...
        	JSONObject json = new JSONObject();
        	json.put("result", strResult);
        	        	
        	this.send(response, json);
        } catch(Exception e) {
            e.printStackTrace();
            throw new AsyncAdaptorDispatchException(this.getClass().getName() + ".stop error: " + e.toString());
        }
        
        return null;
    }
	
	
	
	public ActionForward start(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
        try {
            // get parameters...
        	
            
            // action to do...
        	String strResult = "";
        	try {
	        	AsyncAdaptorEngine engine = AsyncAdaptorEngine.getInstance();
	        		        	
	        	if(!engine.isActive() && !engine.isAlive()) {
	        		AsyncAdaptorEngine.cleanUp();
	        		
	        		AsyncAdaptorEngine.getInstance().start();
	        		
	        		strResult = "OK";
	        	} else {
	        		strResult = "Can not start the engine because current instance is active/alive.";
	        	}
        	} catch(Exception e2) {
        		strResult = "ERROR: " + e2.toString();
        	}
        	
        	
        	// export to JSON...
        	JSONObject json = new JSONObject();
        	json.put("result", strResult);
        	        	
        	this.send(response, json);
        } catch(Exception e) {
            e.printStackTrace();
            throw new AsyncAdaptorDispatchException(this.getClass().getName() + ".start error: " + e.toString());
        }
        
        return null;
    }
	
	
	
	public ActionForward pause(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
        try {
            // get parameters...
        	
            
            // action to do...
        	String strResult = "";
        	try {
	        	AsyncAdaptorEngine engine = AsyncAdaptorEngine.getInstance();

        		if(!engine.isPaused()) {
        			engine.setPaused(true);
	        		
	        		strResult = "OK";
	        	} else {
	        		strResult = "Engine already paused.";
	        	}
        	} catch(Exception e2) {
        		strResult = "ERROR: " + e2.toString();
        	}
        	
        	
        	// export to JSON...
        	JSONObject json = new JSONObject();
        	json.put("result", strResult);
        	        	
        	this.send(response, json);
        } catch(Exception e) {
            e.printStackTrace();
            throw new AsyncAdaptorDispatchException(this.getClass().getName() + ".pause error: " + e.toString());
        }
        
        return null;
    }
	
	
	
	public ActionForward resume(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
        try {
            // get parameters...
        	
            
            // action to do...
        	String strResult = "";
        	try {
	        	AsyncAdaptorEngine engine = AsyncAdaptorEngine.getInstance();

        		if(engine.isPaused()) {
        			engine.setPaused(false);
	        		
	        		strResult = "OK";
	        	} else {
	        		strResult = "Engine already resumed.";
	        	}
        	} catch(Exception e2) {
        		strResult = "ERROR: " + e2.toString();
        	}
        	
        	
        	// export to JSON...
        	JSONObject json = new JSONObject();
        	json.put("result", strResult);
        	        	
        	this.send(response, json);
        } catch(Exception e) {
            e.printStackTrace();
            throw new AsyncAdaptorDispatchException(this.getClass().getName() + ".resume error: " + e.toString());
        }
        
        return null;
    }
	
	
	
	// http://localhost:9082/AsyncAdaptor/aa.do?cmd=moveForProcessingFromHoldBySzKey&k=230123456781&h=ASYNC_RTY_MSGS_HOLD
	public ActionForward moveForProcessingFromHoldBySzKey(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
        try {
            // get parameters...
        	String strSzKey = request.getParameter("k");
        	String strHoldTableName = request.getParameter("h");
        	
            
            // action to do...
        	String strResult = "";
        	try {
	        	AsyncAdaptorService.getInstance().getAsyncAdaptorDAO().moveMessageListForProcessingFromHoldBySzKey(strSzKey, strHoldTableName);
	        	
	        	strResult = "OK";
        	} catch(Exception e2) {
        		strResult = "ERROR: " + e2.toString();
        	}
        	
        	
        	// export to JSON...
        	JSONObject json = new JSONObject();
        	json.put("result", strResult);
        	        	
        	this.send(response, json);
        } catch(Exception e) {
            e.printStackTrace();
            throw new AsyncAdaptorDispatchException(this.getClass().getName() + ".reprocessFromHoldBySzKey error: " + e.toString());
        }
        
        return null;
    }
}


