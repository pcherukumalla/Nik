/*
****************************************************************************************************
 ezWebToolkit Library, http://ezwt.blogspot.com
****************************************************************************************************
Copyright [2006-2008] [Pro Net Systems Inc., http://www.pronetsystems.com]

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

	http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
***************************************************************************************************
*/



/*
------------------------------------------------------------------------------------------
Form
------------------------------------------------------------------------------------------
*/
js.wtc.Form = function() {
	js.wtc.ContentPanel.call(this);

	this.objectType = "js.wtc.Form";
}
js.wtc.Form.prototype = new js.wtc.ContentPanel();
js.wtc.Form.prototype.constructor = js.wtc.Form;



js.wtc.Form.prototype.init = function() {
	// create the main div...
	this.theViewport = document.createElement("FORM");
	
	// instrument the new node...
	this.instrumentViewport();
}



js.wtc.Form.prototype.submit = function() {
	this.viewport().submit();
}



js.wtc.Form.prototype.set = function(name, value) {
	if(name == "action") {
		this.viewport().action = value;
	} else if(name == "enctype") {
		this.viewport().enctype = value;
	} else if(name == "method") {
		this.viewport().method = value;
	} else if(name == "name") {
		this.viewport().name = value;
	} else if(name == "target") {
		this.viewport().target = value;
	} else {
		js.wtc.ContentPanel.prototype.set.call(this, name, value);
	}
}



js.wtc.Form.prototype.get = function(name) {
	if(name == "action") {
		return this.viewport().action;
	} else if(name == "enctype") {
		return this.viewport().enctype;
	} else if(name == "method") {
		return this.viewport().method;
	} else if(name == "name") {
		return this.viewport().name;
	} else if(name == "target") {
		return this.viewport().target;
	} else {
		return js.wtc.ContentPanel.prototype.get.call(this, name);
	}
}
