package com.rogers.rci.wsl;

import java.rmi.RemoteException;
import javax.ejb.CreateException;
import javax.ejb.EJBHome;

public abstract interface SamServicesEJBFacadeRemoteHome extends EJBHome
{
  public abstract SamServicesEJBFacadeRemote create()
    throws CreateException, RemoteException, CreateException;
}