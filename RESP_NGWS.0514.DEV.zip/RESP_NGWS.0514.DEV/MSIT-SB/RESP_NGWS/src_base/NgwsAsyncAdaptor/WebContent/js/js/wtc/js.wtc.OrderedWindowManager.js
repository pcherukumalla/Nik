/*
****************************************************************************************************
 ezWebToolkit Library, http://ezwt.blogspot.com
****************************************************************************************************
Copyright [2006-2008] [Pro Net Systems Inc., http://www.pronetsystems.com]

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

	http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
***************************************************************************************************
*/



/*
------------------------------------------------------------------------------------------
OrderedWindowManager
------------------------------------------------------------------------------------------
*/
js.wtc.OrderedWindowManager = function() {
	this.descendents = new Array();

	this.left = null;
	this.top = null;
	this.spacing = null;
	this.direction = "x";
	this.showIn = false;
	this.cover = null;

	this.objectType = "js.wtc.OrderedWindowManager";
}



js.wtc.OrderedWindowManager.prototype.init = function() {
	this.cover = new js.wtc.ContentPanel();
	this.cover.init();
	this.cover.set("border", "1px dotted #AFAFAF");
}



js.wtc.OrderedWindowManager.prototype.append = function(o) {
	if(this.direction == "x") {
		o.set("top", this.top);
		o.set("left", "60000px");
	} else {
		o.set("left", this.left);
		o.set("top", "60000px");
	}

	this.descendents.push(o);
	o.manager = this;

	if(this.showIn) {
		o.show();
	}
}



js.wtc.OrderedWindowManager.prototype.remove = function(o) {
	var nIndex = -1;
	for(var i = 0; i < this.descendents.length; i++) {
		if(o == this.descendents[i]) {
			nIndex = i;
		}
	}

	if(nIndex > -1) {
		for(var i = nIndex; i < this.descendents.length; i++) {
			this.descendents[i] = this.descendents[i + 1];
		}

		this.descendents.pop();

		if(o.get("showIn")) {
			o.hide();
		}
	}
}



js.wtc.OrderedWindowManager.prototype.show = function() {
	for(var i = 0; i < this.descendents.length; i++) {
		this.descendents[i].show();
	}

	this.showIn = true;
}



js.wtc.OrderedWindowManager.prototype.hide = function() {
	for(var i = 0; i < this.descendents.length; i++) {
		this.descendents[i].hide();
	}

	this.showIn = false;
}



js.wtc.OrderedWindowManager.prototype.reorder = function() {
	var aux = null;
	var bReorder = false;
	do {
		bReorder = false;

		for(var i = 0; i < this.descendents.length - 1; i++) {
			if(this.direction == "x") {
				if(parseInt(this.descendents[i+1].get("left")) < parseInt(this.descendents[i].get("left"))) {
					aux = this.descendents[i+1];
					this.descendents[i+1] =  this.descendents[i];
					this.descendents[i] = aux;
					bReorder = true;
				}
			} else {
				if(parseInt(this.descendents[i+1].get("top")) < parseInt(this.descendents[i].get("top"))) {
					aux = this.descendents[i+1];
					this.descendents[i+1] =  this.descendents[i];
					this.descendents[i] = aux;
					bReorder = true;
				}
			}
		}
	} while(bReorder);
}



js.wtc.OrderedWindowManager.prototype.recalc = function() {
	var size = 0;
	
	if(this.direction == "x") {
		size += parseInt(this.left);
	} else {
		size += parseInt(this.top);
	}

	for(var i = 0; i < this.descendents.length; i++) {
		if(this.descendents[i].get("showIn")) {
			if(this.direction == "x") {
				this.descendents[i].set("left", size + "px");
				size += parseInt(this.descendents[i].get("width")) + parseInt(this.spacing);
			} else {
				this.descendents[i].set("top", size + "px");
				size += parseInt(this.descendents[i].get("height")) + parseInt(this.spacing);
			}
		}
	}
}



js.wtc.OrderedWindowManager.prototype.onDragStart = function(o) {
	this.cover.set("left", o.get("left"));
	this.cover.set("top", o.get("top"));
	this.cover.set("width", o.get("width"));
	this.cover.set("height", o.get("height"));
	this.cover.show();
}



js.wtc.OrderedWindowManager.prototype.onDragEnd = function(o) {
	if(this.direction == "x") {
		o.set("top", this.top);
	} else {
		o.set("left", this.left);
	}

	this.reorder();
	this.recalc();
	this.cover.hide();
}



js.wtc.OrderedWindowManager.prototype.set = function(name, value) {
	if(name == "left") {
		this.left = value;

		if(this.direction == "y") {
			for(var i = 0; i < this.descendents.length; i++) {
				this.descendents[i].set("left", this.left);
			}
		}
	} else if(name == "top") {
		this.top = value;

		if(this.direction == "x") {
			for(var i = 0; i < this.descendents.length; i++) {
				this.descendents[i].set("top", this.top);
			}
		}
	} else if(name == "direction") { // before init...
		this.direction = value;
	} else if(name == "spacing") {
		this.spacing = value;

		this.recalc();
	}
}



js.wtc.OrderedWindowManager.prototype.get = function(name) {
	if(name == "left") {
		return this.left;
	} else if(name == "top") {
		return this.top;
	} else if(name == "direction") {
		return this.direction;
	} else if(name == "spacing") {
		return this.spacing;
	} else if(name == "showIn") {
		return this.showIn;
	}
}
