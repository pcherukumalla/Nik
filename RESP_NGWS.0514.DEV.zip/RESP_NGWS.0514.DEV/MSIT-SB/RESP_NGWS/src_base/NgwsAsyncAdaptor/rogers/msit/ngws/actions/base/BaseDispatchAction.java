package com.rogers.msit.ngws.actions.base;

import java.io.*;
import javax.servlet.http.*;

import org.json.*;
import org.apache.struts.actions.*;



public class BaseDispatchAction extends DispatchAction {
	public void send(HttpServletResponse response, JSONObject json) throws Exception {
		response.setContentType("text/plain;charset=UTF-8");
		
    	PrintWriter pw = response.getWriter();
    	json.write(pw);
    	pw.close();
	}
	
	
	
	public void sendText(HttpServletResponse response, String text) throws Exception {
		response.setContentType("text/plain;charset=UTF-8");
		
    	PrintWriter pw = response.getWriter();
    	pw.println(text);
    	pw.close();
	}
	
	
	
	public void sendXml(HttpServletResponse response, String text) throws Exception {
		response.setContentType("text/xml;charset=UTF-8");
		
    	PrintWriter pw = response.getWriter();
    	pw.println(text);
    	pw.close();
	}
}