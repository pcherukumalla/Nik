/*
****************************************************************************************************
 ezWebToolkit Library, http://ezwt.blogspot.com
****************************************************************************************************
Copyright [2006-2008] [Pro Net Systems Inc., http://www.pronetsystems.com]

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

	http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
***************************************************************************************************
*/



/*
------------------------------------------------------------------------------------------
TreePanel
------------------------------------------------------------------------------------------
*/
js.wtc.TreePanel = function() {
	js.wtc.ContentPanel.call(this);

	this.highlightIn = true;
	this.theOPTION = null;

	this.elemImage = js.IMAGES_PATH + "elem.gif";
	this.openedImage = js.IMAGES_PATH + "opened.gif";
	this.closedImage = js.IMAGES_PATH + "closed.gif";

	this.objectType = "js.wtc.TreePanel";
}
js.wtc.TreePanel.prototype = new js.wtc.ContentPanel();
js.wtc.TreePanel.prototype.constructor = js.wtc.TreePanel;



js.wtc.TreePanel.prototype.highlightOption = function(id) {
	if(this.theOPTION != null) {
		var txt = document.getElementById("div_ezView_treeopt_txt" + this.index + "_" + this.theOPTION);
		txt.style.backgroundColor = "";
		txt.style.color = "black";
	}

	var txt = document.getElementById("div_ezView_treeopt_txt" + this.index + "_" + id);
	txt.style.backgroundColor = "navy";
	txt.style.color = "white";

	this.theOPTION = id;
}



js.wtc.TreePanel.prototype.expandOption = function(id) {
	var opt = document.getElementById("div_ezView_treeopt" + this.index + "_" + id);
	var lst = opt.childNodes;
	for(var i = 0; i < lst.length; i++) {
		if((lst.item(i).tagName == "SPAN") && (lst.item(i).getAttribute("objectId") != null)) {
			lst.item(i).style.display = "block";
		}
	}

	var img = document.getElementById("div_ezView_treeopt_img" + this.index + "_" + id);
	img.src = this.openedImage;
	img.title = "collapse";

	opt.setAttribute("collapsed", "false");

	// expand backwards to the root...
	while(opt.parentNode.id != "div_ezView" + this.index) {
		this.expandOption(opt.parentNode.getAttribute("objectId"));

		opt = opt.parentNode;
	}
}



js.wtc.TreePanel.prototype.collapseOption = function(id) {
	var opt = document.getElementById("div_ezView_treeopt" + this.index + "_" + id);
	var lst = opt.childNodes;
	for(var i = 0; i < lst.length; i++) {
		if((lst.item(i).tagName == "SPAN") && (lst.item(i).getAttribute("objectId") != null)) {
			lst.item(i).style.display = "none";
		}
	}

	var img = document.getElementById("div_ezView_treeopt_img" + this.index + "_" + id);
	img.src = this.closedImage;
	img.title = "expand";

	opt.setAttribute("collapsed", "true");
}



js.wtc.TreePanel.prototype.switchOption = function(id) {
	var opt = document.getElementById("div_ezView_treeopt" + this.index + "_" + id);
	if(opt.getAttribute("collapsed") == "true") {
		this.expandOption(id);
	} else {
		this.collapseOption(id);
	}
}



js.wtc.TreePanel.prototype.removeOption = function(id) {
	var opt = document.getElementById("div_ezView_treeopt" + this.index + "_" + id);
	var parentOpt = opt.parentNode;

	parentOpt.removeChild(opt);
}



js.wtc.TreePanel.prototype.addOption = function(o, id) {
	var SELF = this;

	var opt = document.createElement("SPAN");
	opt.id = "div_ezView_treeopt" + this.index + "_" + o.id;
	opt.style.cursor = "pointer";
	
	// set title...
	if(o.title != null) {
		opt.title = o.title;
	}

	// set inner HTML...
	if(o.imageSrc == null) {
		opt.innerHTML = "<img id=\"div_ezView_treeopt_img" + this.index + "_" + o.id + "\" src=\"" + this.elemImage + "\">&nbsp;<span id=\"div_ezView_treeopt_txt" + this.index + "_" + o.id + "\">" + o.name + "</span>";
	} else {
		opt.innerHTML = "<img id=\"div_ezView_treeopt_img" + this.index + "_" + o.id + "\" src=\"" + o.imageSrc + "\">&nbsp;<span id=\"div_ezView_treeopt_txt" + this.index + "_" + o.id + "\">" + o.name + "</span>";
	}

	// set attributes...
	opt.setAttribute("collapsed", "true");
	opt.setAttribute("hasChildren", "false");
	opt.setAttribute("objectId", o.id);

	if(o.action != null) {
		js.wtc.Manager.addEventListener(opt, "onclick", o.action);
	}

	if(id) {
		opt.style.marginLeft = "15px";
		opt.style.display = "none";

		var parentOpt = document.getElementById("div_ezView_treeopt" + this.index + "_" + id);
		parentOpt.appendChild(opt);

		if(parentOpt.getAttribute("hasChildren") == "false") {
			var parentOptImg = document.getElementById("div_ezView_treeopt_img" + this.index + "_" + id);
			parentOptImg.src = this.closedImage;
			parentOptImg.title = "expand";

			parentOptImg.onclick = function(e) {
				SELF.switchOption(id);

				// prevent propagation...
				js.wtc.Manager.preventEventPropagation(e);
			}

			parentOpt.setAttribute("hasChildren", "true");
		}
	} else {
		opt.style.display = "block";

		this.viewport().appendChild(opt);
	}

	if(this.highlightIn) {
		var txt = document.getElementById("div_ezView_treeopt_txt" + this.index + "_" + o.id);

		js.wtc.Manager.addEventListener(txt, "onclick", function(){SELF.highlightOption(o.id)});
	}
}



js.wtc.TreePanel.prototype.addEventListener = function(id, evtname, act) {
	var txt = document.getElementById("div_ezView_treeopt_txt" + this.index + "_" + id);
	js.wtc.Manager.addEventListener(txt, evtname, act);
}



js.wtc.TreePanel.prototype.setEventListener = function(id, evtname, act) {
	var txt = document.getElementById("div_ezView_treeopt_txt" + this.index + "_" + id);
	js.wtc.Manager.setEventListener(txt, evtname, act);
}



js.wtc.TreePanel.prototype.setOption = function(id, name, value) {
	var opt = document.getElementById("div_ezView_treeopt" + this.index + "_" + id);
	var img = document.getElementById("div_ezView_treeopt_img" + this.index + "_" + id);
	var txt = document.getElementById("div_ezView_treeopt_txt" + this.index + "_" + id);
	
	if(name == "name") {
		txt.innerHTML = value;
	} else if(name == "title") {
		opt.title = value;
	} else if(name == "imageSrc") {
		img.src = value;
	} else {
		eval("opt.style." + name + " = \"" + value + "\"");
	}
}



js.wtc.TreePanel.prototype.set = function(name, value) {
	if(name == "highlightIn") { // before init...
		this.highlightIn = value;
	} else if(name == "elemImage") { // before init...
		this.elemImage = value;
	} else if(name == "openedImage") { // before init...
		this.openedImage = value;
	} else if(name == "closedImage") { // before init...
		this.closedImage = value;
	} else {
		js.wtc.ContentPanel.prototype.set.call(this, name, value);
	}
}
