package com.rogers.eaiosb.aync;

import com.async.engine.common.services.AsyncAdaptorService;


public class AyncReaderUtils extends AsyncReaderBase
{
	public static void processMessage(javax.jms.Message msg)
		throws Exception
	{
		String msgReceived = null;
		//long startTime = System.currentTimeMillis();

		if (msg instanceof javax.jms.TextMessage)
		{
			javax.jms.TextMessage textMessage = (javax.jms.TextMessage) msg;
			msgReceived = textMessage.getText();
		}
		if (msg instanceof javax.jms.BytesMessage)
		{
		    javax.jms.BytesMessage textMessage = (javax.jms.BytesMessage) msg;
		    byte[] bytes = new byte[(int) textMessage.getBodyLength()];
		    textMessage.readBytes(bytes);

		    msgReceived = new String(bytes, "UTF-8");
		}

		AsyncAdaptorService.push( getOpType( msg ),getSzKey( msg ), getCustomizedMsg(msg, msgReceived)  );
		//System.out.println(new StringBuffer("Pushed to DB: ").append( "" + msg.getJMSMessageID() ).toString());

		//System.out.println("Send:" + getOpType( msg ) + getSzKey( msg ) + getCustomizedMsg(msg, msgReceived));

		//System.out.println( "Duration: " + (System.currentTimeMillis() - startTime));
		//java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss SSS");
		//System.out.println( "Now is: " + sdf.format( java.util.Calendar.getInstance().getTime() ));
	}

	private static String getOpType( javax.jms.Message msg )
		throws Exception
	{
		String opType = "" + msg.getStringProperty( MSGTYPE_FLAG );
		return opType;
	}

	private static String getSzKey( javax.jms.Message msg )
		throws Exception
	{
		String szKey = "" + msg.getStringProperty( BLOCK_KEY_FLAG );
		String returnVal = (szKey != null ? szKey.trim() : "");
		return returnVal;
	}

	private static String getCustomizedMsg(javax.jms.Message msg, String txtMessage )
		throws Exception
	{
		int poz=-1;
		StringBuffer tmpBuff = new StringBuffer("");
		String jmsCorrelationId = msg.getJMSCorrelationID()!= null ? msg.getJMSCorrelationID() : "" ;
		String msgCorrelationList = "" + msg.getStringProperty( MSG_CORRELATION_LIST_FLAG );

		//System.out.println( "jmsCorrelationId: " + jmsCorrelationId);
		//System.out.println( "msgCorrelationList: " + msgCorrelationList);
		String tmp = null;

		String[] msgCorrelationListElement	= msgCorrelationList.split( DELIMITER );
		//add message to customized message
		tmp = XMLWrapperConstants.MSG_NODE.replace(XMLWrapperConstants.DELIMITER, txtMessage);
		tmpBuff.append( tmp );

		//add correlation id to customized message
		tmp = XMLWrapperConstants.ELEMENT_NODE.replace(XMLWrapperConstants.ELEMENT_DELIMITER ,JMS_CORRELATION_FLAG);
		tmp=tmp.replace(XMLWrapperConstants.DELIMITER, jmsCorrelationId );
		tmpBuff.append( tmp );
		//add additional elements from correlation list to customized message
		for ( int count = 0; (!"".equalsIgnoreCase( msgCorrelationList.trim() )) && count < msgCorrelationListElement.length; count ++ )
		{
		      poz = msgCorrelationListElement[ count ].indexOf("=");
		      tmp = XMLWrapperConstants.ELEMENT_NODE.replace(XMLWrapperConstants.ELEMENT_DELIMITER ,msgCorrelationListElement[ count ].substring(0,poz).trim()).replace(XMLWrapperConstants.DELIMITER, msgCorrelationListElement[ count ].substring(poz+1).trim() + "");
		      tmpBuff.append( tmp );
		}

		//final value:
		tmp = XMLWrapperConstants.ROOT_NODE.replace(XMLWrapperConstants.DELIMITER, tmpBuff.toString() );
		//System.out.println( "Sync back correlation details: " + tmp);
		return tmp;
	}
}
