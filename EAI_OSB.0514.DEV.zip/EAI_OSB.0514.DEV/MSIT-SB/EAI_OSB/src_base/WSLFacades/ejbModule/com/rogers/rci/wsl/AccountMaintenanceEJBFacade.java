package com.rogers.rci.wsl;

import javax.ejb.SessionBean;

import weblogic.ejb.GenericSessionBean;
import weblogic.ejbgen.Session;
import weblogic.ejbgen.JndiName;
import weblogic.ejbgen.FileGeneration;
import weblogic.ejbgen.Constants;
import weblogic.ejbgen.RemoteMethod;

import com.rogers.rci.wsl.WSLLogger;

import com.rogers.wireless.schemas.applyOneTimeCharge.request.ApplyOneTimeChargeRequestDocument;
import com.rogers.wireless.schemas.applyOneTimeCharge.response.ApplyOneTimeChargeResponseDocument;
import com.rogers.wireless.schemas.makeOneTimePayment.request.MakeOneTimePaymentRequestDocument;
import com.rogers.wireless.schemas.makeOneTimePayment.response.MakeOneTimePaymentResponseDocument;
import com.rogers.wireless.schemas.retrieveBanInfo.request.RetrieveBanInfoRequestDocument;
import com.rogers.wireless.schemas.retrieveBanInfo.response.RetrieveBanInfoResponseDocument;
import com.rogers.wireless.schemas.retrieveBanSubscribers.request.RetrieveBanSubscribersRequestDocument;
import com.rogers.wireless.schemas.retrieveBanSubscribers.response.RetrieveBanSubscribersResponseDocument;
import com.rogers.wireless.schemas.retrieveCreditEvaluation.request.RetrieveCreditEvaluationRequestDocument;
import com.rogers.wireless.schemas.retrieveCreditEvaluation.response.RetrieveCreditEvaluationResponseDocument;
import com.rogers.wireless.schemas.updateBanInfo.request.UpdateBanInfoRequestDocument;
import com.rogers.wireless.schemas.updateBanInfo.response.UpdateBanInfoResponseDocument;
import com.rogers.wireless.schemas.updateCreditEvaluation.request.UpdateCreditEvaluationRequestDocument;
import com.rogers.wireless.schemas.updateCreditEvaluation.response.UpdateCreditEvaluationResponseDocument;
import com.rogers.wireless.schemas.retrieveCustomerBalance.request.RetrieveCustomerBalanceRequestDocument;
import com.rogers.wireless.schemas.retrieveCustomerBalance.response.RetrieveCustomerBalanceResponseDocument;
import com.rogers.wireless.schemas.addAndDeleteBillingAddressParameters.request.AddAndDeleteBillingAddressParametersRequestDocument;
import com.rogers.wireless.schemas.addAndDeleteBillingAddressParameters.response.AddAndDeleteBillingAddressParametersResponseDocument;
import com.rogers.wireless.schemas.adjustBan.request.AdjustBanRequestDocument;
import com.rogers.wireless.schemas.adjustBan.response.AdjustBanResponseDocument;
import com.rogers.wireless.schemas.createMemo.request.CreateMemoRequestDocument;
import com.rogers.wireless.schemas.createMemo.response.CreateMemoResponseDocument;
import com.rogers.wireless.schemas.modifyBillingAddressParameters.request.ModifyBillingAddressParametersRequestDocument;
import com.rogers.wireless.schemas.modifyBillingAddressParameters.response.ModifyBillingAddressParametersResponseDocument;
import com.rogers.wireless.schemas.performDuplicateCheck.request.PerformDuplicateCheckRequestDocument;
import com.rogers.wireless.schemas.performDuplicateCheck.response.PerformDuplicateCheckResponseDocument;
import com.rogers.wireless.schemas.retrieveAvailableBanPricePlans.request.RetrieveAvailableBanPricePlansRequestDocument;
import com.rogers.wireless.schemas.retrieveAvailableBanPricePlans.response.RetrieveAvailableBanPricePlansResponseDocument;
import com.rogers.wireless.schemas.retrieveAvailableBillCycleList.request.RetrieveAvailableBillCycleListRequestDocument;
import com.rogers.wireless.schemas.retrieveAvailableBillCycleList.response.RetrieveAvailableBillCycleListResponseDocument;
import com.rogers.wireless.schemas.retrieveBalances.request.RetrieveBalancesRequestDocument;
import com.rogers.wireless.schemas.retrieveBalances.response.RetrieveBalancesResponseDocument;
import com.rogers.wireless.schemas.retrieveBanServices.request.RetrieveBanServicesRequestDocument;
import com.rogers.wireless.schemas.retrieveBanServices.response.RetrieveBanServicesResponseDocument;
import com.rogers.wireless.schemas.retrieveBillList.request.RetrieveBillListRequestDocument;
import com.rogers.wireless.schemas.retrieveBillList.response.RetrieveBillListResponseDocument;
import com.rogers.wireless.schemas.retrieveBilledCharges.request.RetrieveBilledChargesRequestDocument;
import com.rogers.wireless.schemas.retrieveBilledCharges.response.RetrieveBilledChargesResponseDocument;
import com.rogers.wireless.schemas.retrieveBillingAddressParameters.request.RetrieveBillingAddressParametersRequestDocument;
import com.rogers.wireless.schemas.retrieveBillingAddressParameters.response.RetrieveBillingAddressParametersResponseDocument;
import com.rogers.wireless.schemas.retrieveFirstBillEstimate.request.RetrieveFirstBillEstimateRequestDocument;
import com.rogers.wireless.schemas.retrieveFirstBillEstimate.response.RetrieveFirstBillEstimateResponseDocument;
import com.rogers.wireless.schemas.retrieveLastPayment.request.RetrieveLastPaymentRequestDocument;
import com.rogers.wireless.schemas.retrieveLastPayment.response.RetrieveLastPaymentResponseDocument;
import com.rogers.wireless.schemas.retrieveEnhancedProductLevelServices.request.RetrieveEnhancedProductLevelServicesRequestDocument;
import com.rogers.wireless.schemas.retrieveEnhancedProductLevelServices.response.RetrieveEnhancedProductLevelServicesResponseDocument;
import com.rogers.wireless.schemas.submitEnhancedProductLevelServices.request.SubmitEnhancedProductLevelServicesRequestDocument;
import com.rogers.wireless.schemas.submitEnhancedProductLevelServices.response.SubmitEnhancedProductLevelServicesResponseDocument;

import com.rogers.wireless.schemas.retrieveMemos.request.RetrieveMemosRequestDocument;
import com.rogers.wireless.schemas.retrieveMemos.response.RetrieveMemosResponseDocument;
import com.rogers.wireless.schemas.serviceRequest.ServiceResponseDocument;
import com.rogers.wireless.schemas.updateCreditClass.request.UpdateCreditClassRequestDocument;
import com.rogers.wireless.schemas.retrievePaymentHistory.request.RetrievePaymentHistoryRequestDocument;
import com.rogers.wireless.schemas.retrievePaymentHistory.response.RetrievePaymentHistoryResponseDocument;
import com.rogers.wireless.schemas.retrieveEbppInfo.request.RetrieveEbppInfoRequestDocument;
import com.rogers.wireless.schemas.retrieveEbppInfo.response.RetrieveEbppInfoResponseDocument;

/**
 * GenericSessionBean subclass automatically generated by Workshop.
 *
 * Please complete the ejbCreate method as needed to properly initialize new instances of your bean and add
 * all required business methods. Also, review the Session, JndiName and FileGeneration annotations 
 * to ensure the settings match the bean's intended use.
 */
@Session(ejbName = "AccountMaintenanceEJBFacade", initialBeansInFreePool="4", maxBeansInFreePool="10", transTimeoutSeconds="30", isClusterable=Constants.Bool.FALSE, methodsAreIdempotent=Constants.Bool.FALSE)
@JndiName(remote = "ejb/wsl/AccountMaintenanceEJBFacadeRemoteHome")
@FileGeneration(remoteClass = Constants.Bool.TRUE, remoteHome = Constants.Bool.TRUE, localClass = Constants.Bool.FALSE, localHome = Constants.Bool.FALSE)
public class AccountMaintenanceEJBFacade extends GenericSessionBean implements
		SessionBean {

	/* (non-Javadoc)
	 * @see weblogic.ejb.GenericSessionBean#ejbCreate()
	 */
	public void ejbCreate() {
		// IMPORTANT: Add your code here
	}
	

	// IMPORTANT: Add business methods
	   //TODO: IMPLEMENT NEW SOLUTION for ICMHelper controls in each facade!
		//DONE: implemented at OSB facade level
	   /**
	    //private com.rogers.rci.icm.AccountMaintenanceICMHelper acctMaintICMHelper;
	    */
	    
	    static final long serialVersionUID = 1L;

	    /**

	     */
	    @RemoteMethod()
	    public org.apache.xmlbeans.XmlObject retrieveBanSubscribers(  org.apache.xmlbeans.XmlObject xmldata )
	    	    throws Exception
	    {
	        WSLLogger.getLogger().info( "WSL: AccountMaintenanceImpl.retrieveBanSubscribers()" );
	        long startTime = System.currentTimeMillis();
	        
	        RetrieveBanSubscribersResponseDocument response = com.rogers.rci.wsl.services.accountmaintenance.RetrieveBanSubscribers.subscriberListByBan( RetrieveBanSubscribersRequestDocument.Factory.parse( xmldata.xmlText() ));
	        WSLLogger.getLogger().info("WSL: AccountMaintenanceImpl.retrieveBanSubscribers() duration: " + (System.currentTimeMillis() - startTime));
	        
			return response;
	    }

	    /**

	     */
	    @RemoteMethod()
	    public org.apache.xmlbeans.XmlObject applyOneTimeCharge(  org.apache.xmlbeans.XmlObject xmldata )
	    	    throws Exception
	    {
	        WSLLogger.getLogger().info( "WSL: AccountMaintenanceImpl.applyOneTimeCharge()" );
	        long startTime = System.currentTimeMillis();

	        ApplyOneTimeChargeResponseDocument response = com.rogers.rci.wsl.services.accountmaintenance.ApplyOneTimeCharge.applyOneTimeCharge( ApplyOneTimeChargeRequestDocument.Factory.parse( xmldata.xmlText() ));
	        WSLLogger.getLogger().info( "WSL: AccountMaintenanceImpl.applyOneTimeCharge() duration: " + (System.currentTimeMillis() - startTime));
	        
			return response;
	    }

	    /**

	     */
	    @RemoteMethod()
	    public org.apache.xmlbeans.XmlObject retrieveBanInfo(  org.apache.xmlbeans.XmlObject xmldata )
	    	    throws Exception
		{
			WSLLogger.getLogger().info( "WSL: AccountMaintenanceImpl.retrieveBanInfo()" );
	        long startTime = System.currentTimeMillis();

	        RetrieveBanInfoResponseDocument response = com.rogers.rci.wsl.services.accountmaintenance.RetrieveBanInfo.retrieveBanInfo( RetrieveBanInfoRequestDocument.Factory.parse( xmldata.xmlText() ));
	        WSLLogger.getLogger().info("WSL: AccountMaintenanceImpl.retrieveBanInfo() duration: " + (System.currentTimeMillis() - startTime));

		//TODO: IMPLEMENT NEW SOLUTION for ICMHelper controls in each facade!
	      //DONE: implemented at OSB facade level
		/**
	        // it will update Account info
	        String METHODNAME = "retrieveBanInfo";
	        //acctMaintICMHelper.processData(xmldata, response, METHODNAME);
	        */
			return response;
	    }

	    /**

	     */
	    @RemoteMethod()
	    public org.apache.xmlbeans.XmlObject updateBanInfo(  org.apache.xmlbeans.XmlObject xmldata )
	    	    throws Exception
	    {
			WSLLogger.getLogger().info( "WSL: AccountMaintenanceImpl.updateBanInfo()" );
	        long startTime = System.currentTimeMillis();
	        
	        UpdateBanInfoResponseDocument response = com.rogers.rci.wsl.services.accountmaintenance.UpdateBanInfo.updateBanInfo( UpdateBanInfoRequestDocument.Factory.parse( xmldata.xmlText() ));
			WSLLogger.getLogger().info( "WSL: AccountMaintenanceImpl.updateBanInfo() duration: " + (System.currentTimeMillis() - startTime));
	        
	        //TODO: IMPLEMENT NEW SOLUTION for ICMHelper controls in each facade!
			//DONE: implemented at OSB facade level
	        /**
	        //acctMaintICMHelper.createUpdateBanInfoInteraction(xmldata, response);        
	        // it will update Account info
	        String METHODNAME = "updateBanInfo";
	        //acctMaintICMHelper.processData(xmldata, response, METHODNAME);
	        */
			return response;
	    }

	    /**

	     */
	    @RemoteMethod()
	    public org.apache.xmlbeans.XmlObject updateCreditEvaluation(  org.apache.xmlbeans.XmlObject xmldata )
	    	    throws Exception
	    {
			WSLLogger.getLogger().info( "WSL: AccountMaintenanceImpl.updateCreditEvaluation()" );
	        long startTime = System.currentTimeMillis();
	        
			UpdateCreditEvaluationResponseDocument response = com.rogers.rci.wsl.services.accountmaintenance.UpdateCreditEvaluation.updateCreditEvaluation( UpdateCreditEvaluationRequestDocument.Factory.parse( xmldata.xmlText() ));
			WSLLogger.getLogger().info( "WSL: AccountMaintenanceImpl.updateCreditEvaluation() duration: " + (System.currentTimeMillis() - startTime));
	        
	        return response;
	        
	    }

	    /**

	     */
	    @RemoteMethod()
	    public org.apache.xmlbeans.XmlObject updateCreditClass(  org.apache.xmlbeans.XmlObject xmldata )
	    	    throws Exception
	    {
			WSLLogger.getLogger().info( "WSL: AccountMaintenanceImpl.updateCreditClass()" );
	        long startTime = System.currentTimeMillis();
	        
			ServiceResponseDocument response = com.rogers.rci.wsl.services.accountmaintenance.UpdateCreditClass.updateCreditClass( UpdateCreditClassRequestDocument.Factory.parse( xmldata.xmlText() ));
			WSLLogger.getLogger().info( "WSL: AccountMaintenanceImpl.updateCreditClass() duration: " + (System.currentTimeMillis() - startTime));
	        
	        return response;
	    }

	    /**

	     */
	    @RemoteMethod()
	    public org.apache.xmlbeans.XmlObject retrieveCreditEvaluation(  org.apache.xmlbeans.XmlObject xmldata )
	    	    throws Exception
	    {
			WSLLogger.getLogger().info( "WSL: AccountMaintenanceImpl.retrieveCreditEvaluation()" );
	        long startTime = System.currentTimeMillis();
	        
			RetrieveCreditEvaluationResponseDocument response = com.rogers.rci.wsl.services.accountmaintenance.RetrieveCreditEvaluation.retrieveCreditEvaluation( RetrieveCreditEvaluationRequestDocument.Factory.parse( xmldata.xmlText() ));
			WSLLogger.getLogger().info( "WSL: AccountMaintenanceImpl.retrieveCreditEvaluation() duration: " + (System.currentTimeMillis() - startTime));
	        
	        return response;
	    }

	    /**

	     */
	    @RemoteMethod()
	    public org.apache.xmlbeans.XmlObject creditEvaluation(  org.apache.xmlbeans.XmlObject xmldata )
	    	    throws Exception
	    {
			WSLLogger.getLogger().info( "WSL: AccountMaintenanceImpl.retrieveCreditEvaluation()" );
	        long startTime = System.currentTimeMillis();
	        
			RetrieveCreditEvaluationResponseDocument response = com.rogers.rci.wsl.services.accountmaintenance.PerformCreditEvaluation.performCreditEvaluation( RetrieveCreditEvaluationRequestDocument.Factory.parse( xmldata.xmlText() ));
			WSLLogger.getLogger().info( "WSL: AccountMaintenanceImpl.retrieveCreditEvaluation() duration: " + (System.currentTimeMillis() - startTime));
	        
	        return response;
	    }

	    /**

	     */
	    @RemoteMethod()
	    public org.apache.xmlbeans.XmlObject makeOneTimePayment(  org.apache.xmlbeans.XmlObject xmldata )
	    	    throws Exception
	    {
			WSLLogger.getLogger().info("WSL: AccountMaintenanceImpl.makeOneTimePayment()");
	        long startTime = System.currentTimeMillis();
	        
	        MakeOneTimePaymentResponseDocument response = com.rogers.rci.wsl.services.accountmaintenance.MakeOneTimePayment.makeOneTimePayment( MakeOneTimePaymentRequestDocument.Factory.parse( xmldata.xmlText() ));
			WSLLogger.getLogger().info( "WSL: AccountMaintenanceImpl.makeOneTimePayment() duration: " + (System.currentTimeMillis() - startTime));
	        
	        return response;
		}


	    /**

	     */
	    @RemoteMethod()
	    public org.apache.xmlbeans.XmlObject retrieveCustomerBalance(  org.apache.xmlbeans.XmlObject xmldata )
	    	    throws Exception
	    {
			WSLLogger.getLogger().info( "WSL: AccountMaintenanceImpl.retrieveCustomerBalance()" );
	        long startTime = System.currentTimeMillis();
	        
			RetrieveCustomerBalanceResponseDocument response = com.rogers.rci.wsl.services.accountmaintenance.RetrieveCustomerBalance.retrieveCustomerBalance( RetrieveCustomerBalanceRequestDocument.Factory.parse( xmldata.xmlText() ));
			WSLLogger.getLogger().info( "WSL: AccountMaintenanceImpl.retrieveCustomerBalance() duration: " + (System.currentTimeMillis() - startTime));

	        return response;
	    }

	    /**

	     */
	    @RemoteMethod()
	    public org.apache.xmlbeans.XmlObject retrieveBalances(  org.apache.xmlbeans.XmlObject xmldata )
	    	    throws Exception
	    {
			WSLLogger.getLogger().info( "WSL: AccountMaintenanceImpl.retrieveBalances()" );
	        long startTime = System.currentTimeMillis();
	        
			RetrieveBalancesResponseDocument response = com.rogers.rci.wsl.services.accountmaintenance.RetrieveBalances.retrieveBalances( RetrieveBalancesRequestDocument.Factory.parse( xmldata.xmlText() ));
			WSLLogger.getLogger().info( "WSL: AccountMaintenanceImpl.retrieveBalances() duration: " + (System.currentTimeMillis() - startTime));

	        return response;
	    }

	    /**

	     */
	    @RemoteMethod()
	    public org.apache.xmlbeans.XmlObject addBillingAddressParameters(  org.apache.xmlbeans.XmlObject xmldata )
	    	    throws Exception
	    {
	        WSLLogger.getLogger().info( "WSL: AccountMaintenanceImpl.addBillingAddressParameters()" );
	        long startTime = System.currentTimeMillis();
	        
			AddAndDeleteBillingAddressParametersResponseDocument response = com.rogers.rci.wsl.services.accountmaintenance.AddBillingAddressParameters.addBillingAddressParameters( AddAndDeleteBillingAddressParametersRequestDocument.Factory.parse( xmldata.xmlText() ));
	        WSLLogger.getLogger().info( "WSL: AccountMaintenanceImpl.addBillingAddressParameters() duration: " + (System.currentTimeMillis() - startTime));

	        return response;
	    }

	    /**

	     */
	    @RemoteMethod()
	    public org.apache.xmlbeans.XmlObject deleteBillingAddressParameters(  org.apache.xmlbeans.XmlObject xmldata )
	    	    throws Exception
	    {
	        WSLLogger.getLogger().info( "WSL: AccountMaintenanceImpl.deleteBillingAddressParameters()" );
	        long startTime = System.currentTimeMillis();
	        
			AddAndDeleteBillingAddressParametersResponseDocument response = com.rogers.rci.wsl.services.accountmaintenance.DeleteBillingAddressParameters.deleteBillingAddressParameters( AddAndDeleteBillingAddressParametersRequestDocument.Factory.parse( xmldata.xmlText() ));
	        WSLLogger.getLogger().info( "WSL: AccountMaintenanceImpl.deleteBillingAddressParameters() duration: " + (System.currentTimeMillis() - startTime));

	        return response;
	    }

	    /**

	     */
	    @RemoteMethod()
	    public org.apache.xmlbeans.XmlObject modifyBillingAddressParameters(  org.apache.xmlbeans.XmlObject xmldata )
	    	    throws Exception
	    {
	        WSLLogger.getLogger().info( "WSL: AccountMaintenanceImpl.modifyBillingAddressParameters()" );
	        long startTime = System.currentTimeMillis();
	        
			ModifyBillingAddressParametersResponseDocument response = com.rogers.rci.wsl.services.accountmaintenance.ModifyBillingAddressParameters.modifyBillingAddressParameters( ModifyBillingAddressParametersRequestDocument.Factory.parse( xmldata.xmlText() ));
	        WSLLogger.getLogger().info( "WSL: AccountMaintenanceImpl.modifyBillingAddressParameters() duration: " + (System.currentTimeMillis() - startTime));

	        return response;
	    }

	    /**

	     */
	    @RemoteMethod()
	    public org.apache.xmlbeans.XmlObject retrieveBillingAddressParameters(  org.apache.xmlbeans.XmlObject xmldata )
	    	    throws Exception
	    {
	        WSLLogger.getLogger().info( "WSL: AccountMaintenanceImpl.retrieveBillingAddressParameters()" );
	        long startTime = System.currentTimeMillis();
	        
			RetrieveBillingAddressParametersResponseDocument response = com.rogers.rci.wsl.services.accountmaintenance.RetrieveBillingAddressParameters.retrieveBillingAddressParameters( RetrieveBillingAddressParametersRequestDocument.Factory.parse( xmldata.xmlText() ));
	        WSLLogger.getLogger().info( "WSL: AccountMaintenanceImpl.retrieveBillingAddressParameters() duration: " + (System.currentTimeMillis() - startTime));

	        return response;
	    }


	    /**

	     */
		@RemoteMethod()
		public org.apache.xmlbeans.XmlObject createMemo(  org.apache.xmlbeans.XmlObject xmldata )
			    throws Exception
		{
	        WSLLogger.getLogger().info( "WSL: AccountMaintenanceImpl.createMemo()" );
	        long startTime = System.currentTimeMillis();
	        
			CreateMemoResponseDocument response = com.rogers.rci.wsl.services.accountmaintenance.CreateMemo.createMemo( CreateMemoRequestDocument.Factory.parse( xmldata.xmlText() ));
	        WSLLogger.getLogger().info( "WSL: AccountMaintenanceImpl.createMemo() duration: " + (System.currentTimeMillis() - startTime));

	        return response;
		}

	    /**

	     */
		@RemoteMethod()
		public org.apache.xmlbeans.XmlObject adjustBan(  org.apache.xmlbeans.XmlObject xmldata )
			    throws Exception
		{
	        WSLLogger.getLogger().info( "WSL: AccountMaintenanceImpl.adjustBan()" );
	        long startTime = System.currentTimeMillis();
	        
			AdjustBanResponseDocument response = com.rogers.rci.wsl.services.accountmaintenance.AdjustBan.adjustBan( AdjustBanRequestDocument.Factory.parse( xmldata.xmlText() ));
	        WSLLogger.getLogger().info( "WSL: AccountMaintenanceImpl.adjustBan() duration: " + (System.currentTimeMillis() - startTime));

	        return response;
		}

	    /**

	     */
	    @RemoteMethod()
	    public org.apache.xmlbeans.XmlObject retrieveLastPayment(  org.apache.xmlbeans.XmlObject xmldata )
	    	    throws Exception
	    {
			WSLLogger.getLogger().info( "WSL: AccountMaintenanceImpl.retrieveLastPayment()" );
	        long startTime = System.currentTimeMillis();
	        
			RetrieveLastPaymentResponseDocument response = com.rogers.rci.wsl.services.accountmaintenance.RetrieveLastPayment.retrieveLastPayment( RetrieveLastPaymentRequestDocument.Factory.parse( xmldata.xmlText() ));
			WSLLogger.getLogger().info( "WSL: AccountMaintenanceImpl.retrieveLastPayment() duration: " + (System.currentTimeMillis() - startTime));

	        return response;
	    }


	    /**

	     */
	    @RemoteMethod()
	    public org.apache.xmlbeans.XmlObject retrieveMemos( org.apache.xmlbeans.XmlObject xmldata)
	    	    throws Exception
	    {
	        WSLLogger.getLogger().info( "WSL: AccountMaintenanceImpl.retrieveMemos()" );
	        long startTime = System.currentTimeMillis();
	        
			RetrieveMemosResponseDocument response = com.rogers.rci.wsl.services.accountmaintenance.RetrieveMemos.retrieveMemos( RetrieveMemosRequestDocument.Factory.parse( xmldata.xmlText() ));
	        WSLLogger.getLogger().info( "WSL: AccountMaintenanceImpl.retrieveMemos() duration: " + (System.currentTimeMillis() - startTime));

	        return response;

	    }

	    /**

	     */
	    @RemoteMethod()
	    public org.apache.xmlbeans.XmlObject retrieveAvailableBillCycleList( org.apache.xmlbeans.XmlObject xmldata)
	    	    throws Exception
	    {
	        WSLLogger.getLogger().info( "WSL: AccountMaintenanceImpl.retrieveAvailableBillCycleList()" );
	        long startTime = System.currentTimeMillis();
	        
			RetrieveAvailableBillCycleListResponseDocument response = com.rogers.rci.wsl.services.accountmaintenance.RetrieveAvailableBillCycleList.retrieveAvailableBillCycleList( RetrieveAvailableBillCycleListRequestDocument.Factory.parse( xmldata.xmlText() ));
	        WSLLogger.getLogger().info( "WSL: AccountMaintenanceImpl.retrieveAvailableBillCycleList() duration: " + (System.currentTimeMillis() - startTime));

	        return response;

	    }

	    /**

	     */
	    @RemoteMethod()
	    public org.apache.xmlbeans.XmlObject retrieveBillList( org.apache.xmlbeans.XmlObject xmldata)
	    	    throws Exception
	    {
	        WSLLogger.getLogger().info( "WSL: AccountMaintenanceImpl.retrieveBillList()" );
	        long startTime = System.currentTimeMillis();
	        
			RetrieveBillListResponseDocument response = com.rogers.rci.wsl.services.accountmaintenance.RetrieveBillList.retrieveBillList( RetrieveBillListRequestDocument.Factory.parse( xmldata.xmlText() ));
	        WSLLogger.getLogger().info( "WSL: AccountMaintenanceImpl.retrieveBillList() duration: " + (System.currentTimeMillis() - startTime));

	        return response;

	    }

	    /**

	     */
	    @RemoteMethod()
	    public org.apache.xmlbeans.XmlObject retrieveBilledCharges( org.apache.xmlbeans.XmlObject xmldata)
	    	    throws Exception
	    {
	        WSLLogger.getLogger().info( "WSL: AccountMaintenanceImpl.retrieveBilledCharges()" );
	        long startTime = System.currentTimeMillis();
	        
			RetrieveBilledChargesResponseDocument response = com.rogers.rci.wsl.services.accountmaintenance.RetrieveBilledCharges.retrieveBilledCharges( RetrieveBilledChargesRequestDocument.Factory.parse( xmldata.xmlText() ));
	        WSLLogger.getLogger().info( "WSL: AccountMaintenanceImpl.retrieveBilledCharges() duration: " + (System.currentTimeMillis() - startTime));

	        return response;

	    }

	    /**

	     */
	    @RemoteMethod()
	    public org.apache.xmlbeans.XmlObject performDuplicateCheck(  org.apache.xmlbeans.XmlObject xmldata )
	    	    throws Exception
	    {
			WSLLogger.getLogger().info( "WSL: AccountMaintenanceImpl.performDuplicateCheck()" );
	        long startTime = System.currentTimeMillis();
	        
			PerformDuplicateCheckResponseDocument response = com.rogers.rci.wsl.services.accountmaintenance.PerformDuplicateCheck.performDuplicateCheck( PerformDuplicateCheckRequestDocument.Factory.parse( xmldata.xmlText() ));
			WSLLogger.getLogger().info( "WSL: AccountMaintenanceImpl.performDuplicateCheck() duration: " + (System.currentTimeMillis() - startTime));
	        
	        return response;
	        
	    }


	    /**

	     */
	    @RemoteMethod()
	    public org.apache.xmlbeans.XmlObject retrieveFirstBillEstimate( org.apache.xmlbeans.XmlObject xmldata)
	    	    throws Exception
	    {
	        WSLLogger.getLogger().info( "WSL: AccountMaintenanceImpl.retrieveFirstBillEstimate()" );
	        long startTime = System.currentTimeMillis();
	        
			RetrieveFirstBillEstimateResponseDocument response = com.rogers.rci.wsl.services.accountmaintenance.RetrieveFirstBillEstimate.retrieveFirstBillEstimate( RetrieveFirstBillEstimateRequestDocument.Factory.parse( xmldata.xmlText() ));
			WSLLogger.getLogger().info( "WSL: AccountMaintenanceImpl.retrieveFirstBillEstimate() duration: " + (System.currentTimeMillis() - startTime));
	        
	        return response;                    
	    }

	    /**

	     */
	    @RemoteMethod()
	    public org.apache.xmlbeans.XmlObject retrieveBanServices( org.apache.xmlbeans.XmlObject xmldata)
	    	    throws Exception
	    {
	        WSLLogger.getLogger().info( "WSL: AccountMaintenanceImpl.retrieveBanServices()" );
	        long startTime = System.currentTimeMillis();
	        
			RetrieveBanServicesResponseDocument response = com.rogers.rci.wsl.services.accountmaintenance.RetrieveBanServices.retrieveBanServices( RetrieveBanServicesRequestDocument.Factory.parse( xmldata.xmlText() ));
			WSLLogger.getLogger().info( "WSL: AccountMaintenanceImpl.retrieveBanServices() duration: " + (System.currentTimeMillis() - startTime));
	        
	        return response;                    
	    }
	    
	    /**

	     */
	    @RemoteMethod()
	    public org.apache.xmlbeans.XmlObject retrieveAvailableBanPricePlans(  org.apache.xmlbeans.XmlObject xmldata )
	    	    throws Exception
	    {
			WSLLogger.getLogger().info("WSL AccountMainatenanceImpl.retrieveAvailableBanPricePlans(): request");
	        long startTime = System.currentTimeMillis();

			RetrieveAvailableBanPricePlansResponseDocument response = com.rogers.rci.wsl.services.accountmaintenance.RetrieveAvailableBanPricePlans.retrieveAvailableBanPricePlans( RetrieveAvailableBanPricePlansRequestDocument.Factory.parse( xmldata.xmlText() ));
			WSLLogger.getLogger().info("WSL AccountMainatenanceImpl.retrieveAvailableBanPricePlans(): request duration: " + (System.currentTimeMillis() - startTime));

	        return response;
	    }

	    /**

	     */
	    @RemoteMethod()
	    public org.apache.xmlbeans.XmlObject retrievePaymentHistory(  org.apache.xmlbeans.XmlObject xmldata )
	    	    throws Exception
	    {
			WSLLogger.getLogger().info("WSL AccountMainatenanceImpl.retrievePaymentHistory(): request");
	        long startTime = System.currentTimeMillis();

			RetrievePaymentHistoryResponseDocument response = com.rogers.rci.wsl.services.accountmaintenance.RetrievePaymentHistory.retrievePaymentHistory( RetrievePaymentHistoryRequestDocument.Factory.parse( xmldata.xmlText() ));
			WSLLogger.getLogger().info("WSL AccountMainatenanceImpl.retrievePaymentHistory(): request duration: " + (System.currentTimeMillis() - startTime));

	        return response;
	    }
	    
	 
	    /**

	     */
	    
	      
	    @RemoteMethod()
	    public org.apache.xmlbeans.XmlObject retrieveEnhancedProductServices(  org.apache.xmlbeans.XmlObject xmldata )
	    	    throws Exception
	    {
			WSLLogger.getLogger().info("WSL AccountMainatenanceImpl.retrieveEnhancedProductServices(): request");
	        long startTime = System.currentTimeMillis();

			RetrieveEnhancedProductLevelServicesResponseDocument response = com.rogers.rci.wsl.services.accountmaintenance.RetrieveEnhancedProductLevelServices.retrieveEnhancedProductLevelServices( RetrieveEnhancedProductLevelServicesRequestDocument.Factory.parse( xmldata.xmlText() ));
			WSLLogger.getLogger().info("WSL AccountMainatenanceImpl.retrieveEnhancedProductServices(): request duration: " + (System.currentTimeMillis() - startTime));

	        return response;
	    }    


	    /**

	     */
	     

	    @RemoteMethod()
	    public org.apache.xmlbeans.XmlObject submitEnhancedProductServices(  org.apache.xmlbeans.XmlObject xmldata )
	    	    throws Exception
	    {
			WSLLogger.getLogger().info("WSL AccountMainatenanceImpl.submitEnhancedProductServices(): request");
	        long startTime = System.currentTimeMillis();

			SubmitEnhancedProductLevelServicesResponseDocument response = com.rogers.rci.wsl.services.accountmaintenance.SubmitEnhancedProductLevelServices.submitEnhancedProductLevelServices( SubmitEnhancedProductLevelServicesRequestDocument.Factory.parse( xmldata.xmlText() ));
	        WSLLogger.getLogger().info("WSL AccountMainatenanceImpl.submitEnhancedProductServices(): request duration: " + (System.currentTimeMillis() - startTime));

	        return response;
	    }    

	    /**

	     */
	     

	    @RemoteMethod()
	    public org.apache.xmlbeans.XmlObject retrieveEbppInfo(  org.apache.xmlbeans.XmlObject xmldata )
	    	    throws Exception
	    {
			WSLLogger.getLogger().info("WSL AccountMainatenanceImpl.retrieveEbppInfo(): request");
	        long startTime = System.currentTimeMillis();

			RetrieveEbppInfoResponseDocument response = com.rogers.rci.wsl.services.accountmaintenance.RetrieveEbppInfo.RetrieveEbppInfo( RetrieveEbppInfoRequestDocument.Factory.parse( xmldata.xmlText() ));
	        WSLLogger.getLogger().info("WSL AccountMainatenanceImpl.retrieveEbppInfo(): request duration: " + (System.currentTimeMillis() - startTime));

	        return response;
	    }   		
	
}