package com.rogers.logger.utility;

public class UtilityLogger 
{
	private static UtilityLogger logger = null;

	public static UtilityLogger getLogger()
	{
		if ( logger == null )
		{
			synchronized( UtilityLogger.class )
			{
				// create the logger if it has not been created
				if ( logger == null ) logger = new UtilityLogger();
			}
		}
		return logger;
	}

	/**
	 * to be overriden in parent application by class that extends it (using a Logger)
	 * @param message
	 */
	public void infoToLog(String message)
	{	
		System.out.println( "L0:" + message);
	}
	
	public void info (String message)
	{
		infoToLog (message);
	}
	
	public void logException( Throwable exc )
	{

			java.io.StringWriter buffer = new java.io.StringWriter();
			exc.printStackTrace( new java.io.PrintWriter( buffer ) );
			infoToLog( buffer.toString() );
	}
}
