package com.rogers.rci.csl;

import com.async.engine.common.services.AsyncAdaptorService;
import com.async.jms.common.utils.JmsUtils;
import com.async.jms.common.utils.JmsUtilsFactory;
import com.rogers.rci.csl.XMLWrapperConstants;
import com.rogers.rci.csl.sam.header.SAMMQMessagetype;

public class SAMMQSscReaderUtils extends AsyncReaderBase
{
	private static final String READER_PREFIX = "SAM_";

	private static JmsUtils workerToDestination = null;
	private static JmsUtils workerToErrorDestination = null;

	public static void processMessage(javax.jms.Message msg)
	throws Exception
	{
		String msgReceived = null;
		//long startTime = System.currentTimeMillis();

		if (msg instanceof javax.jms.TextMessage)
		{
			javax.jms.TextMessage textMessage = (javax.jms.TextMessage) msg;
			msgReceived = textMessage.getText();
		}
		if (msg instanceof javax.jms.BytesMessage)
		{
		    javax.jms.BytesMessage textMessage = (javax.jms.BytesMessage) msg;
		    byte[] bytes = new byte[(int) textMessage.getBodyLength()];
		    textMessage.readBytes(bytes);

		    msgReceived = new String(bytes, "UTF-8");
		}
		//System.out.println(new StringBuffer("Handle SAM msg: ").append( "" + msg.getJMSMessageID() ).toString());

		try
		{
			workerToDestination = JmsUtilsFactory.getInstance( SAMMQSscConstants.JMS_CONNECTION_FACTORY_JNDI, SAMMQSscConstants.JMS_DESTINATION_QUEUE_JNDI);
			workerToDestination.sendMessage( getCustomizedMsg(msg, msgReceived), msg.getJMSMessageID(), getExtraParamsMap(msgReceived));
		}
		catch (Exception ex)
		{
			workerToErrorDestination = JmsUtilsFactory.getInstance( SAMMQSscConstants.JMS_CONNECTION_FACTORY_JNDI, SAMMQSscConstants.JMS_ERROR_DESTINATION_QUEUE_JNDI);
			workerToErrorDestination.sendMessage( getCustomizedMsg(msg, msgReceived), msg.getJMSMessageID(), getExtraParamsMap(msgReceived));
			System.out.println("Exception in MscMessageBean: routed message to " + SAMMQSscConstants.JMS_ERROR_DESTINATION_QUEUE_JNDI);
			//Throwable e1=ex;
			//while ( e1.getCause() !=null ) e1=e1.getCause();
			ex.printStackTrace();
		}

		//System.out.println("Content:" + getCustomizedMsg(msg, msgReceived));

		//System.out.println( "Duration: " + (System.currentTimeMillis() - startTime));
		//java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss SSS");
		//System.out.println( "Now is: " + sdf.format( java.util.Calendar.getInstance().getTime() ));
	}

	/**
	 * Should set all mentioned in AsyncReaderBase such as:
	 * MSGTYPE
	 * SZKEY
	 * FILTERKEY
	 * CORRLIST (list of name/value pairs delimited by 'e##e' delimiter)
	 */
	private static java.util.HashMap<String,String> getExtraParamsMap(String msgReceived)
		throws Exception
	{
		java.util.HashMap<String,String> extraParamsMap = new java.util.HashMap<String,String>();
		extraParamsMap.put(XMLWrapperConstants.MSG_CATEGORY, XMLWrapperConstants.MSG_CURRENT_CATEGORY);

		// set MSGTYPE
		String msgType = SAMMQMessagetype.getMsgType( msgReceived );
		extraParamsMap.put(MSGTYPE_FLAG, msgType);

		//set SZKEY
		//System.out.println( "Retrieve SZKEY for MSGTYPE: " + msgType);
		com.async.engine.common.MessageInterface msgInterfHandler = AsyncAdaptorService.getMessageInterface( msgType );
		String szkey = SAMMQSscReaderUtils.READER_PREFIX + msgInterfHandler.getSzKey( msgReceived );
		extraParamsMap.put(BLOCK_KEY_FLAG, szkey);

		//set FILTERKEY
		String filterkey = szkey.substring(szkey.length()); //get last char
		if ("".equalsIgnoreCase(filterkey) || "_".equalsIgnoreCase(filterkey) )
		{
			System.out.println("Default filter key set for " + msgType);
			filterkey = getRandomBeanFilter();
		}
		extraParamsMap.put(FILTER_KEY_FLAG, filterkey);

		//set CORRLIST
		extraParamsMap.put(MSG_CORRELATION_LIST_FLAG, "");


		return extraParamsMap;
	}

	private static String getCustomizedMsg(javax.jms.Message msg, String txtMessage )
		throws Exception
	{
		StringBuffer tmpBuff = new StringBuffer("");
		String jmsCorrelationId = msg.getJMSMessageID();

		String tmp = null;

		//add message to customized message: clean up message and remove null chars
		tmp = XMLWrapperConstants.MSG_NODE.replace(XMLWrapperConstants.DELIMITER, txtMessage.replace( (char)0, ' '));
		tmpBuff.append( tmp );

		//add correlation id to customized message
		tmp = XMLWrapperConstants.ELEMENT_NODE.replace(XMLWrapperConstants.ELEMENT_DELIMITER ,XMLWrapperConstants.JMS_CORRELATION_FLAG);
		tmp=tmp.replace(XMLWrapperConstants.DELIMITER, jmsCorrelationId + "");
		tmpBuff.append( tmp );

		//final value:
		tmp = XMLWrapperConstants.ROOT_NODE.replace(XMLWrapperConstants.DELIMITER, tmpBuff.toString() );

		return tmp;
	}
}
