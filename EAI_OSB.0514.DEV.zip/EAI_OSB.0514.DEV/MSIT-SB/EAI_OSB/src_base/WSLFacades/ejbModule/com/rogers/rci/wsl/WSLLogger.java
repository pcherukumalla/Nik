package com.rogers.rci.wsl;

public class WSLLogger
{
	private static WSLLogger logger = null;

	public static WSLLogger getLogger()
	{
		if ( logger == null )
		{
			synchronized( WSLLogger.class )
			{
				// create the logger if it has not been created
				if ( logger == null ) logger = new WSLLogger();
			}
		}
		return logger;
	}

	public void infoToLog(String message)
	{		
	    try {
	        weblogic.logging.LoggingHelper.getServerLogger().info( message );
	      } catch(Exception ex) {
	    	  System.out.println( "L0:" + message);
	      }
	}
	
	public void info (String message)
	{
		infoToLog (message);
	}
	
	public void logException( Throwable exc )
	{

			java.io.StringWriter buffer = new java.io.StringWriter();
			exc.printStackTrace( new java.io.PrintWriter( buffer ) );
			infoToLog( buffer.toString() );
	}
}