package com.rogers.sspmw.tdvLogPolicy.exception;


public class TDVException extends Exception {
	private static final long serialVersionUID = -5666880717133127589L;

	public TDVException() {
		super();
	}

	public TDVException(String message, Throwable cause) {
		super(message, cause);
	}

	public TDVException(String message) {
		super(message);
	}

	public TDVException(Throwable cause) {
		super(cause);
	}


}
