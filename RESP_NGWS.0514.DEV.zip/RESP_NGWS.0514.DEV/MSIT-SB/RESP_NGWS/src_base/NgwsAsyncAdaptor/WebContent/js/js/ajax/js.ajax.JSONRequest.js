/*
****************************************************************************************************
 ezWebToolkit Library, http://www.ezwebtoolkit.com
****************************************************************************************************
Copyright [2006-2008] [Pro Net Systems Inc., http://www.pronetsystems.com]

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

	http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
***************************************************************************************************
*/



js.ajax.JSONRequest = function() {
	this.requests = new Array();
	
	this.DEFAULT_TIMEOUT = 10000;
	this.MAX_NR_OF_CONCURRENT_THREADS = 2;
	this.PERIODICITY = 1;

	this.requestNumber = 100000;
	this.nrOfConcurrentThreads = 0;

	this.objectType = "js.ajax.JSONRequest";
}



js.ajax.JSONRequest.prototype.error = function(msg) {
	err = new Error(msg);
	err.name = "JSONRequestError";
	
	return err;
}



js.ajax.JSONRequest.prototype.action = function(mth, url, send, done, timeout) {
	// check callback function...
	if((typeof(done) != "function") || (done.length != 3)) {
		throw this.error("bad function");
	}
	
	// check and set timeout...
	var tout = this.DEFAULT_TIMEOUT;
	if(timeout) {
		// check if a valid timeout...
		if(isNaN(timeout) || (timeout <= 0)) {
			throw this.error("bad timeout");
		} else {
			tout = timeout;
		}
	}
	
	// generate new request number...
	this.requestNumber++;
	var reqno = this.requestNumber;
	
	// create request message...
	var reqInfo = new js.ajax.JSONRequestMessage(reqno, url, send, done, tout, mth, this);
	this.requests.push(reqInfo);
	
	// return the request number...
	return reqno;
}



js.ajax.JSONRequest.prototype.post = function(url, send, done, timeout) {
	return this.action("POST", url, send, done, timeout);
}



js.ajax.JSONRequest.prototype.get = function(url, done, timeout) {
	return this.action("GET", url, null, done, timeout);
}



js.ajax.JSONRequest.prototype.cancel = function(reqno) {
	for(var i = 0; i < this.requests.length; i++) {
		if(this.requests[i].reqno == reqno) {
			// change status...
			this.requests[i].status = "CANCELLED";
			
			// callback function call for a "cancelled" error...
			var err = this.error("cancelled");
		    err.description = "Request was cancelled."
			
			try {
				this.requests[i].done(reqno, null, err);
			} catch(e) {}
		}
	}
}



js.ajax.JSONRequest.prototype.process = function() {
	var SELF = this;
	
	if((this.nrOfConcurrentThreads < this.MAX_NR_OF_CONCURRENT_THREADS) && (this.requests.length > 0)) {
		var reqInfo = this.requests.shift();
		
		// process message if in "PENDING" status only...
		if(reqInfo.status == "PENDING") {
			reqInfo.process();
			
			// meke process thread unavailable...
			this.nrOfConcurrentThreads++;
		}
	}
	
	// call function again after "this.PERIODICITY" ms...
	setTimeout(function(){SELF.process()}, this.PERIODICITY);
}



js.ajax.JSONRequest = new js.ajax.JSONRequest();
js.ajax.JSONRequest.process();
