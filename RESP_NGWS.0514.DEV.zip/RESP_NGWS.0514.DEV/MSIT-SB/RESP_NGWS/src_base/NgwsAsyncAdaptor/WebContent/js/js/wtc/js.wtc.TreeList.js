/*
****************************************************************************************************
 ezWebToolkit Library, http://ezwt.blogspot.com
****************************************************************************************************
Copyright [2006-2008] [Pro Net Systems Inc., http://www.pronetsystems.com]

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

	http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
***************************************************************************************************
*/



/*
------------------------------------------------------------------------------------------
TreeList
------------------------------------------------------------------------------------------
*/
document.write("<style type=\"text/css\">");
document.write(".ezTreeClass {");
document.write("	margin: 0px;");
document.write("	padding: 0px;");
document.write("}");
document.write(".ezTreeLIClass {");
document.write("	background-repeat: no-repeat;");
document.write("	background-position:left center;");
document.write("	list-style-type: none;");
document.write("	padding-left: 15px;");
document.write("	cursor: pointer;");
document.write("}");
document.write(".ezTreeLISubMenuClass {");
document.write("	background-repeat: no-repeat;");
document.write("	background-position:left 4px;");
document.write("	list-style-type: none;");
document.write("	padding-left: 15px;");
document.write("	cursor: pointer;");
document.write("}");
document.write("</style>");



js.wtc.TreeList = function() {
	js.wtc.ContentPanel.call(this);

	this.treeClass = "ezTreeClass";
	this.treeLIClass = "ezTreeLIClass";
	this.treeLISMClass = "ezTreeLISubMenuClass"; // SM = sub menu...
	this.elemImage = js.IMAGES_PATH + "elem.gif";
	this.openedImage = js.IMAGES_PATH + "opened.gif";
	this.closedImage = js.IMAGES_PATH + "closed.gif";

	this.objectType = "js.wtc.TreeList";
}
js.wtc.TreeList.prototype = new js.wtc.ContentPanel();
js.wtc.TreeList.prototype.constructor = js.wtc.TreeList;



js.wtc.TreeList.prototype.init = function() {
	// create the main div...
	this.theViewport = document.createElement("UL");
	this.theViewport.className = this.treeClass;
	
	// instrument the new node...
	this.instrumentViewport();
}



js.wtc.TreeList.prototype.addOption = function(o, id) {
	// create the new LI element...
	var li = document.createElement("LI");
	li.className = this.treeLIClass;
	if(o.imageSrc != null) {
		li.style.backgroundImage = "url(" + o.imageSrc + ")";
	} else {
		li.style.backgroundImage = "url(" + this.elemImage + ")";
	}
	li.innerHTML = o.name;
	li.title = o.title;
	li.setAttribute("objectId", o.id);

	// add action...
	if(o.action != null) {
		js.wtc.Manager.addEventListener(li, "onclick", o.action);
	}

	// store the new element reference into the TreeListOption object...
	// so you can get access to the HTML LI element corresponding to this tree option...
	o.li = li; // see TreeListOption.htmlView() function...

	// append the new element...
	if(id) { 
		// store parent id...
		o.pid = id;

		// append the new LI to either root or to the element with "objectId = id"...
		var liById = this.findTreeOption(this.viewport(), id);
		liById.className = this.treeLISMClass;
		liById.style.backgroundImage = "url(" + this.closedImage + ")";

		// check if there is already an UL here...
		var ul = null;
		var lst = liById.childNodes;
		for(var i = 0; i < lst.length; i++) {
			if(lst.item(i).tagName == "UL") {
				ul = lst.item(i);
				break;
			}
		}

		// if no UL then create one and attach it...
		if(ul == null) {
			ul = document.createElement("UL");
			ul.style.display = "none";
			liById.appendChild(ul);
		}

		// add new element to th UL...
		ul.appendChild(li);

		// attach action to the UL onclick...
		ul.onclick = function(e) {
			// prevent propagation...
			js.wtc.Manager.preventEventPropagation(e);
		}

		// attach action to the LI onclick...
		var SELF = this;
		liById.onclick = function(e) {
			var submenu = this.getElementsByTagName("UL")[0];
			
			// fix display attribute...
			if(submenu.style.display == "") {
				submenu.style.display = "block";
			}

			// display or hide the UL fragment...
			if(submenu.style.display == "block") {
				submenu.style.display = "none";
				this.style.backgroundImage = "url(" + SELF.closedImage + ")";
			} else {
				submenu.style.display = "block";
				this.style.backgroundImage = "url(" + SELF.openedImage + ")";
			}

			// prevent propagation...
			js.wtc.Manager.preventEventPropagation(e);
		}
	} else { // add new element to the root UL...
		this.viewport().appendChild(li);
	}
}



js.wtc.TreeList.prototype.removeTO = function(ul, id) {
	var lst = ul.childNodes;
	for(var i = 0; i < lst.length; i++) {
		if(lst.item(i).getAttribute("objectId") == id) {
			ul.removeChild(lst.item(i));
			break;
		}

		if(lst.item(i).getElementsByTagName("UL").length > 0) {
			this.removeTO(lst.item(i).getElementsByTagName("UL")[0], id);
		}
	}
}



js.wtc.TreeList.prototype.removeTreeOption = function(id) {
	this.removeTO(this.viewport(), id);
}



js.wtc.TreeList.prototype.expandOption = function(id) {
	var li = this.findTreeOption(this.viewport(), id);
	if(li != null) {
		// if there are children then expand them...
		if(li.getElementsByTagName("UL").length > 0) {
			var submenu = li.getElementsByTagName("UL")[0];
			submenu.style.display = "block";
			li.style.backgroundImage = "url(" + this.openedImage + ")";
		}

		// expand all of them up to the top level...
		var ul = li.parentNode;
		while(ul != this.viewport()) {
			ul.style.display = "block";
			ul.parentNode.style.backgroundImage = "url(" + this.openedImage + ")";
			ul = ul.parentNode.parentNode;
		}
	}
}



js.wtc.TreeList.prototype.collapseOption = function(id) {
	var li = this.findTreeOption(this.viewport(), id);
	if(li != null) {
		// if there are children then collapse them...
		if(li.getElementsByTagName("UL").length > 0) {
			var submenu = li.getElementsByTagName("UL")[0];
			submenu.style.display = "none";
			li.style.backgroundImage = "url(" + this.closedImage + ")";
		}
	}
}



js.wtc.TreeList.prototype.expandOptions = function() {
	this.expand(this.viewport());
}



js.wtc.TreeList.prototype.collapseOptions = function() {
	this.collapse(this.viewport());
}



js.wtc.TreeList.prototype.expand = function(ul) {
	var lst = ul.childNodes;
	for(var i = 0; i < lst.length; i++) {
		if(lst.item(i).getElementsByTagName("UL").length > 0) {
			var submenu = lst.item(i).getElementsByTagName("UL")[0];
			submenu.style.display = "block";
			lst.item(i).style.backgroundImage = "url(" + this.openedImage + ")";

			this.expand(submenu);
		}
	}
}



js.wtc.TreeList.prototype.collapse = function(ul) {
	var lst = ul.childNodes;
	for(var i = 0; i < lst.length; i++) {
		if(lst.item(i).getElementsByTagName("UL").length > 0) {
			var submenu = lst.item(i).getElementsByTagName("UL")[0];
			submenu.style.display = "none";
			lst.item(i).style.backgroundImage = "url(" + this.closedImage + ")";

			this.expand(submenu);
		}
	}
}



js.wtc.TreeList.prototype.findTreeOption = function(ul, id) {
	var ret = null;

	var lst = ul.childNodes;
	for(var i = 0; i < lst.length; i++) {
		if(lst.item(i).getAttribute("objectId") == id) {
			ret = lst.item(i);
			break;
		}

		if(lst.item(i).getElementsByTagName("UL").length > 0) {
			ret = this.findTreeOption(lst.item(i).getElementsByTagName("UL")[0], id);
			if(ret != null) {
				break;
			}
		}
	}

	return ret;
}



js.wtc.TreeList.prototype.getOption = function(id) {
	var ret = null;
	var li = this.findTreeOption(this.viewport(), id);

	if(li != null) {
		ret = new js.wtc.TreeListOption(li.childNodes[0].data, li.onclick, id);
		ret.li = li;
		ret.title = li.title;

		// get parent id...
		if(li.parentNode == this.viewport()) {
			ret.pid = null;
		} else {
			ret.pid = li.parentNode.parentNode.getAttribute("objectId");
		}
	}

	return ret;
}



js.wtc.TreeList.prototype.getOptions = function(id) {
	var ret = new Array();

	var lst = null;
	var o = null;
	if(id) {
		var li = this.findTreeOption(this.viewport(), id);
	
		if(li != null) {
			if(li.getElementsByTagName("UL").length > 0) {
				var submenu = li.getElementsByTagName("UL")[0];
				lst = submenu.childNodes;
				
				for(var i = 0; i < lst.length; i++) {
					o = new js.wtc.TreeListOption(lst.item(i).childNodes[0].data, lst.item(i).onclick, lst.item(i).getAttribute("objectId"));
					o.li = lst.item(i);
					o.pid = li.getAttribute("objectId"); // parent id...
					o.title = lst.item(i).title;
	
					ret.push(o);
				}
			}
		}
	} else {
		lst = this.viewport().childNodes;

		for(var i = 0; i < lst.length; i++) {
			o = new js.wtc.TreeListOption(lst.item(i).childNodes[0].data, lst.item(i).onclick, lst.item(i).getAttribute("objectId"));
			o.li = lst.item(i);
			o.title = lst.item(i).title;

			ret.push(o);
		}
	}

	return ret;
}



js.wtc.TreeList.prototype.addEventListener = function(id, evtname, act) {
	var li = this.findTreeOption(this.viewport(), id);
	js.wtc.Manager.addEventListener(li, evtname, act);
}



js.wtc.TreeList.prototype.set = function(name, value) {
	if(name == "treeClass") { // before init...
		this.treeClass = value;
	} else if(name == "treeLIClass") { // before init...
		this.treeLIClass = value;
	} else if(name == "treeLISMClass") { // before init...
		this.treeLISMClass = value;
	} else if(name == "elemImage") { // before init...
		this.elemImage = value;
	} else if(name == "openedImage") { // before init...
		this.openedImage = value;
	} else if(name == "closedImage") { // before init...
		this.closedImage = value;
	} else {
		js.wtc.ContentPanel.prototype.set.call(this, name, value);
	}
}



js.wtc.TreeList.prototype.get = function(name) {
	if(name == "treeClass") {
		return this.treeClass;
	} else if(name == "treeLIClass") {
		return this.treeLIClass;
	} else if(name == "treeLISMClass") {
		return this.treeLISMClass;
	} else if(name == "elemImage") {
		return this.elemImage;
	} else if(name == "openedImage") {
		return this.openedImage;
	} else if(name == "closedImage") {
		return this.closedImage;
	} else {
		return js.wtc.ContentPanel.prototype.get.call(this, name);
	}
}
