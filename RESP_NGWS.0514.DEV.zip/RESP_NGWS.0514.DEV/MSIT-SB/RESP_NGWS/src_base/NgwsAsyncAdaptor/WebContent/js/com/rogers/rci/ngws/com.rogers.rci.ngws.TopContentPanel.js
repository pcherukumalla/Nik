/*
------------------------------------------------------------------------------------------
TopContentPanel
------------------------------------------------------------------------------------------
*/
document.write("<style type=\"text/css\">");
document.write(".ezListboxSelectedO911Class {");
document.write("	background-color: rgb(120,172,255);");
document.write("	color: white;");
document.write("}");
document.write("</style>");
com.rogers.rci.ngws.TopContentPanel = function(p) {
	js.wtc.ContentPanel.call(this);
	
	this.app = p;
}
com.rogers.rci.ngws.TopContentPanel.prototype = new js.wtc.ContentPanel();
com.rogers.rci.ngws.TopContentPanel.prototype.constructor = com.rogers.rci.ngws.TopContentPanel;



com.rogers.rci.ngws.TopContentPanel.prototype.createValueDetails = function(t) {
	var ret = new js.wtc.Text("");
	ret.init();
	ret.set("top", t);
	ret.set("width", "100px");
	ret.viewport().align = "right";
	
	this.detailsContentPanel.append(ret);
	
	return ret;
}



com.rogers.rci.ngws.TopContentPanel.prototype.initTodayDetails = function(sfcp) {
	this.detailsContentPanel = new js.wtc.ContentPanel();
	this.detailsContentPanel.init();
	this.detailsContentPanel.set("left", "10px");
	this.detailsContentPanel.set("top", "200px");
	
	this.detailsContentPanel.NR_OF_MSG = this.createValueDetails("0px");
	this.detailsContentPanel.NR_OF_MSG_OK = this.createValueDetails("40px");
	this.detailsContentPanel.NR_OF_MSG_ELMS_TIMEOUT = this.createValueDetails("78px");
	this.detailsContentPanel.NR_OF_MSG_ELMS_DOWN = this.createValueDetails("116px");
	this.detailsContentPanel.NR_OF_MSG_OTHER_ERRORS = this.createValueDetails("158px");
	
	// append it...
	sfcp.append(this.detailsContentPanel);
}



com.rogers.rci.ngws.TopContentPanel.prototype.init = function() {
	js.wtc.ContentPanel.prototype.init.call(this);
	
	var SELF = this;

	// set attributes...
	this.set("left", "30px");
	this.set("top", "25px");
	this.set("width", (this.app.width - 75) + "px");
	this.set("height", "35px");
	this.set("backgroundColor", "#FFFFFF");
	this.set("border", "1px solid rgb(120,172,255)");
	this.set("zIndex", "100000000");
	
	// init the background content panel...
	var bkcp = new js.wtc.ContentPanel();
	bkcp.init();
	bkcp.set("left", "150px");
	bkcp.set("top", "1px");
	bkcp.set("width", (this.app.width - 226) + "px");
	bkcp.set("height", "33px");
	bkcp.set("backgroundColor", "rgb(120,172,255)");
	// append it...
	this.append(bkcp);
	
	// init the app logo text...
	this.appLogoText = new js.wtc.Text("ELMS AsyncAdaptor Admin Tool");
	this.appLogoText.init();
	this.appLogoText.set("left", "170px");
	this.appLogoText.set("top", "5px");
	this.appLogoText.set("fontSize", "20px");
	this.appLogoText.set("fontWeight", "bold");
	this.appLogoText.set("color", "#FAE654");
	// appedn it...
	this.append(this.appLogoText);
	
	// init the rogers logo...
	this.rogersLogoImage = new js.wtc.Image("images/logo_rogers.gif");
	this.rogersLogoImage.init();
	this.rogersLogoImage.set("left", "3px");
	this.rogersLogoImage.set("top", "1px");
	// append it...
	this.append(this.rogersLogoImage);
	
	// init the search frame content panel...
	var sfcp = new js.wtc.ContentPanel();
	sfcp.init();
	sfcp.set("left", "-1px");
	sfcp.set("top", "40px");
	sfcp.set("width", (this.app.width - 75) + "px");
	sfcp.set("height", "27px");
	sfcp.set("border", "1px solid rgb(120,172,255)");
	sfcp.set("backgroundColor", "#EFEFEF");
	// append it...
	this.append(sfcp);
	
	// init the start date date...
	this.keywordsTextbox = new com.rogers.rci.ngws.Textbox();
	this.keywordsTextbox.init();
	this.keywordsTextbox.set("value", ""); 
	//this.keywordsTextbox.set("value", "");
	this.keywordsTextbox.set("left", "3px");
	this.keywordsTextbox.set("top", "3px");
	this.keywordsTextbox.set("width", "130px");
	sfcp.append(this.keywordsTextbox);
	
	// init the types list box...
	this.typesListbox = new js.wtc.Listbox();
	this.typesListbox.set("dropdown", true);
	this.typesListbox.set("selectedClassName", "ezListboxSelectedO911Class");
	this.typesListbox.init();
	this.typesListbox.set("left", "140px");
	this.typesListbox.set("top", "2px");
	this.typesListbox.set("width", "70px");
	this.typesListbox.set("height", "25px");
	this.typesListbox.textboxDD.set("border", "1px solid rgb(120,172,255)");
	this.typesListbox.textboxDD.set("height", "17px");
	this.typesListbox.buttonDD.set("borderWidth", "1px");
	this.typesListbox.buttonDD.set("backgroundColor", "rgb(120,172,255)");
	this.typesListbox.buttonDD.set("color", "rgb(255, 255, 255)");
	this.typesListbox.buttonDD.set("height", "21px");
	this.typesListbox.optContainer.set("border", "1px solid rgb(120,172,255)");
	this.typesListbox.optContainer.set("height", "19px");
	this.typesListbox.addOption("ECID", "szkey");
	sfcp.append(this.typesListbox);
	this.typesListbox.selectOption("szkey");
	
	// init the search button...
	this.searchButton = new com.rogers.rci.ngws.Button("Search");
	this.searchButton.init();
	this.searchButton.set("left", "214px");
	this.searchButton.set("top", "2px");
	this.searchButton.set("width", "70px");
	this.searchButton.viewport().onclick = function() {
		SELF.search();
	}
	// append it...
	sfcp.append(this.searchButton);
		
	// init the history button...
	this.historyButton = new com.rogers.rci.ngws.Button("History");
	this.historyButton.init();
	this.historyButton.set("left", "286px");
	this.historyButton.set("top", "2px");
	this.historyButton.set("width", "70px");
	this.historyButton.viewport().onclick = function() {
		SELF.searchHistory();
	}
	// append it...
	sfcp.append(this.historyButton);
	
	// init the stats button...
	this.statsButton = new com.rogers.rci.ngws.Button("Statistics");
	this.statsButton.init();
	this.statsButton.set("left", "358px");
	this.statsButton.set("top", "2px");
	this.statsButton.set("width", "80px");
	this.statsButton.viewport().onclick = function() {
		SELF.showStats();
	}
	// append it...
	sfcp.append(this.statsButton);
	
	// init the statsErrors button...
	this.statsErrorsButton = new com.rogers.rci.ngws.Button("Errors");
	this.statsErrorsButton.init();
	this.statsErrorsButton.set("left", "440px");
	this.statsErrorsButton.set("top", "2px");
	this.statsErrorsButton.set("width", "65px");
	this.statsErrorsButton.viewport().onclick = function() {
		SELF.showStats(true);
	}
	// append it...
	sfcp.append(this.statsErrorsButton);
	
	// init the statsToday button...
	this.statsTodayButton = new com.rogers.rci.ngws.Button("Today");
	this.statsTodayButton.init();
	this.statsTodayButton.set("left", "507px");
	this.statsTodayButton.set("top", "2px");
	this.statsTodayButton.set("width", "65px");
	this.statsTodayButton.viewport().onclick = function() {
		SELF.showTodayStats();
	}
	// append it...
	sfcp.append(this.statsTodayButton);
	
	// init todays details content panel...
	this.initTodayDetails(sfcp);
	
	
	// init the TDV button...
	this.tdvButton = new com.rogers.rci.ngws.Button("Track Data Viewer");
	this.tdvButton.init();
	this.tdvButton.set("left", "654px");
	this.tdvButton.set("top", "2px");
	this.tdvButton.set("width", "140px");
	this.tdvButton.viewport().onclick = function() {
		window.open("http://msit.rogers.com/TDV/index.html?gid=PROD", "", "");
	}
	// append it...
	sfcp.append(this.tdvButton);
	
	// init the engine admin button...
	this.engineAdminButton = new com.rogers.rci.ngws.Button("Engine Administrator");
	this.engineAdminButton.init();
	this.engineAdminButton.set("left", "796px");
	this.engineAdminButton.set("top", "2px");
	this.engineAdminButton.set("width", "150px");
	this.engineAdminButton.set("backgroundColor", "#AFAFAF");
	this.engineAdminButton.set("disabled", true);
	this.engineAdminButton.viewport().onclick = function() {
		SELF.app.engineAdminWindow.show();
	}
	// append it...
	sfcp.append(this.engineAdminButton);	
}



com.rogers.rci.ngws.TopContentPanel.prototype.show = function() {
	js.wtc.ContentPanel.prototype.show.call(this);
	
	this.statsErrorsButton.hide();
	this.statsTodayButton.hide();
	this.detailsContentPanel.hide();
}



com.rogers.rci.ngws.TopContentPanel.prototype.showStats = function(erIn) {
	this.app.resultsContentPanel.show();
	this.app.resultsContentPanel.resetData();
	
	// fix Firefox...
    if (js.util.Browser.isFirefox) {
        try {
            netscape.security.PrivilegeManager.enablePrivilege("UniversalBrowserRead");
        } catch (e) {
            //alert("Permission UniversalBrowserRead denied.");
        }
    }
    
    // TO DO...
    var xmlHttpRequest = new js.ajax.XMLHttpRequest();
    xmlHttpRequest.set("url", this.app.appServicesURL);
    if(!erIn) {
    	xmlHttpRequest.setVar("cmd", "stats");
    } else {
    	xmlHttpRequest.setVar("cmd", "statsErrors");
    }
    //xmlHttpRequest.setVar("dt", "");
    xmlHttpRequest.object = this;
    xmlHttpRequest.open();

    xmlHttpRequest.onComplete = function() {
        //alert(this.response);
        
        // eval the JSON data...
        var data = null;
        eval("data = " + this.response);
        
        // ...
        if(data.items.length > 1) {
        	this.object.app.resultsContentPanel.buildStatsData(data.items, erIn);
        } else {
        	alert("No data found.");
        }
        
        this.object.app.loadingDataContentPanel.hide();
    }
    xmlHttpRequest.onError = function() {
    	this.object.app.loadingDataContentPanel.hide();
    	
        alert("ERROR while executing showStats: " + this.response);
    }

	this.app.loadingDataContentPanel.show();
	this.statsButton.set("backgroundColor", "#FF9900");
	this.historyButton.set("backgroundColor", "rgb(120,172,255)");
	this.searchButton.set("backgroundColor", "rgb(120,172,255)");
	this.statsErrorsButton.show();
	this.statsTodayButton.show();
	this.detailsContentPanel.hide();
	if(!erIn) {
		this.statsErrorsButton.set("backgroundColor", "rgb(120,172,255)");
		this.statsTodayButton.set("backgroundColor", "rgb(120,172,255)");
	} else {
		this.statsErrorsButton.set("backgroundColor", "#FF9900");
		this.statsTodayButton.set("backgroundColor", "rgb(120,172,255)");
	}
	this.app.detailsWindow.hide();
	try {
    	xmlHttpRequest.send();
	} catch(e) {
		alert("ERROR (showStats):\n\n" + e);
	}
}



com.rogers.rci.ngws.TopContentPanel.prototype.showTodayStats = function() {
	this.app.resultsContentPanel.show();
	//this.app.resultsContentPanel.resetData();
	
	// fix Firefox...
    if (js.util.Browser.isFirefox) {
        try {
            netscape.security.PrivilegeManager.enablePrivilege("UniversalBrowserRead");
        } catch (e) {
            //alert("Permission UniversalBrowserRead denied.");
        }
    }
    
    // TO DO...
    var xmlHttpRequest = new js.ajax.XMLHttpRequest();
    xmlHttpRequest.set("url", this.app.appServicesURL);
    xmlHttpRequest.setVar("cmd", "statsToday");
    xmlHttpRequest.object = this;
    xmlHttpRequest.open();

    xmlHttpRequest.onComplete = function() {
        //alert(this.response);
        
        // eval the JSON data...
        var data = null;
        eval("data = " + this.response);
        
        // ...
        this.object.app.resultsContentPanel.resetData();
        if(data.items.length > 1) {
        	this.object.app.resultsContentPanel.buildTodayStatsData(data.items, data.item);
        } else {
        	alert("No data found.");
        }
        
        this.object.app.loadingDataContentPanel.hide();
    }
    xmlHttpRequest.onError = function() {
    	this.object.app.loadingDataContentPanel.hide();
    	
        alert("ERROR while executing showTodayStats: " + this.response);
    }

	this.app.loadingDataContentPanel.show();
	this.statsButton.set("backgroundColor", "#FF9900");
	this.historyButton.set("backgroundColor", "rgb(120,172,255)");
	this.searchButton.set("backgroundColor", "rgb(120,172,255)");
	this.statsErrorsButton.set("backgroundColor", "rgb(120,172,255)");
	this.statsTodayButton.set("backgroundColor", "#FF9900");
	this.app.detailsWindow.hide();
	//this.detailsContentPanel.hide();
	try {
    	xmlHttpRequest.send();
	} catch(e) {
		//alert("ERROR (showTodayStats):\n\n" + e);
	}
}



com.rogers.rci.ngws.TopContentPanel.prototype.search = function() {
	if(this.app.userID == "") {
		this.app.loginWindow.show();
		return;
	}
	
	if(this.keywordsTextbox.get("value").length == 0) {
		alert("Please enter the ECID.");
		return;
	}
		
	this.app.resultsContentPanel.show();
	this.app.resultsContentPanel.resetData();
	
	
	// fix Firefox...
    if (js.util.Browser.isFirefox) {
        try {
            netscape.security.PrivilegeManager.enablePrivilege("UniversalBrowserRead");
        } catch (e) {
            //alert("Permission UniversalBrowserRead denied.");
        }
    }
    
    // TO DO...
    var xmlHttpRequest = new js.ajax.XMLHttpRequest();
    xmlHttpRequest.set("url", this.app.appServicesURL);
    xmlHttpRequest.setVar("cmd", "search");
    xmlHttpRequest.setVar("k", this.keywordsTextbox.get("value"));
    xmlHttpRequest.setVar("typ", this.typesListbox.get("value"));
    xmlHttpRequest.object = this;
    xmlHttpRequest.open();

    xmlHttpRequest.onComplete = function() {
        //alert(this.response);
        
        // eval the JSON data...
        var data = null;
        eval("data = " + this.response);
        
        // ...
        this.object.app.resultsContentPanel.buildData(data);
        
        this.object.app.loadingDataContentPanel.hide();
    }
    xmlHttpRequest.onError = function() {
    	this.object.app.loadingDataContentPanel.hide();
    	
        alert("ERROR while executing search: " + this.response);
    }

	this.app.typeOfSearch = "main";
	this.app.loadingDataContentPanel.show();
	this.historyButton.set("backgroundColor", "rgb(120,172,255)");
	this.statsButton.set("backgroundColor", "rgb(120,172,255)");
	this.searchButton.set("backgroundColor", "#FF9900");
	this.statsErrorsButton.hide();
	this.statsTodayButton.hide();
	this.detailsContentPanel.hide();
	this.app.detailsWindow.hide();
	try {
    	xmlHttpRequest.send();
	} catch(e) {
		alert("ERROR (search):\n\n" + e);
	}
}



com.rogers.rci.ngws.TopContentPanel.prototype.searchHistory = function() {
	if(this.app.userID == "") {
		this.app.loginWindow.show();
		return;
	}
	
	if(this.keywordsTextbox.get("value").length == 0) {
		alert("Please enter the ECID.");
		return;
	}
	
	this.app.resultsContentPanel.show();
	this.app.resultsContentPanel.resetData();
	
	
	// fix Firefox...
    if (js.util.Browser.isFirefox) {
        try {
            netscape.security.PrivilegeManager.enablePrivilege("UniversalBrowserRead");
        } catch (e) {
            //alert("Permission UniversalBrowserRead denied.");
        }
    }
    
    // TO DO...
    var xmlHttpRequest = new js.ajax.XMLHttpRequest();
    xmlHttpRequest.set("url", this.app.appServicesURL);
    xmlHttpRequest.setVar("cmd", "searchHistory");
    xmlHttpRequest.setVar("k", this.keywordsTextbox.get("value"));
    xmlHttpRequest.setVar("typ", this.typesListbox.get("value"));
    xmlHttpRequest.object = this;
    xmlHttpRequest.open();

    xmlHttpRequest.onComplete = function() {
        //alert(this.response);
        
        // eval the JSON data...
        var data = null;
        eval("data = " + this.response);
        
        // ...
        this.object.app.resultsContentPanel.buildData(data);
        
        this.object.app.loadingDataContentPanel.hide();
    }
    xmlHttpRequest.onError = function() {
    	this.object.app.loadingDataContentPanel.hide();
    	
        alert("ERROR while executing searchHistory: " + this.response);
    }

	this.app.typeOfSearch = "history";
	this.app.loadingDataContentPanel.show();
	this.historyButton.set("backgroundColor", "#FF9900");
	this.statsButton.set("backgroundColor", "rgb(120,172,255)");
	this.searchButton.set("backgroundColor", "rgb(120,172,255)");
	this.statsErrorsButton.hide();
	this.statsTodayButton.hide();
	this.detailsContentPanel.hide();
	this.app.detailsWindow.hide();
	try {
    	xmlHttpRequest.send();
	} catch(e) {
		alert("ERROR (searchHistory):\n\n" + e);
	}
}
