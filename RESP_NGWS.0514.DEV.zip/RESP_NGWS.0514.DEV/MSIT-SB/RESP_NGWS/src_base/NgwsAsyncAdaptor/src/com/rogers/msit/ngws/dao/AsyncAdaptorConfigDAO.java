package com.rogers.msit.ngws.dao;

import java.sql.*;
import java.util.*;
import java.util.logging.*;

import com.rogers.msit.ngws.dao.base.*;
import com.rogers.msit.ngws.utils.*;



public class AsyncAdaptorConfigDAO extends BaseDAO {
	public List getConfigEntries() throws AsyncAdaptorDAOException {
		List ret = null;
		
		// params...

		// get data...
		Connection conn = null;
		try {
			conn = getConnection();
			ret = getDAOObjectList(conn, DAOUtils.getInstance().getQueries().getProperty("sql.GET_CONFIG_ENTRIES"), null);
		} catch(Exception e) {
			Constants.LOGGER.log(Level.SEVERE,  this.getClass().getName() + ".getConfigEntries error: " + e.toString());
			throw new AsyncAdaptorDAOException(e);
		} finally {
			closeConnection(conn);
		}
		
		return ret;
	}
	
	
	
	public List getErrorMessages() throws AsyncAdaptorDAOException {
		List ret = null;
		
		// params...

		// get data...
		Connection conn = null;
		try {
			conn = getConnection();
			ret = getDAOObjectList(conn, DAOUtils.getInstance().getQueries().getProperty("sql.GET_ERROR_MESSAGES"), null);
		} catch(Exception e) {
			Constants.LOGGER.log(Level.SEVERE,  this.getClass().getName() + ".getErrorMessages error: " + e.toString());
			throw new AsyncAdaptorDAOException(e);
		} finally {
			closeConnection(conn);
		}
		
		return ret;
	}
	
	
	
	public List getStatuses() throws AsyncAdaptorDAOException {
		List ret = null;
		
		// params...

		// get data...
		Connection conn = null;
		try {
			conn = getConnection();
			ret = getDAOObjectList(conn, DAOUtils.getInstance().getQueries().getProperty("sql.GET_STATUSES"), null);
		} catch(Exception e) {
			Constants.LOGGER.log(Level.SEVERE,  this.getClass().getName() + ".getStatuses error: " + e.toString());
			throw new AsyncAdaptorDAOException(e);
		} finally {
			closeConnection(conn);
		}
		
		return ret;
	}
	
	
	
	public boolean isControlEngineActive() throws AsyncAdaptorDAOException {
		boolean bRet = true;
		DAOObject ret = null;
		
		// params...
		
		// get data...
		Connection conn = null;
		try {
			conn = getConnection();
			
			ret = getDAOObject(conn, DAOUtils.getInstance().getQueries().getProperty("sql.GET_CONTROL_ENGINE_STATUS"), null);
			
			if(ret != null) {
				bRet = "Y".equals(ret.getString("CFG_VALUE"));
			}
		} catch(Exception e) {
			Constants.LOGGER.log(Level.SEVERE,  this.getClass().getName() + ".getControlEngineStatus error: " + e.toString());
			throw new AsyncAdaptorDAOException(e);
		} finally {
			closeConnection(conn);
		}
		
		return bRet;
	}
	
	
	
	public String getNextCommandToBeExecuted() throws AsyncAdaptorDAOException {
		String strRet = "-";
		DAOObject ret = null;
		
		// params...
		
		// get data...
		Connection conn = null;
		try {
			conn = getConnection();
			
			ret = getDAOObject(conn, DAOUtils.getInstance().getQueries().getProperty("sql.GET_NEXT_COMMAND_TO_BE_EXECUTED"), null);
			
			if(ret != null) {
				strRet = ret.getString("CFG_VALUE");
			}
		} catch(Exception e) {
			Constants.LOGGER.log(Level.SEVERE,  this.getClass().getName() + ".getNextCommandToBeExecuted error: " + e.toString());
			throw new AsyncAdaptorDAOException(e);
		} finally {
			closeConnection(conn);
		}
		
		return strRet;
	}
	
	
	
	public int updateNextCommandToBeExecuted(String strCommand) throws AsyncAdaptorDAOException {
		int nRet = -1;
		
		// params...

		// get data...
		Connection conn = null;
		PreparedStatement st = null;
		try {
			conn = getConnection();
			
			st = conn.prepareStatement(DAOUtils.getInstance().getQueries().getProperty("sql.UPDATE_ENGINE_STATUS_PARAM"));
			
			// result...
			st.setString(1, strCommand);
			st.setString(2, "CONTROL_ENGINE_NEXT_COMMAND");
			nRet = st.executeUpdate();
			
			//st = conn.prepareStatement(DAOUtils.getInstance().getQueries().getProperty("sql.UPDATE_NEXT_COMMAND_TO_BE_EXECUTED"));
			//st.setString(1, strCommand);
			
			nRet = st.executeUpdate();
		} catch(Exception e) {
			Constants.LOGGER.log(Level.SEVERE,  this.getClass().getName() + ".updateNextCommandToBeExecuted error: " + e.toString());
			throw new AsyncAdaptorDAOException(e);
		} finally {
			closeStatement(st);
			closeConnection(conn);
		}
		
		return nRet;
	}
	
	
	
	public int updateLastCommandResult(String strCommand, String strResult) throws AsyncAdaptorDAOException {
		int nRet = -1;
		
		// params...

		// get data...
		Connection conn = null;
		PreparedStatement st = null;
		try {
			conn = getConnection();
			conn.setAutoCommit(false);
			
			st = conn.prepareStatement(DAOUtils.getInstance().getQueries().getProperty("sql.UPDATE_ENGINE_STATUS_PARAM"));
			
			// result...
			st.setString(1, strResult);
			st.setString(2, "CONTROL_ENGINE_LAST_COMMAND_RESULT");
			nRet = st.executeUpdate();
			
			// command...
			st.setString(1, strCommand);
			st.setString(2, "CONTROL_ENGINE_LAST_COMMAND");
			nRet = st.executeUpdate();
			
			// timestamp...
			st.setString(1, Constants.DEFAULT_DATE_FORMAT.format(new java.util.Date()));
			st.setString(2, "CONTROL_ENGINE_LAST_COMMAND_TS");
			nRet = st.executeUpdate();
					
			conn.commit();
			conn.setAutoCommit(true);
		} catch(Exception e) {
			try {
				conn.rollback();
			} catch(SQLException sqle) {
				Constants.LOGGER.log(Level.SEVERE,  this.getClass().getName() + ".updateLastCommandResult rollback error: " + sqle.toString());
			}
			
			Constants.LOGGER.log(Level.SEVERE,  this.getClass().getName() + ".updateLastCommandResult error: " + e.toString());
			throw new AsyncAdaptorDAOException(e);
		} finally {
			closeStatement(st);
			closeConnection(conn);
		}
		
		return nRet;
	}
	
	
	
	public int updateEngineStatusParams(Properties params) throws AsyncAdaptorDAOException {
		int nRet = -1;
		
		// params...

		// get data...
		Connection conn = null;
		PreparedStatement st = null;
		try {
			conn = getConnection();
			conn.setAutoCommit(false);
			
			st = conn.prepareStatement(DAOUtils.getInstance().getQueries().getProperty("sql.UPDATE_ENGINE_STATUS_PARAM"));
			
			Enumeration keys = params.keys();
			String strVal = "";
			String strKey = "";
			while(keys.hasMoreElements()) {
				strKey = (String)keys.nextElement();
				strVal = params.getProperty(strKey);
				if((strVal == null) || "".equals(strVal)) {
					strVal = "-";
				}
				
				st.setString(1, strVal);
				st.setString(2, strKey);
				
				nRet = st.executeUpdate();
				
			}
			
			conn.commit();
			conn.setAutoCommit(true);
		} catch(Exception e) {
			try {
				conn.rollback();
			} catch(SQLException sqle) {
				Constants.LOGGER.log(Level.SEVERE,  this.getClass().getName() + ".updateEngineStatusParams rollback error: " + sqle.toString());
			}
			
			Constants.LOGGER.log(Level.SEVERE,  this.getClass().getName() + ".updateEngineStatusParams error: " + e.toString());
			throw new AsyncAdaptorDAOException(e);
		} finally {
			closeStatement(st);
			closeConnection(conn);
		}
		
		return nRet;
	}
	
	
	
	public List getEngineStatusParams() throws AsyncAdaptorDAOException {
		List ret = null;
		
		// params...

		// get data...
		Connection conn = null;
		try {
			conn = getConnection();
			ret = getDAOObjectList(conn, DAOUtils.getInstance().getQueries().getProperty("sql.GET_ENGINE_STATUS_PARAMS"), null);
		} catch(Exception e) {
			Constants.LOGGER.log(Level.SEVERE,  this.getClass().getName() + ".getEngineStatusParams error: " + e.toString());
			throw new AsyncAdaptorDAOException(e);
		} finally {
			closeConnection(conn);
		}
		
		return ret;
	}
}
