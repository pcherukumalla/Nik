package com.async.jms.common.utils;

import java.util.Iterator;
import java.util.Map.Entry;

import javax.jms.*;
import javax.naming.InitialContext;

public class JmsUtils
{
	private QueueConnectionFactory queueConnectionFactory = null;
	private javax.jms.Queue queue = null;
	private QueueConnection connection = null;
	private QueueSession session = null;
	private QueueSender sender = null; 
	private String JMS_CONN_FACTORY_JNDI = null;
	private String JMS_QUEUE_JNDI = null;
	
	protected void prepareSupportJMSArtifacts()
		throws Exception 
	{
		try
		{
			if( ( this.queueConnectionFactory == null) || (this.queue == null) )
			{
				
				InitialContext ic = new InitialContext();
				
				this.queueConnectionFactory = (QueueConnectionFactory)ic.lookup( JMS_CONN_FACTORY_JNDI );
				this.queue = (javax.jms.Queue)ic.lookup( JMS_QUEUE_JNDI );
			}
			
			this.connection = this.queueConnectionFactory.createQueueConnection();
			this.session = this.connection.createQueueSession(true, Session.AUTO_ACKNOWLEDGE);
			this.sender = this.session.createSender(this.queue);
		}
		catch (Exception ex)
		{
			commitClose();
			
			Throwable e1=ex;
			while (e1.getCause() != null ) e1 = e1.getCause();
			throw new Exception (e1);
		}
	}

	public void sendMessage(String strMsg, String correlationID, java.util.HashMap<String, String> paramsMap) 	
		throws Exception
	{       
            BytesMessage message = this.session.createBytesMessage();
            message.setJMSCorrelationID("" +  correlationID);
            Iterator<Entry<String,String>> it = paramsMap.entrySet().iterator();
            while (it.hasNext()) {
				java.util.Map.Entry<String,String> pairs = (java.util.Map.Entry<String,String>)it.next();
                message.setStringProperty("" + pairs.getKey(), "" + pairs.getValue());
            }            

            message.writeBytes( strMsg.getBytes() );
            this.sender.send(message);	
            
            commitClose();
	}

	protected void commitClose() 
	throws Exception 
	{
		if (this.session != null) 
			this.session.commit();
		
		if(this.sender != null) {
			this.sender.close();
		}
		
		if (this.session != null) {
			this.session.close();
		}
	
	    if (this.connection != null) {
	    	this.connection.close();
	    }
	    
	    this.sender = null;
	    this.session = null;
	    this.connection = null;
	}

	protected void setJMS_CONN_FACTORY_JNDI(String jMS_CONN_FACTORY_JNDI) {
		JMS_CONN_FACTORY_JNDI = jMS_CONN_FACTORY_JNDI;
	}

	protected void setJMS_QUEUE_JNDI(String jMS_QUEUE_JNDI) {
		JMS_QUEUE_JNDI = jMS_QUEUE_JNDI;
	}

	protected String getJMS_CONN_FACTORY_JNDI() {
		return JMS_CONN_FACTORY_JNDI;
	}

	protected String getJMS_QUEUE_JNDI() {
		return JMS_QUEUE_JNDI;
	}
}