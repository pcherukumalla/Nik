package com.rogers.rci.nrm;

import com.async.engine.common.services.AsyncAdaptorService;
import com.async.jms.common.utils.JmsUtils;
import com.async.jms.common.utils.JmsUtilsFactory;


public class AsyncJMSReaderHelper extends AsyncReaderBase 
{
	private static JmsUtils workerToDestination = null;
	private static JmsUtils workerToErrorDestination = null;

	public static void processMessage(javax.jms.Message msg)
	throws Exception
	{		
		String msgReceived = null;		
		//long startTime = System.currentTimeMillis();
		
		if (msg instanceof javax.jms.TextMessage)
		{
			javax.jms.TextMessage textMessage = (javax.jms.TextMessage) msg;
			msgReceived = textMessage.getText();
		}
		if (msg instanceof javax.jms.BytesMessage)
		{
		    javax.jms.BytesMessage textMessage = (javax.jms.BytesMessage) msg;
		    byte[] bytes = new byte[(int) textMessage.getBodyLength()];
		    textMessage.readBytes(bytes);
	
		    msgReceived = new String(bytes, "UTF-8");			    
		}
		
		String correlationID = msg.getJMSCorrelationID()==null?"":msg.getJMSCorrelationID();
		//TODO: remove system.out
		//System.out.println(new StringBuffer("Handle SAM msg: ").append( "" + msg.getJMSMessageID() ).toString());
		//System.out.println("CorrelationID: " + correlationID);
		//System.out.println("*********** MESAGE RECEIVED By EJB: " + msgReceived);
		
		correlationID = correlationID.replaceAll("<", "").replaceAll(">", "").trim();
		try
		{
			workerToDestination = JmsUtilsFactory.getInstance( NRMReaderConstants.JMS_CONNECTION_FACTORY_JNDI, NRMReaderConstants.JMS_DESTINATION_QUEUE_JNDI);
			// NOTE: for JMS Readers, the correlationID is coming in JMS Header JMSCorrelationId
			workerToDestination.sendMessage( getCustomizedMsg(msg, msgReceived), correlationID, getExtraParamsMap(msg)); 
		}
		catch (Exception ex)
		{			
			workerToErrorDestination = JmsUtilsFactory.getInstance( NRMReaderConstants.JMS_CONNECTION_FACTORY_JNDI, NRMReaderConstants.JMS_ERROR_DESTINATION_QUEUE_JNDI);
			// NOTE: for JMS Readers, the correlationID is coming in JMS Header JMSCorrelationId
			workerToErrorDestination.sendMessage( getCustomizedMsg(msg, msgReceived), correlationID, getExtraParamsMap(msg));
			System.out.println("Exception in MscMessageBean: routed message to " + NRMReaderConstants.JMS_ERROR_DESTINATION_QUEUE_JNDI);
			//Throwable e1=ex;
			//while ( e1.getCause() !=null ) e1=e1.getCause();
			ex.printStackTrace();
		}
			
		//System.out.println("Content:" + getCustomizedMsg(msg, msgReceived));
		
		//System.out.println( "Duration: " + (System.currentTimeMillis() - startTime));		
		//java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss SSS");
		//System.out.println( "Now is: " + sdf.format( java.util.Calendar.getInstance().getTime() ));
	}

	
	private static String getCustomizedMsg(javax.jms.Message msg, String txtMessage )
	throws Exception
	{	
		StringBuffer tmpBuff = new StringBuffer("");	
		
		// TODO: for JMS Readers, the correlationID is coming in JMS Header JMSCorrelationId. is used in the send method directly, NOT here.
		String jmsCorrelationId = msg.getJMSMessageID()!=null?msg.getJMSMessageID().replaceAll("<", "").replaceAll(">", "").trim():"";
		String tmp = null;
			
		//add message to customized message
		tmp = XMLWrapperConstants.MSG_NODE.replace(XMLWrapperConstants.DATA_PLACE_HOLDER, txtMessage);
		tmpBuff.append( tmp );		
	
		//add correlation id to customized message
		tmp = XMLWrapperConstants.ELEMENT_NODE.replace(XMLWrapperConstants.ELEMENT_DELIMITER ,XMLWrapperConstants.MESSAGE_ID);
		tmp=tmp.replace(XMLWrapperConstants.DATA_PLACE_HOLDER, jmsCorrelationId);
		tmpBuff.append( tmp );
		
		//final value:
		tmp = XMLWrapperConstants.ROOT_NODE.replace(XMLWrapperConstants.DATA_PLACE_HOLDER, tmpBuff.toString() );
	
		return tmp;
	}		

	/**
	 * Should set all mentioned in AsyncReaderBase such as:
	 * MSGTYPE
	 * SZKEY
	 * FILTERKEY
	 * CORRLIST (list of name/value pairs delimited by 'e##e' delimiter)
	 */	
	private static java.util.HashMap<String,String> getExtraParamsMap(javax.jms.Message msg)
		throws Exception
	{
		java.util.HashMap<String,String> extraParamsMap = new java.util.HashMap<String,String>();
		
		//TODO: category is NOT in use FOR NOW... may be required later
		extraParamsMap.put(XMLWrapperConstants.MSG_CATEGORY, XMLWrapperConstants.MSG_CURRENT_CATEGORY);
		
		// set MSGTYPE		
		String msgType = msg.getStringProperty(AsyncReaderBase.MSGTYPE_FLAG);
		extraParamsMap.put(MSGTYPE_FLAG, msgType);
		
		//set SZKEY
		//System.out.println( "Retrieve SZKEY for MSGTYPE: " + msgType);
		//String szkey = msg.getStringProperty(BLOCK_KEY_FLAG)!=null?msg.getStringProperty(BLOCK_KEY_FLAG).trim():"";
		com.async.engine.common.MessageInterface msgInterfHandler = AsyncAdaptorService.getMessageInterface( msgType );
		String szkey = msgInterfHandler.getSzKey( msg );
		extraParamsMap.put(BLOCK_KEY_FLAG, szkey);	

		//set FILTERKEY
		String filterkey = msg.getStringProperty(FILTER_KEY_FLAG)!=null?msg.getStringProperty(FILTER_KEY_FLAG).trim():"";
		if (isNullOrEmpty(filterkey))
		{
			System.out.println("*** AsyncJMSReaderHelper.getExtraParamsMap -> Default filter key set for " + msgType);
			filterkey = getRandomBeanFilter();
		}
		extraParamsMap.put(FILTER_KEY_FLAG, filterkey);
		
		//set CORRLIST
		String corrList = msg.getStringProperty(MSG_CORRELATION_LIST_FLAG)!=null?msg.getStringProperty(MSG_CORRELATION_LIST_FLAG).trim().replaceAll("<", "").replaceAll("<", ""):"";
		extraParamsMap.put(MSG_CORRELATION_LIST_FLAG, corrList);

		return extraParamsMap;
	}


}
