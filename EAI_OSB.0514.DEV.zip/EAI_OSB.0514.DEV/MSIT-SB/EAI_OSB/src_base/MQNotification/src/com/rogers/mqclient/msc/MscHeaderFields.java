package com.rogers.mqclient.msc;

public class MscHeaderFields implements java.io.Serializable
{
	private static final long serialVersionUID = 1L;
		
	private String mscHeaderFromSS;
	private long lengthReceived = 0;
	
	public MscHeaderFields( String header )
	{
		mscHeaderFromSS = header;
		if ( header.length() > 0 ) setLengthReceived( header.length() );
	}

	public String getServerId()
	{
		return mscHeaderFromSS.substring( 6, 14 );
	}

	public String getActionCode()
	{
		return mscHeaderFromSS.substring( 14, 18 );
	}

	public String getCompany()
	{
		return mscHeaderFromSS.substring( 18, 21 );
	}

	public String getUserId()
	{
		return mscHeaderFromSS.substring( 21, 29 );
	}

	public String getResourceToken()
	{
		return mscHeaderFromSS.substring( 29, 33 );
	}

	public long getLengthReceived() {
		return lengthReceived;
	}

	private void setLengthReceived(long lengthReceived) {
		this.lengthReceived = lengthReceived;
	}
}