package com.async.engine.common.services;

import java.util.*;
import java.util.logging.*;

import javax.naming.*;
import javax.sql.*;

import com.async.engine.common.*;
import com.async.engine.common.dao.*;
import com.async.engine.common.dao.base.*;
import com.async.engine.common.utils.*;



public class AsyncAdaptorService {
	private static long lastRefreshTime = 0;
	private static String lastRefreshTimeAsString = "";
	private static HashMap errorMessages = new HashMap();
	private static Properties errorDescriptions = new Properties();
	private static HashMap messageTypes = new HashMap();
	private static HashMap messageTypesByStr = new HashMap();
	private static Object refreshSyncObject = new Object();
	
	protected static CommonDAOComponent commonDAOComponent = null;
	
	static {
		try {
			// try first to get data source name from JVM system property (-Dae.config.datasource=mydatasource)...
			String strDataSourceName = System.getProperty(Constants.DATA_SOURCE_CONFIG_NAME);
			// if no one found then use the default one...
			if(strDataSourceName == null) {
				Constants.LOGGER.log(Level.WARNING, "Unable to retrieve the data source name from JVM startup config, will use the default one: " + Constants.DEFAULT_DATA_SOURCE_JNDI_NAME);
				strDataSourceName = Constants.DEFAULT_DATA_SOURCE_JNDI_NAME;
			}
			
			// obtain initial context...
			InitialContext ctx = new InitialContext();
			// get data source...
			DataSource dataSource = (DataSource)ctx.lookup(strDataSourceName);
			if(dataSource == null) {
				throw new AsyncAdaptorServiceException("No data source found with this name: " + strDataSourceName);
			}
			
			// create the DAO component and set the datasource...
			commonDAOComponent = new CommonDAOComponent();
			commonDAOComponent.setDataSource(dataSource);
		} catch(Exception e) {
			Constants.LOGGER.log(Level.SEVERE, "com.async.engine.common.services.AsyncAdaptorService - Unable to create data source: " + e.toString());
		}
	}
	
	
	
	public static MessageInterface getMessageInterface(String msgType) throws Exception {
		// refresh data from the database if expired...
		refreshConfig();
		
		DAOObject typ = (DAOObject)messageTypesByStr.get(msgType);
		if(typ == null) {
			return null;
		} else {
			MessageInterface ret = (MessageInterface)typ.get("MSG_INTERFACE_INSTANCE");
			
			if(ret == null) {
				ret = (MessageInterface)Class.forName(typ.getString("MSG_INTERFACE_CLASS")).newInstance();
				typ.set("MSG_INTERFACE_INSTANCE", ret);
			}
					
			return ret;
		}
	}
	
	
	
	public static MessageInterface getMessageInterface(int msgTypeId) throws Exception {
		// refresh data from the database if expired...
		refreshConfig();
		
		DAOObject typ = (DAOObject)messageTypes.get(new Integer(msgTypeId));
		if(typ == null) {
			return null;
		} else {
			return getMessageInterface(typ.getString("MSGTYPE"));
		}
	}
	
	
	
	public static DAOObject getMessageType(String msgType) throws Exception {
		// refresh data from the database if expired...
		refreshConfig();
		
		DAOObject ret = (DAOObject)messageTypesByStr.get(msgType); 
		if(ret == null) {
			ret = (DAOObject)messageTypes.get(Constants.UNKNOWN_MESSAGE_TYPE_ID);
		}
		
		return ret;
	}
	
	
	
	public static DAOObject getMessageType(int msgTypeId) throws Exception {
		// refresh data from the database if expired...
		refreshConfig();
		
		DAOObject ret = (DAOObject)messageTypes.get(msgTypeId);
		if(ret == null) {
			ret = (DAOObject)messageTypes.get(Constants.UNKNOWN_MESSAGE_TYPE_ID);
		}
		
		return ret;
	}
	
	
	
	public static void push(String msgType, String szKey, String message) throws Exception {
		// refresh data from the database if expired...
		refreshConfig();

		boolean bUnknown = false;
		DAOObject typ = (DAOObject)messageTypesByStr.get(msgType);
		if(typ == null) {
			bUnknown = true;
			
			typ = (DAOObject)messageTypes.get(new Integer(Constants.UNKNOWN_MESSAGE_TYPE_ID));
		}
		
		if(bUnknown) {
			commonDAOComponent.insertUnknownMessage(szKey, message, msgType, typ, lastRefreshTimeAsString);
		} else {
			commonDAOComponent.insertMessage(szKey, message, typ, lastRefreshTimeAsString);
		}
	}
		
	
	
	public static void acknowledge(long msgId, int msgTypeId, String errorCd, String errorDesc) throws Exception {
		// refresh data from the database if expired...
		refreshConfig();
		
		// get the details for this error and use the default error if the sent one not found in the current configuration...
		DAOObject err = (DAOObject)errorMessages.get(errorCd);
		if(err == null) {
			//err = (DAOObject)errorMessages.get(Constants.ERROR);
			err = getErrorByDescription(errorDesc);
		}
		
		// get type details for this message...
		DAOObject typ = (DAOObject)messageTypes.get(new Integer(msgTypeId));
		if(typ == null) {
			throw new AsyncAdaptorServiceException("Unknown message type: " + msgTypeId);
		}
		
		// update/move message...
		commonDAOComponent.updateMessageAfterProcessing(msgId, errorCd,	errorDesc, err, typ, lastRefreshTimeAsString);
	}
	
	
	
	public static void acknowledge(long msgId, int msgTypeId, String correlationId) throws Exception {
		acknowledge(msgId, msgTypeId, Constants.OK, correlationId);
	}
	
	
	
	public static void acknowledge(long msgId, int msgTypeId) throws Exception {
		acknowledge(msgId, msgTypeId, Constants.OK, "");
	}
	
	
	
	private static DAOObject getErrorByDescription(String errorDesc) {
		DAOObject ret = null;
		
		if(errorDescriptions.size() > 0) {
			Enumeration enumNames = errorDescriptions.propertyNames();
			
			String strName = "";
			while(enumNames.hasMoreElements()) {
				strName = (String)enumNames.nextElement();
				
				if(errorDesc.indexOf(strName) != -1) {
					ret = (DAOObject)errorMessages.get(errorDescriptions.getProperty(strName));
					
					break;
				}
			}
		}
		
		if(ret == null) {
			ret = (DAOObject)errorMessages.get(Constants.ERROR);
		}
		
		return ret;
	}
	
	
	
	private static void refreshConfig() throws Exception {
		long currentTime = System.currentTimeMillis();
		
		// if more then Constants.ERROR_MESSAGES_REFRESH_PERIOD minutes have passed then refresh...
		if(currentTime - lastRefreshTime > Constants.ERROR_MESSAGES_REFRESH_PERIOD) {
			synchronized(refreshSyncObject) {
				// get message types from the database...
				List entries = commonDAOComponent.getErrorMessages();
				List entries2 = commonDAOComponent.getMessageTypes();
				List entries3 = commonDAOComponent.getErrorDescriptions();
				
				// cache data...
				errorMessages.clear();
				errorDescriptions.clear();
				messageTypes.clear();
				messageTypesByStr.clear();
				
				// error messages...
				DAOObject o = null;
				for(int i = 0; i < entries.size(); i++) {
					o = (DAOObject)entries.get(i);
					
					errorMessages.put(o.getString("ERR_CD"), o);
				}
				
				// error descriptions...
				DAOObject o3 = null;
				for(int i = 0; i < entries3.size(); i++) {
					o3 = (DAOObject)entries3.get(i);
					
					errorDescriptions.setProperty(o3.getString("DESCRIPTION"), o3.getString("ERR_CD"));
				}
				
				// message types...
				DAOObject o2 = null;
				for(int i = 0; i < entries2.size(); i++) {
					o2 = (DAOObject)entries2.get(i);
					
					messageTypes.put(new Integer(o2.getInt("MSGTYPE_ID")), o2);
					messageTypesByStr.put(o2.getString("MSGTYPE"), o2);
				}
		
				// store the current time...
				lastRefreshTime = currentTime;
				lastRefreshTimeAsString = Constants.STATS_DATE_FORMAT.format(new Date(lastRefreshTime));
			}
		}
	}
}


