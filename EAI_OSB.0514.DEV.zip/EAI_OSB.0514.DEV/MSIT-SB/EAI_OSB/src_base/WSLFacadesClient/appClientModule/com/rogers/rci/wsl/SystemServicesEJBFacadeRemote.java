package com.rogers.rci.wsl;

import java.rmi.RemoteException;
import javax.ejb.EJBObject;
import org.apache.xmlbeans.XmlObject;

public abstract interface SystemServicesEJBFacadeRemote extends EJBObject
{
  public abstract XmlObject retrieveSystemInformation(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject testSystem(XmlObject paramXmlObject)
    throws RemoteException, Exception;
}