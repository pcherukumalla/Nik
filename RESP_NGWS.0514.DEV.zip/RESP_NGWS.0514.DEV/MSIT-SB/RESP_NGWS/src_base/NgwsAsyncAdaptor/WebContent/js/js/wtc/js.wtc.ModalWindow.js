/*
****************************************************************************************************
 ezWebToolkit Library, http://ezwt.blogspot.com
****************************************************************************************************
Copyright [2006-2008] [Pro Net Systems Inc., http://www.pronetsystems.com]

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

	http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
***************************************************************************************************
*/



/*
------------------------------------------------------------------------------------------
ModalWindow
------------------------------------------------------------------------------------------
*/
js.wtc.ModalWindow = function(p) {
	js.wtc.Window.call(this);

	this.windowParent = null;
	if(p) {
		this.windowParent = p;
	}

	this.cover = null;
	
	this.objectType = "js.wtc.ModalWindow";
}
js.wtc.ModalWindow.prototype = new js.wtc.Window();
js.wtc.ModalWindow.prototype.constructor = js.wtc.ModalWindow;



js.wtc.ModalWindow.prototype.init = function() {
	js.wtc.Window.prototype.init.call(this);

	this.cover = new js.wtc.ContentPanel();
	this.cover.init();
	this.cover.set("filter", "alpha(opacity=40)");
	this.cover.set("MozOpacity", 0.40);
	this.cover.set("KhtmlOpacity", 0.40);
	this.cover.set("opacity", 0.40);
	this.cover.set("backgroundColor", "#AFAFAF");
}



js.wtc.ModalWindow.prototype.hide = function() {
	js.wtc.Window.prototype.hide.call(this);

	this.cover.hide();
}



js.wtc.ModalWindow.prototype.show = function() {
	if(this.windowParent != null) { // if the window has a parent then cover only the parent...
		var pos = this.windowParent.get("pos");

		if(document.all) {
			this.cover.set("left", (pos.left - 2) + "px");
			this.cover.set("top", (pos.top - 2) + "px");
			this.cover.set("width", (pos.width + 1) + "px");
			this.cover.set("height",  (pos.height + 1) + "px");
		} else {
			this.cover.set("left", pos.left + "px");
			this.cover.set("top", pos.top + "px");
			this.cover.set("width", pos.width + "px");
			this.cover.set("height",  pos.height + "px");
		}

		if(this.windowParent.get("zIndex") != "") {
			this.cover.set("zIndex", "" + (parseInt(this.windowParent.get("zIndex"))+ 1));
		} else {
			this.cover.set("zIndex", "1");
		}
	} else { // if the window has NO parent then cover the whole active screen area...
		this.cover.set("left", "0px");
		this.cover.set("top", "0px");
		this.cover.set("width", js.wtc.Manager.getGlobalWidth());
		this.cover.set("height", js.wtc.Manager.getGlobalHeight());
		this.cover.set("zIndex", "" + (parseInt(js.wtc.Manager.getMaxZIndex())+ 1));
	}
	
	this.cover.show();
	this.set("zIndex", "" + (parseInt(this.cover.get("zIndex")) + 1));
	
	js.wtc.Window.prototype.show.call(this);
}
