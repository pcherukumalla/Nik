package com.rogers.msit.ngws.dao.base;



public class BaseDAOException extends Exception {
	final private static long serialVersionUID = -197010084L;
	
	
	
	public BaseDAOException() {
		super();
	}
	
	
	
	public BaseDAOException(String message) {
		super(message);
	}
	
	
	
	public BaseDAOException(String message, Throwable cause) {
		super(message, cause);
	}
	
	
	
	public BaseDAOException(Throwable cause) {
		super(cause);
	}
}