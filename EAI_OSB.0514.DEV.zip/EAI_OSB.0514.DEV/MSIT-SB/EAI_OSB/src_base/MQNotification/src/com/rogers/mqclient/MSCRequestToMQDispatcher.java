package com.rogers.mqclient;

import com.rogers.logger.utility.UtilityLogger;
import com.rogers.mqclient.get.GetNativeMSCResponseFromMQ;
import com.rogers.mqclient.msc.GetMSCResponseInterface;
import com.rogers.mqclient.msc.SendMSCInterface;
import com.rogers.mqclient.send.SendNativeMSCRequestToMQ;

public class MSCRequestToMQDispatcher implements SendMSCInterface, GetMSCResponseInterface
{
    private static SendMSCInterface sendInterface = new SendNativeMSCRequestToMQ();
    private static GetMSCResponseInterface getInterface = new GetNativeMSCResponseFromMQ();

    public void setRequestPrerequisites(String mqconfiguration, boolean resetMqConn, boolean resetMqDetail, String correlationId, String mscMsgReceived, String password)
    	throws Exception
    {
    	sendInterface.setPrerequisites( mqconfiguration, resetMqConn, resetMqDetail, correlationId, mscMsgReceived, password);
    }
    
    public void setResponsePrerequisites(String mqconfiguration, boolean resetMqConn, boolean resetMqDetail, String correlationId, String mscMsgReceived, String password)
		throws Exception
	{
		getInterface.setPrerequisites( mqconfiguration, resetMqConn, resetMqDetail, correlationId, mscMsgReceived, password);
	}    


    public void resetMSCReqConnection()
    {
    	sendInterface.resetConnection();
    }
    public void resetMSCRespConnection()
    {
    	getInterface.resetConnection();
    }    
	
	public String getMSCResponse(byte[] correlationId) throws Exception {
		 long startTime = System.currentTimeMillis();
		 String mscResponse = getInterface.getMSCResponse(correlationId);
		 UtilityLogger.getLogger().info("Duration MSC get (msec):" + (System.currentTimeMillis() - startTime));	
		 return mscResponse;
	}

	public byte[] putMSCMessage(String txtMessage, String session, String typeOfCall) 
		throws Exception 
	{
		  long startTime = System.currentTimeMillis();

		  byte[] msgId = sendInterface.putMSCMessage(txtMessage, session, typeOfCall);

		  UtilityLogger.getLogger().info("Duration MSC put (msec):" + (System.currentTimeMillis() - startTime));
		  return msgId;
	}
	
	
	public void setPrerequisites(String mqconfiguration, boolean resetMqConn,
			boolean resetMqDetail, String correlationId, String mscMsgReceived,
			String returnCodeOrPassword) throws Exception 
	{
		throw new Exception("Not to be used for sync MSC calls");		
	}
	
    /**
     * @param txtMessage
     * @throws Exception
     */
	public void putMessage( String txtMessage )
        throws Exception
	{
		throw new Exception("Not to be used for sync MSC calls");
    }

	public void resetConnection() {
		//"Not to be used for sync MSC calls";		
	}	

}