package com.rogers.rci.csl.sam.header;

public class SAMMQHeaderUtils extends com.async.engine.common.DefaultMessageInterface
{
	private String msgType= null;
	
	/**
	 * @param message - expects whole message with SSC header
	 */
	@Override
	public String getSzKey(String message) 
		throws Exception 
	{		
		setMsgType( SAMMQMessagetype.getMsgType( message ) );
		String[] otherInfo = getOtherInfo( this.msgType ).split(",");		
		
		String tmp = message.substring(SAMMQMessagetype.SSC_HEADER_LENGTH);
		
		if ( otherInfo.length == 0 ) throw new Exception("OTHER INFO is mandatory for each type of message" + getMsgType());
		
		//prefix the SZKEY with client identifier:
		tmp = tmp.substring(Integer.parseInt(otherInfo[0]), Integer.parseInt(otherInfo[1]));
		tmp = tmp.replaceAll("\\W","").toUpperCase().trim(); //remove all unexpected type of chars
		
		return tmp;
	}
	
	public void setMsgType(String value)
	{
		this.msgType = value;
	}	
	private String getMsgType()
	{
		return ("" + this.msgType);
	}
}