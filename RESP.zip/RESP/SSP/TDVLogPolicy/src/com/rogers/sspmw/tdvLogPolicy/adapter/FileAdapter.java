package com.rogers.sspmw.tdvLogPolicy.adapter;

import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.rogers.sspmw.tdvLogPolicy.MessageBean;
import com.rogers.sspmw.tdvLogPolicy.exception.TDVException;

public class FileAdapter implements ILogAdapter{
	static Logger dataLogger = Logger.getLogger("tdvRequestLog");
	
	@Override
	public void log(MessageBean message) throws TDVException {
		dataLogger.info(message.getTDVMessage());
	}


	@Override
	public void initAdapter(Properties properties) throws TDVException {
		PropertyConfigurator.configure(properties);
	}


}
