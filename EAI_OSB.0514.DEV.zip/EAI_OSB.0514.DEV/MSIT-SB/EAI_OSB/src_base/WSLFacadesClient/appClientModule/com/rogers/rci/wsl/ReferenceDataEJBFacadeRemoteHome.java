package com.rogers.rci.wsl;

import java.rmi.RemoteException;
import javax.ejb.CreateException;
import javax.ejb.EJBHome;

public abstract interface ReferenceDataEJBFacadeRemoteHome extends EJBHome
{
  public abstract ReferenceDataEJBFacadeRemote create()
    throws CreateException, RemoteException, CreateException;
}