package com.rogers.mqclient.cache;

import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueSession;

public class JMSCacheVO {
    private static QueueConnectionFactory factory = null;
    private static QueueConnection connection = null;    
    private static QueueSession session = null;
    private static javax.jms.Queue queue = null;
    
    private static String RESET_MQ_CONN = null;
    private static String RESET_MQ_DETAIL = null;
	
    public static QueueConnectionFactory getFactory() {
		return factory;
	}
	public static void setFactory(QueueConnectionFactory factory) {
		JMSCacheVO.factory = factory;
	}
	public static QueueConnection getConnection() {
		return connection;
	}
	public static void setConnection(QueueConnection connection) {
		JMSCacheVO.connection = connection;
	}
	public static QueueSession getSession() {
		return session;
	}
	public static void setSession(QueueSession session) {
		JMSCacheVO.session = session;
	}
	public static javax.jms.Queue getQueue() {
		return queue;
	}
	public static void setQueue(javax.jms.Queue queue) {
		JMSCacheVO.queue = queue;
	}
	public static String getRESET_MQ_CONN() {
		return RESET_MQ_CONN;
	}
	public static void setRESET_MQ_CONN(String reset_mq_conn) {
		RESET_MQ_CONN = reset_mq_conn;
	}
	public static String getRESET_MQ_DETAIL() {
		return RESET_MQ_DETAIL;
	}
	public static void setRESET_MQ_DETAIL(String reset_mq_detail) {
		RESET_MQ_DETAIL = reset_mq_detail;
	}
    

}
