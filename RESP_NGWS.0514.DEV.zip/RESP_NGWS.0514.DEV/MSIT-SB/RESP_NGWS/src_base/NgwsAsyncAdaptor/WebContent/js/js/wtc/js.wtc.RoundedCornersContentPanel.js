/*
****************************************************************************************************
ezWebToolkit Library, http://www.ezwebtoolkit.com
****************************************************************************************************
Copyright [2006-2008] [Pro Net Systems Inc., http://www.pronetsystems.com]

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
***************************************************************************************************
*/



/*
------------------------------------------------------------------------------------------
RoundedCornersContentPanel
------------------------------------------------------------------------------------------
based on this article: http://www.html.it/articoli/nifty/index.html
*/
document.write("<style type=\"text/css\">");
document.write(".RCCP_top, .RCCP_bottom {");
document.write("    display:block;");
document.write("    background:transparent; font-size:1px;");
document.write("}");

document.write(".RCCP_b1, .RCCP_b2, .RCCP_b3, .RCCP_b4 {");
document.write("    display:block;");
document.write("    overflow:hidden;");
document.write("}");

document.write(".RCCP_b1, .RCCP_b2, .RCCP_b3 {");
document.write("    height:1px;");
document.write("}");

document.write(".RCCP_b2, .RCCP_b3, .RCCP_b4 {");
document.write("    background:#FFFFFF;");
document.write("    border-left:1px solid #000000;");
document.write("    border-right:1px solid #000000;");
document.write("}");

document.write(".RCCP_b1 { margin:0 5px; background:#000000; }");
document.write(".RCCP_b2 {margin:0 3px; border-width:0 2px;}");
document.write(".RCCP_b3 {margin:0 2px;}");
document.write(".RCCP_b4 {height:2px; margin:0 1px;}");
document.write("</style>");



js.wtc.RoundedCornersContentPanel = function() {
    js.wtc.ContentPanel.call(this);

    this.bodyContentPanel = null;
    
    this.topXB1 = null;
    this.topXB2 = null;
    this.topXB3 = null;
    this.topXB4 = null;

    this.bottomXB1 = null;
    this.bottomXB2 = null;
    this.bottomXB3 = null;
    this.bottomXB4 = null;

    this.objectType = "js.wtc.RoundedCornersContentPanel";
}
js.wtc.RoundedCornersContentPanel.prototype = new js.wtc.ContentPanel();
js.wtc.RoundedCornersContentPanel.prototype.constructor = js.wtc.RoundedCornersContentPanel;


js.wtc.RoundedCornersContentPanel.prototype.addTop = function() {
    var d = document.createElement("B");
    d.className = "RCCP_top";

    this.topXB1 = document.createElement("B");
    this.topXB1.className = "RCCP_b1";
    d.appendChild(this.topXB1);

    this.topXB2 = document.createElement("B");
    this.topXB2.className = "RCCP_b2";
    d.appendChild(this.topXB2);

    this.topXB3 = document.createElement("B");
    this.topXB3.className = "RCCP_b3";
    d.appendChild(this.topXB3);

    this.topXB4 = document.createElement("B");
    this.topXB4.className = "RCCP_b4";
    d.appendChild(this.topXB4);

    this.viewport().insertBefore(d, this.viewport().firstChild);
}



js.wtc.RoundedCornersContentPanel.prototype.addBottom = function() {
    var d = document.createElement("B");
    d.className = "RCCP_bottom";

    this.bottomXB4 = document.createElement("B");
    this.bottomXB4.className = "RCCP_b4";
    d.appendChild(this.bottomXB4);

    this.bottomXB3 = document.createElement("B");
    this.bottomXB3.className = "RCCP_b3";
    d.appendChild(this.bottomXB3);

    this.bottomXB2 = document.createElement("B");
    this.bottomXB2.className = "RCCP_b2";
    d.appendChild(this.bottomXB2);

    this.bottomXB1 = document.createElement("B");
    this.bottomXB1.className = "RCCP_b1";
    d.appendChild(this.bottomXB1);

    this.viewport().appendChild(d, this.viewport().firstChild);
}



js.wtc.RoundedCornersContentPanel.prototype.init = function() {
    js.wtc.ContentPanel.prototype.init.call(this);

    // init the body...
    this.bodyContentPanel = new js.wtc.ContentPanel();
    this.bodyContentPanel.init();
    this.bodyContentPanel.set("border", "0 solid #000000");
    this.bodyContentPanel.set("borderWidth", "0 1px");
    this.bodyContentPanel.set("position", "");
    this.append(this.bodyContentPanel);

    // add top...
    this.addTop();
    // add bottom...
    this.addBottom();
}



js.wtc.RoundedCornersContentPanel.prototype.set = function(name, value) {
    if ((name == "left") ||
        (name == "top") ||
        (name == "width") ||
        (name == "position") ||
        (name == "zIndex")) {
        js.wtc.ContentPanel.prototype.set.call(this, name, value);
    } else {
        this.bodyContentPanel.set(name, value);

        if (name == "borderColor") {
            this.topXB1.style.backgroundColor = value;
            this.topXB2.style.borderLeftColor = value;
            this.topXB2.style.borderRightColor = value;
            this.topXB3.style.borderLeftColor = value;
            this.topXB3.style.borderRightColor = value;
            this.topXB4.style.borderLeftColor = value;
            this.topXB4.style.borderRightColor = value;

            this.bottomXB1.style.backgroundColor = value;
            this.bottomXB2.style.borderLeftColor = value;
            this.bottomXB2.style.borderRightColor = value;
            this.bottomXB3.style.borderLeftColor = value;
            this.bottomXB3.style.borderRightColor = value;
            this.bottomXB4.style.borderLeftColor = value;
            this.bottomXB4.style.borderRightColor = value;
        } else if (name == "backgroundColor") {
            this.topXB2.style.backgroundColor = value;
            this.topXB3.style.backgroundColor = value;
            this.topXB4.style.backgroundColor = value;

            this.bottomXB2.style.backgroundColor = value;
            this.bottomXB3.style.backgroundColor = value;
            this.bottomXB4.style.backgroundColor = value;
        }
    }
}



js.wtc.RoundedCornersContentPanel.prototype.get = function(name) {
    if ((name == "left") ||
        (name == "top") ||
        (name == "width") ||
        (name == "position") ||
        (name == "zIndex")) {
        return js.wtc.ContentPanel.prototype.get.call(this, name);
    } else if (name == "borderColor") {
        return this.topXB1.style.backgroundColor;
    } else {
        return this.bodyContentPanel.get(name);
    }
}

