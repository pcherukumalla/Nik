from java.util import HashMap
from java.util import HashSet
from java.util import ArrayList
from java.io import FileInputStream

from com.bea.wli.sb.util import Refs
from com.bea.wli.config.customization import Customization
from com.bea.wli.sb.management.importexport import ALSBImportOperation

from com.bea.wli.sb.management.configuration import ALSBConfigurationMBean
from com.bea.wli.sb.management.configuration import SessionManagementMBean
import sys

#====================================================================
# Entry function to deploy project configuration and resources
#        into a ALSB domain
#====================================================================

def importToALSBDomain(importConfigFile):
    try:
        SessionMBean = None
        print 'Loading Deployment config from :', importConfigFile
        exportConfigProp = loadProps(importConfigFile)
        adminUrl = exportConfigProp.get("adminUrl")
        configFile = exportConfigProp.get("configFile")
        keyFile = exportConfigProp.get("keyFile")
        customizationFile = exportConfigProp.get("customizationFile")

        print 'adminUrl=', adminUrl
        print 'customizationFile=', customizationFile

        connect(userConfigFile=configFile, userKeyFile=keyFile, url=adminUrl)
        domainRuntime()
        sessionName = String("Customization"+Long(System.currentTimeMillis()).toString())
        SessionMBean = findService("SessionManagement", "com.bea.wli.sb.management.configuration.SessionManagementMBean")
        SessionMBean.createSession(sessionName)
        OSBConfigurationMBean = findService(String("ALSBConfiguration.").concat(sessionName), "com.bea.wli.sb.management.configuration.ALSBConfigurationMBean")
        print 'Loading customization File', importConfigFile
        iStream = FileInputStream(customizationFile)
        customizationList = Customization.fromXML(iStream)       
        OSBConfigurationMBean.customize(customizationList)
        SessionMBean.activateSession(sessionName, "Complete customization using wlst")
	print 'CustomizationFile has been applied Succesfully!'
        print 'Disconnecting from Server!'
        disconnect()

    except:
        print "Unexpected error:", sys.exc_info()[0]
        if SessionMBean != None:
            SessionMBean.discardSession(sessionName)
        raise


#===================================================================
# Utility function to load properties from a config file
#===================================================================

def loadProps(configPropFile):
    propInputStream = FileInputStream(configPropFile)
    configProps = Properties()
    configProps.load(propInputStream)
    return configProps



# IMPORT script init
try:
    # import the service bus configuration
    # argv[1] is the export config properties file
    importToALSBDomain(sys.argv[1])

except:
    print "Unexpected error: ", sys.exc_info()[0]
    dumpStack()
    raise
