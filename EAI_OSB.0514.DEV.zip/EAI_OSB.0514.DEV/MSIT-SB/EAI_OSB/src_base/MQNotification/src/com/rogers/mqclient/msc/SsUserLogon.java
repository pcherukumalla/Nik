package com.rogers.mqclient.msc; 

import java.text.SimpleDateFormat;

public class SsUserLogon
{
	public static final int maxSessions = 15;
	
	public static final String SERVER  = "S01OS021";
	public static final String ACTION  = "LOGN";

    public static final String passwdExpiredStatus = "3382";
    public static final String passwdIncorrectStatus = "3378";
    public static final String invalidTokenStatus = "STKN";
    public static final String notSignedInStatus = "SNSO";	
	public static final String successStatus = "0000";
	
	/**
	 * Creates the Logon request
	 * @param password	Password to be sent
	 * @param newpwd	New Password (optional)
	 * @param sessions	Number of Session required
	 * @return	Message Body
	 */
    public static String createRequest( String password, String newpwd, int sessions )
    {
        char [] buffer = new char[38];
        java.util.Arrays.fill( buffer, ' ' );

        // <noSessions(6)><sessionName(10)><pwd(8)><newPwd(8)><authTimeout(6)>
        MscMessageUtils.numToSsStr( sessions, buffer, 0, 6 );
        encryptPassword( password, buffer, 16, 8 );
        if ( newpwd != null ) encryptPassword( newpwd, buffer, 24, 8 );

        java.util.Arrays.fill( buffer, 32, buffer.length, '0' );
        return String.valueOf( buffer );
    }

	/**
	 * Parses session token from the response
	 * @param response	Response from Super System
	 * @return Session	Token
	 * @throws Exception	Invalid response
	 */
    public static String parseSessionToken( String response )
    {
        // <sessions(6)><sessReq(6)><authToken(8)><sessionName(10)><operator(4)><security(2)><busDate(8)>
        return response.substring( 12, 30 );
    }

	/**
	 * Parses number of sessions established
	 * @param response	Response String
	 * @return	Sessions Established
	 */
    public static int parseSessionEstablished( String response )
    {
        // return number of sessions established
        return Integer.valueOf( response.substring( 0, 6 ) ).intValue();
    }

	/**
	 * Generates New Password
	 * @return	Generated Password
	 */
	public static String generatePassword()
	{
		SimpleDateFormat formatter = new SimpleDateFormat( "yyMMdd" );
		return ("ER" + formatter.format( new java.util.Date() ));
	}

    // Fill encrypted password to the buffer
    private static void encryptPassword( String password, char[] buffer, int from, int length )
    {
        // change password to upper case
        password = password.toUpperCase() ;

        int pwdlen = password.length();
        if ( pwdlen > length ) pwdlen = length;

        for ( int idx = 0; idx < pwdlen; idx++ )
        {
            buffer[from + idx] = encryptCharacter( password.charAt( idx ) );
        }
    }

    // Encrypt character
    private static char encryptCharacter( char cCharToEncrypt )
    {
        switch ( cCharToEncrypt )
        {
            case 'A': return '0' ;
            case 'B': return 'J' ;
            case 'C': return 'B' ;
            case 'D': return 'K' ;
            case 'E': return '1' ;
            case 'F': return 'M' ;
            case 'G': return 'C' ;
            case 'H': return 'N' ;
            case 'I': return '2' ;
            case 'J': return 'D' ;
            case 'K': return 'O' ;
            case 'L': return 'F' ;
            case 'M': return '5' ;
            case 'N': return 'Q' ;
            case 'O': return 'R' ;
            case 'P': return 'S' ;
            case 'Q': return 'T' ;
            case 'R': return '8' ;
            case 'S': return 'Y' ;
            case 'T': return 'Z' ;
            case 'U': return 'H' ;
            case 'V': return 'X' ;
            case 'W': return '6' ;
            case 'X': return 'I' ;
            case 'Y': return 'U' ;
            case 'Z': return 'V' ;
            
            case '0': return 'A' ;
            case '1': return 'L' ;
            case '2': return 'E' ;
            case '3': return '4' ;
            case '4': return '3' ;
            case '5': return 'P' ;
            case '6': return '9' ;
            case '7': return 'G' ;
            case '8': return '7' ;
            case '9': return 'W' ;
            default:  return ' ' ;
        }
    }
} 