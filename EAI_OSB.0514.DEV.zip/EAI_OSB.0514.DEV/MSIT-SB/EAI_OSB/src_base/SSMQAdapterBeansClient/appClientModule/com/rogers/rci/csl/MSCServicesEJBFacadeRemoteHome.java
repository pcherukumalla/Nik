package com.rogers.rci.csl;

import java.rmi.RemoteException;
import javax.ejb.CreateException;
import javax.ejb.EJBHome;

public abstract interface MSCServicesEJBFacadeRemoteHome extends EJBHome
{
  public abstract MSCServicesEJBFacadeRemote create()
    throws CreateException, RemoteException, CreateException;
}