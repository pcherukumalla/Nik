select utl_raw.cast_to_varchar2(dbms_lob.substr(DATA)) from EAI_APPL_LOG where EAI_APPL_LOG.LOGID = '12340';


SELECT * FROM "EAI_APPL_LOG" where EVENT_DATE > to_date('20120612', 'yyyymmdd')

truncate table "TDV"."EAI_APPL_LOG"