package com.rogers.rci.wsl;

import java.rmi.RemoteException;
import javax.ejb.EJBObject;
import org.apache.xmlbeans.XmlObject;

public abstract interface SubscriberMaintenanceEJBRemote extends EJBObject
{
  public abstract XmlObject addAndRemoveSubscriberServices(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject moveRhpLight(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject moveSubscriber(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject provisionReservedSubscriber(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject retrieveAvailablePricePlans(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject retrieveAvailableServices(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject retrieveEmergencyAddress(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject retrieveEquipmentInfo(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject retrieveEquipmentUpgradeStatus(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject retrievePricePlanServices(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject retrieveRustyEnrollment(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject retrieveSubscriberEquipment(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject retrieveSubscriberInfo(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject retrieveSubscriberList(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject retrieveSubscriberServices(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject setRustyEnrollment(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject setVoicemailPassword(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject submitEmergencyAddress(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject updateSubscriberInfo(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject updateSubscriberServices(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject upgradeEquipment(XmlObject paramXmlObject)
    throws RemoteException, Exception;

  public abstract XmlObject validateEquipmentNumber(XmlObject paramXmlObject)
    throws RemoteException, Exception;
}