0.a) Make sure that for each managed server these start up arguments are set: 
-Deai.config.datasource=<YoursTDVJNDIDatasource> -Dappl.config.datasource=<YoursConfigJNDIDatasource>

0.b) Make sure that in WLS console the JMS connection factory with JNDI "common.tdv.cf" and JMS queue "common.tdv.request.internal.q" exist.
0.c) Make sure the TDV database of the domain has the artifacts created and that table EAI_APPL_LOG_CONFIG has #DEFAULT=Y there.
0.d) Make sure Configuration database has the expected EAI_APPL_CONFIG table and this entry exists:
'TOKENIZATIONSERVICES','SERVICES_DECOMISSIONED','Y'

=============================================================================================================================================

1. Install first sbconfig for common-services project (distinct jar file)
2. Change the URI for common-services's TDVPublisher.biz and TDVLogEntryProcessor.proxy and specify instead of the existent URI
another one that exposes the local URI configuration.
Since the cluster in QA for the OSB has at least 2 managed servers the URI should have this format:
jms://IP1:PORT1,IP2:PORT2/common.tdv.cf/common.tdv.request.internal.q

3. Import the EAIOSB config jar
4. Edit the EAIOSB customization file and replace in a text editor:
a) all occurences of "http://localhost:7011" with end point specific to QA domain of EAI Express Managed server 1
b) all occurences of "http://mylocalhost:7012" with end point specific to QA domain of EAI Express Managed server 2
c) all occurences of "http://localhost:9011" with end point specific to QA domain of EAI Lite
5. Save the changes and execute the modified customization file in the QA environment under the WL service bus console.

Make sure to Activate the changes in the WL service bus console.