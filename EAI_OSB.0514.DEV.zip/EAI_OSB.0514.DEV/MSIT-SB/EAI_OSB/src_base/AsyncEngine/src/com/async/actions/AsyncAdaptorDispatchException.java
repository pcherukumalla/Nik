package com.async.actions;



public class AsyncAdaptorDispatchException extends Exception {
	final private static long serialVersionUID = -197010085L;
	
	
	
	public AsyncAdaptorDispatchException() {
		super();
	}
	
	
	
	public AsyncAdaptorDispatchException(String message) {
		super(message);
	}
	
	
	
	public AsyncAdaptorDispatchException(String message, Throwable cause) {
		super(message, cause);
	}
	
	
	
	public AsyncAdaptorDispatchException(Throwable cause) {
		super(cause);
	}
}
