/*
****************************************************************************************************
 ezWebToolkit Library, http://www.ezwebtoolkit.com
****************************************************************************************************
Copyright [2006-2008] [Pro Net Systems Inc., http://www.pronetsystems.com]

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

	http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
***************************************************************************************************
*/



js.util.logging.Logger = function() {
    this.name = "LOGGER";
    this.consoleId = "";
    this.debugEnabled = true;
    this.infoEnabled = true;
    this.errorEnabled = true;
    this.order = "ASC"; // posible values: ASC or DESC
    this.alertEnabled = false;

    this.container = "";

    this.objectType = "js.util.logging.Logger";
}



js.util.logging.Logger.prototype.writeToConsole = function(typ, msg) {
    if(this.order == "DESC") {
		this.container = "\n" + this.container;
        this.container = msg + "\n" + this.container;
        this.container = typ + " on " + (new Date()) + " (" + this.name + ")" + "\n" + this.container;
    } else {
		if(this.container.length > 0) {
            this.container += "\n\n";
        }
        this.container += typ + " on " + (new Date()) + " (" + this.name + ")" + "\n";
        this.container += msg;
    }

	// write the container content into the textarea console if exists...
	if(this.consoleId != "") {
		var obj = document.getElementById(this.consoleId);

		if(obj != null) {
			obj.value = this.container;
		}
	}
    
	// alert if "alert" enabled...
    if(this.alertEnabled) {
        alert(typ + " on " + (new Date()) + " (" + this.name + ")" + "\n\n" + msg);
    }
}



js.util.logging.Logger.prototype.debug = function(msg) {
    if (js.LOGGING && this.debugEnabled) {
        this.writeToConsole("DEBUG", msg);
    }
}



js.util.logging.Logger.prototype.info = function(msg) {
    if (js.LOGGING && this.infoEnabled) {
        this.writeToConsole("INFO", msg);
    }
}



js.util.logging.Logger.prototype.error = function(msg) {
    if (js.LOGGING && this.errorEnabled) {
        this.writeToConsole("ERROR", msg);
    }
}



js.util.logging.Logger.prototype.enable = function(typ) {
    if(typ == "DEBUG") {
        this.debugEnabled = true;
    } else if(typ == "INFO") {
        this.infoEnabled = true;
    } else if(typ == "ERROR") {
        this.errorEnabled = true;
    }
}



js.util.logging.Logger.prototype.disable = function(typ) {
    if(typ == "DEBUG") {
        this.debugEnabled = false;
    } else if(typ == "INFO") {
        this.infoEnabled = false;
    } else if(typ == "ERROR") {
        this.errorEnabled = false;
    }
}



js.util.logging.Logger.prototype.set = function(name, value) {
	if(name == "order") {
		this.order = value;
	} else if(name == "alert") {
		this.alertEnabled = value;
	} else if(name == "console") {
		this.consoleId = value;
	} else if(name == "name") {
		this.name = value;
	}
}



js.util.logging.Logger.prototype.get = function(name) {
	if(name == "order") {
		return this.order;
	} else if(name == "alert") {
		return this.alertEnabled;
	} else if(name == "console") {
		return this.consoleId;
	} else if(name == "name") {
		return this.name;
	}
}
