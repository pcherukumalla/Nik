package com.async.engine.common.dao;

import java.io.*;
import java.util.*;
import java.sql.*;
import java.util.logging.*;

import com.async.engine.common.dao.base.*;
import com.async.engine.common.utils.*;



public class CommonDAOComponent extends DAOComponent {
	public List getErrorMessages() throws CommonDAOException {
		List ret = null;
		
		// params...

		// get data...
		Connection conn = null;
		try {
			conn = getConnection();
			ret = getDAOObjectList(conn, Constants.GET_ERROR_MESSAGES_SQL, null);
		} catch(Exception e) {
			Constants.LOGGER.log(Level.SEVERE,  this.getClass().getName() + ".getErrorMessages error: " + e.toString());
			throw new CommonDAOException(e);
		} finally {
			closeConnection(conn);
		}
		
		return ret;
	}
	
	
	
	public List getErrorDescriptions() throws CommonDAOException {
		List ret = null;
		
		// params...

		// get data...
		Connection conn = null;
		try {
			conn = getConnection();
			ret = getDAOObjectList(conn, Constants.GET_ERROR_DESCRIPTIONS_SQL, null);
		} catch(Exception e) {
			Constants.LOGGER.log(Level.SEVERE,  this.getClass().getName() + ".getErrorDescriptions error: " + e.toString());
			throw new CommonDAOException(e);
		} finally {
			closeConnection(conn);
		}
		
		return ret;
	}
	
	
	
	public List getMessageTypes() throws CommonDAOException {
		List ret = null;
		
		// params...

		// get data...
		Connection conn = null;
		try {
			conn = getConnection();
			ret = getDAOObjectList(conn, Constants.GET_MESSAGE_TYPES_SQL, null);
		} catch(Exception e) {
			Constants.LOGGER.log(Level.SEVERE,  this.getClass().getName() + ".getMessageTypes error: " + e.toString());
			throw new CommonDAOException(e);
		} finally {
			closeConnection(conn);
		}
		
		return ret;
	}
	
	
	
	private void saveStats(Connection conn, PreparedStatement st1, PreparedStatement st2, int msgTypeId, String statsDate, String statsSQL) throws SQLException {
		// try to update stats...
		try
		{
			st1 = conn.prepareStatement(statsSQL);
			st1.setString(1, statsDate);
			st1.setInt(2, msgTypeId);
			int nUpdateStatsRet = st1.executeUpdate();
			
			// if no row exists for this day of year then insert one and then update again...
			if(nUpdateStatsRet == 0) {
				st2 = conn.prepareStatement(Constants.INSERT_STATS_SQL);
				st2.setString(1, statsDate);
				st2.setInt(2, msgTypeId);
				st2.executeUpdate();
				
				st1.executeUpdate();
			}
		}
		catch(Exception ee)
		{
			System.out.println(this.getClass().getName() + ".saveStats ERROR: " + ee.toString());
		}
	}
	
	
	
	public int insertMessage(String szKey, String message, DAOObject typ, String statsDate) throws CommonDAOException, DAOException {
		int nRet = -1;
		
		// get message type attributes...
		String strMainTableName = typ.getString("MAIN_TABLE_NAME");
		int nMsgTypeId = typ.getInt("MSGTYPE_ID");
		int nSetId = typ.getInt("SET_ID");
		int nStatsActiveIn = typ.getInt("STATS_ACTIVE_IN");
		
		// params...

		// get data...
		Connection conn = null;
		PreparedStatement st = null;
		PreparedStatement st1 = null;
		PreparedStatement st2 = null;
		try {
			conn = getConnection();
			conn.setAutoCommit(false);
			
			st = conn.prepareStatement(Constants.INSERT_MESSAGE_SQL.replaceFirst("~", strMainTableName));
			st.setInt(1, nMsgTypeId);
			st.setString(2, szKey);
			st.setBinaryStream(3, new ByteArrayInputStream(message.getBytes()), message.length());
			st.setInt(4, nSetId);
			
			nRet = st.executeUpdate();
			
			// store stats about this event...
			if(nStatsActiveIn == 1) {
				this.saveStats(conn, st1, st2, nMsgTypeId, statsDate, Constants.UPDATE_NR_OF_MSG_STATS_SQL);
			}
			
			conn.commit();
			conn.setAutoCommit(true);
		} catch(Exception e) {
			Constants.LOGGER.log(Level.SEVERE,  this.getClass().getName() + ".insertMessage error: " + e.toString());
			throw new CommonDAOException(e);
		} finally {
			closeStatement(st);
			closeStatement(st1);
			closeStatement(st2);
			closeConnection(conn);
		}
		
		return nRet;
	}
	
	
	
	public int insertUnknownMessage(String szKey, String message, String msgType, DAOObject typ, String statsDate) throws CommonDAOException, DAOException {
		int nRet = -1;
		
		// get message type attributes...
		String strMainTableName = typ.getString("MAIN_TABLE_NAME");
		int nStatsActiveIn = typ.getInt("STATS_ACTIVE_IN");
		
		// params...

		// get data...
		Connection conn = null;
		PreparedStatement st = null;
		PreparedStatement st1 = null;
		PreparedStatement st2 = null;
		try {
			conn = getConnection();
			conn.setAutoCommit(false);
			
			st = conn.prepareStatement(Constants.INSERT_UNKNOWN_MESSAGE_SQL.replaceFirst("~", strMainTableName));
			st.setString(1, msgType);
			st.setString(2, szKey);
			st.setBinaryStream(3, new ByteArrayInputStream(message.getBytes()), message.length());
			
			nRet = st.executeUpdate();
			
			// store stats about this event...
			if(nStatsActiveIn == 1) {
				this.saveStats(conn, st1, st2, Constants.UNKNOWN_MESSAGE_TYPE_ID, statsDate, Constants.UPDATE_NR_OF_MSG_STATS_SQL);
			}
			
			conn.commit();
			conn.setAutoCommit(true);
		} catch(Exception e) {
			Constants.LOGGER.log(Level.SEVERE,  this.getClass().getName() + ".insertMessage error: " + e.toString());
			throw new CommonDAOException(e);
		} finally {
			closeStatement(st);
			closeStatement(st1);
			closeStatement(st2);
			closeConnection(conn);
		}
		
		return nRet;
	}
	
	
	
	public int updateMessageAfterProcessing(long msgId, String errorCd, String errorDesc, DAOObject err, DAOObject typ, String statsDate) throws CommonDAOException, DAOException {
		int nRet = -1;
		boolean bMoveTo = false;
		
		// get message type attributes...
		int nMsgTypeId = typ.getInt("MSGTYPE_ID");
		int nSetId = typ.getInt("SET_ID");
		int nStatsActiveIn = typ.getInt("STATS_ACTIVE_IN");
		int nWaitForReplyIn = typ.getInt("WAIT_FOR_REPLY_IN");
		String strHoldTableName = typ.getString("HOLD_TABLE_NAME");
		String strHistTableName = typ.getString("HIST_TABLE_NAME");
		
		// get error attributes...
		int nStatusIn = err.getInt("STATUS_IN");
		int nMoveTo = err.getInt("MOVE_TO_IN");
		
		// params...

		// get data...
		Connection conn = null;
		PreparedStatement st = null;
		PreparedStatement st1 = null;
		PreparedStatement st2 = null;
		PreparedStatement st2a = null;
		PreparedStatement st2b = null;
		PreparedStatement st2c = null;
		PreparedStatement st2d = null;
		PreparedStatement st2e = null;
		PreparedStatement st3 = null;
		PreparedStatement st4 = null;
		PreparedStatement st5 = null;
		ResultSet res = null;
		ResultSet res1 = null;
		ResultSet res2 = null;
		try {
			conn = getConnection();
			conn.setAutoCommit(false);
			
			// update message...
			String strCorrelationId = "";
			if(Constants.OK.equals(errorCd) && (nWaitForReplyIn != 0)) {
				strCorrelationId = errorDesc;
			}
			
			st = conn.prepareStatement(Constants.UPDATE_MESSAGE_AFTER_PROCESSING_SQL);
			st.setInt(1, nStatusIn);
			st.setString(2, errorCd);
			st.setString(3, errorDesc);
			st.setString(4, strCorrelationId);
			st.setLong(5, msgId);
			nRet = st.executeUpdate();
			
			if(nMoveTo == 0) {
				bMoveTo = true;
			} else if(nMoveTo > 0) {
				// get number of retries...
				st1 = conn.prepareStatement(Constants.GET_MESSAGE_NR_OF_RETRIES_SQL);
				st1.setLong(1, msgId);
				res = st1.executeQuery();
				
				int nNrOfRetries = -1;
				if(res.next()) {
					nNrOfRetries = res.getInt("NR_OF_RETRIES");
				}
				
				if(nNrOfRetries >= nMoveTo) {
					bMoveTo = true;
				}
			}
			
			if(bMoveTo) {
				if(Constants.OK.equals(errorCd)) {
					if(nWaitForReplyIn == 1) {
						// insert into hold and wait for reply...
						st2 = conn.prepareStatement(Constants.INSERT_MESSAGE_TO_HOLD_SQL.replaceFirst("~", strHoldTableName));
						st2.setLong(1, msgId);
						nRet = st2.executeUpdate();
					} else if(nWaitForReplyIn == 2) {
						// get initial message from hold by correlation id...
						st2a = conn.prepareStatement(Constants.GET_MESSAGE_FROM_HOLD_BY_CORRELATION_ID_SQL);
						st2a.setString(1, errorDesc);
						res1 = st2a.executeQuery();
						
						if(res1.next()) {
							String strInitialMsgSzKey = res1.getString("SZKEY");
							long nInitialMsgId = res1.getLong("MSGID");
							
							// insert into history the initial message...
							st2a = conn.prepareStatement(Constants.INSERT_MESSAGE_TO_HISTORY_SQL.replaceFirst("~", strHistTableName));
							st2a.setLong(1, nInitialMsgId);
							nRet = st2a.executeUpdate();
							
							// delete from hold...
							st2b = conn.prepareStatement(Constants.DELETE_MESSAGE_FROM_HOLD_SQL.replaceFirst("~", strHoldTableName));
							st2b.setLong(1, nInitialMsgId);
							nRet = st2b.executeUpdate();
							
							// get the next dependent message to be moved to the working table if any...
							st2c = conn.prepareStatement(Constants.GET_OLDEST_MESSAGE_FROM_HOLD_BY_SZKEY_SQL.replaceFirst("~", strHoldTableName));
							st2c.setString(1, strInitialMsgSzKey);
							res2 = st2c.executeQuery();
							
							if(res2.next()) {
								long nNextMsgId = res1.getLong("MIN_MSGID");
								
								// insert the next dependent one into the working table...
								st2d = conn.prepareStatement(Constants.INSERT_MESSAGE_TO_TEMP_SQL.replaceFirst("~", strHoldTableName));
								st2d.setLong(1, nNextMsgId);
								nRet = st2d.executeUpdate();
								
								// delete from hold...
								st2e = conn.prepareStatement(Constants.DELETE_MESSAGE_FROM_HOLD_SQL.replaceFirst("~", strHoldTableName));
								st2e.setLong(1, nNextMsgId);
								nRet = st2e.executeUpdate();
							}
						}
						
						// insert into history this message...  
						st2 = conn.prepareStatement(Constants.INSERT_MESSAGE_TO_HISTORY_SQL.replaceFirst("~", strHistTableName));
						st2.setLong(1, msgId);
						nRet = st2.executeUpdate();
					} else {
						// insert into history table...
						st2 = conn.prepareStatement(Constants.INSERT_MESSAGE_TO_HISTORY_SQL.replaceFirst("~", strHistTableName));
						st2.setLong(1, msgId);
						nRet = st2.executeUpdate();
					}
				} else {
					if(nSetId == 0) {
						// insert into history...  
						st2 = conn.prepareStatement(Constants.INSERT_MESSAGE_TO_HISTORY_SQL.replaceFirst("~", strHistTableName));
						st2.setLong(1, msgId);
						nRet = st2.executeUpdate();
					} else {
						// insert into hold...  
						st2 = conn.prepareStatement(Constants.INSERT_MESSAGE_TO_HOLD_SQL.replaceFirst("~", strHoldTableName));
						st2.setLong(1, msgId);
						nRet = st2.executeUpdate();
					}
				}
				
				// delete message...
				st3 = conn.prepareStatement(Constants.DELETE_MESSAGE_SQL);
				st3.setLong(1, msgId);
				nRet = st3.executeUpdate();
			}
			
			// store stats about this event...
			if(nStatsActiveIn == 1) {
				// set the appropriate SQL..
				String strStatsSQL = Constants.UPDATE_NR_OF_MSG_OTHER_ERRORS_STATS_SQL;
				if(Constants.OK.equals(errorCd)) {
					strStatsSQL = Constants.UPDATE_NR_OF_MSG_OK_STATS_SQL;
				} else if(Constants.TIMEOUT_ERROR.equals(errorCd)) {
					strStatsSQL = Constants.UPDATE_NR_OF_MSG_TIMEOUT_STATS_SQL;
				} else if(Constants.DOWN_ERROR.equals(errorCd)) {
					strStatsSQL = Constants.UPDATE_NR_OF_MSG_DOWN_STATS_SQL;
				}
				
				this.saveStats(conn, st4, st5, nMsgTypeId, statsDate, strStatsSQL);
			}
			
			conn.commit();
			conn.setAutoCommit(true);
		} catch(Exception e) {
			try {
				conn.rollback();
			} catch(SQLException sqle) {
				Constants.LOGGER.log(Level.SEVERE,  this.getClass().getName() + ".updateMessageAfterProcessing rollback error: " + sqle.toString());
			}
			Constants.LOGGER.log(Level.SEVERE,  this.getClass().getName() + ".updateMessageAfterProcessing error: " + e.toString());
			throw new CommonDAOException(e);
		} finally {
			closeResultSet(res);
			closeResultSet(res1);
			closeResultSet(res2);
			closeStatement(st);
			closeStatement(st1);
			closeStatement(st2);
			closeStatement(st2a);
			closeStatement(st2b);
			closeStatement(st2c);
			closeStatement(st2d);
			closeStatement(st2e);
			closeStatement(st3);
			closeStatement(st4);
			closeStatement(st5);
			closeConnection(conn);
		}
		
		return nRet;
	}
}


