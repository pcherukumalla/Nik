package com.rogers.mqclient.env;

import java.util.HashMap;

public class MQEnvDetailBase
{

  protected void setMQEnvDetail(String params, MQEnvDetailInterface obj)
  	throws Exception
  {
    	//UtilityLogger.getLogger().info("mqconfiguration from SendNativeMSCReplyToMQ to MSCOutEnvDetail: " + params);

      HashMap<String, String> mp = new HashMap<String, String>();
      int poz = -1;

      String mqConfigValue = params;
      if (mqConfigValue == null || "".equalsIgnoreCase( mqConfigValue.trim() ))
      {
      	throw new Exception("MQ env details not defined!");
      }

      String[] pairs = mqConfigValue.toUpperCase().split( ";" );
      for ( int count = 0; count < pairs.length; count ++ )
      {
          poz = pairs[ count ].indexOf("=");
          mp.put( pairs[ count ].substring(0,poz).trim(), pairs[ count ].substring(poz+1).trim() );
      }

      	obj.setHOST ( getConfField( mp, "HOST" ) );
        obj.setPORT( getConfField( mp, "PORT" ) );
        obj.setCHANNEL( getConfField( mp, "CHANNEL" ) );
        obj.setQNAME( getConfField( mp, "QUEUE" ));
        obj.setQMGR( getConfField( mp, "QMANAGER" ));;
        obj.setCCSID( Integer.parseInt( getConfField( mp, "CCSID" ) ));

        obj.setSYS_USER( getConfField( mp, "SYS_USER" ) );
        obj.setLAST_GOOD_MQ_DETAILS( params );
  }

	private String getConfField( HashMap<String, String> mp, String name )
	{
      if (!mp.containsKey( name ) ) return null;
 	    return (String)mp.get( name );
	}
}