package com.rogers.mqclient.send;

import javax.jms.QueueSender;
import javax.jms.Session;
import javax.jms.TextMessage;

import com.ibm.mq.MQEnvironment;
import com.ibm.mq.jms.JMSC;
import com.ibm.mq.jms.MQQueueConnectionFactory;
import com.rogers.logger.utility.UtilityLogger;
import com.rogers.mqclient.cache.JMSCacheVO;
import com.rogers.mqclient.env.MSCOutEnvDetail;

public class SendViaJMSMSCReplyToMQ implements SendInterface
{
	public String TEXT = "Did not receive input text message for MQ";
	/*
	 * IMPORTANT: TODO: add logic for String correlationId, String mscMsgReceived (to set up response header) and String returnCode
	 *
	 */
    public void setPrerequisites(String mqconfiguration, boolean resetMqConn, boolean resetMqDetail, String correlationId, String mscMsgReceived, String returnCode)
		throws Exception
	{
		//set the environment variables:
		if ( resetMqDetail || JMSCacheVO.getRESET_MQ_DETAIL() == null )
		{
			synchronized ( MSCOutEnvDetail.class )
			{
				new MSCOutEnvDetail( mqconfiguration );
				if (MSCOutEnvDetail.CCSID > 0 && MSCOutEnvDetail.QMGR != null ) JMSCacheVO.setRESET_MQ_DETAIL( "SET" );
			}
		}

		if ( resetMqConn ) resetConnection();
	}

    public void resetConnection()
    {
        try
        {
        	JMSCacheVO.setQueue( null );
        	JMSCacheVO.setSession( null );
        	JMSCacheVO.setFactory( null );
            if ( JMSCacheVO.getConnection() != null ) JMSCacheVO.getConnection().close();
            JMSCacheVO.setConnection( null ) ;

            JMSCacheVO.setRESET_MQ_CONN( null );
        } catch ( Exception ex ){}
    }

    public void putMessage( String txtMessage )
		throws Exception
	{
	  if ( JMSCacheVO.getRESET_MQ_DETAIL() == null )
		  throw new Exception ("Set first prerequisites!");

      	  if (txtMessage != null ) TEXT = txtMessage;

          //UtilityLogger.getLogger().info("Using MQ detail:" + MSCOutEnvDetail.LAST_GOOD_MQ_DETAILS);

          //populate the Environment
          MQEnvironment.hostname = MSCOutEnvDetail.HOST;
          MQEnvironment.port = new Integer(MSCOutEnvDetail.PORT).intValue();
          MQEnvironment.channel = MSCOutEnvDetail.CHANNEL;

          synchronized (JMSCacheVO.class)
          {

	          // create the factory
	          if (JMSCacheVO.getFactory() == null)
	          {
	        	  JMSCacheVO.setFactory ( new MQQueueConnectionFactory() );

	              // set the environment
	              ((MQQueueConnectionFactory)JMSCacheVO.getFactory()).setHostName( MSCOutEnvDetail.HOST );
	              ((MQQueueConnectionFactory)JMSCacheVO.getFactory()).setChannel( MSCOutEnvDetail.CHANNEL );
	              ((MQQueueConnectionFactory)JMSCacheVO.getFactory()).setCCSID( MSCOutEnvDetail.CCSID );
	              ((MQQueueConnectionFactory)JMSCacheVO.getFactory()).setPort( new Integer( MSCOutEnvDetail.PORT).intValue() );
	              ((MQQueueConnectionFactory)JMSCacheVO.getFactory()).setTransportType( JMSC.MQJMS_TP_CLIENT_MQ_TCPIP );

	              // connect to the Queuemanager
	              ((MQQueueConnectionFactory)JMSCacheVO.getFactory()).setQueueManager( MSCOutEnvDetail.QMGR );
	          }

	          // create the connection and send the message
	          if (JMSCacheVO.getConnection() == null)
	        	  JMSCacheVO.setConnection( ((MQQueueConnectionFactory)JMSCacheVO.getFactory()).createQueueConnection() );

	          if ( JMSCacheVO.getSession() == null )
	        	  JMSCacheVO.setSession ( JMSCacheVO.getConnection().createQueueSession( false, Session.AUTO_ACKNOWLEDGE ));

	          if ( JMSCacheVO.getQueue() == null)
	        	  JMSCacheVO.setQueue( JMSCacheVO.getSession().createQueue ( MSCOutEnvDetail.QNAME ) );
          }

          QueueSender sender = JMSCacheVO.getSession().createSender( JMSCacheVO.getQueue() );
          TextMessage message = JMSCacheVO.getSession().createTextMessage();

          UtilityLogger.getLogger().info( "Ready .." );

          message.setText( TEXT );
          sender.send( message );

          UtilityLogger.getLogger().info("Pushed to MQ:" + TEXT);

          if ( JMSCacheVO.getRESET_MQ_CONN() == null) JMSCacheVO.setRESET_MQ_CONN( "SET" );
	}
}
