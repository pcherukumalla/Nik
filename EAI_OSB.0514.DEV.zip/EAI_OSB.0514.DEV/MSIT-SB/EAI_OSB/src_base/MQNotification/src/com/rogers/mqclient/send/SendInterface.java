package com.rogers.mqclient.send;

public interface SendInterface {
	
	public String TEXT = null;
	
    public void setPrerequisites(String mqconfiguration, boolean resetMqConn, boolean resetMqDetail, String correlationId, String mscMsgReceived, String returnCodeOrPassword)
		throws Exception;
    
    public void resetConnection();
    
    public void putMessage( String txtMessage )
    	throws Exception;
}
