/*
****************************************************************************************************
 ezWebToolkit Library, http://ezwt.blogspot.com
****************************************************************************************************
Copyright [2006-2008] [Pro Net Systems Inc., http://www.pronetsystems.com]

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

	http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
***************************************************************************************************
*/



/*
------------------------------------------------------------------------------------------
SplitPanel
------------------------------------------------------------------------------------------
*/
js.wtc.SplitPanel = function() {
	js.wtc.ContentPanel.call(this);
	
	this.direction = "x";
	this.splitSize = "3px";
	this.splitterActiveColor = "#EEEEEE";
	this.splitterColor = "#FFFFFF";
	this.splitterMin = "100px";
	this.splitterMax = "400px";
	
	this.firstContentPanel = null;
	this.splitterContentPanel = null;
	this.secondContentPanel = null;

	this.objectType = "js.wtc.SplitPanel";
}
js.wtc.SplitPanel.prototype = new js.wtc.ContentPanel();
js.wtc.SplitPanel.prototype.constructor = js.wtc.SplitPanel;



js.wtc.SplitPanel.prototype.init = function() {
	js.wtc.ContentPanel.prototype.init.call(this);
	
	// create the splitter...
	this.splitterContentPanel = new js.wtc.ContentPanel();
	this.splitterContentPanel.init();
	this.append(this.splitterContentPanel);
	
	// set attributes...
	if(this.direction == "x") {
		this.splitterContentPanel.set("top", "0px");
		this.splitterContentPanel.set("left", (parseInt(this.splitterMin) + 2) + "px");
		this.splitterContentPanel.set("width", this.splitSize);
		this.splitterContentPanel.set("cursor", "col-resize");
	} else {
		this.splitterContentPanel.set("left", "0px");
		this.splitterContentPanel.set("top", (parseInt(this.splitterMin) + 2) + "px");
		this.splitterContentPanel.set("height", this.splitSize);
		this.splitterContentPanel.set("cursor", "row-resize");
	}
	
	this.splitterContentPanel.set("title", "resize panels");
	this.splitterContentPanel.set("overflow", "hidden");
	this.splitterContentPanel.set("zIndex", "1");
	this.splitterContentPanel.set("backgroundColor", this.splitterColor);
	
	// add move logic...
	this.splitterContentPanel.onDragStart = function(x, y) {
		this.set("backgroundColor", this.parent.splitterActiveColor);
	}
	
	this.splitterContentPanel.onDrag = function(x, y) {
		// check for boundaries...
		if(this.parent.direction == "x") {
			if(parseInt(this.get("left")) < parseInt(this.parent.splitterMin) + 2) {
				this.set("left", (parseInt(this.parent.splitterMin) + 2) + "px");
			}
			if(parseInt(this.get("left")) > parseInt(this.parent.splitterMax)) {
				this.set("left", this.parent.splitterMax);
			}
			if(parseInt(this.get("top")) != 0) {
				this.set("top", "0px");
			}
		} else {
			if(parseInt(this.get("top")) < parseInt(this.parent.splitterMin) + 2) {
				this.set("top", (parseInt(this.parent.splitterMin) + 2) + "px");
			}
			if(parseInt(this.get("top")) > parseInt(this.parent.splitterMax)) {
				this.set("top", this.parent.splitterMax);
			}
			if(parseInt(this.get("left")) != 0) {
				this.set("left", "0px");
			}
		}
	}
	
	this.splitterContentPanel.onDragEnd = function(x, y) {
		// resize first panel...
		if(this.parent.firstContentPanel != null) {
			if(this.parent.direction == "x") {
				this.parent.firstContentPanel.set("width", (parseInt(this.get("left")) - 2) + "px");
			} else {
				this.parent.firstContentPanel.set("height", (parseInt(this.get("top")) - 2) + "px");
			}
		}
		
		// resize second panel...
		if(this.parent.secondContentPanel != null) {
			if(this.parent.direction == "x") {
				this.parent.secondContentPanel.set("left", (parseInt(this.get("left")) + parseInt(this.parent.splitSize)) + "px");
				this.parent.secondContentPanel.set("width", (parseInt(this.parent.get("width")) - parseInt(this.parent.firstContentPanel.get("width")) - parseInt(this.parent.splitSize) - 4) + "px");
			} else {
				this.parent.secondContentPanel.set("top", (parseInt(this.get("top")) + parseInt(this.parent.splitSize)) + "px");
				this.parent.secondContentPanel.set("height", (parseInt(this.parent.get("height")) - parseInt(this.parent.firstContentPanel.get("height")) - parseInt(this.parent.splitSize) - 4) + "px");
			}
		}

		// hide the splitter...
		this.set("backgroundColor", this.parent.splitterColor);
	}
	
	// make it draggable...
	this.splitterContentPanel.draggable(true);
}



js.wtc.SplitPanel.prototype.addPanel = function(o, pos) {
	if(pos == "F") {
		if(this.firstContentPanel == null) {
			this.firstContentPanel = o;
			
			this.firstContentPanel.set("zIndex", "0");
			this.firstContentPanel.set("left", "0px");
			this.firstContentPanel.set("top", "0px");
			if(this.direction == "x") {
				this.firstContentPanel.set("width", this.splitterMin);
				this.firstContentPanel.set("height", (parseInt(this.get("height")) - 2) + "px");
			} else {
				this.firstContentPanel.set("width", (parseInt(this.get("width")) - 2) + "px");
				this.firstContentPanel.set("height", this.splitterMin);
			}
			
			js.wtc.ContentPanel.prototype.append.call(this, o);
		} else {
			return;
		}
	} else if(pos == "S") {
		if(this.secondContentPanel == null) {
			this.secondContentPanel = o;
			
			this.secondContentPanel.set("zIndex", "0");
			if(this.direction == "x") {
				this.secondContentPanel.set("top", "0px");
				this.secondContentPanel.set("left", (parseInt(this.splitterMin) + parseInt(this.splitSize) + 2) + "px");
				this.secondContentPanel.set("width", (parseInt(this.get("width")) - parseInt(this.splitterMin) - parseInt(this.splitSize) - 4) + "px");
				this.secondContentPanel.set("height", (parseInt(this.get("height")) - 2) + "px");
			} else {
				this.secondContentPanel.set("left", "0px");
				this.secondContentPanel.set("top", (parseInt(this.splitterMin) + parseInt(this.splitSize) + 2) + "px");
				this.secondContentPanel.set("height", (parseInt(this.get("height")) - parseInt(this.splitterMin) - parseInt(this.splitSize) - 4) + "px");
				this.secondContentPanel.set("width", (parseInt(this.get("width")) - 2) + "px");
			}
			
			js.wtc.ContentPanel.prototype.append.call(this, o);
		} else {
			return;
		}
	}
}



js.wtc.SplitPanel.prototype.set = function(name, value) {
	if(name == "direction") { // before init...
		this.direction = value;
	} else if(name == "width") {
		if(this.direction != "x") {
			if(this.firstContentPanel != null) {
				this.firstContentPanel.set("width", (parseInt(value) - 2) + "px");
			}
			this.splitterContentPanel.set("width", value);
			if(this.secondContentPanel != null) {
				this.secondContentPanel.set("width", (parseInt(value) - 2) + "px");
			}
		} else {
			if(this.secondContentPanel != null) {
				this.secondContentPanel.set("width", (parseInt(value) - parseInt(this.firstContentPanel.get("width")) - parseInt(this.splitSize) - 4) + "px");
			}
		}
		
		js.wtc.ContentPanel.prototype.set.call(this, "width", value);
	} else if(name == "height") {
		if(this.direction == "x") {
			if(this.firstContentPanel != null) {
				this.firstContentPanel.set("height", (parseInt(value) - 2) + "px");
			}
			this.splitterContentPanel.set("height", value);
			if(this.secondContentPanel != null) {
				this.secondContentPanel.set("height", (parseInt(value) - 2) + "px");
			}
		} else {
			if(this.secondContentPanel != null) {
				this.secondContentPanel.set("height", (parseInt(value) - parseInt(this.firstContentPanel.get("height")) - parseInt(this.splitSize) - 4) + "px");
			}
		}
		
		js.wtc.ContentPanel.prototype.set.call(this, "height", value);
	} else if(name == "splitterSize") { // before init...
		this.splitSize = value;
	} else if(name == "splitterActiveColor") { // before init...
		this.splitterActiveColor = value;
	} else if(name == "splitterColor") { // before init...
		this.splitterColor = value;
	} else if(name == "splitterMin") { // before init...
		this.splitterMin = value;
	} else if(name == "splitterMax") { // before init...
		this.splitterMax = value;
	} else {
		js.wtc.ContentPanel.prototype.set.call(this, name, value);
	}
}



js.wtc.SplitPanel.prototype.get = function(name) {
	if(name == "direction") {
		return this.direction;
	} else if(name == "splitterSize") {
		return this.splitSize;
	} else if(name == "splitterActiveColor") {
		return this.splitterActiveColor;
	} else if(name == "splitterColor") {
		return this.splitterColor;
	} else if(name == "splitterMin") {
		return this.splitterMin;
	} else if(name == "splitterMax") {
		return this.splitterMax;
	} else {
		return js.wtc.ContentPanel.prototype.get.call(this, name);
	}
}
