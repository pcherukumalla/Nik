package com.rogers.mqclient.ssc;

public class DocsisSSCOutHeader {
	// message header for request messages
	private char[] requestHeader = null;
	
	private static final String version = "01";
	private static final String sourceSystem = "SAM";
	private static final String messageType_reply  = "121003";
	private static final String messageType_source = "121001";
	private static final String messageType_status = "121005";
	
	// message type for current message
	private String messageType = messageType_source;	
	
	public String getMessageType()
	{
		return messageType;
	}
	
	public char[] getSSCOutRequestHeader()
	{
		return this.requestHeader;
	}
	
	public void setServerInfo( SscHeaderType hdrType, String system, String appname, String structid )
	{
		// set header with info provided
		requestHeader = new char[105];
		java.util.Arrays.fill( requestHeader, ' ' );

		SscMessageUtils.copyChars( hdrType.toString(), requestHeader,  0, 4 );
		SscMessageUtils.copyChars( version, requestHeader,  4, 2 );
		SscMessageUtils.copyChars( sourceSystem, requestHeader, 14, 10 );
		SscMessageUtils.copyChars( system, requestHeader, 24, 8 );
		SscMessageUtils.copyChars( appname, requestHeader, 32, 8 );
		SscMessageUtils.copyChars( structid, requestHeader, 40, 8 );

		SscMessageUtils.numToSsStr( 0, requestHeader, 48, 2 );  // completion code
		SscMessageUtils.copyChars( SsConfirmationType.coc.toString(), requestHeader, 62, 4 );
		//set empty confirmation number
		SscMessageUtils.copyChars( "", requestHeader, 66, 24 );

		// set message type
		if ( hdrType == SscHeaderType.reply ) messageType = messageType_reply;
		else if ( hdrType == SscHeaderType.status ) messageType = messageType_status;
		else messageType = messageType_source;
	}

	private String createConfirmationNumber()
	{
		return "NER" + String.valueOf( System.currentTimeMillis() );
	}
	
	public void setUser( String userid, String company )
		throws Exception
	{
		if ( requestHeader == null ) throw new Exception( "Missing Header Info" );
		SscMessageUtils.copyChars( userid, requestHeader,  6, 8 );
		SscMessageUtils.copyChars( company, requestHeader, 102, 3 );
	}

	public void setConfirmationType( SsConfirmationType value )
		throws Exception
	{
		if ( requestHeader == null ) throw new Exception( "Missing Header Info" );
		SscMessageUtils.copyChars( value.toString(), requestHeader, 62, 4 );
	}

	public void setConfirmationNumber( String value )
		throws Exception
	{
		if ( requestHeader == null ) throw new Exception( "Missing Header Info" );
		if ( value == null ) value = createConfirmationNumber();
		SscMessageUtils.copyChars( value, requestHeader, 66, 24 );
	}

	public void setMessageCodes( int completion, int reason, String action )
		throws Exception
	{
		if ( requestHeader == null ) throw new Exception( "Missing Header Info" );
		SscMessageUtils.numToSsStr( completion, requestHeader, 48, 2 );
		SscMessageUtils.numToSsStr( reason, requestHeader, 50, 4 );
		SscMessageUtils.copyChars( action, requestHeader, 54, 2 );
	}

	public void setSerialNumber( long serialNumber )
		throws Exception
	{
		if ( requestHeader == null ) throw new Exception( "Missing Header Info" );
		SscMessageUtils.numToSsStr( serialNumber, requestHeader, 90, 12 );
	}
}