package com.rogers.mqclient.cache;

public class MQMSCReqCacheVO extends MQCacheBase
{
	private static MQCacheBase mqCacheVO = null;
	
	public static MQCacheBase getInstance()
	{
		synchronized( MQMSCReqCacheVO.class )
		{
			if ( mqCacheVO == null ) mqCacheVO = new MQCacheBase();
		}
		return mqCacheVO;
	}
	
}
