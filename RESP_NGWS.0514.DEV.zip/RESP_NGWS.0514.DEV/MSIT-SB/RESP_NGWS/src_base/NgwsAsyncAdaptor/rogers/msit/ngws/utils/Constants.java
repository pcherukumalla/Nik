package com.rogers.msit.ngws.utils;

import java.text.*;



public class Constants {
	public static final String LOGGER_NAME = "NgwsAsyncAdaptor";
	public static final java.util.logging.Logger LOGGER = java.util.logging.Logger.getLogger(LOGGER_NAME);
	
	public static final int CONFIG_VALUES_REFRESH_PERIOD = 300000;
	public static final int ASYNC_ADAPTOR_ENGINE_IDLE_INTERVAL = 5000;
	//public static final int ASYNC_ADAPTOR_ENGINE_AUX_THREAD_POOL_SIZE = 50;
		
	public static final String ELMS_TEMP_JMS_CONNECTION_FACTORY = "ELMSConnectionFactory";
	public static final String ELMS_TEMP_JMS_QUEUE = "ELMS_PUSH_QUEUE";
	
	public static final int UPDATE_FOR_PROCESSING = 156;
	public static final int PUSH_FOR_PROCESSING = 157;
	public static final int AFTER_PUSH_FOR_PROCESSING = 158;
			
	public static final String PUSH_FOR_PROCESSING_ERROR = "99998";
	public static final String MESSAGE_FORMAT_ERROR = "99997";
	public static final String ELMS_DOWN_ERROR = "99995";
	public static final String TIMEOUT_ERROR = "99994";
	public static final String ERROR = "99999";
	public static final String OK = "OK";
	
	public static final String NGWS_JNDI_NAME_CONFIG_PARAM = "ngws.config.datasource";
	public static final String NGWS_DB_JNDI_NAME_CONFIG_PARAM = "ngws.db.datasource";
	public static final String THIS_SERVER_NAME_CONFIG_PARAM = "weblogicName";
	public static final String DAO_PROP_FILENAME = "dao.properties";
	public static final String PROP_FILENAME = "ngws.properties";
	
	public static final SimpleDateFormat DEFAULT_DATE_FORMAT = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
	public static final SimpleDateFormat STATS_DATE_FORMAT = new SimpleDateFormat("MMddyyyy");
	
	public static final int MAX_NR_OF_RECORDS = 200; // max of records displayed in the UI...
	public static final int MAX_NR_OF_STATS_RECORDS = 10; // max of records displayed in the UI...
}
