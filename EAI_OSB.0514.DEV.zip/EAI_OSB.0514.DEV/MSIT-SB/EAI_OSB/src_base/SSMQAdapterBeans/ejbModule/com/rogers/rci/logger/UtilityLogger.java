package com.rogers.rci.logger;

public class UtilityLogger extends com.rogers.logger.utility.UtilityLogger
{
	@Override
	public void infoToLog(String message)
	{	
	    try {
	        weblogic.logging.LoggingHelper.getServerLogger().info( message );
	      } catch(Exception ex) {
	    	  System.out.println( "L0:" + message);
	      }
	}
}
