package com.rogers.mqclient.msc;

public interface SessionDataInterface {

	public abstract void setToken(String token);

	public abstract void setSstart(String sstart);

	public abstract void setScount(int scount);

	public abstract void setCompany(String company);

	public abstract void setPasswd(String passwd);

	public abstract void setPstarttime(String pstarttime);

	public abstract void setPwd_updated(String pwd_updated);

	public abstract void setDays_valid(String days_valid);

	public abstract void setUserid(String userid);

	public abstract String getToken();

	public abstract String getSstart();

	public abstract int getScount();

	public abstract String getCompany();

	public abstract String getPasswd();

	public abstract String getPstarttime();

	public abstract String getPwd_updated();

	public abstract String getDays_valid();

	public abstract String getUserid();

	public abstract void setSessionDataDetail(String params, SessionDataInterface obj) throws Exception;
}