Instructions:
==============
1.
Insert into DB of EAI-OSB (application schema):
Insert into EAI_APPL_CONFIG (APPLICATION_ID,CFG_NAME,CFG_VALUE) values ('OLB','OLBUPDATEV21MAP','<map xmlns=''http://eai/configuration/maps''><item fieldin="OLBIndicator" fieldout="EbppInd"  in=''Y'' out=''Y''/><item fieldin="OLBIndicator" fieldout="EbpsInd"  in=''Y'' out=''Y''/><item fieldin="OLBIndicator" fieldout="WaiveInd" in=''Y'' out=''N''/><item fieldin="OLBIndicator" fieldout="EbppInd"  in=''N'' out=''N''/><item fieldin="OLBIndicator" fieldout="EbpsInd"  in=''N'' out=''N''/><item fieldin="OLBIndicator" fieldout="WaiveInd" in=''N'' out=''N''/><item fieldin="OLBIndicator" fieldout="EbppInd"  in=''W'' out=''N''/><item fieldin="OLBIndicator" fieldout="EbpsInd"  in=''W'' out=''N''/><item fieldin="OLBIndicator" fieldout="WaiveInd" in=''W'' out=''Y''/></map>');
Insert into EAI_APPL_CONFIG (APPLICATION_ID,CFG_NAME,CFG_VALUE) values ('OLB','ENROLLMAP','<map xmlns=''http://eai/configuration/maps''><item in=''Y'' out=''ONLINE''/><item in=''N'' out=''PAPER''/><item in=''W'' out=''PAPER''/><item in=''F'' out=''PAPER''/></map>');
Insert into EAI_APPL_CONFIG (APPLICATION_ID,CFG_NAME,CFG_VALUE) values ('OLB','GETCLIENTINFOMAP','<map xmlns=''http://eai/configuration/maps''><item in=''ONLINE'' out=''Y''/><item in=''PAPER'' out=''N''/><item in=''EMAIL'' out=''Y''/><item in=''WIN ONLINE'' out=''WIN ONLINE''/></map>');
Insert into EAI_APPL_CONFIG (APPLICATION_ID,CFG_NAME,CFG_VALUE) values ('OLB','OLBUPDATESSMAP','<map xmlns=''http://eai/configuration/maps''><item fieldin=''EbpsInd|EbppInd|PaperFeeInd'' fieldout=''OLBIndicator'' in=''Y|Y|N'' out=''Y'' /> <item fieldin=''EbpsInd|EbppInd|PaperFeeInd'' fieldout=''OLBIndicator'' in=''N|N|Y'' out=''N'' /><item fieldin=''EbpsInd|EbppInd|PaperFeeInd'' fieldout=''OLBIndicator'' in=''N|N|W'' out=''W'' /></map>');

2.
Under the WLS console of the EAI-OSB domain in QA 713 
Create under WorkManager:
OLBUpdateConsPolicy_MAX=15 and its OLBUpdateConsPolicy to use it.
OLBServicePolicy_MAX=20 and its OLBServicePolicy to use it.
OLBAsyncUpdatePolicy_MAX=15 and its OLBAsyncUpdatePolicy to use it.
Save/Activate the changes.

3.
Copy EAI-OSBForQA713_ALSBCustomizationLOCAL.xml as EAI-OSBForQA713_ALSBCustomizationInQA.xml
Edit EAI-OSBForQA713_ALSBCustomizationInQA.xml and replace all occurences of the mentioned local end points below with the corresponding 
QA 713 end points:
a) Replace all "http://localhost:7100/OLBServices/test/SimulateEAICCustomerAccountMaintenanceProxyService" with end point of EAIC 713 for http://<QA_EAIC_713_IP:PORT>/CustomerAccountMaintenance/CustomerAccountMaintenance.jws
b) Replace all "http://localhost:7100/SimulateS016/SSAWeb/SSAWeb.jws" with the end point of EAI-OSB 713 for http://<QA_EAI-OSB_713_IP:PORT>/SSAWeb/SSAWeb.jws
c) Replace all "http://localhost:7100/OLBServices/test/SimulateRogersComProxyService" with the end point of Rogers.com 713 for auto-registration (enrollment) for http://<QA_RogersCom_713_IP:PORT>/PortalWebService/AutoRegistrationServices
d) Replace all "http://192.168.1.104:7001/AsyncMsgProcess/AsyncMessageProcessorWSFacade" with the end point of ROP WLI 713 for http://<QA_ROP_WLI_713_IP:PORT>/AsyncMsgProcess/AsyncMessageProcessorWSFacade
e) Replace all "http://localhost:7100/OLBServices/test/SimulateRWSSetEBPPInfoProxyService" with the end point for RWS-ESP 713 for http://<QA_RWS_ESP_713_IP:PORT>/WSLServices/AccountMaintenance.jws
Save the file changes.

4.
Install/import under OSB console the EAI-OSBForQA713_Initial.jar
Save/Activate changes.

5.
Execute the update customization file for QA:EAI-OSBForQA713_ALSBCustomizationInQA.xml
Save/Activate changes.