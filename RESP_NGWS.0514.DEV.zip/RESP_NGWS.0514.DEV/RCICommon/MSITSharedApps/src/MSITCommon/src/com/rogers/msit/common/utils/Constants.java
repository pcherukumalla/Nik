package com.rogers.msit.common.utils;



public class Constants {
	public static final String DATA_SOURCE_CONFIG_NAME = "eai.config.datasource"; //"msit.config.datasource"; // TDV use ONLY
	public static final String DATA_SOURCE_APPL_CONFIG_NAME = "appl.config.datasource"; // application(s) config ONLY (EAI_APPL_CONFIG)
	public static final String DEFAULT_DATA_SOURCE_JNDI_NAME = "cgDataSource";
	
	public static final long CONFIG_REFRESH_PERIOD = 600000;
	public static final long LOGGER_REFRESH_PERIOD = 600000;

	public static final String GET_IP_ADDR_ERROR = "Unable to obtain the local IP address\n";
	public static final String GET_DATA_SOURCE_ERROR = "Unable to obtain a config/logging datasource.\n";
	public static final String GET_DATA_SOURCE_CONFIG_WARNING = "Unable to find datasource config name, using the default one: " + DEFAULT_DATA_SOURCE_JNDI_NAME;
	
	
	
	public static final java.util.logging.Logger LOGGER = java.util.logging.Logger.getLogger("");
	
	
	
	//public static final String GET_CONFIG_ENTRIES_SQL = "SELECT application_id, config_name, config_value FROM eai_appl_config";
	public static final String GET_CONFIG_ENTRIES_SQL = "SELECT application_id, cfg_name, cfg_value FROM eai_appl_config";
	public static final String GET_LOG_CONFIG_ENTRIES_SQL = "SELECT process_type, log_enabled FROM eai_appl_log_config";
	public static final String INSERT_LOG_ENTRY_SQL = "INSERT INTO eai_appl_log (event_time, process_instance, process_type, data) VALUES (?, ?, ?, ?)";
}
