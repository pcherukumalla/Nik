package com.rogers.rci.wsl;

import javax.ejb.SessionBean;

import weblogic.ejb.GenericSessionBean;
import weblogic.ejbgen.Session;
import weblogic.ejbgen.JndiName;
import weblogic.ejbgen.FileGeneration;
import weblogic.ejbgen.Constants;
import weblogic.ejbgen.RemoteMethod;

import com.rogers.rci.wsl.WSLLogger;
import com.rogers.wireless.schemas.addAndRemoveSubscriberServices.request.AddAndRemoveSubscriberServicesRequestDocument;
import com.rogers.wireless.schemas.addAndRemoveSubscriberServices.response.AddAndRemoveSubscriberServicesResponseDocument;
import com.rogers.wireless.schemas.moveSubscriber.MoveSubscriberRequestDocument;
import com.rogers.wireless.schemas.moveSubscriber.MoveSubscriberResponseDocument;
import com.rogers.wireless.schemas.provisionReservedSubscriber.request.ProvisionReservedSubscriberRequestDocument;
import com.rogers.wireless.schemas.provisionReservedSubscriber.response.ProvisionReservedSubscriberResponseDocument;
import com.rogers.wireless.schemas.retrieveAvailablePricePlans.request.RetrieveAvailablePricePlansRequestDocument;
import com.rogers.wireless.schemas.retrieveAvailablePricePlans.response.RetrieveAvailablePricePlansResponseDocument;
import com.rogers.wireless.schemas.retrieveAvailableServices.request.RetrieveAvailableServicesRequestDocument;
import com.rogers.wireless.schemas.retrieveAvailableServices.response.RetrieveAvailableServicesResponseDocument;
import com.rogers.wireless.schemas.retrieveEmergencyAddress.request.RetrieveEmergencyAddressRequestDocument;
import com.rogers.wireless.schemas.retrieveEmergencyAddress.response.RetrieveEmergencyAddressResponseDocument;
import com.rogers.wireless.schemas.retrieveEquipmentInfo.request.RetrieveEquipmentInfoRequestDocument;
import com.rogers.wireless.schemas.retrieveEquipmentInfo.response.RetrieveEquipmentInfoResponseDocument;
import com.rogers.wireless.schemas.retrieveEquipmentUpgradeStatus.request.RetrieveEquipmentUpgradeStatusRequestDocument;
import com.rogers.wireless.schemas.retrieveEquipmentUpgradeStatus.response.RetrieveEquipmentUpgradeStatusResponseDocument;
import com.rogers.wireless.schemas.retrievePricePlanServices.request.RetrievePricePlanServicesRequestDocument;
import com.rogers.wireless.schemas.retrievePricePlanServices.response.RetrievePricePlanServicesResponseDocument;
import com.rogers.wireless.schemas.retrieveRustyEnrollment.request.RetrieveRustyEnrollmentRequestDocument;
import com.rogers.wireless.schemas.retrieveRustyEnrollment.response.RetrieveRustyEnrollmentResponseDocument;
import com.rogers.wireless.schemas.retrieveSubscriberEquipment.request.RetrieveSubscriberEquipmentRequestDocument;
import com.rogers.wireless.schemas.retrieveSubscriberEquipment.response.RetrieveSubscriberEquipmentResponseDocument;
import com.rogers.wireless.schemas.retrieveSubscriberInfo.request.RetrieveSubscriberInfoRequestDocument;
import com.rogers.wireless.schemas.retrieveSubscriberInfo.response.RetrieveSubscriberInfoResponseDocument;
import com.rogers.wireless.schemas.retrieveSubscriberList.request.RetrieveSubscriberListRequestDocument;
import com.rogers.wireless.schemas.retrieveSubscriberList.response.RetrieveSubscriberListResponseDocument;
import com.rogers.wireless.schemas.retrieveSubscriberServices.request.RetrieveSubscriberServicesRequestDocument;
import com.rogers.wireless.schemas.retrieveSubscriberServices.response.RetrieveSubscriberServicesResponseDocument;
import com.rogers.wireless.schemas.setRustyEnrollment.response.SetRustyEnrollmentResponseDocument;
import com.rogers.wireless.schemas.setRustyEnrollment.resquest.SetRustyEnrollmentRequestDocument;
import com.rogers.wireless.schemas.setVoicemailPassword.request.SetVoicemailPasswordRequestDocument;
import com.rogers.wireless.schemas.setVoicemailPassword.response.SetVoicemailPasswordResponseDocument;
import com.rogers.wireless.schemas.submitEmergencyAddress.request.SubmitEmergencyAddressRequestDocument;
import com.rogers.wireless.schemas.submitEmergencyAddress.response.SubmitEmergencyAddressResponseDocument;
import com.rogers.wireless.schemas.transferResponsability.request.TransferResponsabilityRequestDocument;
import com.rogers.wireless.schemas.transferResponsability.response.TransferResponsabilityResponseDocument;
import com.rogers.wireless.schemas.updateSubscriberInfo.request.UpdateSubscriberInfoRequestDocument;
import com.rogers.wireless.schemas.updateSubscriberInfo.response.UpdateSubscriberInfoResponseDocument;
import com.rogers.wireless.schemas.updateSubscriberServices.request.UpdateSubscriberServicesRequestDocument;
import com.rogers.wireless.schemas.updateSubscriberServices.response.UpdateSubscriberServicesResponseDocument;
import com.rogers.wireless.schemas.upgradeEquipment.request.UpgradeEquipmentRequestDocument;
import com.rogers.wireless.schemas.upgradeEquipment.response.UpgradeEquipmentResponseDocument;
import com.rogers.wireless.schemas.validateEquipmentNumber.request.ValidateEquipmentNumberRequestDocument;
import com.rogers.wireless.schemas.validateEquipmentNumber.response.ValidateEquipmentNumberResponseDocument;

/**
 * GenericSessionBean subclass automatically generated by Workshop.
 *
 * Please complete the ejbCreate method as needed to properly initialize new instances of your bean and add
 * all required business methods. Also, review the Session, JndiName and FileGeneration annotations 
 * to ensure the settings match the bean's intended use.
 */
@Session(ejbName = "SubscriberMaintenanceEJB", initialBeansInFreePool="4", maxBeansInFreePool="10", transTimeoutSeconds="30", isClusterable=Constants.Bool.FALSE, methodsAreIdempotent=Constants.Bool.FALSE)
@JndiName(remote = "ejb/wsl/SubscriberMaintenanceEJBRemoteHome")
@FileGeneration(remoteClass = Constants.Bool.TRUE, remoteHome = Constants.Bool.TRUE, localClass = Constants.Bool.FALSE, localHome = Constants.Bool.FALSE)
public class SubscriberMaintenanceEJB extends GenericSessionBean implements
		SessionBean {
	private static final long serialVersionUID = 1L;

	/* (non-Javadoc)
	 * @see weblogic.ejb.GenericSessionBean#ejbCreate()
	 */
	public void ejbCreate() {
		// IMPORTANT: Add your code here
	}

	// IMPORTANT: Add business methods
    /**
     **TODO: replace ALL occurences that use the old control calls
     */
    
    //private com.rogers.rci.icm.SubscriberMaintenanceICMHelper subscriberMaintanceICMHelper;

    @RemoteMethod
    public org.apache.xmlbeans.XmlObject addAndRemoveSubscriberServices( org.apache.xmlbeans.XmlObject xmldata )
    throws Exception
    {
		WSLLogger.getLogger().info("WSL SubscriberMainatenanceImpl.addAndRemoveSubscriberServices(): request");
        long startTime = System.currentTimeMillis();

		AddAndRemoveSubscriberServicesResponseDocument response = com.rogers.rci.wsl.services.subscribermaintenance.AddAndRemoveSubscriberServices.addAndRemoveSubscriberServices( AddAndRemoveSubscriberServicesRequestDocument.Factory.parse( xmldata.xmlText()));
		WSLLogger.getLogger().info("WSL SubscriberMainatenanceImpl.addAndRemoveSubscriberServices(): request duration: " + (System.currentTimeMillis() - startTime));
        
		//TODO: replace call using control
		//DONE: in OSB
        //subscriberMaintanceICMHelper.createAddandRemoveSubscriberServicesInteraction(xmldata, response);

        return response;
    }

    @RemoteMethod
    public org.apache.xmlbeans.XmlObject retrieveSubscriberList( org.apache.xmlbeans.XmlObject xmldata )
    throws Exception
    {
		WSLLogger.getLogger().info("WSL SubscriberMainatenanceImpl.retrieveSubscriberList(): request");
        long startTime = System.currentTimeMillis();

		RetrieveSubscriberListResponseDocument response = com.rogers.rci.wsl.services.subscribermaintenance.SubscriberList.retrieveSubscriberList( RetrieveSubscriberListRequestDocument.Factory.parse( xmldata.xmlText()) );
		WSLLogger.getLogger().info("WSL SubscriberMainatenanceImpl.retrieveSubscriberList(): request duration: " + (System.currentTimeMillis() - startTime));

        return response;
    }

    @RemoteMethod
    public org.apache.xmlbeans.XmlObject setVoicemailPassword( org.apache.xmlbeans.XmlObject xmldata )
    throws Exception
    {
		WSLLogger.getLogger().info("WSL SubscriberMainatenanceImpl.setVoicemailPassword(): request");
        long startTime = System.currentTimeMillis();

		SetVoicemailPasswordResponseDocument response = com.rogers.rci.wsl.services.subscribermaintenance.SetVoicemailPassword.setVoicemailPassword( SetVoicemailPasswordRequestDocument.Factory.parse( xmldata.xmlText()) );
		WSLLogger.getLogger().info("WSL SubscriberMainatenanceImpl.setVoicemailPassword(): request duration: " + (System.currentTimeMillis() - startTime));
        
		//TODO: replace call using control
        //subscriberMaintanceICMHelper.createSetVoiceMailPasswordInteraction(xmldata, response);

        return response;
    }

    @RemoteMethod
    public org.apache.xmlbeans.XmlObject updateSubscriberServices( org.apache.xmlbeans.XmlObject xmldata )
    throws Exception
    {
		WSLLogger.getLogger().info("WSL SubscriberMainatenanceImpl.updateSubscriberServices(): request");
        long startTime = System.currentTimeMillis();

		UpdateSubscriberServicesResponseDocument response = com.rogers.rci.wsl.services.subscribermaintenance.UpdateSubscriberServices.updateSubscriberServices( UpdateSubscriberServicesRequestDocument.Factory.parse( xmldata.xmlText()) );
		WSLLogger.getLogger().info("WSL SubscriberMainatenanceImpl.updateSubscriberServices(): request duration: " + (System.currentTimeMillis() - startTime));
        
		//TODO: replace call using control
        //subscriberMaintanceICMHelper.createUpdateSubscriberServicesInteraction(xmldata, response);

        return response;
    }

    @RemoteMethod
    public org.apache.xmlbeans.XmlObject provisionReservedSubscriber( org.apache.xmlbeans.XmlObject xmldata )
    throws Exception
    {
		WSLLogger.getLogger().info("WSL SubscriberMainatenanceImpl.provisionReservedSubscriber(): request");
        long startTime = System.currentTimeMillis();

		ProvisionReservedSubscriberResponseDocument response = com.rogers.rci.wsl.services.subscribermaintenance.ProvisionReservedSubscriber.provisionReservedSubscriber( ProvisionReservedSubscriberRequestDocument.Factory.parse( xmldata.xmlText()) );
		WSLLogger.getLogger().info("WSL SubscriberMainatenanceImpl.provisionReservedSubscriber(): request duration: " + (System.currentTimeMillis() - startTime));
        
        // No need to Create Interaction because this is part of the RHP Activation
        //subscriberMaintanceICMHelper.createProvisionReservedSuscriberInteraction(xmldata, response);

        return response;
    }

    @RemoteMethod
    public org.apache.xmlbeans.XmlObject updateSubscriberInfo( org.apache.xmlbeans.XmlObject xmldata )
    throws Exception
    {
		WSLLogger.getLogger().info("WSL SubscriberMainatenanceImpl.updateSubscriberInfo(): request");
        long startTime = System.currentTimeMillis();

		UpdateSubscriberInfoResponseDocument response = com.rogers.rci.wsl.services.subscribermaintenance.UpdateSubscriberInfo.updateSubscriberInfo( UpdateSubscriberInfoRequestDocument.Factory.parse( xmldata.xmlText()) );
		WSLLogger.getLogger().info("WSL SubscriberMainatenanceImpl.updateSubscriberInfo(): request duration: " + (System.currentTimeMillis() - startTime));
        
		//TODO: replace call using control
        //subscriberMaintanceICMHelper.createUpdateSubscriberInfoInteraction(xmldata, response);

        return response;
    }

    @RemoteMethod
    public org.apache.xmlbeans.XmlObject retrieveSubscriberInfo( org.apache.xmlbeans.XmlObject xmldata )
    throws Exception
    {
		WSLLogger.getLogger().info("WSL SubscriberMainatenanceImpl.retrieveSubscriberInfo(): request");
        long startTime = System.currentTimeMillis();

		RetrieveSubscriberInfoResponseDocument response = com.rogers.rci.wsl.services.subscribermaintenance.RetrieveSubscriberInfo.retrieveSubscriberInfo( RetrieveSubscriberInfoRequestDocument.Factory.parse( xmldata.xmlText()) );
		WSLLogger.getLogger().info("WSL SubscriberMainatenanceImpl.retrieveSubscriberInfo(): request duration: " + (System.currentTimeMillis() - startTime));

        return response;
    }

    @RemoteMethod
    public org.apache.xmlbeans.XmlObject retrieveSubscriberServices( org.apache.xmlbeans.XmlObject xmldata )
    throws Exception
    {
		WSLLogger.getLogger().info("WSL SubscriberMainatenanceImpl.retrieveSubscriberServices(): request");
        long startTime = System.currentTimeMillis();

		RetrieveSubscriberServicesResponseDocument response = com.rogers.rci.wsl.services.subscribermaintenance.RetrieveSubscriberServices.retrieveSubscriberServices( RetrieveSubscriberServicesRequestDocument.Factory.parse( xmldata.xmlText()) );
		WSLLogger.getLogger().info("WSL SubscriberMainatenanceImpl.retrieveSubscriberServices(): request duration: " + (System.currentTimeMillis() - startTime));

        return response;
    }


    @RemoteMethod
    public org.apache.xmlbeans.XmlObject retrieveAvailableServices( org.apache.xmlbeans.XmlObject xmldata )
    throws Exception
    {
		WSLLogger.getLogger().info("WSL SubscriberMainatenanceImpl.retrieveAvailableServices(): request");
        long startTime = System.currentTimeMillis();

		RetrieveAvailableServicesResponseDocument response = com.rogers.rci.wsl.services.subscribermaintenance.RetrieveAvailableServices.retrieveAvailableServices( RetrieveAvailableServicesRequestDocument.Factory.parse( xmldata.xmlText()) );
		WSLLogger.getLogger().info("WSL SubscriberMainatenanceImpl.retrieveAvailableServices(): request duration: " + (System.currentTimeMillis() - startTime));

        return response;
    }

    @RemoteMethod
    public org.apache.xmlbeans.XmlObject retrieveAvailablePricePlans( org.apache.xmlbeans.XmlObject xmldata )
    throws Exception
    {
		WSLLogger.getLogger().info("WSL SubscriberMainatenanceImpl.retrieveAvailablePricePlans(): request");
        long startTime = System.currentTimeMillis();

		RetrieveAvailablePricePlansResponseDocument response = com.rogers.rci.wsl.services.subscribermaintenance.RetrieveAvailablePricePlans.retrieveAvailablePricePlans( RetrieveAvailablePricePlansRequestDocument.Factory.parse( xmldata.xmlText()) );
		WSLLogger.getLogger().info("WSL SubscriberMainatenanceImpl.retrieveAvailablePricePlans(): request duration: " + (System.currentTimeMillis() - startTime));

        return response;
    }

    @RemoteMethod
    public org.apache.xmlbeans.XmlObject retrieveSubscriberEquipment( org.apache.xmlbeans.XmlObject xmldata )
    throws Exception
    {
		WSLLogger.getLogger().info("WSL SubscriberMainatenanceImpl.retrieveSubscriberEquipment(): request");
        long startTime = System.currentTimeMillis();

		RetrieveSubscriberEquipmentResponseDocument response = com.rogers.rci.wsl.services.subscribermaintenance.RetrieveSubscriberEquipment.retrieveSubscriberEquipment( RetrieveSubscriberEquipmentRequestDocument.Factory.parse( xmldata.xmlText()) );
		WSLLogger.getLogger().info("WSL SubscriberMainatenanceImpl.retrieveSubscriberEquipment(): request duration: " + (System.currentTimeMillis() - startTime));

        return response;
    }

    @RemoteMethod
    public org.apache.xmlbeans.XmlObject upgradeEquipment( org.apache.xmlbeans.XmlObject xmldata )
    throws Exception
    {
		WSLLogger.getLogger().info("WSL SubscriberMainatenanceImpl.upgradeEquipment(): request");
        long startTime = System.currentTimeMillis();

		UpgradeEquipmentResponseDocument response = com.rogers.rci.wsl.services.subscribermaintenance.UpgradeEquipment.upgradeEquipment( UpgradeEquipmentRequestDocument.Factory.parse( xmldata.xmlText()) );
		WSLLogger.getLogger().info("WSL SubscriberMainatenanceImpl.upgradeEquipment(): request duration: " + (System.currentTimeMillis() - startTime));
        
		//TODO: replace call using control
        //subscriberMaintanceICMHelper.createUpgradeEquipmentServicesInteraction(xmldata, response);

        return response;
    }

    @RemoteMethod
    public org.apache.xmlbeans.XmlObject retrieveEquipmentUpgradeStatus( org.apache.xmlbeans.XmlObject xmldata )
    throws Exception
    {
		WSLLogger.getLogger().info("WSL SubscriberMainatenanceImpl.retrieveEquipmentUpgradeStatus(): request");
        long startTime = System.currentTimeMillis();

		RetrieveEquipmentUpgradeStatusResponseDocument response = com.rogers.rci.wsl.services.subscribermaintenance.RetrieveEquipmentUpgradeStatus.retrieveEquipmentUpgradeStatus( RetrieveEquipmentUpgradeStatusRequestDocument.Factory.parse( xmldata.xmlText()) );
		WSLLogger.getLogger().info("WSL SubscriberMainatenanceImpl.retrieveEquipmentUpgradeStatus(): request duration: " + (System.currentTimeMillis() - startTime));

        return response;
    }

	@RemoteMethod
	public org.apache.xmlbeans.XmlObject moveSubscriber( org.apache.xmlbeans.XmlObject xmldata )
	throws Exception
	{
		WSLLogger.getLogger().info("WSL SubscriberMainatenanceImpl.moveSubscriber(): request");
		long startTime = System.currentTimeMillis();

		MoveSubscriberResponseDocument response = com.rogers.rci.wsl.services.subscribermaintenance.MoveSubscriber.moveSubscriber( MoveSubscriberRequestDocument.Factory.parse( xmldata.xmlText()) );
		WSLLogger.getLogger().info("WSL SubscriberMainatenanceImpl.moveSubscriber(): request duration: " + (System.currentTimeMillis() - startTime));

		return response;
	}

    @RemoteMethod
    public org.apache.xmlbeans.XmlObject retrieveRustyEnrollment(org.apache.xmlbeans.XmlObject xmldata )
    throws Exception
    {
		WSLLogger.getLogger().info("WSL SubscriberMainatenanceImpl.retrieveRustyEnrollment(): request");
        long startTime = System.currentTimeMillis();

		RetrieveRustyEnrollmentResponseDocument response = com.rogers.rci.wsl.services.subscribermaintenance.RetrieveRustyEnrollment.retrieveRustyEnrollment( RetrieveRustyEnrollmentRequestDocument.Factory.parse( xmldata.xmlText()) );
		WSLLogger.getLogger().info("WSL SubscriberMainatenanceImpl.retrieveRustyEnrollment(): request duration: " + (System.currentTimeMillis() - startTime));

        return response;
    }

    @RemoteMethod
    public org.apache.xmlbeans.XmlObject setRustyEnrollment( org.apache.xmlbeans.XmlObject xmldata )
    throws Exception
    {
		WSLLogger.getLogger().info("WSL SubscriberMainatenanceImpl.setRustyEnrollment(): request");
        long startTime = System.currentTimeMillis();

		SetRustyEnrollmentResponseDocument response = com.rogers.rci.wsl.services.subscribermaintenance.SetRustyEnrollment.setRustyEnrollment( SetRustyEnrollmentRequestDocument.Factory.parse( xmldata.xmlText()) );
		WSLLogger.getLogger().info("WSL SubscriberMainatenanceImpl.setRustyEnrollment(): request duration: " + (System.currentTimeMillis() - startTime));
        
        return response;
    }


    @RemoteMethod
    public org.apache.xmlbeans.XmlObject retrievePricePlanServices(org.apache.xmlbeans.XmlObject xmldata )
    throws Exception
    {
		WSLLogger.getLogger().info("WSL SubscriberMainatenanceImpl.retrievePricePlanServices(): request");
        long startTime = System.currentTimeMillis();

		RetrievePricePlanServicesResponseDocument response = com.rogers.rci.wsl.services.subscribermaintenance.RetrievePricePlanServices.retrievePricePlanServices(RetrievePricePlanServicesRequestDocument.Factory.parse( xmldata.xmlText()) );
		WSLLogger.getLogger().info("WSL SubscriberMainatenanceImpl.retrievePricePlanServices(): request duration: " + (System.currentTimeMillis() - startTime));

        return response;
    }

    @RemoteMethod
    public org.apache.xmlbeans.XmlObject submitEmergencyAddress(org.apache.xmlbeans.XmlObject xmldata )
    throws Exception
    {

		WSLLogger.getLogger().info("WSL SubscriberMainatenanceImpl.submitEmergencyAddress(): request");
        long startTime = System.currentTimeMillis();

		SubmitEmergencyAddressResponseDocument response = com.rogers.rci.wsl.services.subscribermaintenance.SubmitEmergencyAddress.submitEmergencyAddress( SubmitEmergencyAddressRequestDocument.Factory.parse( xmldata.xmlText()) );
		WSLLogger.getLogger().info("WSL SubscriberMainatenanceImpl.submitEmergencyAddress(): request duration: " + (System.currentTimeMillis() - startTime));

        return response;
        
    }


    @RemoteMethod
    public org.apache.xmlbeans.XmlObject retrieveEmergencyAddress(org.apache.xmlbeans.XmlObject xmldata)
    throws Exception
    {

		WSLLogger.getLogger().info("WSL SubscriberMainatenanceImpl.retrieveEmergencyAddress(): request");
        long startTime = System.currentTimeMillis();

		RetrieveEmergencyAddressResponseDocument response = com.rogers.rci.wsl.services.subscribermaintenance.RetrieveEmergencyAddress.retrieveEmergencyAddress( RetrieveEmergencyAddressRequestDocument.Factory.parse( xmldata.xmlText()) );
		WSLLogger.getLogger().info("WSL SubscriberMainatenanceImpl.retrieveEmergencyAddress(): request duration: " + (System.currentTimeMillis() - startTime));

        return response;        
        
    }

    @RemoteMethod
    public org.apache.xmlbeans.XmlObject validateEquipmentNumber(org.apache.xmlbeans.XmlObject xmldata )
    throws Exception
    {

		WSLLogger.getLogger().info("WSL SubscriberMainatenanceImpl.validateEquipmentNumber(): request");
        long startTime = System.currentTimeMillis();

		ValidateEquipmentNumberResponseDocument response = com.rogers.rci.wsl.services.subscribermaintenance.ValidateEquipmentNumber.validateEquipmentNumber( ValidateEquipmentNumberRequestDocument.Factory.parse( xmldata.xmlText()) );
		WSLLogger.getLogger().info("WSL SubscriberMainatenanceImpl.validateEquipmentNumber(): request duration: " + (System.currentTimeMillis() - startTime));

        return response;
        
    }

    @RemoteMethod
    public org.apache.xmlbeans.XmlObject retrieveEquipmentInfo(org.apache.xmlbeans.XmlObject xmldata )
    throws Exception
    {

		WSLLogger.getLogger().info("WSL SubscriberMainatenanceImpl.retrieveEquipmentInfo(): request");
        long startTime = System.currentTimeMillis();

		RetrieveEquipmentInfoResponseDocument response = com.rogers.rci.wsl.services.subscribermaintenance.RetrieveEquipmentInfo.retrieveEquipmentInfo( RetrieveEquipmentInfoRequestDocument.Factory.parse( xmldata.xmlText()));
		WSLLogger.getLogger().info("WSL SubscriberMainatenanceImpl.retrieveEquipmentInfo(): request duration: " + (System.currentTimeMillis() - startTime));

        return response;
        
    }


    @RemoteMethod
    public org.apache.xmlbeans.XmlObject moveRhpLight(org.apache.xmlbeans.XmlObject xmldata)
    throws Exception
    {
		WSLLogger.getLogger().info("WSL SubscriberMainatenanceImpl.moveRhpLight(): request");
        long startTime = System.currentTimeMillis();

		TransferResponsabilityResponseDocument response = com.rogers.rci.wsl.services.subscribermaintenance.MoveRhpLight.moveRhpLight( TransferResponsabilityRequestDocument.Factory.parse( xmldata.xmlText()) );
		WSLLogger.getLogger().info("WSL SubscriberMainatenanceImpl.moveRhpLight(): request duration: " + (System.currentTimeMillis() - startTime));

        return response;
    }	
}